# CCD Platform — Pipeline Architecture v1.0
**Author:** M. J. Martin  
**Date:** 2026-05-04  
**Status:** Authoritative Design Specification

---

## Overview

The CCD (Cyber and Compliance Data) Platform manages enterprise IPAM, host inventory, network device inventory, and infrastructure inventory for CVS Health. This document defines the authoritative pipeline architecture governing how source data flows into the platform master datasets.

The architecture is built on three principles:

1. **Complete reversibility** — every master dataset is versioned; every change is tracked; any state can be restored
2. **No overwrite** — new data never overwrites existing data; enhancement only fills gaps
3. **Strict update order** — Location → IPAM → Network → App → Infrastructure → Platform; this order is non-negotiable

---

## Master Datasets

| Dataset | Stem | Description |
|---|---|---|
| `location_master` | `location_master` | Canonical location name registry — ground truth for all location derivation |
| `all_IP_networks` | `all_IP_networks` | Enterprise IP prefix inventory — SINGLE SOURCE OF TRUTH |
| `ent_network_device_master` | `ent_network_device_master` | Network device inventory |
| `ent_host_master` | `ent_host_master` | Application server host inventory |
| `delivery_infrastructure` | `delivery_infrastructure` | Physical compute infrastructure (ESXi, Mainframe, HMC, DataPower, iSeries, zOS) |
| `delivery_platform` | `delivery_platform` | Container/orchestration platform (Kubernetes, OpenShift, Docker) |
| `retail_networks` | `retail_networks` | Retail store /26 subnet allocations |
| `mgmt_ip_index` | `mgmt_ip_index` | OOB/management-plane subnets |
| `app_subnet_index` | `app_subnet_index` | Application-to-subnet index |
| `csna_site_registry` | `csna_site_registry` | Stealthwatch CSNA hostgroup registry |

All master datasets are managed by `ipam-db.py` and registered in `ipam-db.json`.

---

## Source Systems

| Source | Script | Output |
|---|---|---|
| Qualys VAE Risk Register | `build_qualys_pipeline.py` | Normalized host/subnet data in `Qualys_processed_results/` |
| SNOW CMDB Master Inventory | `build_cmdb_pipeline.py` | Normalized host/app data in `CMDB_processed_results/` |
| NMS IP Report | Built into `preprocess_p2.py` | Location and IPAM candidates |
| ADL / SNOW Server Report | Built into `preprocess_p2.py` | App candidates |
| HR Location Data | Built into `preprocess_p2.py` | Location validation |

Source-specific scripts handle format complexity (multi-file streaming, multi-row headers, multi-app-per-IP merging) and produce normalized outputs that the preprocess pipeline consumes.

---

## Pipeline Architecture

### Stage 0 — Source Parsing

Source-specific scripts run first, independently of each other:

```
build_qualys_pipeline.py
    Input:  ./IP_Datasets_Raw/Risk-Reg_Files/*.csv  (VAE Risk Register)
    Output: qualys_processed_results/
              qualys_new_hosts_vDATE.csv
              qualys_ipam_candidates_vDATE.csv
              qualys_ndm_gaps_vDATE.csv
              qualys_security_flags_vDATE.csv
              qualys_subnet_summary_vDATE.csv
              ehm_enrichment_patch_vDATE.csv

build_cmdb_pipeline.py  (future — currently build_cmdb_enrichment.py)
    Input:  ./IP_Datasets_Raw/CMDB-Master/CMDB_Master_Inventory*.csv
    Output: cmdb_processed_results/
              cmdb_new_hosts_vDATE.csv
              cmdb_enhancement_patch_vDATE.csv
              cmdb_ipam_candidates_vDATE.csv
```

### Stage 1 — preprocess_p1.py (Known Data)

Compares all source outputs against all master datasets simultaneously. Never touches location master. Produces three classified files per source.

```
preprocess_p1.py
    Input:  All source processed results
            All master datasets (read-only)

    For each source record, classifies as:
      MATCHED     — exact match in master, no action needed
      ENHANCEMENT — partial match, master can be improved (gap fill only)
      NEW         — never seen before, needs normalization

    Output per source:
      matched_vDATE.csv      — excluded from further processing
      enhancement_vDATE.csv  — feeds update scripts
      new_vDATE.csv          — feeds preprocess_p2

    Rules:
      - Never touches location_master
      - Enhancement never overwrites existing values — gap fill only
      - MATCHED records are excluded — no processing cost
```

### Stage 2 — Update Scripts (Enhancement Pass)

Apply enhancements to existing masters in strict order. Each script reads its enhancement file, fills gaps in the current registered master, and produces a new versioned output.

```
update_ipam.py          → all_IP_networks (new version)
update_network.py       → ent_network_device_master (new version)
update_app.py           → ent_host_master (new version)
update_infrastructure.py → delivery_infrastructure (new version)
update_platform.py      → delivery_platform (new version)
```

Each script:
- Loads current registered master from `ipam-db/`
- Applies enhancement patch (gap fill only — no overwrite)
- Writes new versioned CSV
- Registers via `ipam-db.py --import`

### Stage 3 — preprocess_p2.py (New Data)

Processes only the NEW records from Stage 1. Performs full normalization:

```
preprocess_p2.py
    Input:  new_vDATE.csv files from preprocess_p1
            All master datasets (read-only)
            HR location data
            Hostname translation rules

    Normalization steps per new record:
      1. IP → CIDR-LPM → CANONICAL_LOCATION, ROUTING_DOMAIN, HERITAGE
      2. Hostname translation → location hint (if LPM fails)
      3. OS/Class → device classification (server/network/infra/platform)
      4. Business Unit → heritage derivation
      5. Confidence scoring

    Output candidates:
      location_candidates_vDATE.csv   → update_location.py
      ipam_candidates_vDATE.csv       → update_ipam.py
      network_candidates_vDATE.csv    → update_network.py
      app_candidates_vDATE.csv        → update_app.py
      infra_candidates_vDATE.csv      → update_infrastructure.py
      platform_candidates_vDATE.csv   → update_platform.py

    Rules:
      - New data never goes directly to masters
      - All candidates require review/approval via update scripts
      - New data cannot overwrite existing data — ever
```

### Stage 4 — Update Scripts (New Data Pass)

Apply approved candidates to masters in strict order:

```
update_location.py       → location_master (new version)
update_ipam.py           → all_IP_networks (new version)
update_network.py        → ent_network_device_master (new version)
update_app.py            → ent_host_master (new version)
update_infrastructure.py → delivery_infrastructure (new version)
update_platform.py       → delivery_platform (new version)
```

Each script:
- Interactive review with accept/reject/skip per candidate
- Or `--auto-approve` for high-confidence automated runs
- Writes new versioned master
- Registers via `ipam-db.py --import`
- Runs `ipam-db.py --cross-check` after registration

---

## Update Order — Non-Negotiable

```
1. location_master          ← ground truth, must be correct before anything else
2. all_IP_networks          ← location derivation depends on LM
3. ent_network_device_master ← location derived from IPAM
4. ent_host_master          ← location derived from IPAM
5. delivery_infrastructure  ← location derived from IPAM
6. delivery_platform        ← location derived from IPAM
7. app_subnet_index         ← rebuilt from EHM
8. csna_site_registry       ← rebuilt from all_IP_networks + LM
```

**Why this order:** Each dataset derives location from the one above it. Running out of order means hosts get located against a stale IPAM, producing wrong canonical locations that propagate downstream.

---

## Iterative Cycles

The pipeline is designed to run in cycles. What is NEW in cycle N becomes MATCHED or ENHANCEMENT in cycle N+1 as the masters absorb the new data:

```
Cycle 1: preprocess_p1 → some hosts UNMAPPED (subnet not in IPAM)
         preprocess_p2 → generates ipam_candidates for those subnets
         update_ipam   → new subnets registered

Cycle 2: preprocess_p1 → previously UNMAPPED now resolve to ENHANCEMENT or MATCHED
         Fewer NEW records — pipeline converges toward complete coverage
```

---

## Reversibility

Every operation in the pipeline is reversible:

| Operation | Reversal |
|---|---|
| Master update | `ipam-db.py --restore <timestamp>` |
| Enhancement patch | Previous version still in `ipam-db-archive/` |
| Candidate generation | Re-run `preprocess_p1` / `preprocess_p2` |
| Registry corruption | `ipam-db.py --sync` reconciles from file headers |

---

## Data Governance Rules

**Rule 1:** Never rebuild from scratch — always merge from registered master  
**Rule 2:** CANONICAL_LOCATION must resolve to LM CANONICAL_NAME  
**Rule 3:** Location derived from network (CIDR-LPM), never from application owner  
**Rule 4:** Cloud location = zone-based (hub+region), not BU-based  
**Rule 5:** Physical DC canonical names are fixed  
**Rule 6:** Update sequence is non-negotiable (LM→IPAM→Net→App→Infra→Platform)  
**Rule 7:** 100.64.x.x and special ranges never valid host IPs  
**Rule 8:** Source system names never used directly as canonical names  
**Rule 9:** Work From Home / Remote / Offshore locations are HR work locations of the app OWNER — NEVER server locations  
**Rule 10:** Every pipeline script that processes host data produces IPAM candidates for unmatched IPs  
**Rule 11:** New data never overwrites existing data — enhancement fills gaps only  
**Rule 12:** preprocess_p1 never touches location_master  

---

## Scripts To Build

| Script | Status | Priority |
|---|---|---|
| `preprocess_p1.py` | Not built | HIGH — core of new architecture |
| `preprocess_p2.py` | Partial (current `preprocess.py`) | HIGH — refactor |
| `build_cmdb_pipeline.py` | Partial (`build_cmdb_enrichment.py`) | HIGH — refactor |
| `update_infrastructure.py` | Not built | MEDIUM |
| `update_platform.py` | Not built | MEDIUM |

---

## Current Script Inventory

| Script | Version | Function |
|---|---|---|
| `ipam-db.py` | v3.10 | Registry manager |
| `build_qualys_pipeline.py` | v1.6 | Qualys source parser |
| `preprocess.py` | v1.5 | To be split into p1/p2 |
| `update_location.py` | v1.1 | LM delta update |
| `update_ipam.py` | v1.1 | IPAM delta update |
| `update_network.py` | v1.1 | NDM delta update |
| `update_app.py` | v1.0 | EHM delta update |
| `build_infrastructure_split.py` | v1.0 | One-time EHM split |
| `apply_ehm_enrichment.py` | v1.1 | Qualys→EHM enrichment |
| `build_csna_site_registry.py` | v1.0 | CSNA registry builder |
| `generate_csna_hostgroups.py` | v3.3 | CSNA hostgroup generator |
| `hostname_translate.py` | v1.0 | Hostname→location resolver |
| `preflight_lm_check.py` | v1.1 | LM anchor validation |
