---
name: latex-docx-style
description: >
  Format Word documents (.docx) in traditional LaTeX/TeX academic paper style. Use when the user
  asks for LaTeX formatting, TeX style, academic paper format, Computer Modern look, or
  publication-ready document styling — with DOCX as the output format (not actual .tex files).
  Applies serif typography (Times New Roman), ALL CAPS section headings, justified text, booktabs-style
  tables, monospace code blocks with gray shading, italic cross-references, and running headers.
  This is the user's preferred output style for technical and academic documents.
metadata:
  author: Michael J Martin
  version: '2.1'
---

# LaTeX-Style DOCX Formatting

Produce Word documents that replicate the visual appearance of a LaTeX academic paper — Times New Roman serif typography, traditional academic structure, clean minimalist design. Output is always `.docx`, never `.tex`.

## When to Use This Skill

Use this skill when:

- The user asks for LaTeX or TeX formatting/style in a Word document
- The user requests academic paper formatting
- The user wants a publication-ready or journal-style document
- The user says "use my preferred style" or "standard format" for a technical document
- Any technical paper, whitepaper, or research document is being produced

This is the user's default preferred output style for technical and academic documents.

## Non-Negotiable Rules

1. **Typography first** — Times New Roman serif throughout. No sans-serif except in code blocks (Consolas).
2. **LaTeX-mirrored structure** — ALL CAPS bold section headings, bold mixed-case subsections, centered title block, indented abstract.
3. **Academic table styling** — Booktabs pattern: no vertical borders, thick top/bottom rules, medium rule under header. Never shade header rows.
4. **Monospace code blocks** — State machines, code examples, and technical diagrams in Consolas with light gray background shading.
5. **Zero decorative elements** — No colored headings, no decorative borders, no clip art. Typography, whitespace, and structure carry the design.
6. **Justified body text** — All body paragraphs are fully justified (both margins aligned).

## Page Setup

| Property | Value | DXA |
|----------|-------|-----|
| Paper | US Letter | 12240 x 15840 |
| Left margin | 1.15 inches | 1656 |
| Right margin | 1.15 inches | 1656 |
| Top margin | 1.0 inches | 1440 |
| Bottom margin | 1.0 inches | 1440 |
| Printable width | 6.2 inches | 8928 |
| Layout | Single column | — |

## Typography Hierarchy

All sizes shown in points (half-points in parentheses for the `docx` library `size` parameter).

| Element | Font | Size | Weight | Alignment | Spacing Before | Spacing After |
|---------|------|------|--------|-----------|----------------|---------------|
| Document title | Times New Roman | 16pt (32) | Bold | Center | 0 | 120 |
| Subtitle | Times New Roman | 13pt (26) | Normal | Center | 0 | 120 |
| Author / affiliation | Times New Roman | 11pt (22) | Normal | Center | 0 | 60 |
| Metadata lines | Times New Roman | 10pt (20) | Normal | Center | 0 | 60 |
| Keywords label | Times New Roman | 10pt (20) | Bold ("Keywords:") | Center | 0 | 60 |
| Abstract label | Times New Roman | 11pt (22) | Bold | Center | 240 | 120 |
| Abstract body | Times New Roman | 10pt (20) | Normal | Justify | 0 | 120 |
| Section heading (H1) | Times New Roman | 13pt (26) | Bold, ALL CAPS | Left | 360 | 160 |
| Subsection heading (H2) | Times New Roman | 11pt (22) | Bold | Left | 280 | 120 |
| Body text | Times New Roman | 11pt (22) | Normal | Justify | 0 | 120 |
| Cross-reference | Times New Roman | 10pt (20) | Italic | Justify | 0 | 120 |
| Bullet list item | Times New Roman | 11pt (22) | Normal | Justify | 0 | 60 |
| State machine / code | Consolas | 8.5pt (17) | Normal | Left | 0 | 0 |
| Table body text | Times New Roman | 9.5pt (19) | Normal | Left | 0 | 0 |
| Table header text | Times New Roman | 9.5pt (19) | Bold | Left | 0 | 0 |
| Table caption | Times New Roman | 10pt (20) | Italic | Center | 120 | 80 |
| Reference entry | Times New Roman | 10pt (20) | Normal | Left | 0 | 60 |
| Running header | Times New Roman | 8pt (16) | Italic | — | — | — |
| Footer | — | — | — | — | — | — |

## Line Spacing

- Body text: 1.15x exact (276 twentieths of a point)
- Abstract: 1.15x exact
- State machine blocks: Single (exact 200 twips) with 0 spacing after — lines must be tightly grouped
- All other elements: Single

## Detailed Element Specifications

### Title Block

Center the title block on the first page. Combine multi-line titles into a single paragraph. Stack elements vertically: title → author → affiliation → version → classification → keywords → status.

Insert a page break after the title block and abstract, before the first section heading.

### Section Headings (Heading 1)

Apply `HeadingLevel.HEADING_1` style. Convert the heading text to ALL CAPS. Preserve any numbering (e.g., "1. PROBLEM STATEMENT: WHY ZTNA CONVERSATIONS COLLAPSE IN PRACTICE"). Use `outlineLevel: 0` so the heading appears in Table of Contents.

### Subsection Headings (Heading 2)

Apply `HeadingLevel.HEADING_2` style. Keep mixed-case as authored. Preserve numbering (e.g., "3.1 Identity Issuance vs. Identity Consumption"). Use `outlineLevel: 1`.

### Abstract

Render the "Abstract" label as a centered, bold paragraph. Render the body text indented 360 DXA on both left and right, at 10pt, justified.

### Cross-References

Paragraphs that begin with "For " and contain "Appendix" or "see Appendix" are appendix cross-references. Render them in 10pt italic. These serve as navigational pointers to the technical appendices.

### State Machines and Code Blocks

Detect state machine / code content by checking if the line:
- Starts with `[` and contains `]` (state names: `[KeyNotPresent]`, `[ConnInit]`)
- Is just `|` or starts with `|` or `  |` (transition pipes)
- Is just `v` or starts with `  v` or `v` (arrow down)
- Contains `-->` or `—>` (transition arrows)
- Contains SQL keywords (`CREATE POLICY`, `USING`, `SET `, `SELECT `)
- Contains policy syntax (`allow if`, `caller.spiffe_id`, `callee.spiffe_id`)
- Starts with `spiffe://` or contains `spiffe://` in a policy context

Render these in Consolas 8.5pt with:
- Left indent: 360 DXA
- Spacing after: 0 (consecutive code lines should be tightly packed)
- Background shading: light gray `#F5F5F5` using `ShadingType.CLEAR` with `fill: "F5F5F5"`

### Bold Label Paragraphs

These short paragraphs introduce lists and should be bold:
- "Capabilities:"
- "Non-capabilities (must be provided elsewhere):"
- "Non-capabilities:"
- "ZT-native:"
- "Legacy:"
- "Key design points for architects:"
- "Key design points:"
- "Key architectural insights:"
- "Key technical points:"
- "Implementation implications:"
- "Architectural implications:"
- "Properties of brokered legacy model:"
- "Properties of ZT-native model:"
- Any paragraph ending with `:` that is followed by bullet list items

### Bullet Lists

Use proper Word numbering config with bullet character `\u2022`. Indent: left 720 DXA, hanging 360 DXA. Spacing after: 60 twips.

```javascript
// Numbering config for bullets
numbering: {
  config: [{
    reference: "bullets",
    levels: [{
      level: 0,
      format: LevelFormat.BULLET,
      text: "\u2022",
      alignment: AlignmentType.LEFT,
      style: {
        paragraph: {
          indent: { left: 720, hanging: 360 }
        }
      }
    }]
  }]
}
```

### Tables (Booktabs Style)

Replicate LaTeX `booktabs` package appearance:

```
═══════════════════════════════  ← thick top rule (1.5pt / size 12)
 Header Col 1    Header Col 2
───────────────────────────────  ← medium rule (0.75pt / size 6)
 Data row 1      Data row 1
 Data row 2      Data row 2
 Data row 3      Data row 3
═══════════════════════════════  ← thick bottom rule (1.5pt / size 12)
```

Implementation:
- **No vertical borders** — set left/right borders to `BorderStyle.NONE` on ALL cells
- **Header row top**: thick border (size 12, `BorderStyle.SINGLE`, color `"000000"`)
- **Header row bottom**: medium border (size 6, `BorderStyle.SINGLE`, color `"000000"`)
- **Last row bottom**: thick border (size 12, `BorderStyle.SINGLE`, color `"000000"`)
- **Data rows**: `BorderStyle.NONE` on top and bottom (except last row)
- **No shading** on any row — pure white background
- **Cell margins**: top 40, bottom 40, left 80, right 80
- **Table width**: full printable width (8928 DXA)
- **Column widths**: 2-column tables: 4000 / 4928. 3-column tables: 2200 / 3364 / 3364. Adjust proportionally for more columns.

Table captions appear ABOVE the table, centered, italic, 10pt (matching LaTeX `\caption{}` placement).

### References

Format citation entries with hanging indent: left 360 DXA, hanging 360 DXA. Size 10pt. Example:

```
[1]  John Kindervag, "Applying Zero Trust to the Extended Enterprise,"
     Forrester Research, 2011.
```

### Running Header

- Left side: short document title, italic, 8pt, gray (`#888888`)
- Right side: "Page X of Y" using `PageNumber.CURRENT` and `PageNumber.TOTAL_PAGES`

### Page Breaks

Insert page breaks before:
- The first section heading (after title block + abstract)
- Each appendix heading (Heading 1 paragraphs starting with "Appendix")
- The "References" section

## Document Type Adjustments

The base specification above works for Research Papers and Technical Reports. Minor adjustments for other document types:

| Document Type | Adjustments |
|---------------|-------------|
| Research Paper | Base specification as-is |
| Technical Report | Base specification as-is |
| Whitepaper | May use 12pt body text; slightly wider margins (1.25") |
| Business Report | May add a separate title page with date and recipients |
| Policy Document | May use numbered paragraphs instead of bullets |
| Executive Summary | May use 12pt body text; shorter total length |

## Build Process

1. Read the source content (from an existing document, JSON, or markdown)
2. Initialize the `docx` Document with styles, numbering config, and page setup
3. Build front matter (title block, abstract)
4. Process each paragraph: detect type → apply correct style
5. Insert tables at their correct positions with booktabs formatting
6. Add running header
7. Save as `.docx`
8. Convert to PDF via `soffice --headless --convert-to pdf` for visual verification
9. Inspect the first few pages and a table page for quality issues before sharing

## Style Registration (Node.js docx module)

When building with the `docx` npm module, register these paragraph styles:

```javascript
styles: {
  default: {
    document: {
      run: { font: "Times New Roman", size: 22 },
      paragraph: {
        alignment: AlignmentType.JUSTIFIED,
        spacing: { after: 120, line: 276, lineRule: "exact" }
      }
    }
  },
  paragraphStyles: [
    {
      id: "Heading1", name: "Heading 1",
      basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 26, bold: true, font: "Times New Roman", allCaps: true },
      paragraph: {
        spacing: { before: 360, after: 160 },
        alignment: AlignmentType.LEFT,
        outlineLevel: 0
      }
    },
    {
      id: "Heading2", name: "Heading 2",
      basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 22, bold: true, font: "Times New Roman" },
      paragraph: {
        spacing: { before: 280, after: 120 },
        alignment: AlignmentType.LEFT,
        outlineLevel: 1
      }
    }
  ]
}
```
