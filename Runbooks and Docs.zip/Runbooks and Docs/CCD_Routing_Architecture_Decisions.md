# CCD Platform — Routing Architecture Decisions
## Established 2026-05-25

---

## 1. CVS Health Network Topology — Confirmed

### Two Primary Routing Planes

**Internal-PBM (CVS Enterprise Plane)**
- Scottsdale AZ — Shea DC
- Woonsocket RI — RI One
- Cumberland RI — 2100 Highland
- CVS Equinix PoP 1 (Ashburn VA)
- CVS Equinix PoP 2 (Dallas TX)
- Las Vegas NV — Switch COLO (CVS path)
- Atlanta GA — Switch COLO (CVS path)
- Internal-Retail (SD-WAN, 9,100+ stores) — **hangs off CVS plane**

**Internal-HCB (Aetna/HCB Plane)**
- Middletown CT — Aetna MDC
- Windsor CT — Aetna WDC
- Phoenix AZ — Aetna PDC (Affiliate DC, closing — not yet)
- Aetna Equinix PoP 1 (Ashburn VA HCB)
- Aetna Equinix PoP 2
- Las Vegas NV — Switch COLO (Aetna path)
- Atlanta GA — Switch COLO (Aetna path)

### Shared COLO Facilities
Las Vegas (Switch) and Atlanta (Switch) are **physically shared** but carry
**logically distinct routing paths** — one on the CVS plane, one on the Aetna
plane. SITE_CODE identifies the physical location. ROUTING_DOMAIN identifies
which plane. They are independent dimensions.

### CVS/Aetna Boundary
A dedicated Cisco/Checkpoint FW (being replaced by PA) sits at the CVS/Aetna
boundary. Its **sole function is SNAT between the two planes**. All other
peering is within-plane. Cross-plane traffic is the exception, not the rule.

### Retail Sub-Domains
Retail, Distribution Centers, and Mail-Order/Mail-Centers are all under the
**Internal-Retail / Internal-PBM umbrella** — connected through the CVS routing
plane.

---

## 2. Field Definitions — Corrected and Finalized

### HERITAGE
**Import provenance** — which source system / organization the IP data was
imported from at the time of IPAM population.
- `CVS` = data originated from CVS IPAM/NMS
- `AETNA` = data originated from Aetna IPAM/NMS
- `OMNICARE`, `CAREMARK`, `SWITCH`, `PARTNER`, `OSH`, `SIGNIFY`, `CVSHCD` = respective source systems

**HERITAGE is NOT:**
- IP block ownership in the ARIN/allocation sense
- Evidence of which routing plane a block lives on
- Derivable from SITE_CODE, ROUTING_DOMAIN, NET_TYPE, or workload composition

**Consequence:** HERITAGE and ROUTING_DOMAIN are fully independent dimensions.
A CVS-imported block can legitimately live on Internal-HCB. An Aetna-imported
block can live on Internal-PBM. Co-location at a shared COLO makes this common.

### ROUTING_DOMAIN
**Which routing plane carries the traffic.** The network routing and policy
boundary a subnet rides.
- `Internal-PBM` — CVS enterprise plane
- `Internal-HCB` — Aetna/HCB plane
- `Internal-Retail` — Retail SD-WAN (sub-plane of CVS)
- `COLO` — shared COLO facilities
- `Cloud-GCP`, `Cloud-Azure`, `Cloud-AWS`, `Cloud-Peering` — cloud planes
- `Internal-OSH`, `Internal-SIGNIFY`, `Internal-HCD` — business-line sub-planes

**ROUTING_DOMAIN is NOT derivable from HERITAGE or SITE_CODE.**

### SITE_CODE
**WHERE the subnet physically terminates.** `US_LVG_NV_CI`, `US_MIC_CT_DC`,
`IN_GGN_HR_TP`. Derived from hostname translation and NMS data. Independent of
HERITAGE and ROUTING_DOMAIN.

### NET_TYPE
**WHAT kind of network segment it is.** Architectural function: DataCenter,
Corporate, Retail-Store, DMZ, P2P-WAN, SNAT, Management, etc. Not derivable
from any other field.

---

## 3. HERITAGE-MISMATCH Rule — Removed (v3.12.16)

The audit rule that fired when HERITAGE and ROUTING_DOMAIN didn't align has
been permanently removed from `ipam-db.py v3.12.16`.

**Rationale:** The rule encoded a false assumption that HERITAGE and
ROUTING_DOMAIN are correlated. They are not — they answer different questions.
At shared COLO facilities (Vegas/Atlanta Switch), both CVS and Aetna routing
paths coexist and blocks of any heritage can ride either plane. The rule
generated noise and drove incorrect HERITAGE changes based on routing domain
alone.

---

## 4. Sub-Routing-Domain Architecture (New — To Be Built)

### Concept
Each primary routing plane contains multiple **sub-routing-domains** — distinct
network segments with their own egress topology, FW policy context, and
service dependency profiles.

### Known Sub-Routing-Domains (Provisional)

**CVS Plane (Internal-PBM):**
- `CVS-Corp` — Corporate HQ, RI campuses
- `CVS-Equinix` — CVS Equinix PoPs (cloud peering egress)
- `CVS-PCI` — PCI-scoped segment
- `CVS-Citrix` — Citrix delivery platform
- `Pharm` — PBM/pharmacy services (RxConnect, Caremark)
- `Mail-Order` — Mail-order pharmacies
- `Coram` — Specialty infusion / home health
- `Specialty` — Specialty pharmacies
- `Distribution` — Distribution centers

**CVS Retail Plane (Internal-Retail):**
- `Retail` — Store SD-WAN (9,100+ locations)
- `MC` — MinuteClinic
- `Retail-Optical` — Optical centers

**CVS Business Lines (separate sub-planes):**
- `OSH` — Oak Street Health (`Internal-OSH`)
- `Signify` — Signify Health (`Internal-SIGNIFY`)
- `Omnicare` — Nursing home pharmacy

**Aetna Plane (Internal-HCB):**
- `Aetna-Corp` — Hartford HQ, Aetna corporate offices
- `Aetna-Equinix` — Aetna Equinix PoPs
- `Aetna-PCI` — HCB PCI-scoped segment
- `Aetna-Citrix` — Citrix HCB delivery platform
- `Aetna-Affiliates` — Affiliate DCs (Phoenix PDC)

### Dataset to Build: `routing_context_map`

A separate mapping table — NOT a field on `all_IP_networks`. Maps subnet ranges
or SITE_CODE patterns to sub-routing-domain context and FW path.

**Proposed schema:**
```
ROUTING_DOMAIN        — primary plane
NETWORK_SEGMENT       — sub-routing-domain label
SITE_CODE_PATTERN     — SITE_CODE prefix/pattern that assigns membership
CIDR_PATTERN          — optional CIDR range (for COLO multi-tenant cases)
PRIMARY_EGRESS_FW     — primary FW / FW cluster for this segment
SECONDARY_EGRESS_FW   — failover FW / FW cluster
INTERNET_EGRESS       — internet egress point (Zscaler, direct, proxy)
SNAT_BOUNDARY_FW      — FW handling cross-plane SNAT (if applicable)
ZONE_POLICY_CONTEXT   — PA zone or Cisco zone label for rule generation
NOTES
```

### Intent-Based Rule Construction — Dependency Chain

To build one intent FW rule you need:

```
APP / USER / IoT
  └── ROUTING_DOMAIN + NETWORK_SEGMENT  (from all_IP_networks + routing_context_map)
        └── SERVICE DEPENDENCIES         (from canonical_app_objects + delivery_infrastructure)
              └── each dependency → own ROUTING_DOMAIN + SEGMENT
                    └── cross-segment → FW PATH (from routing_context_map egress mapping)
                          └── cross-plane → SNAT boundary FW
        └── EXTERNAL DEPENDENCIES        (from external_ip_registry)
              └── internet/vendor/cloud → segment internet egress path
```

**Inputs to rule builder:**
- `canonical_app_objects` — app identity, subnet ownership, routing context
- `app_subnet_index` — subnet → app mapping
- `routing_context_map` — segment topology and egress
- `external_ip_registry` — external service dependencies
- `delivery_infrastructure` / `delivery_platform` — shared service dependencies
- `all_IP_networks` — ground truth subnet → routing-domain resolution

**Output:** PA / Cisco / Checkpoint rule candidates scoped to specific FW paths,
with correct zone pairs and application objects — not flat `app=any` ACLs.

---

## 5. Retail IP Addressing — Design Decision

Retail IP space (`172.16.0.0/12`) is allocated to retail stores at `/26`
granularity per function per store. Some non-store sites (e.g., offshore dev
sites using retail addressing for routing continuity) are allocated from this
space. All retail-addressed subnets belong in `retail_networks`, NOT
`all_IP_networks`.

### `preprocess_p1.py` fix (v1.7 — pending)
Must load `retail_networks` as a secondary LPM alongside `all_IP_networks` so
retail-addressed hosts resolve correctly during pipeline processing.

---

## 6. Dataset Corrections Made This Session

| Change | Result |
|---|---|
| `172.21.184/186.0/24` moved from `all_IP_networks` to `retail_networks` v2.9 | RxConnect dev sites (IBM Gurgaon) now resolve via retail LPM |
| ROUTING_DOMAIN patch (45 rows): Internal-PBM → Internal-HCB/Cloud-GCP/Cloud-Azure | Aetna DC subnets and cloud subnets correctly classified |
| `CONTESTED_BLOCK=Y` on `172.19.32/41/43.0/24` | CX12 violations cleared |
| HERITAGE-MISMATCH rule removed from ipam-db.py v3.12.16 | No more false HERITAGE change pressure |
| location_master resolution order fixed (ipam-db.py v3.12.15) | Cross-checks always use versioned LM, version visible in output |

