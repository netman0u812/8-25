# ipam-db.py — Enterprise IPAM Database Manager

**Version:** v1.2  
**Type:** Python  
**Role:** Manages the `ipam-db/` directory and `ipam-db.json` registry. Orchestrates the full raw data import pipeline — checksums `IP_Datasets_Raw/`, processes new or changed files, delegates to `ip_dataset.py` for external IP datasets, and refreshes live URL feeds.

---

## Platform Rules — Never Break These

### Directory Layout

```
IP_Lookup/
├── ipam-db/          ← enterprise IPAM data ONLY
├── ipdatasets/       ← external provider IP ranges (AWS, GCP, Azure, Cloudflare, Zscaler, M365)
├── ip_geo/           ← GeoIP data (IP2Location DB1/DB11, ip2asn, us_geo_networksdb.tsv)
└── IP_Datasets_Raw/  ← raw source exports — checksummed, never modified
```

**Never place geo files or cloud provider IP ranges in `ipam-db/`.**

### IPAM Single Source of Truth

- `all_IP_networks_v3.14.csv` — **single authority** for all subnet→location mapping
- `retail_networks_v2.1.csv` — **single authority** for all retail store subnets
- `cidr_16` — **ABOLISHED** — never registered, never used
- `cidr_24` — **ABOLISHED** — never registered, never used

### Canonical Location Format
`City ST - Site Name` — e.g. `Scottsdale AZ - Shea DC`, `Woonsocket RI - RI One`

---

## Directory Layout

```
IP_Lookup/
    ipam-db.py
    ip_dataset.py
    IP_Datasets_Raw/
    ipdatasets/
    ipam-db/
        ipam-db.json
        all_IP_networks_v3.14.csv      ← SINGLE SOURCE OF TRUTH (19,421 rows)
        retail_networks_v2.1.csv       ← RETAIL AUTHORITY (294,355 rows)
        location_master_v3.7.csv       ← canonical location registry (9,708 rows)
        172_16_allocation_registry.csv ← 172.x /24 allocation map (4,096 rows)
        app_subnet_index_v*.csv
        cpc_infra_services.csv
        ent_host_master_v*.csv
        ent-ipdataset-*.csv
    ip_geo/
```

---

## Managed File Types

| Stem | Pattern | Description |
|---|---|---|
| `all_IP_networks` | `all_IP_networks_v*.csv` | Full IP prefix inventory — SINGLE SOURCE OF TRUTH |
| `retail_networks` | `retail_networks_v*.csv` | Per-store /26 + device /32 allocations — RETAIL AUTHORITY |
| `location_master` | `location_master_v*.csv` | Canonical location registry |
| `app_subnet_index` | `app_subnet_index_v*.csv` | Application-to-subnet index |
| `cpc_infra_services` | `cpc_infra_services.csv` | CPC infrastructure service catalogue |
| `ent_host_master` | `ent_host_master_v*.csv` | Enterprise host dataset (ADL+SNOW merged) |

**Abolished stems — no longer registered:**
- `cidr_16` — permanently removed
- `cidr_24` — permanently removed

ENT ipdatasets (also in `ipam-db/`):

| Descriptor | File | Description |
|---|---|---|
| `ENTERPRISE-APP-SERVER` | `ent-ipdataset-ENTERPRISE-APP-SERVER-v*.csv` | ADL + SNOW merged host/app data |
| `CROWDSTRIKE-ENDPOINTS` | `ent-ipdataset-CROWDSTRIKE-ENDPOINTS-v*.csv` | CrowdStrike Falcon cloud endpoint IPs |
| `F5-VIP-REGISTRY` | `ent-ipdataset-F5-VIP-REGISTRY-v*.csv` | F5 virtual server registry |
| `F5-POOL-MEMBERS` | `ent-ipdataset-F5-POOL-MEMBERS-v*.csv` | F5 pool member IPs |
| `S2S-VPN-PARTNERS` | `ent-ipdataset-S2S-VPN-PARTNERS-v*.csv` | Site-to-site VPN partner subnets |
| `CPC-CORE-SERVICES` | `ent-ipdataset-CPC-CORE-SERVICES-v*.csv` | CPC Tier-1 baseline service IPs |

---

## Usage

```bash
# List all managed files and status
./ipam-db.py --list

# Full pipeline — refresh URL feeds + process all new/changed raw files
./ipam-db.py --import-update

# Import/register a specific file manually
./ipam-db.py --import ipam-db/all_IP_networks_v3.14.csv --type all_IP_networks \
    --description "v3.14 — authoritative rebuild from ground-truth sources"

./ipam-db.py --import ipam-db/retail_networks_v2.1.csv --type retail_networks \
    --description "v2.1 — full rebuild from Store_IP_and_Address_Info.xlsx"

# Get current active file path for a stem (used by iplookup.sh)
./ipam-db.py --resolve all_IP_networks
./ipam-db.py --resolve retail_networks

# Output JSON status (for scripting)
./ipam-db.py --status
```

---

## Current Registry State (as of 2026-04-14)

```
✓  all_IP_networks       all_IP_networks_v3.14.csv        19,421 rows
✓  retail_networks       retail_networks_v2.1.csv         294,355 rows
✓  location_master       location_master_v3.7.csv           9,708 rows
✓  app_subnet_index      app_subnet_index_v1.4.csv         17,139 rows
✓  cpc_infra_services    cpc_infra_services.csv                52 rows
✓  ent_host_master       ent_host_master_v20260410.csv      61,886 rows
✓  ENTERPRISE-APP-SERVER ent-ipdataset-ENTERPRISE-APP-SERVER-v20260410.csv  61,886
✓  F5-VIP-REGISTRY       ent-ipdataset-F5-VIP-REGISTRY-v20260403.csv         4,802
✓  F5-POOL-MEMBERS       ent-ipdataset-F5-POOL-MEMBERS-v20260403.csv         8,913
✓  S2S-VPN-PARTNERS      ent-ipdataset-S2S-VPN-PARTNERS-v20260403.csv        3,741
✓  CPC-CORE-SERVICES     ent-ipdataset-CPC-CORE-SERVICES-v20260413.csv         422
11/11 clean
```

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.2 | 2026-04-14 | **cidr_16 and cidr_24 stems abolished** — removed from registry; all_IP_networks v3.14 and retail_networks v2.1 are new baselines; location_master stem added |
| v1.1 | 2026-04-10 | `--update-cloud-ranges` cloud boundary tagging |
| v1.0 | 2026-04-10 | Initial: `--list`, `--import`, `--resolve`, `--status` |
