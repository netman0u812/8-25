# CCD Platform — Session Restart Prompt — 2026-05-04 (End of Day)

## Upload these files at session start:
- `ccd-data-governance-SKILL.md` — load first, governs all location decisions
- `ccd-versioning-SKILL.md` — governs all script delivery

---

## Platform State — CLEAN as of 2026-05-04

| Dataset | Version | Rows | Status |
|---|---|---|---|
| `location_master` | v4.5 | 10,181 | ✓ Zone-based cloud canonicals |
| `all_IP_networks` | v3.68 | 20,079 | ✓ 1,757 cloud rows corrected |
| `ent_host_master` | v20260427r6 | 60,939 | ✓ Location patch + Qualys enrichment |
| `ent_network_device_master` | v20260504 | 10,849 | ✓ 190 corrected, 206 flagged for review |
| `app_subnet_index` | v20260504 | 2,608 | ✓ Rebuilt from r6 |
| `csna_site_registry` | v2.13 | 348 | ✓ Stable |
| `retail_networks` | v2.5 | — | ✓ Stable |
| `mgmt_ip_index` | v1.2 | 21 | ✓ Stable |

**Cross-check baseline: 0 HIGH, 7 MEDIUM, 35 LOW — all known, none blocking**

**Script versions installed:**
- `ipam-db.py` v3.9 — has `--sync` command
- `build_qualys_pipeline.py` v1.6
- `apply_ehm_enrichment.py` v1.1 — APP_NAMES union merge
- `patch_location_master.py` v1.1
- `patch_ipam_cloud_locations.py` v1.1
- `patch_ehm_locations.py` v1.1
- `patch_ndm_locations.py` v1.1
- `preflight_lm_check.py` v1.1

---

## What Was Completed This Session

**Root cause fixed:** Cloud location names were BU-based instead of
zone-based, and files were being rebuilt from scratch instead of
merged from registered masters. Registry (ipam-db.json) was stale
because LM was updated directly without going through --import.

**Changes made:**
1. `location_master` v4.4 → v4.5: 28 stale cloud entries retired,
   12 new zone-based cloud canonicals added
2. `all_IP_networks` v3.67 → v3.68: 1,757 rows CANONICAL_LOCATION
   corrected via CIDR-LPM lookup
3. `ent_host_master` r4 → r5 → r6: 16,449 hosts location-corrected,
   then Qualys enrichment applied (1,305 rows patched)
4. `ent_network_device_master` v20260501 → v20260504: 35 stale names
   fixed, 155 cloud zones corrected, 206 flagged for review
5. `app_subnet_index` v1.7 → v20260504: rebuilt from r6, +8 rows
6. Qualys pipeline re-run against clean datasets
7. `ipam-db.py` v3.8 → v3.9: added `--sync` command
8. `ccd-data-governance-SKILL.md` created — permanent governance rules

---

## Known Cross-Check Violations (Deferred)

| Rule | Count | Fix |
|---|---|---|
| CX3-LM-REGISTRY | 5 | Add CSNA entries: Mount Prospect IL ×2, Wilkes-Barre PA, Memphis TN, Beach Island SC |
| CX4-TYPE-SYNC | 2 | LM v4.6: change Atlanta GA Switch COLO + Las Vegas NV Switch Colo LOCATION_TYPE from `Datacenter` → `COLO` |
| CX6-LM-ORPHAN | 35 | Advisory — sites with no registered subnets, genuine gaps |

---

## Open Items (Deferred)

1. **`patch_ipam_cloud_locations.py` v1.2** — fix R12 violation:
   `DATA_QUALITY=Review-Split-Block` is non-standard. Change to
   `DATA_QUALITY=Inferred` for 10.243.x.x split block rows.
   Produces `all_IP_networks_v3.69.csv`.

2. **`update_retail.py`** — not built, 4 retail hub candidates waiting

3. **`vv` double-version bug in `ipam-db.py`** — cosmetic, registry
   shows `vv4.5` instead of `v4.5`. Fix in v3.10.

4. **NDM review queue (206 rows)** — devices with on-prem DC location
   but MANAGEMENT_IP in cloud CIDR blocks. Linthicum MD (131),
   Cumberland RI (32), Scottsdale Shea DC (23), Equinix sites (20).
   Network team must confirm before correcting.

5. **10.243.0.0/16 SPLIT block** — 73 EHM hosts, 10 IPAM rows.
   Needs /24-level resolution to determine Azure vs GCP per subnet.

6. **Detroit MI - Specialty** — 1 IPAM row, no CSNA entry.
   Run: `python3 build_csna_site_registry.py --interactive`

7. **Cumberland RI - Highland Lab** — 46 EHM hosts with stale
   location. Which building: 100, 1700, or 2100 Highland?

8. **100.64.x.x** — 27 EHM hosts flagged DATA_QUALITY_ERROR (CGNAT).
   Source data entry errors — remove from EHM.

9. **10.53.x.x** — 12 EHM hosts flagged LOCATION_NEEDS_REVIEW.
   Unknown block — investigate and assign correct location.

10. **CX4 Switch COLO fix** — LM v4.6 needed:
    `Atlanta GA - Switch COLO` and `Las Vegas NV - Switch Colo`
    need LOCATION_TYPE changed from `Datacenter` to `COLO`.

---

## Next Priority: new_hosts and IPAM candidates from Qualys

Qualys produced clean output against corrected datasets.
Next work is reviewing the Qualys candidates:

```bash
# Review new host candidates (2,385 rows)
# These need EHM import after review
head -20 ./Qualys_processed_results/qualys_new_hosts_v20260504.csv

# Review IPAM candidates (2,754 rows)  
# These need promoter review before IPAM import
python3 build_ipam_promoter.py \
    --qualys ./Qualys_processed_results/qualys_ipam_candidates_v20260504.csv \
    --ipam-dir ./ipam-db/ \
    --out-dir ./promoter-output/ \
    --dry-run
```

---

## Authoritative Cloud CIDR Map (from ccd-data-governance-SKILL.md)

```python
CLOUD_CIDR_MAP = {
    # Azure SecureHub UE1 (contain mode)
    "10.68.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.74.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.82.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.83.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.85.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.86.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.98.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.141.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.142.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.159.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.175.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.209.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.210.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.223.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.229.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.242.0.0/16": "Cloud - Azure SecureHub UE1",
    # Azure SecureHub UE2 (active growth)
    "10.152.0.0/16": "Cloud - Azure SecureHub UE2",
    # Azure East US 2 (CVS Digital/PBM/MinuteClinic AKS)
    "10.155.0.0/16": "Cloud - Azure East US 2",
    # Split block
    "10.243.0.0/16": "SPLIT - Azure/GCP",
    # GCP
    "10.114.0.0/16": "Cloud - GCP East4 SecureHub",
    "10.236.0.0/16": "Cloud - GCP East4 SecureHub",
    "10.117.0.0/16": "Cloud - GCP East4 PCI",
    "10.112.0.0/16": "Cloud - GCP East4",
    "10.143.0.0/16": "Cloud - GCP East4",
    "10.149.0.0/16": "Cloud - GCP East4",
    "10.157.0.0/16": "Cloud - GCP East4",
    "10.247.0.0/16": "Cloud - GCP East4",
    "10.252.0.0/16": "Cloud - GCP East4",
    "10.158.0.0/16": "Cloud - GCP West2",
    # AWS CVS
    "10.207.0.0/18":   "Cloud - AWS East1 Prod",
    "10.207.64.0/19":  "Cloud - AWS East1 Prod",
    "10.207.96.0/19":  "Cloud - AWS East1 NonProd",
    "10.207.128.0/18": "Cloud - AWS East1 NonProd",
    "10.207.192.0/19": "Cloud - AWS East2 Prod",
    "10.207.224.0/19": "Cloud - AWS East2 NonProd",
    # AWS Aetna
    "10.208.0.0/16": "Cloud - AWS East1 Aetna",
}
```
