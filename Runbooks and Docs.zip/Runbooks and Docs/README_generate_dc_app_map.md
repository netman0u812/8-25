# generate_dc_app_map.py — DC Application Distribution Map

**Version:** v1.x  
**Type:** Python  
**Role:** Generates an interactive self-contained HTML map showing how applications are distributed across CVS Health datacenters and cloud platforms. Supports three views: DC/Cloud only, Corporate/Retail only, and All Sites.

---

## Overview

```
all_IP_networks_v3.14.csv → site aggregation (CANONICAL_LOCATION, LOCATION_TYPE)
ent_host_master_v*.csv    → per-host app identity, server counts
app_subnet_index_v*.csv   → app→subnet mapping
    ↓
CVS_DC_Application_Map.html (self-contained HTML, ~800KB)
```

---

## Usage

```bash
# Standard run — auto-detects files
python3 generate_dc_app_map.py --db-dir ipam-db/

# Specific view
python3 generate_dc_app_map.py --db-dir ipam-db/ --view dc-cloud
python3 generate_dc_app_map.py --db-dir ipam-db/ --view corp-retail
python3 generate_dc_app_map.py --db-dir ipam-db/ --view all

# Custom output
python3 generate_dc_app_map.py --db-dir ipam-db/ --out CVS_DC_Application_Map.html
```

---

## CLI Reference

| Flag | Default | Description |
|------|---------|-------------|
| `--db-dir DIR` | `ipam-db/` | IPAM directory |
| `--view` | `all` | `dc-cloud` / `corp-retail` / `all` |
| `--out FILE` | `CVS_DC_Application_Map.html` | Output HTML file |
| `--ent-master FILE` | auto | ent_host_master for host drill-down |

---

## Map Views

**dc-cloud:** Shows only Datacenter, COLO, and Cloud platform nodes. Application bubbles sized by server count.

**corp-retail:** Shows Corporate, Campus, Distribution, and Retail sites.

**all:** Combined view of all sites.

---

## Location Classification

Uses `LOCATION_TYPE` from `all_IP_networks` — Stores, Distribution Centers, and Retail are never shown as Datacenter nodes.

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v2.0 | 2026-04-14 | **cidr_24 replaced** — `all_IP_networks_v3.14` is primary source; `app_subnet_index` used for app data |
