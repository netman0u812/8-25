
# Secure Network Analytics XML Formatting Guide (v1)

**Audience:** Large Language Models (LLMs) generating XML data for Secure Network Analytics (SNA)

**Version:** v1.0

**Purpose:**
Provide prescriptive rules and examples to ensure XML generated for Secure Network Analytics ingests cleanly, validates against schema expectations, and avoids common errors (especially IP and network formatting issues).

---

## 1. General Principles

1. Always emit **well‑formed XML**
   - Exactly one root element
   - Properly nested tags
   - Every opening tag has a matching closing tag

2. Use **UTF‑8 encoding**

3. Do **not** escape XML tags unless explicitly required by a consuming system
   - ✅ `<ip-address-ranges>`
   - ❌ `\<ip-address-ranges\>`

4. Avoid optional fields unless values are known and valid

---

## 2. Element Naming Conventions

- Use **lowercase kebab‑case** for element names
- No camelCase or snake_case

✅
```xml
<ip-address-ranges>
<policy-name>
```

❌
```xml
<IpAddressRanges>
<ip_address_ranges>
```

---

## 3. IP Address and Network Rules (Critical)

### 3.1 `<ip-address-ranges>` REQUIREMENTS

This element **MUST** contain a valid CIDR notation network.

**Allowed formats:**
- IPv4 CIDR
  - `192.168.1.0/24`
  - `10.0.0.5/32`
- IPv6 CIDR (if environment supports IPv6)
  - `2001:db8::/64`

**Disallowed formats:**
- IP/IP pairs
- Host + network combinations
- Ranges using hyphens

❌ INVALID
```xml
<ip-address-ranges>152.145.10.5/198.199.54.192</ip-address-ranges>
```

✅ VALID
```xml
<ip-address-ranges>152.145.10.5/32</ip-address-ranges>
<ip-address-ranges>198.199.54.192/26</ip-address-ranges>
```

**Rule:**
> Anything after `/` MUST be a numeric prefix length, not another IP address.

---

## 4. Multiple IP Ranges

When representing multiple networks, repeat the element—**do not comma‑separate values**.

✅
```xml
<ip-address-ranges>10.0.0.0/8</ip-address-ranges>
<ip-address-ranges>192.168.0.0/16</ip-address-ranges>
```

❌
```xml
<ip-address-ranges>10.0.0.0/8,192.168.0.0/16</ip-address-ranges>
```

---

## 5. Boolean Fields

- Use lowercase `true` / `false`
- Never use `1/0` or `yes/no`

✅
```xml
<enabled>true</enabled>
```

❌
```xml
<enabled>1</enabled>
```

---

## 6. Numeric Fields

- No quotes
- No units
- No commas

✅
```xml
<priority>100</priority>
```

❌
```xml
<priority>"100"</priority>
<priority>100ms</priority>
```

---

## 7. Strings and Special Characters

- Escape XML reserved characters inside text nodes
  - `&` → `&amp;`
  - `<` → `&lt;`
  - `>` → `&gt;`

✅
```xml
<description>Finance &amp; Accounting Network</description>
```

---

## 8. Ordering and Consistency

- Maintain **consistent element ordering** within repeated objects
- Prefer deterministic generation over opportunistic ordering

Example (recommended pattern):
```xml
<object>
  <name>example</name>
  <description>example description</description>
  <ip-address-ranges>10.1.0.0/16</ip-address-ranges>
  <enabled>true</enabled>
</object>
```

---

## 9. Validation Checklist (Pre‑Output)

Before emitting XML, an LLM SHOULD internally validate:

- XML is well‑formed
- All IP addresses parse successfully
- CIDR prefix lengths are numeric and within valid range
- No empty elements where values are required
- No escaped tags unless explicitly required

---

## 10. Versioning

This document is **v1**.

Future versions may add:
- Full schema‑specific examples
- IPv6 enforcement rules
- Object‑level dependency validation

---

**End of Secure Network Analytics XML Formatting Guide (v1)**
