# ⚠ DEPRECATED — patch all ip locations

**Status: PERMANENTLY DEPRECATED as of 2026-04-14**

This script and its documentation are obsolete. Do not use.

## Why Deprecated

The IPAM correction pipeline this script was part of has been abolished. In the new
architecture (v4.0), `all_IP_networks_v3.14` is built directly from authoritative
sources (`Store_IP_and_Address_Info.xlsx`, NMS confirmed subnets, Nautobot, ARIN).
There is nothing to patch.

- `cidr_24` — **abolished** as an authoritative data source
- `cidr_16` — **abolished** as an authoritative data source
- `patch_all_ip_locations.py` — location patching no longer needed
- `patch_cidr24_location.py` — cidr_24 abolished
- `patch_cidr24.py` — retail /24 parent rows now in `all_IP_networks` directly

## Replacement

Use `all_IP_networks_v3.14.csv` directly. It contains:
- All enterprise subnet→location mappings (19,421 rows)
- Retail /24 parent rows with `CONTESTED_BLOCK` flag for 172.x
- Cloud, VPN, COLO, Distribution — all confirmed from authoritative sources

For retail device and store data, use `retail_networks_v2.1.csv` (294,355 rows).

See `README_platform_rules.md` v4.0 for the current architecture.

---

*Original documentation preserved below for historical reference only.*

---
# patch_all_ip_locations.py — all_IP_networks Location Corrector

**Version:** v1.0 (pending build)  
**Type:** Python  
**Role:** Applies `location_master_table_v2` corrections and `CVS-Location-Data-11-25` type validation to `all_IP_networks`, producing a corrected versioned output. This is the first step in the IPAM correction pipeline.

---

## Overview

`all_IP_networks_v2.5` contains 5,913 rows with stale or wrong Location values. This script applies the `location_master_table_v2` mapping table (280 raw→canonical mappings) and validates location type assignments using the authoritative `CVS-Location-Data-11-25.csv` (14,007 entries).

```
all_IP_networks_v2.5.csv (75,755 rows)
location_master_table_v2.csv (280 mappings)
CVS-Location-Data-11-25.csv (14,007 authoritative entries)
    ↓
    ├── Apply location_master_table corrections   → fix 3,907 stale values
    ├── Validate site type from CVS location data → flag misclassified sites
    └── Flag Store/Distribution/Branch rows
        incorrectly typed as DataCenter
    ↓
all_IP_networks_v2.6.csv
patch_all_ip_locations_report.txt
```

---

## Status

**NOT YET BUILT** — this is the first task for Session 4.

---

## When to Run

Run this before `patch_cidr24_location.py`. Every downstream dataset depends on clean locations in `all_IP_networks`.

```
patch_all_ip_locations.py        ← produces all_IP_networks_v2.6
    → patch_cidr24_location.py   ← produces cidr_24_v2.7
    → enrich_app_datasets.py     ← produces ent_host_master_v<DATE>
    → reports and maps
```

---

## Planned Usage

```bash
# Standard run
python3 patch_all_ip_locations.py --db-dir ipam-db/

# With explicit CVS location data
python3 patch_all_ip_locations.py \
    --db-dir ipam-db/ \
    --location-data CVS-Location-Data-11-25.csv

# Dry run
python3 patch_all_ip_locations.py --db-dir ipam-db/ --dry-run
```

---

## Corrections to Apply

### Stale Location values (fixable via location_master_table_v2)

| Current Value | Correct Value | Rows |
|---|---|---|
| `Center TX` | `Irving TX - Corporate` | 1,915 |
| `Scottsdale AZ - Aetna SDC` | `Phoenix AZ - Cotton Center (Aetna SDC)` | 591 |
| `Wall, NJ` | `Wall NJ - Corporate` | 381 |
| `Nashville, TN` | `Nashville TN - Corporate` | 271 |
| `Wilkes Barre, PA` | `Wilkes-Barre PA - Corporate` | 255 |
| `Florham Park, NJ` | `Florham Park NJ - Corporate` | 217 |
| `Mount Prospect IL` | `Mount Prospect IL - Corporate` | 320 |
| + 15 more | various | ~357 |
| **Total fixable** | | **3,907** |

### Blank Location (13,769 rows)
Mostly retail store /26 blocks and unallocated space. Not fixable via location master — these inherit from retail_networks or remain blank.

### Location Type Validation
Any row where Location maps to a `Store`, `Distribution`, or `Branch` entry in `CVS-Location-Data-11-25.csv` but has `FACILITY_TYPE=DataCenter` should be flagged and corrected.

---

## Output

### all_IP_networks_v2.6.csv

Same schema as v2.5 with corrected Location field. Register with:
```bash
./ipam-db.py --import ipam-db/all_IP_networks_v2.6.csv \
    --type all_IP_networks \
    --description "Location corrections applied: 3,907 rows fixed from location_master_table_v2"
```

### patch_all_ip_locations_report.txt

Counts of corrections by old value → new value.
