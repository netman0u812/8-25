# generate_fw_rule_report.py — Firewall Rule Recommendation Report

**Version:** v1.2  
**Type:** Python  
**Role:** Analyses Palo Alto firewall Splunk log exports and produces a self-contained interactive HTML report with per-host rule recommendations, full source and destination enrichment, and PA policy rule specifications.

---

## Overview

`generate_fw_rule_report.py` reads one or more Splunk firewall traffic CSV exports, enriches every flow using three data layers, derives a rule action (BLOCK / REVIEW / MONITOR / ALLOW) for each unique src→dst:port combination, and writes a single-file interactive HTML report with six tabs.

```
Splunk CSV log(s) or directory
    ↓
    ├── all_IP_networks LPM     → source IP prefix context (site, BU, PCI, risk, facility, CANONICAL_LOCATION)
    ├── ent_host_master.csv     → per-host identity (hostname, OS, app, APM IDs, CSNA path)
    ├── parse_hostname.py       → site/env/heritage from hostname structure
    ├── ip_dataset_*.csv        → destination provider (AWS, Google, Zscaler, Cloudflare…)
    ├── Supplement table        → Cisco Umbrella, Dynatrace, Meta, AT&T, Shopify, Limelight…
    └── GeoIP (geo_ip.py)       → country, city, ASN, high-risk flagging
    ↓
fw_report_NNNNNN-YYYYMMDD.html  (self-contained, ~2MB with GeoIP)
```

---

## v1.2 Changes

- **Auto-detection** — `--dataset-dir`, `--ip-dataset-dir`, `--ent-master` all auto-discovered. Run with no flags.
- **Directory support for `--log`** — pass a directory to stitch all CSVs into one report, sorted chronologically by mtime.
- **`--log-dir` alias** — explicit alias for `--log DIR`.
- **GeoIP fixed** — `geo_ip.py` v1.1 now accepts `load_us_geo=True` parameter. `stats()` returns `asn` and `us_geo` keys. Auto-discovers `ip_geo/` relative to script location regardless of `--dataset-dir`.

---

## Prerequisites

No third-party packages required. All imports are stdlib.

```bash
# Optional: verify files are in place
./generate_fw_rule_report.py --check
```

---

## Required Files

| File | Required | Purpose |
|---|---|---|
| `ipam-db/all_IP_networks_v3.14.csv` | Yes | Source IP LPM enrichment (single source of truth) |
| `ipam-db/ent_host_master_v*.csv` | Recommended | Per-host hostname, app, BU, CSNA path |
| `ipdatasets/ip_dataset_*.csv` | Recommended | Destination provider identification |
| `geo_ip.py` + `ip_geo/` files | Optional | Country, city, ASN, high-risk on dest IPs |
| `parse_hostname.py` | Auto-loaded | Site/env/heritage from hostname |

---

## Usage

```bash
# Zero flags — auto-detects everything from script directory
./generate_fw_rule_report.py --log 1HR_80_and_443_NOT_TCP-FIN.csv

# Entire log directory — stitches all CSVs into one report
./generate_fw_rule_report.py --log FW_Log_Raw/

# Explicit alias for directory
./generate_fw_rule_report.py --log-dir FW_Log_Raw/

# Multiple specific files
./generate_fw_rule_report.py --log file1.csv file2.csv file3.csv

# Override auto-detected paths
./generate_fw_rule_report.py \
    --log FW_Log_Raw/ \
    --dataset-dir ipam-db/ \
    --ip-dataset-dir ipdatasets/ \
    --ent-master ipam-db/ent_host_master_v20260410.csv \
    --out-dir ./fw-reports

# Dry run — stats only, no file written
./generate_fw_rule_report.py --log FW_Log_Raw/ --dry-run -v

# Check all data files and exit
./generate_fw_rule_report.py --check

# Print Splunk SPL query reference
./generate_fw_rule_report.py --splunk
```

---

## Auto-Detection Logic

| Parameter | Auto-detected from |
|---|---|
| `--dataset-dir` | `ipam-db/` next to script, then cwd |
| `--ip-dataset-dir` | Same as `--dataset-dir` |
| `--ent-master` | Latest `ent_host_master_v*.csv` in dataset-dir |
| `--log` | `FW_Log_Raw/` next to script, then cwd |

---

## CLI Reference

| Flag | Default | Description |
|---|---|---|
| `--log FILE/DIR [...]` | auto | Log file(s) or directory. Directory = stitch all CSVs. |
| `--log-dir DIR` | — | Alias for `--log DIR` |
| `--dataset-dir DIR` | auto (`ipam-db/`) | Directory containing `all_IP_networks_v*.csv` and `retail_networks_v*.csv` |
| `--ip-dataset-dir DIR` | auto (= dataset-dir) | Directory containing `ip_dataset_*.csv` |
| `--ent-master FILE` | auto (latest in dataset-dir) | `ent_host_master_v*.csv` |
| `--out-dir DIR` | `./fw-reports` | Output directory |
| `--min-pkts N` | `10` | FULL schema: minimum total packets to count as established |
| `--title TEXT` | auto | Report title override |
| `--dry-run` | off | Parse + analyse, print stats, write no files |
| `-v` / `--verbose` | off | Verbose progress output |
| `--splunk` | — | Print Splunk SPL query reference and exit |
| `--check` | — | Validate all input files, print status, exit |

---

## Supported Log Schemas

Auto-detected from column headers — no configuration needed.

### FULL Schema (recommended)
Produced by Splunk aggregation with `packets_out` and `packets_in`. `--min-pkts` threshold (default 10) filters to established sessions only.

Required columns: `src_ip`, `dest_ip`, `dest_port`, `packets_out`, `packets_in`, `src_zone`, `dest_zone`, `dvc`, `session_end_reason`, `flags`, `app`

### FLOW Schema (pre-aggregated TCP-FIN)
Each row is a confirmed completed session.

Required columns: `src_ip`, `src_port`, `dest_ip`, `dest_port`, `src_zone`, `dest_zone`, `dvc`, `flags`, `app`, `session_end_reason`

---

## Splunk SPL Queries

Run `--splunk` for the full reference. Two primary queries:

**Query 1C — Ports 80/443, NOT TCP-FIN (aged-out web sessions):**
```spl
index=pan_logs sourcetype=pan:traffic
    (dest_port=80 OR dest_port=443)
    session_end_reason!=tcp-fin
| stats
    sum(packets_out) AS packets_out  sum(packets_in) AS packets_in
    values(src_zone) AS src_zone  values(dest_zone) AS dest_zone
    values(dvc) AS dvc  values(session_end_reason) AS session_end_reason
    values(flags) AS flags  values(app) AS app
    by src_ip dest_ip dest_port
| table src_ip src_zone dest_ip dest_zone dest_port
        packets_out packets_in dvc session_end_reason flags app
```

**Query 2A — All ports, TCP-FIN (confirmed sessions):**
```spl
index=pan_logs sourcetype=pan:traffic
    session_end_reason=tcp-fin
| where src_port > 1023
| dedup src_ip src_port dest_ip dest_port
| table src_ip src_port src_zone dest_ip dest_port dest_zone
        dvc flags fields app session_end_reason
```

---

## Source Enrichment

**Layer 1 — all_IP_networks LPM:**
- Site, canonical location, facility type, routing domain, owner, BU
- PCI designation, risk tier
- FW policy zone
- `all_IP_networks_v3.14` is the single authoritative source — no overlay needed

**Layer 2 — ent_host_master (per-host):**
- Server name, FQDN, OS group + version
- Server class (Windows/Linux/ESX/AIX/Kubernetes)
- Application name, acronym, APM IDs
- Business unit, heritage (CVS/AETNA/HCB)
- CSNA hostgroup path
- Environment (PROD/DEV/TEST/QA/UAT)
- Data source flags (IN_SNOW/IN_QUALYS/IN_WIZ)

**Layer 3 — parse_hostname.py (auto-loaded):**
- Parsed site code → DC name (PAZ→Shea, RRI→Woonsocket, EAW→AWS-East)
- Environment from role code
- Heritage from hostname prefix

---

## Destination Enrichment

**Layer 1 — ip_dataset LPM:**
Longest-prefix-match against all `ipdatasets/ip_dataset_*.csv`. Provider, service, region, service type.

**Layer 2 — Supplemental table (built-in):**
Fills gaps: Cisco Umbrella, Cloudflare, Zscaler, Dynatrace, Meta, Microsoft Teams, Fastly, Limelight, AT&T, Apple, Shopify, Automattic.

**Layer 3 — GeoIP (`geo_ip.py` + `ip_geo/`):**
Country, city, ASN/org from IP2Location LITE + ip2asn. High-risk countries (13 OFAC/watchlist) escalate to REVIEW. Loaded automatically when `geo_ip.py` is present in same directory as report script.

---

## Rule Logic

| Action | Condition |
|---|---|
| `BLOCK` | Critical port (SMTP/23/SMB/RDP/VNC/RPC) |
| `REVIEW` | Destination country on sanctions/watchlist |
| `REVIEW` | High-risk port to unclassified destination |
| `REVIEW` | Medium-risk port to unclassified destination |
| `MONITOR` | Known provider (IAAS/SAAS), medium-risk port |
| `MONITOR` | Low-risk port to unclassified destination |
| `ALLOW` | Cisco Umbrella DNS |
| `ALLOW` | Known IAAS/SAAS provider, low-risk port |

---

## Report Tabs

| Tab | Contents |
|---|---|
| 🔍 Key Findings | Session lifecycle funnel, up to 8 finding cards, modal drill-downs |
| 📋 Rule Candidates | Per-flow rule cards with action badge, host identity, PA rule spec, dest geo |
| ⚠ Port Risk | Every port seen, sorted by volume, risk level, security note |
| 🖥 Source /24s | Source subnets collapsible, per-IP hostname, OS, app, BU, CSNA path |
| 📡 Destinations | Dest IPs with provider, service, country, city, ASN, ARIN/Shodan/BGPView links |
| 🗺 Flow Map | Sankey and Arc visualisations of src location → dest provider |

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.3 | 2026-04-14 | **cidr_24 overlay removed** — `all_IP_networks_v3.14` is single source of truth |
| v1.2 | 2026-04-14 | Auto-detect dirs and ent-master; `--log DIR` stitching; `--log-dir` alias; GeoIP compatibility fix |
| v1.0 | 2026-04-10 | Initial release |
