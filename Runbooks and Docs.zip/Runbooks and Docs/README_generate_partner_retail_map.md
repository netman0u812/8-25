# generate_partner_retail_map.py — Partner & Retail Connection Map

**Version:** v1.x  
**Type:** Python  
**Role:** Generates an interactive HTML map showing S2S VPN partner connections and retail store circuit topology across CVS Health's MPLS and SD-WAN network.

---

## Overview

```
ent-ipdataset-S2S-VPN-PARTNERS → VPN peer registry (partners, healthcare providers)
retail_networks_v2.1.csv        → retail store /26 + device /32 allocations by state
ent-ipdataset-NETWORK-DEVICE-INVENTORY → MPLS L3 VPN carrier circuits (optional)
    ↓
Partner_Retail_Map.html (self-contained HTML)
```

---

## Usage

```bash
python3 generate_partner_retail_map.py --db-dir ipam-db/

# With NMS for carrier circuit data
python3 generate_partner_retail_map.py \
    --db-dir ipam-db/ \
    --nms ipam-db/ent-ipdataset-NETWORK-DEVICE-INVENTORY-v20260413.csv
```

---

## CLI Reference

| Flag | Default | Description |
|------|---------|-------------|
| `--db-dir DIR` | `ipam-db/` | IPAM directory |
| `--nms FILE` | auto | Network device inventory for carrier circuits (optional) |
| `--out FILE` | `Partner_Retail_Map.html` | Output file |

---

## Map Features

- S2S VPN partner nodes with peer IP, IKE version, PFS group
- Retail store counts by state with /26 block distribution
- MPLS L3 VPN carrier circuit overlay when NMS data available
- Partner type classification (healthcare, financial, logistics)

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.1 | 2026-04-14 | Updated to use `retail_networks_v2.1` — includes device /32s, INFRA_ROLE, NETWORK_ADDRESS fields |
