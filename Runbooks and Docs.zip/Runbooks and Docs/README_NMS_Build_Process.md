# README — NMS Network Device Master Build Process

**Script:** `build_network_device_master.py` v2.5  
**Review Tool:** `network_device_review.py` v1.0  
**Output:** `ent_network_device_master_vYYYYMMDD.csv`

---

## Overview

The Network Device Master (`ent_network_device_master`) is the authoritative record of every network infrastructure device in CVS Health. It is built from multiple sources, each covering a different population, and is registered in `ipam-db` for use by the FW enrichment pipeline, CSNA host group generator, and IP lookup tools.

The build process is a four-step workflow: **Build → Review → Confirm → Import**.

```
Source Files
    │
    ├── Netbrain export         site_ip_report_*.csv       24,857 devices
    ├── FW Inventory            fw-inv-3-26.csv               748 devices
    ├── CMDB CI appliances      CI-inv-*.csv                   52 devices
    └── Cisco FMC tracker       Cisco_FMCs.csv                 17 devices
    │
    ▼
build_network_device_master.py
    │
    ├── ent_network_device_master_vYYYYMMDD.csv   ← NDR master (BLOCKED until review clean)
    ├── network_device_review_vYYYYMMDD.csv        ← Flagged records for review
    ├── network_end_devices_vYYYYMMDD.csv           ← Netbrain end devices (staged, not NDR)
    └── network_unassigned_vYYYYMMDD.csv            ← Netbrain unassigned (staged, not NDR)
    │
    ▼
network_device_review.py
    │
    └── review_decisions.json                       ← Persisted resolutions
    │
    ▼
build_network_device_master.py --confirm
    │
    └── Clean ent_network_device_master_vYYYYMMDD.csv
    │
    ▼
ipam-db.py --import
```

---

## Source Files

### 1. Netbrain Export (`--netbrain`)
**File:** `IP_Datasets_Raw/NMS-Source/site_ip_report_4-13-26.csv`  
**Format:** One row per device interface (interface-level export)  
**Columns:** `Hostname, Interface Name, Device Type, Vendor, Model, Site, Location, IPv4 Address, Live Status`

The script collapses this to one row per device:
- Management IP = first interface with `up/up` live status
- Connected subnets = all interface IPs pipe-separated
- Location = decoded from Netbrain site hierarchy path

**Routing:**
- `My Network\End Devices` → staged to `network_end_devices_vYYYYMMDD.csv` (not NDR)
- `My Network\Unassigned` → staged to `network_unassigned_vYYYYMMDD.csv` (not NDR)
- All others → NDR with decoded location

**Site path decoding:** `My Network\North America\STATE\CITY\SITE_TYPE\SITE_NAME`  
Known naming corrections are applied automatically (e.g. `Hartfort CT` → `Hartford CT - Aetna HQ`).

### 2. FW Inventory (`--fw-inv`)
**File:** `IP_Datasets_Raw/FW_Inv/fw-inv-3-26.csv`  
**Format:** One row per firewall device  
**Columns:** `domain, tenant, vendor, manager, hostname, model, version, ip, serial, firewall_type, category, status, hardware_eos, software_eos, decommission_status, ...`

This is the **source of truth for the firewall estate**. It covers 748 devices, approximately 300 of which are not in the Netbrain export (cloud FTDs, ASA security contexts, CDO-only devices).

Location is resolved via IPAM LPM on management IP. Extended fields (`HW_EOS`, `SW_EOS`, `DECOMMISSION_YEAR`, `FW_DOMAIN`, `FW_TENANT`) are preserved in the NDR for lifecycle tracking.

Active/decommission status is derived from the `status` and `decommission_status` fields.

### 3. CMDB CI Appliances (`--ci-inv`)
**File:** `IP_Datasets_Raw/FW_Inv/CI-inv-1-26.csv`  
**Format:** One row per CI appliance (from ServiceNow CMDB export)  
**Columns:** `CI, IP_ADDRESS, LOCATION, HERITAGE, DEVICE_TYPE, PROTECTS, LOC_CONFIDENCE, ...`

These are Sourcefire IDS/IPS sensors and management stations that exist **only in CMDB** — not polled by Netbrain, not in FW Inventory. All 52 are net-new to NDR.

Location is pre-resolved in the file; the build script uses it directly without further resolution.

### 4. Cisco FMC Tracker (`--fmc-inv`)
**File:** `IP_Datasets_Raw/FW_Inv/Cisco_FMCs.csv`  
**Format:** FMC upgrade/migration tracker (one row per FMC group, may contain multiple IPs)  
**Columns:** `Type, DIV, FMC, FMC Hostname, FMC IP, SW Version, ...`

FMCs are **management appliances** — location is derived from **management IP only**, not hostname prefix. IP is the authoritative location indicator for management devices.

The script parses multiple hostnames and IPs per row (space-separated in quoted fields) and produces one NDR row per FMC instance.

---

## Build Commands

### Step 1 — Dry Run (always run first)
```bash
python3 build_network_device_master.py \
  --netbrain ./IP_Datasets_Raw/NMS-Source/site_ip_report_4-13-26.csv \
  --fw-inv   ./IP_Datasets_Raw/FW_Inv/fw-inv-3-26.csv \
  --ci-inv   ./IP_Datasets_Raw/FW_Inv/CI-inv-1-26.csv \
  --fmc-inv  ./IP_Datasets_Raw/FW_Inv/Cisco_FMCs.csv \
  --ipam-dir ./ipam-db/ \
  --out-dir  ./ipam-db/ \
  --dry-run
```

Review the delta report:
- **NEW devices** — net-new to NDR (expected: ~364)
- **DROPPED genuine** — devices in NDR not in any source (should be 0 or near-0)
- **Separated to staging** — end devices and unassigned (intentional, not drops)
- **IP changes** — management IP differs between NDR and new source
- **Location changes** — location differs between NDR and new source

### Step 2 — Run (writes review queue, does NOT write master)
```bash
python3 build_network_device_master.py \
  --netbrain ./IP_Datasets_Raw/NMS-Source/site_ip_report_4-13-26.csv \
  --fw-inv   ./IP_Datasets_Raw/FW_Inv/fw-inv-3-26.csv \
  --ci-inv   ./IP_Datasets_Raw/FW_Inv/CI-inv-1-26.csv \
  --fmc-inv  ./IP_Datasets_Raw/FW_Inv/Cisco_FMCs.csv \
  --ipam-dir ./ipam-db/ \
  --out-dir  ./ipam-db/
```

This writes the review queue and staging files. The master is **blocked** until the review queue is cleared.

### Step 3 — Review
```bash
python3 network_device_review.py \
  --review    ./ipam-db/network_device_review_vYYYYMMDD.csv \
  --decisions ./ipam-db/review_decisions.json \
  --ipam-dir  ./ipam-db/
```

Review tiers processed in order:

**T1 — Naming Mismatch**  
Netbrain site path decoded to a name not in location_master. Suggests closest canonical match.  
`[A]ccept suggestion / [E]dit manually / [S]kip / [Q]uit`

**T2 — IP Conflict**  
Management IP changed between NDR and new source. Shows IPAM LPM result for both IPs. Auto-accepts if both resolve to the same location.  
`[A]ccept new / [K]eep old / [S]kip / [Q]uit`

**T3 — Location Conflict**  
Location disagrees between NDR and new source. Shows old vs new with IPAM cross-check.  
`[A]ccept new / [K]eep old / [O]verride / [S]kip / [Q]uit`

**T4 — Location Unknown**  
No location from any source. Shows IPAM LPM and hostname prefix suggestions.  
`[A]ccept suggestion / [E]nter manually / [S]kip / [Q]uit`

Decisions are saved to `review_decisions.json` after each tier. Re-run the review tool to continue where you left off. Once all items are decided, re-run the build — approved decisions are applied automatically before conflict detection, so resolved items never re-appear.

Check status at any time:
```bash
python3 network_device_review.py --status --decisions ./ipam-db/review_decisions.json
```

### Step 4 — Confirm Build (writes master)
```bash
python3 build_network_device_master.py \
  --netbrain ./IP_Datasets_Raw/NMS-Source/site_ip_report_4-13-26.csv \
  --fw-inv   ./IP_Datasets_Raw/FW_Inv/fw-inv-3-26.csv \
  --ci-inv   ./IP_Datasets_Raw/FW_Inv/CI-inv-1-26.csv \
  --fmc-inv  ./IP_Datasets_Raw/FW_Inv/Cisco_FMCs.csv \
  --ipam-dir ./ipam-db/ \
  --out-dir  ./ipam-db/ \
  --confirm
```

The master file is only written when:
- Review queue is empty (0 flagged records)
- Genuine drops are under 5% of current NDR
- `--confirm` flag is passed

### Step 5 — Import
```bash
python3 ipam-db.py \
  --import ./ipam-db/ent_network_device_master_vYYYYMMDD.csv \
  --type ent_network_device_master
```

---

## Output Files

| File | Contents | Registered in ipam-db |
|---|---|---|
| `ent_network_device_master_vYYYYMMDD.csv` | Full NDR — all managed network devices | Yes |
| `network_device_review_vYYYYMMDD.csv` | Flagged records requiring review | No |
| `network_end_devices_vYYYYMMDD.csv` | Netbrain end devices (workstations, printers) | No — staging only |
| `network_unassigned_vYYYYMMDD.csv` | Netbrain unassigned devices | No — staging only |

---

## NDR Schema

| Column | Description |
|---|---|
| `HOSTNAME` | Device hostname |
| `DEVICE_TYPE` | NMS device type string |
| `VENDOR` | Cisco / Palo Alto / F5 / etc. |
| `MODEL` | Hardware model |
| `DEVICE_CLASS` | ROUTER / SWITCH / FIREWALL / LOAD_BALANCER / WLC / SBC_VOIP / VOICE_GW / MGMT / CLOUD_FW / OTHER |
| `INFRA_ROLE` | WAN_EDGE / CORE / DISTRIBUTION / ACCESS / SECURITY / ADC / WIRELESS / VOIP / MGMT / CLOUD |
| `CANONICAL_LOCATION` | Resolved canonical location |
| `LOCATION_TYPE` | Datacenter / Corporate / Call-Center / etc. |
| `HERITAGE` | CVS / AETNA / OMNICARE / etc. |
| `LOCATION_SOURCE` | NMS_FIELD / IPAM_LPM / HOSTNAME_PREFIX / SITE_CLASS |
| `LOCATION_CONFIDENCE` | HIGH / MEDIUM / LOW |
| `MANAGEMENT_IP` | Primary management IP |
| `CONNECTED_SUBNETS` | All interface IPs (pipe-separated) |
| `INTERFACE_COUNT` | Number of interfaces |
| `VOIP_ROLE` | SBC_EAST / SBC_WEST / VOICE_GW / FIVE9S_CLOUD_PEERING / blank |
| `STATUS` | Active / Decom / Unknown |
| `REVIEW_REQUIRED` | LOCATION_CONFLICT / LOCATION_UNKNOWN / NAMING_MISMATCH / blank |
| `REVIEW_REASON` | Human-readable explanation |
| `REVIEW_TIER` | T1_NAMING / T2_IP_CONFLICT / T3_LOCATION_CONFLICT / T4_UNKNOWN |
| `SOURCE_FILE` | NETBRAIN / FW_INVENTORY / FMC_INVENTORY / CMDB_CI / NMS_KNOWN / etc. |
| `HW_EOS` | Hardware end-of-support date (FW Inventory sourced) |
| `SW_EOS` | Software end-of-support date (FW Inventory sourced) |
| `DECOMMISSION_YEAR` | Planned decommission year (FW Inventory sourced) |
| `FW_DOMAIN` | CVS / HCB (FW/FMC sourced) |
| `FW_TENANT` | Business unit / tenant (FW/FMC sourced) |
| `FW_CATEGORY` | Physical / Virtual / FMC-Management |
| `FW_TYPE` | Firewall zone/role classification |
| `DATASET_VERSION` | Build date stamp |
| `BUILD_DATE` | Build date |

---

## Location Resolution — Priority Order

1. **Pre-decoded location** (CMDB CI and FMC files have location pre-resolved — used directly)
2. **NMS field** (Netbrain site hierarchy path, decoded and corrected)
3. **IPAM LPM** (longest-prefix match on management IP against `all_IP_networks`)
4. **Hostname prefix map** (CVS enterprise naming convention table — 200+ prefixes)
5. **SITE_CLASS map** (for legacy 5-file NMS source — maps site class strings to canonical names)

**For FMC devices:** Only step 1 (if pre-resolved) or step 3 (IPAM LPM) are used. Hostname prefix is intentionally skipped — IP is authoritative for management appliances.

**Review decisions** (`review_decisions.json`) are applied before steps 2–5, so previously approved resolutions are honoured without re-flagging.

---

## Naming Corrections

The following Netbrain site path decoding errors are corrected automatically at build time:

| Netbrain decodes to | Corrected to |
|---|---|
| `Hartfort CT - Corporate` | `Hartford CT - Aetna HQ` |
| `Wilkes Barre PA - Specialty` | `Wilkes Barre PA - Mail Order` |
| `Cumberland RI - DC` | `Cumberland RI - 2100 Highland` |
| `Cumberland RI - Corporate` | `Cumberland RI - 2100 Highland` |
| `San Antonio TX - Specialty` | `San Antonio TX - Mail Order` |
| `Middletown CT - DC` | `Middletown CT - Aetna MDC` |
| `Windsor CT - DC` | `Windsor CT - Aetna WDC` |
| `Ashburn VA - Corporate` | `Ashburn VA - Equinix HCB` |
| `Tallahassee FL - Corporate` | `Tallahassee FL - Specialty` |
| `Parasippany NJ - Corporate` | `Parsippany NJ - Corporate` |
| `Dowers Grove IL - Corporate` | `Downers Grove IL - Corporate` |
| `Aetna WA - Corporate` | `Bellevue WA - Corporate` |

Additional corrections can be added to `NB_NAMING_CORRECTIONS` in `build_network_device_master.py`.

---

## Safety Gates

The build will not write the master file unless all of the following are true:

1. **Review queue is empty** — 0 records flagged
2. **Genuine drops < 5%** — devices in NDR not found in any new source (end devices and unassigned are excluded from this count — their separation is intentional)
3. **`--confirm` flag is passed** — explicit human sign-off required

Use `--force` to override safety gates (not recommended for production imports).

---

## Cadence

Run the NMS build whenever:
- A new Netbrain export is available (typically monthly)
- The FW inventory is updated (`fw-inv-*.csv`)
- New CI appliances are added to CMDB
- FMC inventory changes

Always run `--dry-run` first to review the delta before committing.

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v2.5 | 2026-04-28 | Added `--fmc-inv` for Cisco FMC tracker; FMC location from IP only (not hostname); added FMC to DEVICE_CLASS_MAP |
| v2.4 | 2026-04-28 | Added `--ci-inv` for CMDB CI appliance list (52 Sourcefire sensors) |
| v2.3 | 2026-04-28 | Added `--netbrain` for Netbrain interface-level export; end device / unassigned separation; naming correction map; site hierarchy decoder |
| v2.2 | 2026-04-28 | Added `--fw-inv` for FW inventory database; extended schema (HW_EOS, SW_EOS, decommission, FW_DOMAIN etc.) |
| v2.1 | 2026-04-16 | Delta comparison against current NDR; `--confirm` / `--force` gates |
| v2.0 | 2026-04-16 | Initial v2 — merged 5 NMS source files; location resolution; IPAM LPM enrichment |
