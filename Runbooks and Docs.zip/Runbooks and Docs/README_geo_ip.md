# geo_ip.py — Standalone GeoIP Lookup Tool

**Version:** v1.2 (pending fix — see Known Issues)  
**Type:** Python  
**Role:** Country, region, city, ASN, and high-risk classification for any IPv4 address or CIDR. Used standalone from the CLI and imported by `generate_fw_rule_report.py` and `generate_fw_enrichment.py`.

---

## Overview

`geo_ip.py` provides multi-layer IP geolocation from four data sources loaded at startup:

- **IP2Location DB11** (region/city/lat/lon/zip/timezone, 3.6M networks) — primary
- **IP2Location DB1** (country-level, 369K networks) — fallback if DB11 absent
- **iptoasn BGP table** (ASN + org name, 442K ranges)
- **NetworksDB US geo** (US CIDR → city/state, 2.8M networks) — optional US override

All data files live in the `ip_geo/` subdirectory. The tool finds them automatically regardless of which directory it is called from.

---

## Data Sources

| File | Rows | Purpose | Update |
|---|---|---|---|
| `IP2LOCATION-LITE-DB11.CIDR.CSV` | 3.6M | Region/city/lat/lon/zip/tz (primary) | Monthly |
| `IP2LOCATION-LITE-DB1.CIDR.CSV` | 369K | Country only (fallback) | Monthly |
| `IP2LOCATION-COUNTRY-INFORMATION.CSV` | 249 | Capital, currency, IDD, TLD | Rarely |
| `ip2asn-v4.tsv` | 442K | ASN + org name (BGP table) | Daily available |
| `us_geo_networksdb.tsv` | 2.8M | US CIDR → city/state/lat/lon | As updated |
| `geo_ip_high_risk.json` | 13 | High-risk country config | Edit manually |

Download IP2Location LITE files from https://lite.ip2location.com (free account)  
iptoasn feed: https://iptoasn.com/data/ip2asn-v4.tsv.gz (auto-downloaded by `--update --asn`)

---

## Directory Layout

All data files must be in `ip_geo/` under the `IP_Lookup/` root:

```
IP_Lookup/
├── geo_ip.py
└── ip_geo/
    ├── IP2LOCATION-LITE-DB11.CIDR.CSV
    ├── IP2LOCATION-LITE-DB1.CIDR.CSV
    ├── IP2LOCATION-COUNTRY-INFORMATION.CSV
    ├── ip2asn-v4.tsv
    ├── us_geo_networksdb.tsv
    └── geo_ip_high_risk.json
```

**Note:** These files belong in `ip_geo/` only — never in `ipam-db/` or `ipdatasets/`.

---

## Setup

```bash
# Copy IP2Location files to ip_geo/
cp ~/Downloads/IP2LOCATION-LITE-DB11.CIDR.CSV ./ip_geo/
cp ~/Downloads/IP2LOCATION-LITE-DB1.CIDR.CSV  ./ip_geo/   # optional if DB11 present
cp ~/Downloads/IP2LOCATION-COUNTRY-INFORMATION.CSV ./ip_geo/

# Download ASN feed (auto-downloads ip2asn-v4.tsv)
./geo_ip.py --update --asn

# Verify everything loaded correctly
./geo_ip.py --stats
```

---

## CLI Usage

```bash
# Single lookup
./geo_ip.py --lookup 8.8.8.8
./geo_ip.py --lookup 1.0.0.0/24

# Batch lookup
./geo_ip.py --lookup-file ips.txt
./geo_ip.py --lookup-file ips.txt --csv

# Data management
./geo_ip.py --update                  # validate + create high-risk config
./geo_ip.py --update --asn            # also download fresh iptoasn feed
./geo_ip.py --update --db11-file ~/Downloads/IP2LOCATION-LITE-DB11.CIDR.CSV

# Reporting
./geo_ip.py --list-sources            # show all data files, sizes, dates
./geo_ip.py --stats                   # coverage check + file details
./geo_ip.py --high-risk               # list all high-risk countries
./geo_ip.py --country CN              # show all CIDRs for a country

./geo_ip.py --version
```

---

## Example Output

```
GeoIP Lookup: 8.8.8.8
  ==================================================
  Country      : US -- United States of America  (USA)
  Capital      : Washington, D.C.
  IDD Code     : +1
  Currency     : USD (United States Dollar)
  ccTLD        : .us
  Matched CIDR : 8.8.0.0/15
  Region       : California
  City         : Mountain View
  ZIP          : 94035
  Timezone     : -07:00
  Coordinates  : 37.386050, -122.083850
  ASN          : AS15169 -- GOOGLE
```

---

## High-Risk Country Classification

Configured in `ip_geo/geo_ip_high_risk.json` (editable without code changes):

| Category | Countries |
|---|---|
| Sanctions only | BY, CU, IR, KP, MM, SD, SY, VE, ZW |
| Sanctions + Security Watchlist | RU |
| Security Watchlist only | AZ, CN, KZ |

---

## Python Module API

```python
from geo_ip import GeoIPLookup

# Finds ip_geo/ automatically relative to geo_ip.py location
geo = GeoIPLookup('/path/to/IP_Lookup', load_us_geo=True)

r = geo.lookup('8.8.8.8')
# Returns dict:
# { ip, country_code, country_name, alpha3, capital,
#   currency, currency_name, idd_code, cctld,
#   is_high_risk, risk_reason, matched_cidr,
#   region, city, latitude, longitude, zip_code, timezone,
#   asn, as_name }

# Batch
results = geo.lookup_batch(['8.8.8.8', '1.0.1.1', '43.249.72.1'])

geo.is_loaded()   # True if DB11 or DB1 loaded
geo.stats()       # dict: networks, db11, asn, us_geo, countries, high_risk, dataset_dir
```

### stats() keys

| Key | Description |
|---|---|
| `networks` | Total networks in primary DB |
| `db11` | DB11 network count (0 if only DB1 loaded) |
| `asn` | ip2asn range count |
| `us_geo` | US geo network count |
| `countries` | Country metadata entries |
| `high_risk` | High-risk country count |
| `dataset_dir` | Resolved dataset directory |

---

## Integration with generate_fw_rule_report.py

`geo_ip.py` is auto-loaded by `generate_fw_rule_report.py` when it is present in the same directory. No configuration needed. The report looks for `ip_geo/` relative to the script location, then the parent directory.

When loaded, the report logs:
```
GeoIP loaded: 3,666,788 country CIDRs, 442,210 ASN records
```

High-risk country destinations are automatically escalated to REVIEW in rule recommendations.

---

## Monthly Update Process

```bash
# 1. Download new DB11 from https://lite.ip2location.com
# 2. Update and refresh ASN feed
./geo_ip.py --update \
    --db11-file ~/Downloads/IP2LOCATION-LITE-DB11.CIDR.CSV \
    --asn

# 3. Verify
./geo_ip.py --stats
```

DB1 is optional — DB11 is a superset containing all DB1 data plus city/region/lat/lon.

---

## Known Issues (v1.1 — fixed in v1.2)

| Bug | Symptom | Fix |
|-----|---------|-----|
| Startup performance | Loading 6.7M rows takes >60s; most CLI commands time out | Pickle cache — built on first run, instant on subsequent runs |
| CIDR network-address miss | `--lookup 8.8.8.0/24` returns "No GeoIP match" | `bisect_right(table, (ip_int+1,))` — exact network address off-by-one |
| `--stats` output | Test expects file names in stdout; they were only in stderr | Print file names + row counts in `do_stats()` stdout |

See `GEO_IP_FIX_PROMPT.md` for full root cause analysis and fix instructions.

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.2 | 2026-04-14 (pending) | Startup pickle cache (fix 60s+ load times); CIDR network-address lookup fix (`bisect_right` off-by-one on exact match); `--stats` output now includes data file names for test compatibility |
| v1.1 | 2026-04-14 | `load_us_geo` parameter added; `stats()` returns `asn` and `us_geo` keys; `us_geo_networksdb.tsv` support; auto-discovery searches parent of dataset_dir |
| v1.0 | 2026-04-07 | Initial release |
