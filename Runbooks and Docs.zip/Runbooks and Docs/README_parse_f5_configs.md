# README — F5 BIG-IP Config Import Pipeline

**Script:** `parse_f5_configs.py` v1.3  
**Role:** Parses F5 BIG-IP running configs and produces ENT dataset files for registration into the CCD IPAM platform via `ipam-db.py`.

---

## Overview

```
F5 running configs (.config)
    ↓
    parse_f5_configs.py
    ↓
    ├── ent-ipdataset-F5-VIP-REGISTRY-vYYYYMMDD.csv   — one row per unique VIP IP
    ├── ent-ipdataset-F5-POOL-MEMBERS-vYYYYMMDD.csv   — one row per unique pool member IP
    └── f5_service_registry.csv                        — full VS→pool→member join table
    ↓
    ipam-db.py --import (VIP + pool members only)
    ↓
    ENT ipdatasets registered in ipam-db.json
    ↓
    generate_fw_enrichment.py (F5 VIP/pool enrichment layer)
```

The VIP registry and pool member registry are ENT datasets consumed by the FW enrichment pipeline for F5 VIP → pool member chain resolution. The service registry is a raw join table used directly by `generate_fw_enrichment.py` and is **not** registered in `ipam-db`.

---

## Prerequisites

- F5 BIG-IP running configs exported as `.config` files, collected into a single directory (flat or with subdirectories — duplicates are handled automatically)
- `parse_f5_configs.py` v1.3+ in `IP_Lookup/`
- `ipam-db.py` v3.3+ in `IP_Lookup/`

---

## Step 1 — Collect F5 configs

Export running configs from each F5 device and place them in:

```
IP_Datasets_Raw/F5_Configs/
```

Configs can be organised into subdirectories (e.g. by site or collection date). The script deduplicates by filename automatically — if the same filename appears in both a flat directory and a subdirectory, the first occurrence is used and duplicates are skipped.

**Naming convention expected:**

```
{DEVICENAME}_{YYYYMMDD}_{HHMMSS}.config
```

Example: `pazshdcf5intprd1v_20260427_064033.config`

The capture date is used to derive the output file version stamp.

**Note:** The following config types produce 0 VS and are expected — they are not errors:

| Pattern | Type | Expected |
|---|---|---|
| `cld-f5-*-rshost-*` | VELOS chassis management plane | 0 VS ✅ |
| `scd-f5-*-rhost-*` | Shea chassis sync nodes | 0 VS ✅ |
| `won-f5-*-rshost-*` | HA passive sync nodes | 0 VS ✅ |
| `woc-f5-*-rshost-*` | HA passive sync nodes | 0 VS ✅ |
| `pazshdcf5as4*-01_*` | Old chassis base (pre-vCMP) | 0 VS ✅ |

---

## Step 2 — Run the parse

```bash
cd ~/Documents/IP_Lookup

python3 parse_f5_configs.py \
  --config-dir ./IP_Datasets_Raw/F5_Configs/ \
  --out-dir ./F5_Output/
```

**Expected output:**

```
(skipped N duplicate filename(s) found in subdirectories)
Found 136 .config files
  ...

=== Parse summary ===
  Total VS parsed         : 23,112
  VS with VIP IP          : 23,061
  VS with pool            : 23,112
  VS with FQDN            : 9,950

Building f5_service_registry.csv ...
  Written: ./F5_Output/f5_service_registry.csv  (94,503 rows)
Building ent-ipdataset-F5-VIP-REGISTRY ...
  Written: ./F5_Output/ent-ipdataset-F5-VIP-REGISTRY-vYYYYMMDD.csv  (5,524 rows)
Building ent-ipdataset-F5-POOL-MEMBERS ...
  Written: ./F5_Output/ent-ipdataset-F5-POOL-MEMBERS-vYYYYMMDD.csv  (8,939 rows)
```

**Optional flags:**

```bash
# Preview only — no files written
python3 parse_f5_configs.py --config-dir ./IP_Datasets_Raw/F5_Configs/ --dry-run

# Skip VS entries with no VIP IP (forwarding/internal rules)
python3 parse_f5_configs.py \
  --config-dir ./IP_Datasets_Raw/F5_Configs/ \
  --out-dir ./F5_Output/ \
  --skip-no-vip
```

---

## Step 3 — Register into ipam-db

Import the two ENT dataset files. The version stamp (`vYYYYMMDD`) matches the date the parse was run.

```bash
python3 ipam-db.py \
  --import ./F5_Output/ent-ipdataset-F5-VIP-REGISTRY-vYYYYMMDD.csv \
  --type F5-VIP-REGISTRY \
  --description "F5 BIG-IP VIP registry — 136 configs, Shea+RI, captured YYYY-MM-DD"

python3 ipam-db.py \
  --import ./F5_Output/ent-ipdataset-F5-POOL-MEMBERS-vYYYYMMDD.csv \
  --type F5-POOL-MEMBERS \
  --description "F5 BIG-IP pool member registry — 136 configs, Shea+RI, captured YYYY-MM-DD"
```

Replace `vYYYYMMDD` with the actual date stamp in the output filename.

**Expected registry state after import:**

```
ENT ipdatasets  (registered in ip_dataset.json)
────────────────────────────────────────────────────────────────────────
✓  F5-VIP-REGISTRY     ent-ipdataset-F5-VIP-REGISTRY-vYYYYMMDD.csv   vvYYYYMMDD   5,524 rows
✓  F5-POOL-MEMBERS     ent-ipdataset-F5-POOL-MEMBERS-vYYYYMMDD.csv   vvYYYYMMDD   8,939 rows
```

Both entries must appear in **ENT ipdatasets**, not in Other Registered Datasets. If they land in Other, the filename is missing the `ent-ipdataset-` prefix — re-run with v1.3+ of the script.

Verify with:

```bash
./ipam-db.py --list
```

---

## Output file reference

### `ent-ipdataset-F5-VIP-REGISTRY-vYYYYMMDD.csv`

One row per unique VIP IP. Multiple VS on the same VIP are collapsed — ports, FQDNs, devices pipe-delimited.

| Column | Description |
|---|---|
| `IP` | VIP IP address |
| `CIDR` | VIP IP as /32 |
| `SERVER_NAME` | Primary VS name |
| `FQDN` | Primary FQDN |
| `VS_NAME` | All VS names on this VIP (pipe-delimited) |
| `VIP_PORT` | All ports (pipe-delimited) |
| `POOL_NAME` | All pools (pipe-delimited) |
| `MEMBER_COUNT` | Number of unique pool member IPs |
| `MEMBER_IPS` | Pool member IPs (pipe-delimited) |
| `F5_TIER` | INTERNAL / EXTERNAL / SECURITY / DMZ / REVERSE-PROXY / GTM |
| `F5_SITE` | SHEA / WOONSOCKET / CUMBERLAND-DC |
| `SSL_OFFLOAD` | Y/N — SSL termination at F5 |
| `HAS_IRULE` | Y/N — iRule attached |

### `ent-ipdataset-F5-POOL-MEMBERS-vYYYYMMDD.csv`

One row per unique pool member IP. Multiple pools and VS references collapsed.

| Column | Description |
|---|---|
| `IP` | Pool member IP |
| `MEMBER_STATE` | up / down / user-down / unchecked (pipe-delimited if mixed) |
| `VS_NAMES` | VS(es) this member serves (pipe-delimited, up to 5) |
| `VIP_IPS` | VIP IP(s) upstream (pipe-delimited, up to 5) |
| `POOL_NAMES` | Pool(s) the member belongs to |
| `F5_TIER` | INTERNAL / EXTERNAL / etc. |

### `f5_service_registry.csv`

Full VS → pool → member join table. One row per VS+member combination. Not registered in ipam-db — consumed directly by `generate_fw_enrichment.py`. Leave in `F5_Output/`.

---

## Cadence

Run this pipeline whenever a new F5 config collection is available. Typical cadence is aligned with FW enrichment re-runs. After registering updated ENT datasets, re-run `generate_fw_enrichment.py` with `--no-resume` to pick up the fresh VIP/pool data.

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.3 | 2026-04-28 | Fixed duplicate pool member write block causing crash; output filenames now always use `ent-ipdataset-` prefix |
| v1.2 | 2026-04-28 | Output files now include `#VERSION/#GENERATED/#ROWS/#NOTE` metadata headers; `DATASET_VERSION` stamped in each row |
| v1.1 | 2026-04-28 | Deduplication by basename — skips duplicate filenames in subdirectories; `--version`/`-V` flag added |
| v1.0 | 2026-04-05 | Initial release |
