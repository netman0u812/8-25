# CCD Platform — Canonical App Objects Build
## New Chat Continuation Prompt

Paste this prompt at the start of the new chat, then upload the files listed in §3.

---

## Who I am

Michael J. Martin — Lead Director of Information Security, CVS Health.
Working directory: `~/Documents/IP_Lookup/` on macOS (Yggdrasil, user mj0u812).

---

## What we are building

A canonical App Object Library — ground-truth IP object sets derived from authoritative
CCD Platform datasets, NOT reverse-engineered from FW rule objects.

This feeds:
1. `fw_object_consolidation.py` — compare canonical objects vs messy FW address groups
2. `fw_policy_intent.py` — reconstruct zone-pair allow matrix from canonical objects
3. Panorama/FMC migration — canonical objects replace change-ticket-named groups
4. SNAT mapping — VIP join + third-party access attribution

The governing SKILL file is `canonical_app_objects_SKILL.md` (uploaded).
Read it before writing any code.

---

## Taxonomy (locked — do not change)

| Type | Definition | Source |
|------|-----------|--------|
| **APP_Object** | /32 IPs of application workload instances | `ent_host_master` by APP_ACRONYM |
| **INFRA_Object** | /32 IPs of compute infrastructure (ESXi hosts, bare metal, hypervisor nodes) | `delivery_infrastructure` where ROLE = compute/hypervisor |
| **SERVICE_Object** | /32 IPs of shared enterprise services (AD/DC, DNS, Qualys, Splunk, SCCM, etc.) | `delivery_infrastructure` by service ROLE |
| **DELIVERY_Object** | /32 IPs of platform/delivery layer (K8s nodes, F5 pool members, Citrix, DataPower) | `delivery_platform` by platform type + cluster |

**VIP_IPS** — attribution only, not object membership. Join via F5-POOL-MEMBERS → F5-VIP-REGISTRY.
**SNAT_IPS** — TBD from NAT policy parsing (separate workstream).

---

## Current dataset versions (on Yggdrasil)

| Dataset | Version | Rows | Location |
|---------|---------|------|----------|
| ent_host_master | v20260427r22 | 69,140 | `./ipam-db/` |
| delivery_infrastructure | v20260504r6 | 5,755 | `./ipam-db/` |
| delivery_platform | v20260504r4 | 1,870 | `./ipam-db/` |
| app_subnet_index | v20260520r2 | 4,000 | `./ipam-db/` |
| all_IP_networks | v3.94 | 24,946 | `./ipam-db/` |
| ent-ipdataset-F5-VIP-REGISTRY | v20260520 | 15,127 | `./ipam-db/` |
| ent-ipdataset-F5-POOL-MEMBERS | v20260520 | 62,091 | `./ipam-db/` |
| location_master | v5.11 | 11,527 | `./ipam-db/` |

---

## Open questions before the build starts

The script cannot be written until these are answered by inspecting the uploaded files:

**Q1: delivery_infrastructure role values**
What are the actual ROLE or INFRA_ROLE column values in delivery_infrastructure?
We need to know if ESXi hosts, AD DCs, Qualys scanners, Splunk indexers are distinguishable
by a consistent role field — or if we need a role normalization map.

**Q2: delivery_platform cluster grouping**
Does delivery_platform have a CLUSTER_ID or equivalent field?
Or do we need to derive cluster membership from hostname patterns
(e.g., `k8s-prod-shea-node-01` → cluster=K8S_PROD, loc=SHEA)?

**Q3: ent_host_master APP_ACRONYM coverage**
What percentage of EHM rows have a non-null APP_ACRONYM?
Rows without an APP_ACRONYM cannot be placed into APP_Objects —
do these go to a review queue or get assigned to INFRA/DELIVERY by subnet?

Answer these by inspecting the uploaded files BEFORE writing any script code.

---

## Build sequence

```
1. Inspect uploaded files → answer Q1/Q2/Q3
2. Review canonical_app_objects_SKILL.md → confirm schema
3. Build build_canonical_app_objects.py
4. Dry-run on Yggdrasil
5. Inspect output → confirm object counts and coverage
6. Apply live → canonical_app_objects_vDATE.csv
7. Build fw_object_consolidation.py (needs fw_host_candidates_vDATE.csv also uploaded)
```

---

## Files to upload to this chat

### Required for Q1/Q2/Q3 inspection and script build:

| File | Location on Yggdrasil | Purpose |
|------|-----------------------|---------|
| `delivery_infrastructure_v20260504r6.csv` | `~/Documents/IP_Lookup/ipam-db/` | Q1 — inspect ROLE values |
| `delivery_platform_v20260504r4.csv` | `~/Documents/IP_Lookup/ipam-db/` | Q2 — inspect CLUSTER_ID / hostname patterns |
| `ent_host_master_v20260427r22.csv` | `~/Documents/IP_Lookup/ipam-db/` | Q3 — APP_ACRONYM coverage |
| `canonical_app_objects_SKILL.md` | from this session's outputs | Governing skill — read first |

### Required for VIP join and object building:

| File | Location on Yggdrasil | Purpose |
|------|-----------------------|---------|
| `ent-ipdataset-F5-VIP-REGISTRY-v20260520.csv` | `~/Documents/IP_Lookup/ipam-db/` | VIP → pool member join |
| `ent-ipdataset-F5-POOL-MEMBERS-v20260520.csv` | `~/Documents/IP_Lookup/ipam-db/` | Pool member → VIP join |
| `app_subnet_index_v20260520r2.csv` | `~/Documents/IP_Lookup/ipam-db/` | /24 → APP_ACRONYM context |
| `all_IP_networks_v3_94.csv` | `~/Documents/IP_Lookup/ipam-db/` | Subnet context for IPAM enrichment |

### Required for fw_object_consolidation (Step 7):

| File | Location on Yggdrasil | Purpose |
|------|-----------------------|---------|
| `fw_host_candidates_v20260521.csv` | `~/Documents/IP_Lookup/processed_outputs/` | FW-observed /32s to compare vs canonical |
| `fw_asi_candidates_v20260521.csv` | `~/Documents/IP_Lookup/processed_outputs/` | FW-observed /24 app context |

---

## Key architectural constraints (non-negotiable)

1. Every MEMBER_IP must come from an authoritative dataset — never inferred from FW rules
2. No change ticket numbers in OBJECT_NAME (no PBM12345, no Retail08496)
3. No /32 from retail_networks in any canonical object
4. VIP_IPS are attribution only — not MEMBER_IPS
5. Same IP can appear in multiple object TYPES only if it genuinely serves dual roles
   (flag these for review)
6. HERITAGE=MIXED only when both CVS and Aetna IPs confirmed in the same object
7. Minimum 2 MEMBER_IPS to create an object — single-host apps go to review queue

---

## Related scripts already built (context only — do not rebuild)

- `fw_rule_extraction_translation.py v1.1.0` — FW config parser
- `generate_fw_ingestion_report.py v1.0.0` — ingestion report generator
- `build_ip_allocation_model.py v1.1.0` — CIDR math allocation model
- `ipam-db.py v3.12.9` — IPAM registry with CX1-CX14 cross-checks
- `audit_ipam_hierarchy.py v1.7.1` — hierarchy conflict audit

## Related scripts to build after canonical objects are complete

- `fw_object_consolidation.py` — canonical vs FW gap analysis
- `fw_policy_intent.py` — zone-pair allow matrix from canonical objects
- `build_external_ip_registry.py` — external CIDR enrichment
- `fw_nat_translations.py` — SNAT/DNAT policy parsing
