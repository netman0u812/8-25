# CCD Platform — Rules, Pipeline, and Data Dictionary

**Version:** v4.0  
**Last Updated:** 2026-04-14

---

## Platform Rules

These rules are absolute and must never be broken by any script.

### Rule 1 — Directory Segregation

| Directory | Contents | Never Put Here |
|-----------|----------|----------------|
| `./ipam-db/` | Enterprise IPAM data only | GeoIP files, cloud provider ranges |
| `./ipdatasets/` | External provider IP ranges (AWS, GCP, Azure, Cloudflare, Zscaler, M365) | IPAM files, GeoIP files |
| `./ip_geo/` | GeoIP data files only | IPAM files, cloud provider ranges |
| `./IP_Datasets_Raw/` | Raw source exports — never modified | — |

### Rule 2 — Single Source of Truth (NEW v4.0)

**`all_IP_networks`** is the single authoritative source for all subnet→location mapping.  
**`retail_networks`** is the single authoritative source for all retail store subnets.

`cidr_16` and `cidr_24` are **permanently abolished** as authoritative data sources.  
No script, tool, or pipeline stage may use them for IPAM decisions.

| Old Source | New Source |
|------------|------------|
| `cidr_16_v*.csv` | **ABOLISHED** — never use |
| `cidr_24_v*.csv` | **ABOLISHED** — replaced by `all_IP_networks` |
| `all_IP_networks` + `cidr_24` overlay | `all_IP_networks` only |

### Rule 3 — IPAM Prefix Scope

| Prefix | Rule |
|--------|------|
| /16 | **ABOLISHED** — multi-site, useless for location. Never register or use. |
| /17–/26 | Keep — enterprise subnet blocks and retail boundary |
| /27–/29 | Keep for small enterprise segments |
| /30–/32 | Summarise to /30 or /29 based on usage |

Retail /32 host routes are authoritative in `retail_networks` only — not in `all_IP_networks`.

### Rule 4 — Location Classification

Authoritative source: `CVS-Location-Data-11-25.csv` (14,007 entries, Nov 2025)

| Type | Count | Classification |
|------|-------|----------------|
| Datacenter | 10 | DC sites — assign as datacenter facility |
| COLO | 4 | COLO sites — assign as datacenter facility |
| Campus | 13 | Corporate campus — NOT a datacenter |
| Distribution | 24 | Distribution center — NOT a datacenter |
| Branch | 300 | Corporate office — NOT a datacenter |
| Store | 9,088 active | Retail store — ABSOLUTELY NOT a datacenter |

**Datacenter sites:**
- `Scottsdale AZ - Shea DC` — 9501 East Shea Blvd
- `Cumberland RI - 2100 Highland` — 2100 Highland Corporate Park Drive
- `Woonsocket RI - RI One` — 1 CVS Drive
- `Middletown CT - Aetna MDC` — 930 Middle Street
- `Windsor CT - Aetna WDC` — 570 Pigeon Hill Road
- `Hartford CT - Aetna HQ` — 151 Farmington Avenue
- `Phoenix AZ - Aetna DC` — Cotton Center campus
- `Las Vegas NV - Switch DC` — 5660 West Badura Ave (Switch carrier-neutral DC)
- `Jersey City NJ - Distribution Center` (distribution, not DC)

### Rule 5 — Canonical Location Format

```
Format:  City ST - Site Name
Example: Scottsdale AZ - Shea DC
         Woonsocket RI - RI One
         Irving TX - Corporate
         Lumberton NJ - Distribution Center
```

Never use verbose format: `Scottsdale, AZ - 9501 East Shea Boulevard`

### Rule 6 — 172.16.0.0/12 Split-Brain Resolution

`172.16.0.0/12` is shared between CVS Retail stores and Aetna HCB DC subnets. The
`ROUTING_DOMAIN` + `CIDR` pair is the unique identifier — not CIDR alone.

| ROUTING_DOMAIN | Use |
|---------------|-----|
| `Internal-Retail` | CVS retail store /26 allocations → authoritative in `retail_networks` |
| `Internal-HCB` | Aetna HCB DC subnets → authoritative in `all_IP_networks` |

All `retail_networks` rows in 172.x space have `CONTESTED_BLOCK=True`.  
LPM tools must check both tables and disambiguate via routing domain.

### Rule 7 — Location Authority Chain

```
CVS-Location-Data-11-25.csv     (type classification — authoritative)
         ↓
location_master_v*.csv          (canonical location registry — 9,708 entries)
         ↓
all_IP_networks.CANONICAL_LOCATION  (per-block assignment)
         ↓
ent_host_master.CANONICAL_LOCATION  (derived via enrich_app_datasets.py)
```

---

## IPAM Database Files

### Core IPAM (ipam-db/)

| File | Description | Rows |
|------|-------------|------|
| `all_IP_networks_v3.14.csv` | **SINGLE SOURCE OF TRUTH** — full IP prefix inventory | 19,421 |
| `retail_networks_v2.1.csv` | **SINGLE SOURCE OF TRUTH** — retail store subnets with device /32s | 294,355 |
| `location_master_v3.7.csv` | Canonical location registry | 9,708 |
| `172_16_allocation_registry.csv` | 172.16.0.0/12 /24 allocation map | 4,096 |
| `app_subnet_index_v*.csv` | Application-to-subnet index | 17,139 |
| `cpc_infra_services.csv` | CPC infrastructure service catalogue | 52 |
| `ent_host_master_v*.csv` | Enterprise host dataset | 61,886 |
| `ent-ipdataset-ENTERPRISE-APP-SERVER-v*.csv` | App server dataset | 61,886 |
| `ent-ipdataset-F5-VIP-REGISTRY-v*.csv` | F5 virtual server registry | 4,802 |
| `ent-ipdataset-F5-POOL-MEMBERS-v*.csv` | F5 pool members | 8,913 |
| `ent-ipdataset-S2S-VPN-PARTNERS-v*.csv` | S2S VPN partner subnets | 3,741 |
| `ent-ipdataset-CPC-CORE-SERVICES-v*.csv` | CPC Tier-1 baseline service IPs | 422 |

**Abolished files — do not use:**
- `cidr_16_v*.csv` — permanently abolished
- `cidr_24_v*.csv` — permanently abolished as authoritative source

### all_IP_networks v3.14 Key Fields

| Field | Description |
|-------|-------------|
| `CIDR` | Subnet in CIDR notation |
| `CANONICAL_LOCATION` | Canonical site name from location_master |
| `LOCATION_TYPE` | Datacenter \| Corporate \| Retail \| Distribution \| Cloud \| COLO \| Call-Center \| Specialty \| Partner |
| `HERITAGE` | CVS \| AETNA \| CAREMARK \| OMNICARE |
| `NET_TYPE` | DataCenter \| Corporate \| Cloud \| Distribution \| Internet-Facing \| VPN \| Unallocated |
| `ROUTING_DOMAIN` | Internal-DC \| Internal-HCB \| Internal-PBM \| Internal-Retail \| Internet-Facing |
| `CONTESTED_BLOCK` | True for 172.x dual-allocation (CVS Retail + Aetna HCB) |
| `DATA_QUALITY` | Authoritative \| ESXi-Confirmed \| Nautobot \| Synthesized |

Primary key: `CIDR + ROUTING_DOMAIN` — same CIDR in two routing domains = two separate entries.

### retail_networks v2.1 Key Fields

| Field | Description |
|-------|-------------|
| `CIDR` | /26 (store), /32 (device), /24 (parent) |
| `STORE_NUMBER` | Store number |
| `INFRA_ROLE` | Device role: Router-1 \| POS-Server \| Rx-Server \| Phone-System \| Broadcast Address \| etc. Pipe-delimited if multiple devices share an IP. |
| `NETWORK_ADDRESS` | Platform: Juniper/128T-SDWAN \| Cisco-Viptela-SDWAN \| TBD-Future-Store |
| `FACILITY_TYPE` | Retail-Store \| MinuteClinic \| Optical |
| `CANONICAL_LOCATION` | City, State derived from store address |
| `CONTESTED_BLOCK` | True for all 172.x rows |

Source: `Store_IP_and_Address_Info.xlsx` (authoritative — 9,109 stores, 308,229 device rows).

### External IP Datasets (ipdatasets/)

| File | Provider | Records |
|------|----------|---------| 
| `ip_dataset_aws.csv` | Amazon Web Services | ~7,000 |
| `ip_dataset_gcp.csv` | Google Cloud Platform | ~2,000 |
| `ip_dataset_azure.csv` | Microsoft Azure | ~5,000 |
| `ip_dataset_cloudflare.csv` | Cloudflare | ~15 |
| `ip_dataset_zscaler.csv` | Zscaler ZIA | ~200 |
| `ip_dataset_microsoft365.csv` | Microsoft 365 / Office | ~100 |
| `ip_dataset_crowdstrike.csv` | CrowdStrike Falcon | ~15 |

### GeoIP Data (ip_geo/)

| File | Records | Purpose |
|------|---------|---------| 
| `IP2LOCATION-LITE-DB11.CIDR.CSV` | 3.6M | Region/city/lat/lon/zip/timezone |
| `IP2LOCATION-LITE-DB1.CIDR.CSV` | 369K | Country only (fallback) |
| `IP2LOCATION-COUNTRY-INFORMATION.CSV` | 249 | Capital, currency, IDD, TLD |
| `ip2asn-v4.tsv` | 442K | ASN + org name |
| `us_geo_networksdb.tsv` | 2.8M | US city/state override |
| `geo_ip_high_risk.json` | 13 | High-risk country config |

---

## Pipeline (Simplified — v4.0)

The old correction pipeline (`patch_all_ip_locations` → `patch_cidr24_location` → `patch_cidr24`) is **abolished**. `all_IP_networks_v3.14` is built from authoritative sources directly. There is nothing to patch.

### Current Pipeline

```bash
# 1. Refresh all raw datasets
./ipam-db.py --import-update

# 2. Enrich ent_host_master from all_IP_networks
python3 enrich_app_datasets.py --db-dir ipam-db/
./ipam-db.py --import ipam-db/ent_host_master_v<DATE>.csv --type ent_host_master

# 3. Rebuild network device inventory
python3 build_network_device_dataset.py \
    --input IP_Datasets_Raw/nms_export.csv \
    --ipam-dir ipam-db/

# 4. Generate reports
python3 generate_fw_rule_report.py --log FW_Log_Raw/

# 5. Run test suite
bash test_iplookup.sh
```

### Deprecated/Abolished Pipeline Steps

| Script | Status | Reason |
|--------|--------|--------|
| `patch_all_ip_locations.py` | **DEPRECATED** | `all_IP_networks_v3.14` built from authoritative sources — no patching needed |
| `patch_cidr24_location.py` | **DEPRECATED** | `cidr_24` abolished |
| `patch_cidr24.py` | **DEPRECATED** | `cidr_24` abolished; retail /24 parents now in `all_IP_networks` |

---

## Script Inventory

| Script | Version | Status | Description |
|--------|---------|--------|-------------|
| `ipam-db.py` | v1.2 | ✓ Working | IPAM registry manager |
| `ip_dataset.py` | v1.8 | ✓ Working | External IP dataset manager |
| `iplookup.sh` | v3.6 | ⚠ Needs update | CLI IPAM lookup — remove cidr_24 dep |
| `geo_ip.py` | v1.1 | ⚠ Needs fix | GeoIP lookup — 3 known bugs (see README_geo_ip.md) |
| `build_geoip_db.py` | v1.2 | ✓ Working | GeoIP + cloud IP dataset builder |
| `generate_fw_rule_report.py` | v1.2 | ⚠ Needs update | Remove cidr_24 overlay |
| `generate_fw_enrichment.py` | v1.1 | ✓ Working | FW rule enrichment pipeline |
| `generate_fw_zone_flows.py` | v1.0 | ✓ Working | FW zone flow CSV generator |
| `generate_dc_app_map.py` | v1.x | ⚠ Needs update | Replace cidr_24 with all_IP_networks |
| `generate_network_infra_map.py` | v1.x | ✓ Working | Network infrastructure map |
| `generate_partner_retail_map.py` | v1.x | ✓ Working | Partner/retail map |
| `generate_location_map.py` | v1.0 | ✓ Working | Enterprise location map |
| `generate_app_delivery_map.py` | v1.0 | ✓ Working | App delivery chain tracer |
| `generate_csna_import.py` | v2.1 | ⚠ Needs update | Remove cidr_24 dep |
| `enrich_app_datasets.py` | v1.0 | ⚠ Needs update | Remove cidr_24 overlay |
| `build_network_device_dataset.py` | v1.0 | ⚠ Needs update | Remove cidr_24 overlay |
| `build_ent_host_dataset.py` | v1.0 | ✓ Working | Enterprise host dataset builder |
| `app_classifier.py` | v1.x | ⚠ Needs update | Remove cidr_24 rollup layer |
| `parse_f5_configs.py` | v1.0 | ✓ Working | F5 BIG-IP config parser |
| `parse_vpn_configs.py` | v1.0 | ✓ Working | Cisco ASA VPN config parser |
| `build_nat_reverse_map.py` | v1.0 | ✓ Working | Panorama NAT reverse map |
| `normalize_locations.py` | v1.0 | **DEPRECATED** | Location patching abolished |
| `parse_hostname.py` | v1.x | ✓ Working | CVS hostname parser |
| `patch_all_ip_locations.py` | v1.0 | **DEPRECATED** | cidr_24 pipeline abolished |
| `patch_cidr24_location.py` | v1.0 | **DEPRECATED** | cidr_24 abolished |
| `patch_cidr24.py` | v1.0 | **DEPRECATED** | cidr_24 abolished |

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| v4.0 | 2026-04-14 | **IPAM architecture overhaul** — cidr_16/cidr_24 abolished; all_IP_networks v3.14 is single source of truth; retail_networks v2.1 with INFRA_ROLE/NETWORK_ADDRESS; 172.x split-brain model documented; correction pipeline deprecated |
| v3.0 | 2026-04-14 | Previous version |
