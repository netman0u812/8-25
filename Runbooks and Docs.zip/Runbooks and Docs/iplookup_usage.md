# iplookup.sh — Usage Reference  `v3.20`

IPAM + Application subnet lookup tool for the CVS Health CCD Platform.  
Reads from `all_IP_networks`, `retail_networks`, `app_subnet_index`, `ent_network_device_master`, `delivery_infrastructure`, `delivery_platform`, and registered ENT ipdatasets in `ipam-db/`.

---

## Quick Command Reference

| Command | Purpose |
|---|---|
| `-l <IP>` | Longest-prefix-match IP lookup + provider attribution |
| `-store <NUM>` | Retail store lookup by store number |
| `-host <NAME\|IP>` | Search ENT host datasets by FQDN, hostname, or IP |
| `--hostname <fqdn>` | Lookup by FQDN |
| `-dom <domain>` | Find all subnets for a DNS domain |
| `-app <ID>` | Lookup by IPAM_APP_ID, APM ID, or app acronym |
| `-svc <name>` | CPC infrastructure service lookup |
| `-k <keyword>` | Free-text or structured field search |
| `-loc <name>` | Location-based subnet lookup |
| `-lt` | Tag / field value enumeration |
| `-td <CIDR>` | Subnet tree diagram |
| `--nt <value>` | Filter subnets by NET_TYPE *(v3.13)* |
| `--nt-list` | NET_TYPE taxonomy overview *(v3.13)* |
| `--ds <stem>` | Browse any registered ip_dataset *(v3.15)* |
| `--city / --state / --dns / --pci` | Filter shortcuts |
| `--sc <query>` | Site code lookup |
| `--sc-subnets <query>` | List all subnets for a site |
| `-app-list` | App subnet inventory |
| `-device-list-*` | Network device inventories |
| `-infra-list` | Delivery infrastructure node inventory *(v3.18)* |
| `-platform-list` | Delivery platform node inventory *(v3.18)* |
| `--infra-stats` | Summary stats for delivery_infrastructure *(v3.18)* |
| `--platform-stats` | Summary stats for delivery_platform *(v3.18)* |

---

## Lookup Modes

### `-l <IP>` — IP Lookup

Longest-prefix-match against `all_IP_networks`. For 172.x addresses, queries `retail_networks` first to surface per-store detail.

```bash
iplookup.sh -l 10.18.90.5
iplookup.sh -l 172.16.1.5
iplookup.sh -l 172.16.1.5 --nat --app    # include NAT detail + app index data
iplookup.sh -l 172.18.51.128/26          # CIDR notation for explicit prefix context
```

**Output includes:** CANONICAL_LOCATION, SITE_CODE, ROUTING_DOMAIN, HERITAGE, NET_TYPE, FACILITY_TYPE, DATA_QUALITY, and (for 172.x) retail store detail including STORE_NUMBER, PHYSICAL_ADDRESS, ROUTER_MODEL, COMM_TYPE.

**172.x dual-allocation:** The 172.16–172.31 range is intentionally shared between Internal-HCB (Aetna DC/campus) and Internal-Retail (retail store SNAT pools). Both domains are always shown. A `⚠ Dual-allocation` banner appears when both are present.

**Provider Context *(v3.14)*:** For any IP, `-l` now cross-references all registered ip_dataset feeds after the IPAM lookup. If the IP falls within a registered dataset CIDR, a **Provider Context** section is shown — identifying the provider, dataset stem, covering prefix, and service/region where available. Runs for both IPAM hits (additional context) and misses (attribution for public IPs with no enterprise entry).

```bash
iplookup.sh -l 3.128.162.14              # AWS EC2 IP — shows Provider Context: aws / Amazon Web Services
iplookup.sh -l 8.25.203.1               # Zscaler ZPA node — shows Provider Context: zscaler / Zscaler
iplookup.sh -l 8.8.8.8                  # Google DNS — shows Provider Context: Google_Public_Space
```

---

### `-store <NUM>` — Retail Store Lookup

```bash
iplookup.sh -store 1234
iplookup.sh -store 00418
```

Returns the 172.x /26 allocations for the store plus PHYSICAL_ADDRESS, STORE_OPEN_DATE, ROUTER_MODEL, COMM_TYPE, secondary 10.x LAN CIDR.

---

### `-host <NAME|IP>` — Host Record Lookup

Searches all registered ENT datasets (`ent_host_master`, `delivery_infrastructure`, `delivery_platform`, NDM) by FQDN, hostname, or IP.

```bash
iplookup.sh -host pgc1heaadl10v.corp.cvscaremark.com
iplookup.sh -host 10.130.1.55
```

**Returns:** SERVER_NAME, OS, APPLICATION, PORTS, CSNA_HOSTGROUP_PATH, tool coverage flags (IN_CROWDSTRIKE, IN_QUALYS, IN_WIZ, IN_SNOW).

---

### `--hostname <fqdn>` — FQDN Lookup

Searches `Display_Name` and `Comments` fields in host datasets.

```bash
iplookup.sh --hostname pgc1heaadl10v.corp.cvscaremark.com
```

---

### `-dom <domain>` — Domain Lookup

Find all subnets associated with a DNS domain or partial domain token.

```bash
iplookup.sh -dom caremarkrx.net
iplookup.sh -dom caremark.cvshealth.com
iplookup.sh -dom aeth.aetna.com
```

---

### `-app <ID>` — Application Lookup

Lookup by IPAM_APP_ID (`NET-x-x-x`), APM ID, or app acronym.

```bash
iplookup.sh -app NET-10-130-142
iplookup.sh -app APM0012589
iplookup.sh -app Genetec
```

---

### `-svc <name>` — CPC Service Lookup

Look up CPC infrastructure services (DNS, NTP, Active Directory, Centrify, etc.) by name or slug.

```bash
iplookup.sh -svc all               # list all CPC services
iplookup.sh -svc ntp               # NTP service details
iplookup.sh -svc centrify
iplookup.sh -svc 'active directory'
```

---

### `-k <keyword>` — Keyword Search

Free-text or structured search across 16 fields in `all_IP_networks`. Multiple `-k` flags use AND logic.

```bash
iplookup.sh -k MinuteClinic                        # free-text
iplookup.sh -k city=Dallas                         # structured
iplookup.sh -k city=Dallas -k risk='High Risk'     # AND logic
iplookup.sh -k facility=DataCenter -k env=PROD     # AND logic
iplookup.sh -k list                                # discover all searchable fields
iplookup.sh -k bu=list                             # enumerate all values for a field
```

**Field aliases:**

| Alias | Field |
|---|---|
| `city` | CITIES |
| `state` | STATES |
| `site` | PRIMARY_SITE |
| `owner` | OWNER |
| `bu` | BU |
| `routing` | ROUTING_DOMAIN |
| `nettype` | NET_TYPE |
| `facility` | FACILITY_TYPE |
| `function` | FUNCTION_LOC_ROLE |
| `pci` | PCI_DESIGNATION |
| `risk` | RISK_TIER |
| `env` | APP_ENV_TYPES |
| `dns` | DNS_DOMAINS |
| `appid` | IPAM_APP_ID |
| `division` | DIVISION |
| `location` | CANONICAL_LOCATION |
| `apm` | APM_IDS |
| `acronym` | APP_ACRONYMS |
| `cpcsvcs` | CPC_SERVICES |
| `pcimixed` | PCI_MIXED_INDICATOR |
| `pcivalues` | PCI values list |

---

### `-loc <name>` — Location Lookup

Find all subnets for a location by name substring.

```bash
iplookup.sh -loc 'Scottsdale'
iplookup.sh -loc 'Shea DC'
iplookup.sh -loc 'Middletown CT'
iplookup.sh -loc 'Aetna' -r Internal-HCB    # refine by routing domain
```

Use `-r <routing_domain>` to narrow results when a location name is ambiguous.

---

## Filter Shortcuts

Quick filters against `all_IP_networks` or `app_subnet_index`.

```bash
iplookup.sh --city Scottsdale
iplookup.sh --state RI
iplookup.sh --state TX -n 50
iplookup.sh --dns aetna.com
iplookup.sh --pci                           # all PCI-designated blocks
iplookup.sh --prod                          # subnets with PROD apps
iplookup.sh --risk High
iplookup.sh --high-risk                     # shortcut for --risk High
```

---

## NET_TYPE Query Commands  *(v3.13)*

Query `all_IP_networks` directly by NET_TYPE value. Supports substring matching and all inventory modifier flags.

### `--nt-list` — Taxonomy Overview

Show all NET_TYPE values in the dataset with row counts and top routing domains. Use this to understand estate composition after vocabulary changes.

```bash
iplookup.sh --nt-list
```

**Sample output:**
```
NET_TYPE taxonomy  —  20,942 total rows  (20 distinct values)

  NET_TYPE                      ROWS       %   TOP ROUTING DOMAINS
  ─────────────────────────────────────────────────────────────────
  DataCenter                   11,719   56.0%  Internal-PBM(6821), Internal-HCB(3291), COLO(1236)
  Corporate                     3,923   18.7%  Internal-PBM(2814), Internal-HCB(901), ...
  Omnicare                        881    4.2%  Internal-PBM(591), Internal-HCB(290)
  Cloud-Azure                     911    4.4%  Cloud-Azure(911)
  ...
```

---

### `--nt <value>` — Filter by NET_TYPE

List all subnets matching a NET_TYPE. Matching is case-insensitive substring — `P2P` matches `P2P-WAN` and `P2P-VPN`.

```bash
iplookup.sh --nt DataCenter
iplookup.sh --nt DMZ
iplookup.sh --nt P2P                        # matches P2P-WAN, P2P-VPN
iplookup.sh --nt Cloud                      # matches Cloud-Azure, Cloud-GCP, Cloud-AWS, Cloud-Peering
iplookup.sh --nt CallCenter                 # matches CVS-CallCenter, AETNA-CallCenter, Partner-CallCenter
iplookup.sh --nt SNAT
```

**Combined with modifier flags:**

```bash
iplookup.sh --nt DataCenter --loc Shea               # DataCenter at Shea DC only
iplookup.sh --nt DMZ --heritage AETNA                # Aetna DMZ subnets
iplookup.sh --nt DataCenter --routing-domain Internal-HCB
iplookup.sh --nt P2P-WAN --loc 'Woonsocket'
iplookup.sh --nt DataCenter -n 100                   # override max results
```

**Output columns:** CIDR, NET_TYPE, SITE_CODE, LOCATION, ROUTING_DOMAIN, HERITAGE, DATA_QUALITY  
Results are grouped by NET_TYPE, then sorted by SITE_CODE and CIDR within each group.

---

### NET_TYPE Controlled Vocabulary

**Tier 1 — Site/function types:**

| Value | Description |
|---|---|
| `DataCenter` | All DC/server infrastructure (CVS, Aetna, Switch COLO) |
| `Corporate` | Corporate office / campus networks |
| `Distribution` | CVS distribution center networks |
| `Specialty` | Specialty pharmacy (including Coram infusion) |
| `Mail-Order` | Mail-order pharmacy networks |
| `Omnicare` | Omnicare long-term care pharmacy networks |
| `CarePlus` | CarePlus HMO clinic networks |
| `CVS-CallCenter` | CVS/Caremark call center networks |
| `AETNA-CallCenter` | Aetna call center networks |
| `Partner-CallCenter` | Third-party contracted call centers |
| `DR` | Disaster recovery sites |
| `Cloud-Azure` | Azure VNet subnets |
| `Cloud-GCP` | GCP VPC subnets |
| `Cloud-AWS` | AWS VPC subnets |
| `Cloud-Peering` | Equinix cloud peering POPs |
| `Partner` | Partner network connectivity |
| `Offshore-Dev` | Offshore development (Infosys, Concentrix) |
| `CGNAT-K8s` | GKE pod networking (100.64.0.0/10 RFC 6598 space) |
| `Internet-Facing` | Internet-exposed subnets |

**Tier 2 — Functional sub-types** *(in use, Tier 1 promotion pending):*

| Value | Description |
|---|---|
| `DMZ` | Demilitarized zone segments |
| `P2P-WAN` | Point-to-point WAN carrier circuit links (/29–/31) |
| `SNAT` | Source NAT pool addresses |
| `P2P-VPN` | IPSec VPN point-to-point links |

---

## Dataset Browser  *(v3.15)*

Browse any registered ip_dataset by stem with optional service and region filters. Column names are auto-detected per dataset so the command works across all provider schemas without configuration.

### `--ds <stem>` — Browse a Dataset

```bash
iplookup.sh --ds zscaler                    # all rows in the Zscaler ZPA dataset
iplookup.sh --ds zscaler-zia               # Zscaler ZIA enforcement nodes
iplookup.sh --ds aws                        # all AWS IP ranges (10,212 rows)
iplookup.sh --ds azure
iplookup.sh --ds cloudflare
iplookup.sh --ds akamai
```

Output shows a formatted column table with dataset metadata (provider, class, data version, detected column mapping) and a row count footer.

Partial stem matching is supported — `--ds zscal` matches `zscaler`.

### `--service <str>` — Filter by Service

Substring match, case-insensitive, against the detected SERVICE column.

```bash
iplookup.sh --ds zscaler --service ZPA          # Zscaler-ZPA rows only
iplookup.sh --ds zscaler-zia --service ZIA      # Zscaler-ZIA rows only
iplookup.sh --ds aws --service EC2
iplookup.sh --ds aws --service S3
iplookup.sh --ds azure --service AzureActiveDirectory
iplookup.sh --ds github --service actions
```

**Zero-result diagnostic:** If no rows match, the command shows all distinct values in the SERVICE column so you know what strings to filter on — no guessing required.

### `--region <str>` — Filter by Region

Substring match, case-insensitive, against the detected REGION column.

```bash
iplookup.sh --ds aws --region us-east-1
iplookup.sh --ds aws --region us-east          # matches us-east-1, us-east-2
iplookup.sh --ds azure --region eastus
```

### Combined Filters

```bash
iplookup.sh --ds aws --service EC2 --region us-east-1
iplookup.sh --ds aws --service S3 --region us-east-1 --csv /tmp/s3_east.csv
```

### `--csv <file>` Export

Any `--ds` query can be exported with `--csv`. Works with or without filters.

```bash
iplookup.sh --ds zscaler --csv /tmp/zscaler_zpa.csv
iplookup.sh --ds aws --service EC2 --csv /tmp/aws_ec2_ranges.csv
```

---

## Tag Lookup (-lt)

Enumerate field values across all_IP_networks.

```bash
iplookup.sh -lt                       # list all tag categories with unique value counts
iplookup.sh -lt -dom                  # all DNS_DOMAINS values, sorted by /24 count
iplookup.sh -lt --city                # all CITIES values
iplookup.sh -lt --state               # all STATES codes
iplookup.sh -lt -loc                  # all PRIMARY_SITE / DC location values
iplookup.sh -lt -loc group            # APP_LOCATION_GROUP and OS_LOCATION_GROUP
iplookup.sh -lt -k nettype            # all NET_TYPE values
iplookup.sh -lt -k facility           # all FACILITY_TYPE values
iplookup.sh -lt -k routing            # all ROUTING_DOMAIN values
iplookup.sh -lt -k bu                 # all BU values
iplookup.sh -lt -k risk               # all RISK_TIER values
iplookup.sh -lt -k env                # all APP_ENV_TYPES values
iplookup.sh -lt -k pci                # all PCI_DESIGNATION values
```

---

## Tree Diagram (-td)

Render a colour-coded CLI subnet tree for any CIDR block.

```bash
iplookup.sh -td 10.18.0.0/16
iplookup.sh -td 172.16.0.0/16 --max-24s 20
iplookup.sh -td 172.16.1.0/24 --nat
iplookup.sh -td 10.130.0.0/16 --no-colour    # plain text / pipe-safe
```

| Flag | Description |
|---|---|
| `--max-24s <n>` | Max /24 blocks to display (default: 12) |
| `--nat` | Expand /32 device rows with NAT public IPs |
| `--no-colour` | Suppress ANSI colour codes |

---

## Site Code Commands  *(v3.10)*

```bash
iplookup.sh --sc-list                         # list all active LM entries by SITE_CODE
iplookup.sh --sc US_HFD_CT_CO1               # lookup by exact site code
iplookup.sh --sc CT                           # search by state code
iplookup.sh --sc hartford                     # search by city substring
iplookup.sh --sc-subnets US_HFD_CT_CO1       # all IPAM subnets for a site
iplookup.sh --sc-subnets 'Shea'              # subnets matching location name
iplookup.sh --loc-list                        # all active location_master entries
iplookup.sh --loc-lookup 'Moon Township'      # search LM by name substring
iplookup.sh --loc-lookup 'Omnicare'
```

---

## Inventory Lists  *(v3.10)*

### Device Inventories

List network devices from `ent_network_device_master`, filtered by device class.

```bash
iplookup.sh -device-list-fw-pa               # Palo Alto firewalls
iplookup.sh -device-list-fw-cisco            # Cisco firewalls
iplookup.sh -device-list-fw-checkpoint       # Check Point firewalls
iplookup.sh -device-list-l3switch            # L3 switches
iplookup.sh -device-list-router              # Routers
iplookup.sh -device-list-wireless-ctl        # Wireless LAN controllers
iplookup.sh -device-list-lb                  # Load balancers
iplookup.sh -device-list-sbc                 # Session border controllers / voice gateways
iplookup.sh -device-list-all                 # All devices
```

### App Subnet Inventory

```bash
iplookup.sh -app-list                         # all apps from app_subnet_index
```

### Delivery Infrastructure Inventory  *(v3.18)*

List nodes from `delivery_infrastructure` (ESX hosts, container bridges, shared platforms).

```bash
iplookup.sh -infra-list                      # all nodes
iplookup.sh -infra-list --platform-type ESX-HOST
iplookup.sh -infra-list --platform-type CONTAINER-BRIDGE
iplookup.sh -infra-list --loc 'Shea DC'
iplookup.sh -infra-list --heritage Aetna
iplookup.sh -infra-list --heritage Aetna --csv /tmp/aetna_infra.csv
iplookup.sh --infra-stats                    # summary breakdown by PLATFORM_TYPE, OS_GROUP, HERITAGE, location
```

**PLATFORM_TYPE values:** `ESX-HOST` (5,084) · `CONTAINER-BRIDGE` (68) · `SHARED-PLATFORM` (44)

### Delivery Platform Inventory  *(v3.18)*

List nodes from `delivery_platform` (Kubernetes clusters and managed platforms).

```bash
iplookup.sh -platform-list                   # all nodes
iplookup.sh -platform-list --platform-type KUBERNETES
iplookup.sh -platform-list --loc 'Cloud - GCP'
iplookup.sh -platform-list --csv /tmp/k8s_nodes.csv
iplookup.sh --platform-stats                 # summary breakdown
```

**PLATFORM_TYPE values:** `KUBERNETES` (1,105)

### Inventory Modifier Flags

All inventory commands (`-app-list`, `-device-list-*`, `-infra-list`, `-platform-list`) accept these modifiers:

| Flag | Description |
|---|---|
| `--loc <str>` | Substring filter on CANONICAL_LOCATION / SITE_CODE |
| `--heritage <str>` | Substring filter on HERITAGE (CVS, AETNA, SWITCH, PARTNER) |
| `--routing-domain <str>` | Substring filter on ROUTING_DOMAIN |
| `--net-type <str>` | Substring filter on NET_TYPE *(v3.13)* |
| `--platform-type <str>` | Substring filter on PLATFORM_TYPE *(v3.18 — infra/platform only)* |
| `--os-group <str>` | Substring filter on OS_GROUP *(v3.18 — infra/platform only)* |
| `--server-class <str>` | Substring filter on SERVER_CLASS *(v3.18 — infra/platform only)* |
| `--csv <file>` | Export results to CSV instead of screen table |

```bash
iplookup.sh -device-list-fw-pa --loc 'Shea DC'
iplookup.sh -device-list-all --heritage AETNA --csv /tmp/aetna_devices.csv
iplookup.sh -app-list --heritage CVS
iplookup.sh -app-list --routing-domain Internal-HCB
iplookup.sh -app-list --net-type DataCenter
iplookup.sh -app-list --csv /tmp/apps.csv
```

---

## Options

| Flag | Description |
|---|---|
| `-h`, `--help` | Show help |
| `-V` | Show dataset versions and resolved filenames |
| `-n <num>` | Max results (default: 20) |
| `--nat` | Include NAT detail in `-l`; expand /32s in `-td` |
| `--app` | Include app index data in `-l` output |
| `--no-pager` | Disable paging (useful for scripting) |
| `--no-colour` | Suppress ANSI colour codes |
| `--min-version X.Y` | Abort if `all_IP_networks` version < X.Y |
| `-r <routing_domain>` | Refine `-loc` results by routing domain |

---

## Dataset Version Targeting  *(v2.6)*

```bash
iplookup.sh -V                                           # show active + all available versions
iplookup.sh --use-version 3.76 -l 10.1.1.1              # lookup against a specific version
iplookup.sh --dataset-dir /data/ipam/archive -l 10.1.1.1
iplookup.sh --dataset-dir /archive --use-version 3.70 -V
```

| Flag | Description |
|---|---|
| `--dataset-dir <path>` | Use IPAM files from `<path>` instead of default `ipam-db/` |
| `--use-version X.Y` | Pin to a specific dataset version; uses highest available if not set |

---

## IP Dataset Management  *(v3.2 / v3.16)*

Import and manage external IP datasets (cloud ranges, VPN partner lists, SaaS proxies, etc.). `iplookup.sh` is the single entry point — all operations pass through to `ip_dataset.py`.

### Import

```bash
iplookup.sh --import gcp_asia_pacific_ipv4.csv
iplookup.sh --import crowdstrike_us_1_ips.txt --service-type-code ENDPOINT-SEC
iplookup.sh --import https://saasedl.paloaltonetworks.com/feeds/okta/all/ipv4
iplookup.sh --import rriwsdc_vpn_report.html --E VPN-RRIWSDC --service-type-code S2S-VPN
iplookup.sh --import pazshdc_vpn_report.html --E VPN-PAZSHDC --service-type-code S2S-VPN
iplookup.sh --import --values                            # show all available override values
```

**Dataset tiers (mutually exclusive — `--S` is default):**

| Flag | Description |
|---|---|
| `--S` | Standard tier (default): `ip_dataset_NNNNN_YYYYMMDD.csv` |
| `--E <DESCRIPTOR>` | Enterprise tier: `ent-ipdataset-<DESCRIPTOR>-vYYYYMMDD.csv` |

**Override flags (optional with either tier):**

| Flag | Description |
|---|---|
| `--service-type-code C` | Override service type: `CLOUD-INFRA`, `CDN`, `WAF`, `IAM`, `S2S-VPN`, `ENDPOINT-SEC`, ... |
| `--provider NAME` | Override provider name e.g. Google, CrowdStrike |
| `--region REGION` | Override region e.g. `us-east-1`, `asia-pacific`, `EU` |
| `--tags T1,T2` | Override domain/enrichment tags |
| `--description TEXT` | Override dataset description |
| `--priority INT` | Override lookup priority within class |
| `--name STEM` | Override registry key (default: derived from filename) |
| `--force` | Skip overwrite prompt on re-import |
| `--dry-run` | Validate and show what would happen — nothing written |
| `--sheet-map JSON` | XLSX: per-sheet column mapping for non-standard headers |

### Named Feeds  *(v3.16)*

Import from a pre-configured named feed without specifying a URL. Use `--feeds` to see all available names.

```bash
iplookup.sh --feeds                          # list all known named feed URLs
iplookup.sh --import-feed aws               # import / refresh AWS IP ranges
iplookup.sh --import-feed azure
iplookup.sh --import-feed gcp
iplookup.sh --import-feed zscaler-three     # Zscaler ZIA — zscalerthree.net cloud
iplookup.sh --import-feed zscaler-zpa-three # Zscaler ZPA — zscalerthree.net cloud
iplookup.sh --import-feed cloudflare
iplookup.sh --import-feed github
```

### Registry Management

```bash
iplookup.sh --list-datasets                  # list all registered datasets
iplookup.sh --list-sources                   # unified view: IPAM files + datasets
iplookup.sh --refresh <stem>                 # re-fetch one URL-sourced dataset
iplookup.sh --refresh-feeds                  # re-fetch ALL URL-sourced datasets  (v3.16)
iplookup.sh --compare <file|URL>             # overlap analysis against registered datasets  (v3.16)
iplookup.sh --remove-dataset <stem>          # deregister a dataset (CSV kept)
iplookup.sh --ip-dataset-purge               # delete ip_dataset.json, revert to IPAM-only
iplookup.sh --ip-dataset-rebuild             # rescan and re-import all ip_dataset_* CSVs
```

**Ownership:** `ip_dataset.py` is the data management layer (import, refresh, validate, register). `iplookup.sh` is the query layer (lookup, browse, filter). `ip_dataset.json` is the shared registry — `ip_dataset.py` writes it, `iplookup.sh` reads it.

---

## Examples by Use Case

### Find a subnet / host
```bash
iplookup.sh -l 10.130.1.55                             # IP lookup with host record
iplookup.sh -l 172.16.1.5 --nat --app                  # retail IP with NAT + app data
iplookup.sh -host pgc1heaadl10v.corp.cvscaremark.com   # find server by hostname
iplookup.sh -app Genetec                               # find subnets by application
```

### Identify a public IP
```bash
iplookup.sh -l 3.128.162.14                            # AWS EC2 — Provider Context shown
iplookup.sh -l 8.25.203.1                              # Zscaler ZPA node
iplookup.sh -l 8.8.8.8                                 # Google DNS
iplookup.sh --ds aws --service EC2 --region us-east-2  # all AWS EC2 ranges in us-east-2
iplookup.sh --ds zscaler-zia                           # all Zscaler ZIA enforcement nodes
```

### Understand a location's estate
```bash
iplookup.sh --sc-subnets US_SCO_AZ_DC                  # all Shea DC subnets
iplookup.sh --nt DataCenter --loc Shea                 # DataCenter-typed at Shea
iplookup.sh --nt DMZ --loc Shea                        # DMZ segments at Shea
iplookup.sh -device-list-fw-pa --loc 'Shea'            # PA firewalls at Shea
iplookup.sh -infra-list --loc 'Shea DC'               # ESX/infra nodes at Shea
iplookup.sh --infra-stats                             # full infra breakdown
```

### Explore NET_TYPE composition
```bash
iplookup.sh --nt-list                                  # full taxonomy with counts
iplookup.sh --nt DMZ                                   # all DMZ subnets
iplookup.sh --nt P2P                                   # all P2P WAN links
iplookup.sh --nt DataCenter --heritage AETNA           # Aetna DC subnets
iplookup.sh --nt Cloud                                 # all Cloud-* subnets
```

### Browse registered datasets
```bash
iplookup.sh --ds zscaler --service ZPA                 # Zscaler ZPA ranges
iplookup.sh --ds zscaler-zia                           # Zscaler ZIA enforcement nodes
iplookup.sh --ds aws --service S3                      # AWS S3 ranges
iplookup.sh --ds aws --service EC2 --region us-east-1  # AWS EC2 in us-east-1
iplookup.sh --ds azure --service AzureActiveDirectory  # Azure AD ranges
iplookup.sh --feeds                                    # discover all named feeds
```

### Security / compliance
```bash
iplookup.sh --pci                                      # all PCI blocks
iplookup.sh --risk High                                # High Risk subnets
iplookup.sh -k risk='High Risk' -k env=PROD            # High Risk + PROD
iplookup.sh --nt Internet-Facing                       # internet-exposed subnets
iplookup.sh --nt SNAT                                  # SNAT pool addresses
```

### Explore field values
```bash
iplookup.sh -lt -k nettype                             # all NET_TYPE values
iplookup.sh -lt -k routing                             # all routing domains
iplookup.sh -lt -k facility                            # all FACILITY_TYPE values
iplookup.sh -lt -dom                                   # all DNS domains with counts
iplookup.sh --nt-list                                  # NET_TYPE taxonomy
```

### Aetna / CVS heritage split
```bash
iplookup.sh --nt DataCenter --heritage AETNA           # Aetna DC subnets
iplookup.sh --nt DataCenter --heritage CVS             # CVS DC subnets
iplookup.sh -device-list-all --heritage AETNA          # all Aetna network devices
iplookup.sh -app-list --routing-domain Internal-HCB    # Aetna-domain app subnets
```

### Export for downstream analysis
```bash
iplookup.sh -device-list-all --heritage AETNA --csv /tmp/aetna_devices.csv
iplookup.sh -app-list --csv /tmp/all_apps.csv
iplookup.sh -device-list-fw-pa --loc 'Shea' --csv /tmp/shea_fw.csv
iplookup.sh --ds aws --service EC2 --csv /tmp/aws_ec2.csv
iplookup.sh -infra-list --heritage Aetna --csv /tmp/aetna_infra.csv
iplookup.sh -platform-list --csv /tmp/k8s_nodes.csv
```

---

## Dataset Files

| File | Description | SSOT for |
|---|---|---|
| `all_IP_networks_vX.Y.csv` | Enterprise IPAM — all non-retail subnets | All IP→location mapping |
| `retail_networks_vX.Y.csv` | Per-store 172.x /26 allocations | Retail store subnets |
| `app_subnet_index_vX.Y.csv` | Application coverage by /24 block | App→subnet mapping |
| `ent_host_master_vX.csv` | Enterprise application servers | Server records |
| `delivery_infrastructure_vX.csv` | ESX hosts, container bridges, shared platforms | Infrastructure node records |
| `delivery_platform_vX.csv` | Kubernetes clusters and managed platforms | Platform node records |
| `ent_network_device_master_vX.csv` | Network device inventory | Device records |
| `csna_site_registry_vX.Y.csv` | CSNA site coverage registry | CSNA hostgroup generation |
| `location_master_table.csv` | Location master (LM) cache | CANONICAL_LOCATION→SITE_CODE |
| `ip_dataset.json` | External dataset registry | All registered ip_datasets |

**Update order (non-negotiable):** LM → `all_IP_networks` → NDM → EHM → `delivery_infrastructure` → `delivery_platform`

---

## Version History

| Version | Key Changes |
|---|---|
| v3.18 | `-infra-list`, `-platform-list`, `--infra-stats`, `--platform-stats` — delivery_infrastructure and delivery_platform inventory and stats; `--platform-type`, `--os-group`, `--server-class` modifier flags; `-V` now shows both delivery master files |
| v3.17 | `--ds` dataset browser bug fixes; pass-1 flag detection fix; `run_paged` exit code propagation |
| v3.16 | `--import-feed`, `--refresh-feeds`, `--feeds`, `--compare` pass-throughs — `iplookup.sh` is now single entry point for all dataset management |
| v3.15 | `--ds` dataset browser with `--region`, `--service` filters and `--csv` export; column auto-detection; zero-result diagnostics |
| v3.14 | Provider Context in `-l` — ip_dataset cross-reference for public IP attribution (AWS, Azure, GCP, Zscaler, Akamai, etc.) |
| v3.13 | `--nt`, `--nt-list`, `--net-type` inventory modifier |
| v3.12 | `--sc-list`, `--sc`, `--sc-subnets` site code commands |
| v3.10 | Inventory list commands (`-app-list`, `-device-list-*`), `--loc`/`--heritage`/`--routing-domain` modifiers |
| v3.9 | Host record lookup refactored from four master files |
| v3.7 | `all_IP_networks` as single SSOT; `cidr_16`/`cidr_24` abolished |
| v3.6 | 172.x dual-allocation resolution; CIDR notation in `-l` |
| v3.5 | ENT host dataset integration; `-host` command |
| v3.2 | `--import` with `--E`/`--S` dataset tier; enterprise dataset support |

## ENT Ipdataset Commands

| Command | Purpose |
|---|---|
| `--ds INTERNET-FACING <IP>` | Check if IP is in confirmed public BGP space |
| `--ds F5-VIP-REGISTRY <IP>` | Look up F5 VIP details for an IP |
| `--ds F5-POOL-MEMBERS <IP>` | Find all VIPs that use this IP as a pool member |

## IPAM Hierarchy Audit Commands

The following scripts work alongside iplookup.sh for IPAM maintenance:

```bash
# Audit parent-child routing domain conflicts
python3 audit_ipam_hierarchy.py --ipam-dir ./ipam-db --review

# Generate interactive HTML report
python3 generate_ipam_hierarchy_report.py --ipam-dir ./ipam-db --lm-dir ./ipam-db

# Show full detail for one parent block
python3 audit_ipam_hierarchy.py --ipam-dir ./ipam-db --show-parent 10.223.0.0/17

# Filter to one pattern type
python3 audit_ipam_hierarchy.py --ipam-dir ./ipam-db --filter-type WAN_P2P_AGGREGATE
```

