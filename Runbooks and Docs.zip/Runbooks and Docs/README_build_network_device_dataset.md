# build_network_device_dataset.py — Network Device Inventory Builder

**Version:** v1.0  
**Type:** Python  
**Role:** Collapses the NMS interface-level export into a per-device inventory with IPAM enrichment, canonical location assignment, and IPAM gap detection. Produces the network device ipdataset used by FW enrichment and infra map tools.

---

## Overview

The NMS system exports one row per device interface — a single 24K-device network has 653K interface rows. This script collapses those to one row per device, assigns location via three-layer resolution (NMS location field → IPAM LPM → hostname prefix), enriches with `FW_POLICY`, `ROUTING_DOMAIN`, and `HERITAGE` from `all_IP_networks` (with `cidr_24` overlay for corrected values), then flags subnets present in NMS but absent from IPAM.

```
NMS interface export (one row per interface)
    ↓
    ├── Collapse to per-device          → 24,857 devices from 653K interface rows
    ├── Location resolution             → LOCATION_FIELD_MAP → IPAM LPM → hostname prefix
    ├── all_IP_networks LPM lookup      → FW_POLICY, ROUTING_DOMAIN, CLOUD_PLATFORM, CANONICAL_LOCATION
    └── IPAM gap detection              → subnets in NMS but missing from IPAM
    ↓
ent-ipdataset-NETWORK-DEVICE-INVENTORY-v<DATE>.csv   (24,857 rows)
network_device_ipam_gaps.csv
network_device_build_report.txt
```

---

## Input Files

| File | Required | Source |
|---|---|---|
| NMS interface export CSV | Yes | NMS system export — one row per interface |
| `ipam-db/all_IP_networks_v3.14.csv` | Yes | IPAM prefix database — LPM location lookup (single source of truth) |

**NMS export column requirements:**
`Hostname`, `Device Type`, `Vendor`, `Model`, `Site`, `Location`, `IPv4 Address`, `Live Status`, `Routing Protocol`

---

## Usage

```bash
python3 build_network_device_dataset.py \
    --input IP_Datasets_Raw/nms_export.csv \
    --ipam-dir ipam-db/ \
    --out-dir .

# Dry run — print stats without writing
python3 build_network_device_dataset.py \
    --input IP_Datasets_Raw/nms_export.csv \
    --ipam-dir ipam-db/ \
    --dry-run
```

---

## CLI Reference

| Flag | Required | Description |
|---|---|---|
| `--input FILE` | Yes | NMS interface export CSV |
| `--ipam-dir DIR` | Yes | Directory containing `all_IP_networks_v*.csv` and `retail_networks_v*.csv` |
| `--out-dir DIR` | No | Output directory (default: current directory) |
| `--dry-run` | No | Print stats without writing output files |

---

## Output Files

### ent-ipdataset-NETWORK-DEVICE-INVENTORY-v\<DATE\>.csv

One row per network device. Register with:
```bash
./ipam-db.py --import ent-ipdataset-NETWORK-DEVICE-INVENTORY-v20260414.csv \
    --type ent_network_devices
```

| Column | Description |
|---|---|
| `HOSTNAME` | Device hostname |
| `DEVICE_TYPE` | NMS device classification (Cisco IOS Switch, F5 Load Balancer, etc.) |
| `VENDOR` | Hardware vendor |
| `MODEL` | Hardware model |
| `CANONICAL_LOCATION` | Resolved canonical site name (`Scottsdale AZ - Shea DC`) |
| `LOCATION_SOURCE` | How location was resolved: `location_field`, `ipam_lpm`, `hostname_prefix`, `site_class_only`, `unresolved` |
| `SITE_CLASS` | DC / RETAIL / CORP / BRANCH |
| `SITE_NAME` | Site display name |
| `HERITAGE` | CVS / Aetna / HCB |
| `ROUTING_DOMAIN` | IPAM routing domain |
| `CLOUD_PLATFORM` | Azure / GCP / AWS / on-prem |
| `FW_POLICY` | FW zone policy from IPAM LPM |
| `MANAGEMENT_IP` | Primary management IP |
| `CONNECTED_SUBNETS` | Pipe-delimited list of connected interface subnets |
| `CONNECTED_IPS` | Pipe-delimited list of interface IPs |
| `INTERFACE_COUNT` | Total interface count |
| `LIVE_INTERFACES` | Interfaces with status `up` |
| `PUBLIC_IPS` | Public IP addresses if any |
| `IPAM_GAPS` | Count of interface subnets not found in IPAM |

### network_device_ipam_gaps.csv

Subnets present in NMS interface data but absent from `all_IP_networks`. Each row is a coverage gap to investigate.

### network_device_build_report.txt

Summary: device counts by type, location resolution breakdown, IPAM coverage stats.

---

## Location Resolution

Three layers applied in order:

**Layer 1 — Location field string matching (`LOCATION_FIELD_MAP`)**
Matches known address strings in the NMS `Location` field:
- `9501 E Shea` → `Scottsdale AZ - Shea DC`
- `930 Middle` → `Middletown CT - Aetna MDC`
- `570 Pigeon` → `Windsor CT - Aetna WDC`
- `1 CVS Drive` → `Woonsocket RI - RI One`
- `2100 Highland` → `Cumberland RI - 2100 Highland`
- etc.

**Layer 2 — IPAM LPM on interface IPs**
Each interface IP is looked up against `all_IP_networks`. The `Location` field from the matching IPAM prefix is used. `cidr_24` overlay corrects stale values.

**Layer 3 — Hostname prefix**
CVS enterprise hostname site codes (e.g. `PAZSH` → Shea, `RRICM` → Cumberland).

---

## IPAM LPM

`build_lpm()` loads `all_IP_networks_v3.14` as the single source of truth for all subnet→location mapping. The `cidr_24` overlay has been abolished — `all_IP_networks` now contains authoritative `CANONICAL_LOCATION`, `FW_POLICY`, `ROUTING_DOMAIN`, and `HERITAGE` directly.

---

## Device Types

| Device Type | Count (typical) |
|---|---|
| Cisco IOS Switch | 2,529 |
| Cisco Nexus Switch | 1,152 |
| Cisco Router | 925 |
| Cisco Firepower NGFW with FTD | 431 |
| Cisco ACI Leaf Switch | 306 |
| F5 Load Balancer | 279 |
| Cisco ASA Firewall | 200 |
| Dell EMC Switch | 169 |
| Cisco WLC | 104 |
| Infoblox | 90 |
| End System | 18,005 |

---

## Re-running After IPAM Updates

Whenever `all_IP_networks` is updated, re-run this script to refresh location data:

```bash
python3 build_network_device_dataset.py \
    --input IP_Datasets_Raw/nms_export.csv \
    --ipam-dir ipam-db/

# Register the new version
./ipam-db.py --import ent-ipdataset-NETWORK-DEVICE-INVENTORY-v<DATE>.csv \
    --type ent_network_devices
```

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.1 | 2026-04-14 | **cidr_24 overlay removed** — `all_IP_networks_v3.14` is single source of truth; `CANONICAL_LOCATION` field used directly |
| v1.0 | 2026-04-14 | Initial release |
