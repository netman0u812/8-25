# build_app_inventory.py — CCD Platform App Inventory Tool

**Version:** 1.1  
**Working directory:** `~/Documents/IP_Lookup/`  
**Primary input:** `ipam-db/ent_host_master_v*.csv` (auto-discovers latest version)

---

## Overview

`build_app_inventory.py` aggregates every host, subnet, and location that makes up each registered application in the CVS Health enterprise. It reads `ent_host_master` — which merges ADL, SNOW, and IPAM data — and produces both static CSV reports and an interactive terminal browser.

The tool handles two categories of asset:

- **Registered applications** — hosts with an APM ID in `APM_IDS`. One host can belong to multiple apps (pipe-separated APM IDs are exploded).
- **Infrastructure groups** — hosts with no APM registration but a recognised infrastructure `SERVER_CLASS` (ESX, Kubernetes, appliances etc.). These are synthesised into `INFRA-*` pseudo-APM entries so they appear in every view alongside real apps.

Hosts with neither an APM ID nor a recognised infrastructure class are written to `app_inventory_no_apm.csv` and excluded from aggregations.

---

## Quick Start

```bash
# Generate all CSV reports
python3 build_app_inventory.py

# Custom directories
python3 build_app_inventory.py --ipam-dir ipam-db/ --out-dir app-inventory/

# Launch the interactive browser (no files written)
python3 build_app_inventory.py --browse

# Browser with CPC services and IP dataset enrichment
python3 build_app_inventory.py --browse \
  --cpc-services ipdatasets/cpc_infra_services.csv \
  --ipdatasets-dir ipdatasets/
```

---

## Command-Line Arguments

| Argument | Default | Description |
|---|---|---|
| `--ipam-dir DIR` | `ipam-db` | Directory containing `ent_host_master_v*.csv` |
| `--out-dir DIR` | `app-inventory` | Output directory for CSV reports |
| `--apm APM_ID,...` | — | Filter output to specific APM ID(s), comma-separated |
| `--acronym NAME,...` | — | Filter output to specific app acronym(s), comma-separated |
| `--top N` | — | Only write the top N apps by host count |
| `--no-hosts` | off | Skip `app_host_map.csv` (saves time/disk for summary-only runs) |
| `--browse` | off | Launch the interactive browser after loading (no files written) |
| `--cpc-services FILE` | — | Path to `cpc_infra_services.csv` — enables `[C]PC` browser command |
| `--ipdatasets-dir DIR` | — | Path to `ipdatasets/` directory — enables `[D]ataset` browser command |

---

## Output Files

All files are written to `--out-dir` (default `app-inventory/`). Every file includes `#ROWS=` and `#VERSION=` comment headers.

### app_inventory.csv
**One row per APM ID.** The primary summary report — sorted by host count descending.

| Column | Description |
|---|---|
| `APM_ID` | APM application identifier |
| `APP_ACRONYMS` | Pipe-separated acronyms (e.g. `ZSC \| ZPA`) |
| `APP_NAMES` | Up to 3 application names |
| `HOST_COUNT` | Total hosts assigned to this app |
| `SUBNET_COUNT` | Distinct /24 subnets occupied |
| `LOCATION_COUNT` | Distinct canonical locations |
| `DC_HOSTS` | Hosts in datacenter / COLO facilities |
| `CLOUD_HOSTS` | Hosts in cloud environments |
| `CORPORATE_HOSTS` | Hosts in campus / corporate facilities |
| `OTHER_HOSTS` | Hosts not classified above |
| `DOMINANT_HERITAGE` | Most common heritage (CVS / AETNA) |
| `PCI_FLAG` | `PCI` if any host is in PCI scope |
| `DOMINANT_RISK` | Most common risk tier |
| `DOMINANT_RD` | Most common routing domain |
| `DOMINANT_ENV` | Most common environment (PROD / NONPROD / DEV) |
| `DOMINANT_OS` | Most common OS group |
| `SOX_CRITICAL` | `SOX` if any host is SOX-critical |
| `PHI` | `PHI` if any host handles protected health info |
| `PII` | `PII` if any host handles personally identifiable info |
| `LOCATIONS` | Up to 5 canonical locations (+ count of remainder) |

---

### app_location_map.csv
**One row per app × location.** Shows how each application is distributed across sites.

| Column | Description |
|---|---|
| `APM_ID` | APM identifier |
| `APP_ACRONYMS` | App acronym(s) |
| `CANONICAL_LOCATION` | Site name |
| `HOST_COUNT` | Hosts at this location for this app |
| `SUBNET_COUNT` | Distinct /24s at this location |
| `SUBNETS` | Up to 6 CIDRs (pipe-separated) |
| `ROUTING_DOMAIN` | Dominant routing domain at this location |
| `FACILITY_TYPE` | Facility type at this location |

---

### app_subnet_map.csv
**One row per app × /24 subnet.** Useful for firewall rule scoping and network object generation.

| Column | Description |
|---|---|
| `APM_ID` | APM identifier |
| `APP_ACRONYMS` | App acronym(s) |
| `CIDR_24` | /24 subnet in CIDR notation |
| `CANONICAL_LOCATION` | Site name for this subnet |
| `HOST_COUNT` | Hosts on this subnet for this app |
| `IP_ADDRESSES` | Up to 8 individual IPs (pipe-separated) |
| `ROUTING_DOMAIN` | Routing domain |
| `FACILITY_TYPE` | Facility type |

---

### app_host_map.csv
**One row per app × host.** The full host-level footprint for every application. Omitted when `--no-hosts` is passed.

| Column | Description |
|---|---|
| `APM_ID` | APM identifier |
| `APP_ACRONYM` | App acronym for this assignment |
| `IP_ADDRESS` | Host IP |
| `SERVER_NAME` | Hostname |
| `OS_GROUP` | OS family (Windows Server, Linux, AIX, Appliance, etc.) |
| `SERVER_CLASS` | SNOW server class |
| `CANONICAL_LOCATION` | Site name |
| `CIDR_24` | /24 subnet |
| `ROUTING_DOMAIN` | Routing domain |
| `HERITAGE` | CVS / AETNA |
| `PCI` | PCI designation |
| `RISK_TIER` | Risk tier |
| `OPERATIONAL_STATUS` | Operational / Non-Operational / Retired |
| `ACTIVE_STATUS` | Active / Retired |

---

### app_inventory_no_apm.csv
Hosts with no APM registration and no recognised infrastructure class. Not counted in any application. Useful for identifying SNOW-only and Aetna legacy hosts that need APM registration.

| Column | Description |
|---|---|
| `IP_ADDRESS` | Host IP |
| `SERVER_NAME` | Hostname |
| `OS_GROUP` | OS family |
| `SERVER_CLASS` | SNOW server class |
| `CANONICAL_LOCATION` | Site name |
| `ROUTING_DOMAIN` | Routing domain |
| `HERITAGE` | CVS / AETNA |
| `PCI` | PCI designation |
| `RISK_TIER` | Risk tier |

---

### Network object exports (app-inventory/network-objects/)
Generated on demand from the `[N]etwork` browser command. One file per app per export type.

**Subnet list** — `{APM}_{ACRONYM}_network_objects_subnets.txt`  
One /24 CIDR per line, grouped by canonical location with `# location` section headers. Paste-ready for firewall platform or Stealthwatch host group import.

**IP list** — `{APM}_{ACRONYM}_network_objects_ips.txt`  
Individual host IPs sorted numerically — one per line. Clean flat file for /32 host object lists.

Both files include a comment header with APM ID, acronym, generated timestamp, and counts.

---

## Infrastructure Groups

Hosts with no APM ID but a recognised `SERVER_CLASS` are automatically classified into synthetic `INFRA-{CLASS}-{ENV}` groups. These appear in all browser views alongside registered applications.

### Recognised infrastructure classes

| INFRA Class | Source (`SERVER_CLASS` / `PLATFORM_TYPE`) |
|---|---|
| `ESX-HOST` | `PLATFORM_TYPE = ESX-HOST` or `SERVER_CLASS` contains "ESX Server" |
| `KUBERNETES` | `PLATFORM_TYPE = KUBERNETES` |
| `CONTAINER-BRIDGE` | `PLATFORM_TYPE = CONTAINER-BRIDGE` |
| `NETWORK-APPLIANCE` | `SERVER_CLASS` contains "Network Appliance Hardware" |
| `DATAPOWER` | `SERVER_CLASS` contains "Data Power Hosting Server" |
| `WEB-GATEWAY` | `SERVER_CLASS` contains "Web Gateway" |
| `CLOUD-VM` | `SERVER_CLASS` contains "Cloud WebServer" |
| `PLATFORM` | All other infra |

### Environment derivation rules

Environment is appended to the class to form the full synthetic ID (e.g. `INFRA-ESX-HOST-PROD`):

| Platform | Environment source |
|---|---|
| **ESX-HOST** | `OPERATIONAL_STATUS` only — `Operational` → PROD, `Non-Operational` → NONPROD |
| **KUBERNETES** | Cluster name keywords: `nonprod/nonprd/-np-` → NONPROD; `dev/devc` → DEV; `qa/test/sit/uat` → QA; `poc-/-poc-` → NONPROD; GKE/AKS/cloudpak without nonprod keyword → PROD |
| **NETWORK-APPLIANCE / DATAPOWER / WEB-GATEWAY** | `OPERATIONAL_STATUS` only (site-based naming collides with env chars) |
| **Generic** | CVS7 hostname position 4–8 character: `p` → PROD, `d` → DEV, `q`/`t` → QA; falls back to `OPERATIONAL_STATUS` |
| **Any** | `ACTIVE_STATUS = RETIRED` or `OPERATIONAL_STATUS` contains "retired" → DECOMMISSIONED |

---

## Interactive Browser

Launch with:
```bash
python3 build_app_inventory.py --browse
```

The browser header shows live counts: total apps, host-assignments, and subnet-assignments.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CCD App Inventory Browser   1,924 apps  |  55,793 host-assignments  |  13,394 subnet-assignments
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### Browser Commands

#### `[S]` Search
Keyword, acronym, or APM ID search across all app names and acronyms. Results displayed as a paginated list sorted by host count. Enter a number to drill into any result.

```
> S
Search (keyword / acronym / APM ID): zscaler
→ Returns paginated list of all apps matching "zscaler"
```

---

#### `[L]` Location
Browse all canonical locations sorted by total host count. Locations are paginated (20 per page). Enter a number to select a location and see all apps at that site as a paginated app list. Also accepts a keyword to jump to a matching location.

```
> L
→ Shows paginated list of all locations
→ Select a location → shows all apps at that site
→ Select an app → shows full app detail
```

---

#### `[Z]` Zone
Browse by CSNA zone. Zones are derived from the dominant `ROUTING_DOMAIN` and `FACILITY_TYPE` of each app:

| Zone | Derivation rule |
|---|---|
| `CLOUD` | `cloud` in routing domain or facility type |
| `AETNA-DC` | `internal-hcb` in routing domain |
| `CVS-DC` | `internal-pbm` in routing domain + datacenter facility |
| `RETAIL` | `retail` in routing domain or facility type |
| `DC-COLO` | `colo` in facility type or routing domain |
| `CORPORATE` | `corporate` or `campus` in facility type |
| `OTHER` | Everything else |

Select a zone to list all apps in it.

---

#### `[T]` Top N
List the top N applications by host count. Defaults to 20 if no number is entered. Useful for quick identification of the heaviest hitters.

```
> T
Show top N apps (default 20): 50
→ Shows top 50 apps by host count, paginated
```

---

#### `[P]` PCI
List all applications flagged as PCI in scope, sorted by host count. A PCI flag is set if any host assigned to the app has a non-empty, non-"No" PCI designation.

---

#### `[I]` Infra
Browse infrastructure groups (the `INFRA-*` synthetic entries). Shows a summary table of all groups by class and environment with host, subnet, and location counts. Paginated. Enter a number to drill into any group.

```
  #    Class                   Env              Hosts   Subnets   Locs
  ──────────────────────────────────────────────────────────────────────
  1    ESX-HOST                PROD             3,307       891     42
  2    KUBERNETES              PROD               892       234     18
  3    NETWORK-APPLIANCE       PROD               441        89     31
  ...
```

---

#### `[F]` Footprint
Infrastructure footprint breakdown by canonical location. Covers **all hosts** — APM-registered, infrastructure groups, and no-APM hosts — giving a complete picture of what physically lives at each site.

The summary table shows per-site: total hosts, ESXi count, Kubernetes count, virtual vs physical split, and PCI host count.

```
  #    Location                                   Total    ESXi    K8s    Virt    Phys    PCI
  ──────────────────────────────────────────────────────────────────────────────────────────
  1    Las Vegas Switch COLO                      8,432   1,203     42   6,891     891    234
  2    Atlanta GA - Aetna DC                      6,104     892     18   4,823     421    189
```

Drilling into a location shows:
- Virtual vs physical split with percentages
- Operational status breakdown (Active / Non-Op / Retired)
- Heritage breakdown
- PCI host count
- **Platform type breakdown** (ESX-HOST, KUBERNETES, VIRTUAL-VM, PHYSICAL, etc.)
- **OS group breakdown** (Windows Server, Linux, AIX, Appliance, etc.)
- **Server class breakdown** (all SNOW server classes at this site)
- **Routing domain breakdown**

All sub-tables are paginated. Accepts keyword search to jump to a location by name.

---

#### `[H]` Host lookup
IP address or hostname lookup. Accepts exact IP, IP prefix, or partial hostname. Returns:
1. Paginated list of matching hosts with IP, hostname, OS, and location
2. All applications the matched hosts belong to
3. Option to drill into any of those apps

```
> H
IP address or hostname (partial OK): atl-01a
→ Shows all hosts matching that hostname fragment
→ Shows all apps those hosts belong to
→ Enter a number to view full app detail
```

---

#### `[N]` Network objects
Generate a network object list (subnet CIDRs or individual host IPs) for a specific application. Useful for firewall rule scoping, Stealthwatch host group imports, and network access control lists.

```
> N
App (APM ID, acronym, keyword, or ? to browse): zsc

  APM0013984  ZSC | Zscaler
  142 subnets  |  3,297 hosts

  [S]ubnets — /24 CIDR list grouped by location
  [I]P list — individual host IPs (/32)
  [V]iew    — show subnets in terminal (no export)
  [B]ack
```

- **`?`** at the prompt opens a browseable list of all apps sorted by APM ID or acronym, so you can find an app without knowing its APM ID
- **`[S]` Subnets** — exports `/24` CIDRs grouped by location to `app-inventory/network-objects/{APM}_{ACRONYM}_network_objects_subnets.txt`
- **`[I]` IP list** — exports individual host IPs to `app-inventory/network-objects/{APM}_{ACRONYM}_network_objects_ips.txt`
- **`[V]` View** — shows subnets paginated in the terminal without writing a file

---

#### `[C]` CPC Services *(requires `--cpc-services`)*
Browse the CPC Master Security Template service catalogue. Lists all parsed service objects with IP ranges and port definitions. Enables export of CPC-specific network object lists.

Requires: `--cpc-services ipdatasets/cpc_infra_services.csv`

---

#### `[D]` Dataset browser *(requires `--ipdatasets-dir`)*
Browse all registered IP datasets (AWS, Azure, Zscaler, VPN partners, F5 VIPs etc.) from `ip_dataset.json`. Supports:
- Listing all datasets by class and provider
- Viewing CIDRs for any dataset paginated in the terminal
- Filtering by region (for Azure/AWS)
- Exporting network object files for any dataset

Requires: `--ipdatasets-dir ipdatasets/`

---

#### `[#]` Drill-in shortcut
After any list command, type a number at the main menu to drill directly into that list item without re-running the search.

---

#### `[Q]` Quit

---

## App Detail View

Selecting any application from any list shows its full detail:

```
════════════════════════════════════════════════════════════════════════
  APM0013984  ZSC | Zscaler
════════════════════════════════════════════════════════════════════════
  App name:    Zscaler Secure Web Proxy
  Heritage:    AETNA         Zone: CLOUD
  Routing:     Internal-Cloud
  Env:         PROD          OS: Linux
  Risk:        High
  Flags:       PCI

  Hosts:      3,297   DC=0  Cloud=3,297  Corp=0  Other=0
  Subnets:      142
  Locations:     18

  Locations  (18 total)
  ────────────────────────────────────────────────────────────────────
  Azure East US 2                          1,203     89
  Azure Central US                           891     34
  ...                           [N]ext / [P]rev / [D]one

  Subnets  (142 total — page 1/8)
  ────────────────────────────────────────────────────────────────────
  10.219.36.0/24                  892  Atlanta GA - Aetna DC
  ...

  Hosts  (3,297 total — page 1/165)
  ────────────────────────────────────────────────────────────────────
  10.219.36.21    atl-01a-r1-cab...  ESX-VMware   Atlanta GA - Aetna DC
  ...
```

All three sub-tables (Locations, Subnets, Hosts) are independently paginated with `[N]ext / [P]rev / [D]one` navigation.

---

## Pagination

All lists in the browser use 20 rows per page. Navigation is consistent throughout:

| Key | Action |
|---|---|
| `N` | Next page |
| `P` | Previous page |
| `M` or `Q` | Return to main menu |
| `D` | Done / exit sub-table (detail view sub-tables only) |
| `1–N` | Select item by number |
| keyword | Location lists accept text to jump to a matching entry |

---

## Data Sources

The tool reads from a single primary file — `ent_host_master_v*.csv` — which is built by `build_ent_host_dataset.py` and merges:

- **ADL** — Application Data Library (APM IDs, app names, acronyms, environments, risk tiers)
- **SNOW** — ServiceNow CMDB (server class, OS, operational status, PCI/SOX/PHI/PII flags)
- **IPAM** — `all_IP_networks` via LPM lookup (canonical location, routing domain, facility type, heritage)

The tool auto-discovers the latest version of `ent_host_master_v*.csv` using numeric version key extraction (`v20260419r2` sorts correctly vs `v20260401`).

---

## Known Limitations

- **Subnet granularity is /24** — app_subnet_map groups hosts into /24 buckets. Apps on the same /24 that have different sub-/24 allocations are not distinguished at subnet level.
- **Multi-app hosts** — a host with 3 APM IDs is counted once in each app's `host_count`. The total across all apps will exceed the total unique host count in ent_host_master.
- **Infrastructure env derivation** — ESX and appliance env is operational-status-only; there is no reliable hostname convention for these classes. A Non-Operational ESX host will show as NONPROD even if it is a decommissioned PROD host.
- **No-APM hosts** — 14,483 SNOW-only and Aetna legacy hosts have no APM registration. They appear in `[F]ootprint` totals and `app_inventory_no_apm.csv` but not in any app's host count. Requires APM registration to appear in app views.
- **stale `location_master_table.csv`** — must be regenerated after every `location_master` import. Stale cache causes R6 violations in host location resolution.

---

## File Versioning

| File | Version scheme | Notes |
|---|---|---|
| `ent_host_master` | `vYYYYMMDDrN` | Date + revision; `r2` = second rebuild same day |
| `all_IP_networks` | `vMAJOR.MINOR` | Semantic; `v3.44` |
| `location_master` | `vMAJOR.MINOR` | Semantic; `v3.20` |
| `app_inventory.csv` | `#VERSION=` header | Script version, not data version |
| Network object exports | Timestamped on generation | No version suffix in filename |

---

## Typical Workflow

```bash
# 1. Rebuild ent_host_master after IPAM updates
python3 build_ent_host_dataset.py \
  --app   IP_Datasets_Raw/APP_DATA-4-14/ADL_APP_INFO_Report.csv \
  --ent   IP_Datasets_Raw/APP_DATA-4-14/ENT_APP_INFRA_REPORT.csv \
  --snow  IP_Datasets_Raw/APP_DATA-4-14/SNOW_SERVER-REPORT.csv \
  --all-ip-networks ipam-db/all_IP_networks_v3.46.csv \
  --loc-master      ipam-db/location_master_v3.20.csv \
  --out   ipam-db/ent_host_master_v20260420.csv

# 2. Register new host master
./ipam-db.py --import ipam-db/ent_host_master_v20260420r1.csv --type ent_host_master

# 3. Rebuild CSV reports
python3 build_app_inventory.py --ipam-dir ipam-db/ --out-dir app-inventory/

# 4. Launch browser for investigation
python3 build_app_inventory.py --browse \
  --ipam-dir ipam-db/ \
  --cpc-services ipdatasets/cpc_infra_services.csv \
  --ipdatasets-dir ipdatasets/

# 5. Generate network objects for a specific app
# → Use [N] command in the browser, then [S] for subnets or [I] for IPs
# → Files written to app-inventory/network-objects/
```

---

## Directory Layout

```
~/Documents/IP_Lookup/
├── build_app_inventory.py          # This tool
├── ipam-db/
│   ├── ent_host_master_v20260419r2.csv   # Primary input (auto-discovered)
│   ├── all_IP_networks_v3.44.csv
│   └── location_master_v3.20.csv
├── ipdatasets/
│   ├── ip_dataset.json                   # Dataset registry
│   ├── ip_dataset_00113_20260413.csv     # Zscaler ZPA
│   ├── ent-ipdataset-ENTERPRISE-APP-SERVER-v20260414.csv
│   └── ...
├── app-inventory/                        # Output directory
│   ├── app_inventory.csv
│   ├── app_location_map.csv
│   ├── app_subnet_map.csv
│   ├── app_host_map.csv
│   ├── app_inventory_no_apm.csv
│   └── network-objects/
│       ├── APM0013984_ZSC_network_objects_subnets.txt
│       └── APM0013984_ZSC_network_objects_ips.txt
└── README_build_app_inventory.md         # This file
```
