# CCD Platform — IPAM, NMS & APP Dataset Build Guide

**Part of the CVS Health CCD Platform** · Network Inventory · Firewall Reporting · Security Tooling Pipelines

**Last updated:** 2026-04-27 · **Current dataset state:** see Part 7

---

## Overview

This guide covers the complete process for updating and rebuilding the three core CCD data layers:

- **IPAM** — `all_IP_networks`, `location_master`, `csna_site_registry` (Layer 1 + Layer 2)
- **NMS** — `ent_network_device_master` (network device inventory)
- **APP** — `ent_host_master` (application and server inventory)

These three datasets are interdependent. The correct build order is always: IPAM first, then NMS and APP (which both depend on IPAM for LPM location resolution).

```
location_master ─────────────┐
csna_site_registry ──────────┤
all_IP_networks (SSOT) ───────┼──→ build_ent_host_dataset.py      → ent_host_master
                              └──→ build_network_device_master.py  → ent_network_device_master
                                        ↓
                              generate_csna_hostgroups.py
                                        ↓
                              generate_csna_map.py
```

### Dependency import order (non-negotiable)

```
1. location_master          ← foundation — everything depends on this
2. csna_site_registry       ← depends on location_master (CX4 type-sync)
3. all_IP_networks          ← depends on csna_site_registry (R13 location check)
4. retail_networks          ← independent, but cross-checked against all_IP_networks
5. ent_host_master          ← depends on all_IP_networks (LPM location)
6. app_subnet_index         ← rebuilt after ent_host_master
7. ent_network_device_master ← depends on all_IP_networks (LPM location)
```

> **Never import in reverse order.** Every new `CANONICAL_LOCATION` in `all_IP_networks` needs a `csna_site_registry` entry first or R13 violations will accumulate.

---

## Part 0 — ipam-db.py Operations Reference

### 0.1 Pre-flight check before any import

Use `--plan` to check dependency status and preview what needs to happen:

```bash
cd ~/Documents/IP_Lookup

# Check current state of all datasets
python3 ipam-db.py --plan

# Pre-flight a specific proposed import
python3 ipam-db.py --plan --import ipam-db/all_IP_networks_v3.57.csv
```

Output shows:
- Current version and row count for every registered dataset
- Any new `CANONICAL_LOCATION` values not yet in `csna_site_registry`
- Recommended import sequence with exact commands

### 0.2 Standard import

```bash
python3 ipam-db.py --import ipam-db/<filename>.csv --type <stem>
```

Common stems: `all_IP_networks`, `location_master`, `csna_site_registry`,
`retail_networks`, `ent_host_master`, `app_subnet_index`, `ent_network_device_master`

After every import the script prints:
- Audit results (R-rules) for IPAM prefix files
- Cross-check results (CX-rules) across all four managed files
- **Next steps** — ordered list of downstream rebuilds required

### 0.3 Archive management

Old versions are automatically moved to `../ipam-db-archive/` on every import.
For one-time cleanup of accumulated old versions:

```bash
# Preview what would be archived
python3 ipam-db.py --archive --dry-run

# Run for real
python3 ipam-db.py --archive
```

> **Warning:** `--archive` checks `ip_dataset.json` and warns before archiving any file
> referenced there but deregistered from `ipam-db.json`. Answer `N` and re-register the
> file first, then archive.

Files never archived regardless of registration status:
- `ent-ipdataset-ENTERPRISE-APP-SERVER-*` — `iplookup.sh` and `ip_dataset.py` expect these on disk
- `location_master_table.csv` — unversioned lookup cache
- `cross_check_violations.csv`, `hostname_prefix_registry.csv`

### 0.4 Remove a registry entry

```bash
python3 ipam-db.py --remove <stem>
```

This removes the registry entry only — the CSV file is **not** deleted from disk.
Use `--archive` after removing to move the file to `ipam-db-archive/`.

### 0.5 Backup / restore

```bash
# Create snapshot of all ipam-db/ CSVs + registry
python3 ipam-db.py --backup

# List available snapshots
python3 ipam-db.py --list-backups

# Restore from snapshot (auto-backs up current state first)
python3 ipam-db.py --restore 20260427_143022
```

Backups land in `../backups/YYYYMMDD_HHMMSS/` (sibling of `ipam-db/`, inside `IP_Lookup/`).

---

## Part 1 — IPAM Update

### 1.1 When to Update IPAM

- New subnets discovered via NMS export or network team notification
- Unknown-zone CSNA entries that need location resolution
- Quarterly Nautobot reconciliation pass
- After running `build_ipam_promotion_candidates.py` and approving candidates

### 1.2 Versioning Rules

Every change to any IPAM file **must** produce a new version file. No exceptions.

| File | Versioning | Format |
|---|---|---|
| `all_IP_networks` | Semantic `vMAJOR.MINOR` | `all_IP_networks_v3.57.csv` |
| `location_master` | Semantic `vMAJOR.MINOR` | `location_master_v3.34.csv` |
| `retail_networks` | Semantic `vMAJOR.MINOR` | `retail_networks_v2.6.csv` |
| `csna_site_registry` | Semantic `vMAJOR.MINOR` | `csna_site_registry_v2.11.csv` |
| `ent_host_master` | Date + revision | `ent_host_master_v20260427r1.csv` |
| `ent_network_device_master` | Date | `ent_network_device_master_v20260427.csv` |

Every row in `all_IP_networks` must carry `DATASET_VERSION` and `LOC_MASTER_VERSION` stamps.

### 1.3 Adding Subnets to IPAM

**Pre-requisite:** Confirm `CANONICAL_LOCATION` exists in `csna_site_registry` first.
If adding a new location, add it to `csna_site_registry` and import that before `all_IP_networks`.

```bash
cd ~/Documents/IP_Lookup

# Pre-flight — check new locations against registry before importing
python3 ipam-db.py --plan --import ipam-db/all_IP_networks_v3.57.csv

# Import
python3 ipam-db.py --import ipam-db/all_IP_networks_v3.57.csv --type all_IP_networks
```

Required fields for every new row:
```
CIDR, PREFIX_LEN, NETWORK_ADDRESS, BROADCAST_ADDRESS,
CANONICAL_LOCATION, NET_TYPE, ROUTING_DOMAIN, HERITAGE,
LOCATION_TYPE, FACILITY_TYPE, STATUS, SOURCE, DATA_QUALITY,
DATASET_VERSION, LOC_MASTER_VERSION
```

### 1.4 IPAM Promotion (Automated Gap-Fill)

Use `build_ipam_promotion_candidates.py` to find and promote subnets using host inventory signals.

```bash
./build_ipam_promotion_candidates.py --dry-run    # review first
./build_ipam_promotion_candidates.py              # generate patch
./build_ipam_promotion_candidates.py --review     # interactive review of ambiguous cases
```

See `README_build_ipam_promotion_candidates.md` for full workflow and known review patterns.

### 1.5 Updating csna_site_registry

Required whenever a new `CANONICAL_LOCATION` is being added to `all_IP_networks`.

```bash
# 1. Generate gaps report — shows which locations are unregistered
python3 build_csna_site_registry.py --gaps-csv
# Output: ipam-db/site_registry_gaps_YYYYMMDD_HHMMSS.csv

# 2. Edit the gaps CSV: fill in SUGGESTED_SITE_DC_NAME and SUGGESTED_KEYWORDS
# 3. Batch import the filled CSV
python3 build_csna_site_registry.py --batch ipam-db/site_registry_gaps_<timestamp>.csv
# Output: ipam-db/csna_site_registry.csv (bare — must be versioned before import)

# 4. Copy to versioned filename and import
cp ipam-db/csna_site_registry.csv ipam-db/csna_site_registry_v2.11.csv
python3 ipam-db.py --import ipam-db/csna_site_registry_v2.11.csv --type csna_site_registry

# 5. Delete the gaps CSV (one-time input file, not needed after import)
rm ipam-db/site_registry_gaps_<timestamp>.csv
```

> **Critical:** Always copy the bare `csna_site_registry.csv` to a versioned filename before
> importing. Never import the bare file directly — the registry will point to the bare file
> and future batch imports may silently overwrite it with stale data.

### 1.6 Updating location_master

```bash
# After editing location_master_v3.34.csv
python3 ipam-db.py --import ipam-db/location_master_v3.34.csv --type location_master
# location_master_table.csv is auto-rebuilt by ipam-db.py after every location_master import
```

> **Note:** `location_master_table.csv` is the unversioned lookup cache used for R13 audit
> validation. `ipam-db.py` rebuilds it automatically — do not edit it manually.

### 1.7 Retail Networks

Retail subnet updates go into `retail_networks`, never into `all_IP_networks`:

```bash
python3 ipam-db.py --import ipam-db/retail_networks_v2.6.csv --type retail_networks
```

### 1.8 Post-Import Rebuild Sequence

After any `all_IP_networks` import, `ipam-db.py` prints the required next steps.
The full sequence is:

```bash
# 1. Rebuild app subnet index
python3 build_app_subnet_index.py
python3 ipam-db.py --import app-inventory/app_subnet_index_v<N>.csv --type app_subnet_index

# 2. Regenerate CSNA hostgroups
python3 generate_csna_hostgroups.py

# 3. Verify test suite
bash test_iplookup.sh
```

---

## Part 2 — NMS Dataset Build

### 2.1 Source Files

```
IP_Datasets_Raw/NMS-Source/
    site_ip_report_<date>.csv    ← primary NMS interface export
```

### 2.2 Rebuild Network Device Dataset

```bash
cd ~/Documents/IP_Lookup

python3 build_network_device_master.py \
  --nms-dir  NMS-Invintory/ \
  --ipam-dir ipam-db/ \
  --out-dir  ipam-db/

python3 ipam-db.py --import ipam-db/ent_network_device_master_v<DATE>.csv \
  --type ent_network_device_master
```

### 2.3 Reducing Unknown NMS Devices

Devices in `2_network_devices_unknown_location.csv` have hostnames that don't match
the hostname translation tables. Resolution paths:

```bash
# Check what patterns are failing
python3 hostname_translate.py \
  --batch <(awk -F, 'NR>1 {print $2}' ipam-db/2_network_devices_unknown_location.csv) \
  --format csv | grep UNKNOWN | head -30

# Add a new prefix
python3 hostname_translate.py --db-dir ipam-db/ \
  --add-prefix <prefix> "<Site Name ST - Location>" <HERITAGE> <ZONE>
```

---

## Part 3 — APP Dataset Build

### 3.1 Source Files

Application/server data comes from three sources in `IP_Datasets_Raw/APP_DATA-<date>/`:

| File | Source | Contents |
|---|---|---|
| `ADL_APP_INFO_Report.csv` | ADL | APM IDs, app acronyms, app names, environments, PCI, risk tier |
| `ENT_APP_INFRA_REPORT.csv` | ADL infrastructure | Server-to-application mappings |
| `SNOW_SERVER-REPORT.csv` | ServiceNow | Server name, OS, hardware, site location (declared) |
| `Master Inventory - 3rd Party Conn.csv` | CMDB | Third-party connection inventory (optional `--cmdb`) |
| `SNOW_APP_VAL-Repost.csv` | ServiceNow | App validation data (optional `--snow-val`) |

> **Important:** The `SERVER_SITE` / location field in SNOW is the **declared** location
> from the application team — often the server owner's office, not the physical server.
> `CANONICAL_LOCATION` in `ent_host_master` is always derived from IP via IPAM LPM, never
> from this field.

**Current source directory:** `IP_Datasets_Raw/APP_DATA-4-14/`

### 3.2 Rebuild ent_host_master

```bash
cd ~/Documents/IP_Lookup

python3 build_ent_host_dataset.py \
  --app             IP_Datasets_Raw/APP_DATA-4-14/ADL_APP_INFO_Report.csv \
  --ent             IP_Datasets_Raw/APP_DATA-4-14/ENT_APP_INFRA_REPORT.csv \
  --snow            IP_Datasets_Raw/APP_DATA-4-14/SNOW_SERVER-REPORT.csv \
  --all-ip-networks ipam-db/all_IP_networks_v3.56.csv \
  --loc-master      ipam-db/location_master_table.csv \
  --cmdb            IP_Datasets_Raw/APP_DATA-4-14/"Master Inventory - 3rd Party Conn.csv" \
  --snow-val        IP_Datasets_Raw/APP_DATA-4-14/SNOW_APP_VAL-Repost.csv \
  --out             ipam-db/

# Import (script auto-increments rN suffix if date already exists)
python3 ipam-db.py --import ipam-db/ent_host_master_v20260427r1.csv \
  --type ent_host_master
```

> **Note:** Update `--all-ip-networks` and `--loc-master` to point to the current versions
> when rebuilding. The output filename date will match the run date automatically.

### 3.3 Rebuild ipdataset after ent_host_master

After importing `ent_host_master`, rebuild the ENTERPRISE-APP-SERVER ipdataset
so `iplookup.sh` uses the latest data:

```bash
# The build script writes ent-ipdataset-ENTERPRISE-APP-SERVER-v<DATE>.csv to ipam-db/
# Register it in ip_dataset.json
python3 ip_dataset.py --import ipam-db/ent-ipdataset-ENTERPRISE-APP-SERVER-v<DATE>.csv \
  --E ENTERPRISE-APP-SERVER
```

> **Important:** `ent-ipdataset-ENTERPRISE-APP-SERVER-*.csv` files must always remain in
> `ipam-db/` — they are never moved to `ipam-db-archive/` by `--archive` because
> `iplookup.sh` and `ip_dataset.py` reference them by glob pattern.

### 3.4 Location Source Priority

```
1. IP → all_IP_networks LPM      → CANONICAL_LOCATION  (authoritative — always wins)
2. IP → hostname_translate.py    → HOSTNAME_DERIVED_LOCATION (fallback if no LPM hit)
3. ADL/SNOW declared location    → SOURCE_DECLARED_LOCATION  (stored for reference only)
```

The `LOCATION_SOURCE` field records which path was used: `ipam_lpm`, `ipam_lpm_stale`, or `unresolved`.

### 3.5 Verification After Build

```bash
# Check location source distribution
python3 -c "
import csv; from collections import Counter
with open('ipam-db/ent_host_master_v20260427r1.csv', newline='', errors='replace') as f:
    rows = list(csv.DictReader(l for l in f if not l.startswith('#')))
src = Counter(r.get('LOCATION_SOURCE','') for r in rows)
for k,v in src.most_common(): print(f'{v:>6,}  {k}')
print(f'---')
print(f'{len(rows):>6,}  TOTAL')
"

# Check unknown location count
python3 -c "
import csv
with open('ipam-db/ent_host_master_v20260427r1.csv', newline='', errors='replace') as f:
    rows = [r for r in csv.DictReader(l for l in f if not l.startswith('#'))
            if 'unknown' in r.get('CANONICAL_LOCATION','').lower()
            or not r.get('CANONICAL_LOCATION','').strip()]
print(f'Unresolved hosts: {len(rows)}')
"
```

---

## Part 4 — CSNA Hostgroup Generation

### 4.1 Generate

```bash
cd ~/Documents/IP_Lookup

python3 generate_csna_hostgroups.py \
  --ipam-dir ipam-db/ \
  --vpn-dir  ipam-db/ \
  --out-dir  csna_output/
```

The script runs a post-write continuity check automatically (Checks 1-7). Check 7
validates that every `<ip-address-ranges>` element contains a valid CIDR prefix —
not an IP/IP malformation. The script exits with code 1 if any check fails.

### 4.2 Known issue — IP/IP CIDR malformation

Symptom: `<ip-address-ranges>167.69.153.151/216.39.107.216</ip-address-ranges>`

Cause: `vpn_protected_subnets.csv` has rows where the remote peer network address
was written into the `IP_NETWORK` field instead of the CIDR prefix length.

Fix (in script v3.4+): `_sanitise_cidr()` auto-corrects these to `/32` and logs
a WARNING for each correction. Check the WARNING output to identify which VPN
partner entries need to be fixed in the source data.

Manual fix for existing XML output: see `CSNA_Import_*_fixed.xml`.

### 4.3 Import to SNA

Import the generated XML via the Stealthwatch Management Console:
- **File:** `csna_output/CSNA_Import_<TIMESTAMP>.xml`
- **Type:** Host Group import

---

## Part 5 — Full Rebuild Sequence

When raw source data has been updated (new ADL/SNOW export), run the complete sequence:

```bash
cd ~/Documents/IP_Lookup

# 0. Check current state and pre-flight
python3 ipam-db.py --plan

# 1. Run IPAM promoter to resolve unknown subnets
python3 build_ipam_promotion_candidates.py --dry-run
python3 build_ipam_promotion_candidates.py
python3 build_ipam_promotion_candidates.py --review     # if any ambiguous cases
# merge patch and import — see Part 1.4

# 2. Update csna_site_registry if any new locations were added to IPAM
python3 build_csna_site_registry.py --gaps-csv
# <fill gaps CSV, copy to versioned file, import>
python3 ipam-db.py --import ipam-db/csna_site_registry_v<N>.csv --type csna_site_registry

# 3. Import updated all_IP_networks
python3 ipam-db.py --import ipam-db/all_IP_networks_v<N>.csv --type all_IP_networks

# 4. Rebuild NMS dataset
python3 build_network_device_master.py \
  --nms-dir  NMS-Invintory/ \
  --ipam-dir ipam-db/ \
  --out-dir  ipam-db/
python3 ipam-db.py --import ipam-db/ent_network_device_master_v<DATE>.csv \
  --type ent_network_device_master

# 5. Rebuild APP dataset
python3 build_ent_host_dataset.py \
  --app             IP_Datasets_Raw/APP_DATA-4-14/ADL_APP_INFO_Report.csv \
  --ent             IP_Datasets_Raw/APP_DATA-4-14/ENT_APP_INFRA_REPORT.csv \
  --snow            IP_Datasets_Raw/APP_DATA-4-14/SNOW_SERVER-REPORT.csv \
  --all-ip-networks ipam-db/all_IP_networks_v<N>.csv \
  --loc-master      ipam-db/location_master_table.csv \
  --cmdb            IP_Datasets_Raw/APP_DATA-4-14/"Master Inventory - 3rd Party Conn.csv" \
  --snow-val        IP_Datasets_Raw/APP_DATA-4-14/SNOW_APP_VAL-Repost.csv \
  --out             ipam-db/
python3 ipam-db.py --import ipam-db/ent_host_master_v<DATE>r1.csv --type ent_host_master

# 6. Rebuild ipdataset
python3 ip_dataset.py --import ipam-db/ent-ipdataset-ENTERPRISE-APP-SERVER-v<DATE>.csv \
  --E ENTERPRISE-APP-SERVER

# 7. Rebuild app subnet index
python3 build_app_subnet_index.py
python3 ipam-db.py --import app-inventory/app_subnet_index_v<N>.csv --type app_subnet_index

# 8. Regenerate CSNA hostgroups
python3 generate_csna_hostgroups.py

# 9. Run quality gate
bash test_iplookup.sh

# 10. Archive old versions
python3 ipam-db.py --archive --dry-run    # verify list
python3 ipam-db.py --archive
```

---

## Part 6 — Troubleshooting

### R13-UNMAPPED-LOCATION violations on all_IP_networks import

```
CANONICAL_LOCATION: 'New Site TX - Corporate' has no site registry entry
```

**Fix:** Add the location to `csna_site_registry` before importing `all_IP_networks`.
Use `--plan` to pre-flight and see exactly which locations are missing:

```bash
python3 ipam-db.py --plan --import ipam-db/all_IP_networks_v<N>.csv
```

### CX4-TYPE-SYNC violations on csna_site_registry import

```
LOCATION_TYPE/SITE_CLASS mismatch for 'Woonsocket RI - PBM DR'
```

**Fix:** The `location_master` LOCATION_TYPE and `csna_site_registry` SITE_CLASS are
out of sync. Check both files for the site and align them. Common mappings:

| LM LOCATION_TYPE | Expected SITE_CLASS |
|---|---|
| `DR` | `DR` |
| `Corporate` | `CORPORATE` |
| `Call-Center` | `CVS-CALLCENTER` or `AETNA-CALLCENTER` |
| `Cloud-Peering` | `CLOUD` |
| `COLO` | `DC-COLO` |

> **Note:** If violations persist after fixing the registry, check that the correct
> versioned registry file was imported — not the bare `csna_site_registry.csv`.
> The bare file may contain stale data from a previous batch run.

### CX7-REGISTRY-LM-BACK violations (orphaned registry entries)

```
csna_site_registry entry 'Atlanta GA - Switch DC' has no backing location_master entry
```

**Fix:** The registry entry uses a stale site name. The correct name in `location_master`
is `Atlanta GA - Switch COLO`. Update the registry entry SITE_DC_NAME to match.

### CX6-LM-ORPHAN violations (permanent — expected)

These 8 entries are decommissioned sites with no subnets. They are expected and permanent:
- `Phoenix AZ - Cotton Center Call Center`
- `Honolulu HI / Greenfield IN / Davenport FL / Ontario CA` — Distribution Centers
- `Pittsburgh PA - CVS Specialty Pharmacy`
- `San Antonio TX - Omnicare`
- `Exeter NH - CarePlus`

### R8-NET-TYPE violations

```
NET_TYPE: 'Cloud-VM' not in valid NET_TYPE taxonomy
```

**Fix:** Use `Cloud-Azure`, `Cloud-GCP`, or `Cloud-AWS` instead of the generic `Cloud-VM`.

### ent_host_master rebuild writes wrong rN suffix

The build script auto-increments `rN` based on files present in `ipam-db/`.
If old revisions were archived, the script may write `r1` when you expect `r3`.
Import whatever it produces — `ipam-db.py` registers it correctly:

```bash
python3 ipam-db.py --import ipam-db/ent_host_master_v20260427r1.csv --type ent_host_master
```

### F5 / VPN ipdataset files missing after --archive

`--archive` may move ipdataset files if they were deregistered from `ipam-db.json`
before archiving. Recovery:

```bash
# Copy back from archive
cp ipam-db-archive/ent-ipdataset-F5-VIP-REGISTRY-v20260403.csv ipam-db/
cp ipam-db-archive/ent-ipdataset-F5-POOL-MEMBERS-v20260403.csv ipam-db/

# Re-register
python3 ipam-db.py --import ipam-db/ent-ipdataset-F5-VIP-REGISTRY-v20260403.csv
python3 ipam-db.py --import ipam-db/ent-ipdataset-F5-POOL-MEMBERS-v20260403.csv
```

**Prevention:** Always re-register files under their correct stems before running
`--archive`. Use `--archive --dry-run` to review the list first.

---

## Part 7 — Current Dataset State (as of 2026-04-27)

### Registered datasets

| Dataset | Version | Rows | Notes |
|---|---|---|---|
| `all_IP_networks` | v3.56 | 19,083 | +47 F5 pool member /24s from r8 |
| `location_master` | v3.33 | 9,930 | Includes CarePlus VDC fleet |
| `csna_site_registry` | v2.10 | 400 | Clean — 0 HIGH, 0 MEDIUM violations |
| `retail_networks` | v2.5 | 294,463 | Current |
| `app_subnet_index` | v1.7 | 2,600 | Rebuilt against r8 + v3.56 |
| `ent_host_master` | r8 | 58,871 | Built from APP_DATA-4-14 + CMDB merge |
| `ent_network_device_master` | v20260424 | 24,857 | Current |

### Source file locations

| Build | Source Directory |
|---|---|
| APP dataset | `IP_Datasets_Raw/APP_DATA-4-14/` |
| NMS dataset | `IP_Datasets_Raw/NMS-Source/` |
| IPAM promoter | reads `ipam-db/ent_host_master_*r8.csv` |

### Script versions

| Script | Version | Notes |
|---|---|---|
| `ipam-db.py` | v3.3 | --plan, --archive, overwrite fix, KEEP_PATTERNS |
| `generate_csna_hostgroups.py` | v3.4 | IP/IP CIDR fix, Check 7 format validation |
| `build_app_subnet_index.py` | v1.7 | Current |
| `build_ent_host_dataset.py` | v3.1 | CMDB merge, SNOW continue bug fix |
| `build_network_device_master.py` | v2.0 | Current |

### Open items

- [ ] 59 F5 pool member /24s held pending manual review (no EHM confirmation)
- [ ] BDL / UND CarePlus site codes still unidentified
- [ ] `vpn_protected_subnets.csv` source data has 18 IP/IP malformations — fix in source
- [ ] CSNA XML generation — run `generate_csna_hostgroups.py` and verify Check 7 passes
- [ ] New dataset design: `cvs_public_networks`, `fw_snat_networks`, `f5_vip_networks`
- [ ] ipam-db.py v3.4 — `--plan` command improvements (deferred)

### Cross-check status

Current violations — all expected / permanent:

| Rule | Count | Severity | Notes |
|---|---|---|---|
| CX6-LM-ORPHAN | 8 | LOW | Decommissioned sites — permanent |

0 HIGH · 0 MEDIUM · 8 LOW (expected)
