# CCD Platform — Session Restart Prompt — 2026-05-04
## Upload these files at session start:
- `ccd-data-governance-SKILL.md` — load first, governs all location decisions
- `ccd-versioning-SKILL.md` — governs all script delivery
- `CCD_Update_Process_v1_0.docx` — process reference
- `CCD_Tool_README_v1_0.docx` — tool reference

---

## Current Platform State

| Dataset | Version | Rows | Status |
|---|---|---|---|
| `location_master` | v4.4 | 10,169 | NEEDS PATCH → v4.5 |
| `all_IP_networks` | v3.67 | 20,079 | NEEDS PATCH → v3.68 |
| `ent_host_master` | v20260427r4 | 60,939 | NEEDS PATCH → r5 |
| `ent_network_device_master` | v20260501 | 10,849 | NEEDS PATCH |
| `app_subnet_index` | v1.7 | 2,600 | NEEDS REBUILD after EHM |
| `retail_networks` | v2.5 | — | STABLE ✓ |
| `mgmt_ip_index` | v1.2 | 21 | STABLE ✓ |

**Tools state:**
- `build_qualys_pipeline.py` v1.6 — installed, outputs in `./Qualys_processed_results/`
- `apply_ehm_enrichment.py` v1.1 — installed, APP_NAMES union merge fixed
- `ipam-db.py` v3.7 — installed
- `preflight_lm_check.py` v1.1 — installed, passing

---

## What We Are Fixing — Root Cause

Location, IPAM, and EHM data was being rebuilt from scratch on each
update cycle instead of merging into the registered master. Source
systems (NMS, Qualys, ADL) use their own location strings — not CCD
canonical names. Without merge-from-master discipline, each rebuild
re-introduced stale or wrong location values.

**Three specific problems being remediated:**
1. Cloud canonical names wrong/inconsistent in LM (17 stale entries)
2. IPAM cloud CIDR rows have wrong CANONICAL_LOCATION (1,768 rows)
3. EHM has 14,451 cloud hosts with wrong CANONICAL_LOCATION

---

## Step 1 — Location Master v4.4 → v4.5

### New canonical names to ADD:
| Canonical Name | Type | Heritage | Notes |
|---|---|---|---|
| `Cloud - Azure SecureHub UE1` | Cloud | CVS | UE1/UW3 contain-mode blocks |
| `Cloud - Azure SecureHub UE2` | Cloud | CVS | 10.152 active-growth |
| `Cloud - Azure East US 2` | Cloud | CVS | 10.155 Digital/PBM/MinuteClinic AKS |
| `Cloud - GCP East4 SecureHub` | Cloud | CVS | 10.114, 10.236 |
| `Cloud - GCP East4 PCI` | Cloud | CVS | 10.117 PCI/shared hub |
| `Cloud - GCP East4` | Cloud | Mixed | 10.112,143,149,157,247,252 |
| `Cloud - GCP West2` | Cloud | CVS | 10.158 |
| `Cloud - AWS East1 Prod` | Cloud | CVS | 10.207.0/18, 10.207.64/19 |
| `Cloud - AWS East1 NonProd` | Cloud | CVS | 10.207.96/19, 10.207.128/18 |
| `Cloud - AWS East2 Prod` | Cloud | CVS | 10.207.192/19 |
| `Cloud - AWS East2 NonProd` | Cloud | CVS | 10.207.224/19 |
| `Cloud - AWS East1 Aetna` | Cloud | AETNA | 10.208 — Aetna AWS unknown sub-alloc |

### Entries to RETIRE (set STATUS=Retired, do not delete):
```
Cloud - Azure CVS East US 2       (replaced by SecureHub UE1 + Azure East US 2)
Cloud - Azure CVS Central US      (mislabel — hosts are in UE1 SecureHub blocks)
Cloud - Azure CVS                 (too generic)
Cloud - Azure Aetna East US 2     (hosts are in UE1 SecureHub)
Cloud - Azure HCB - Aetna         (hosts are in UE1 SecureHub)
Cloud - Azure CVS West US         (1 host, in UE1 SecureHub)
Azure - Central US                (old format)
Azure - East US 2                 (old format)
West US Azure                     (non-standard format)
Cloud - Azure UE2 - SecureHub     (rename → Cloud - Azure SecureHub UE2)
Cloud - GCP US-East4 - CVS        (BU-suffix, replaced by zone-based)
Cloud - GCP US-East4 - Aetna      (BU-suffix, replaced by zone-based)
Cloud - GCP US-East4 - Aetna 2    (consolidate into GCP East4)
Cloud - GCP US-East4 - SecureHub  (rename → Cloud - GCP East4 SecureHub)
Cloud - GCP US-East4 - RxConnect  (BU-suffix, replaced by zone-based)
Cloud - GCP US-East4 - PCI        (rename → Cloud - GCP East4 PCI)
Cloud - GCP US-West2 - CVS        (rename → Cloud - GCP West2)
Cloud - GCP CVS West US 2         (duplicate)
Cloud - GCP US-East4              (missing zone label)
Cloud - GCP US-West2              (missing zone label)
GCP - US East 4                   (old format)
GCP - US West 2                   (old format)
AWS - US East 1                   (old format)
Cloud - AWS CVS East US           (generic)
Cloud - AWS US-East1 - Prod       (rename → Cloud - AWS East1 Prod)
Cloud - AWS US-East1 - NonProd    (rename → Cloud - AWS East1 NonProd)
Cloud - AWS US-East2 - Prod       (rename → Cloud - AWS East2 Prod)
Cloud - AWS US-East2 - NonProd    (rename → Cloud - AWS East2 NonProd)
Las Vegas NV - Switch DC          (stale → Las Vegas NV - Switch Colo)
Las Vegas NV - Switch COLO        (stale → Las Vegas NV - Switch Colo)
Cumberland RI - Highland Lab      (ambiguous — which building?)
```

---

## Step 2 — IPAM all_IP_networks v3.67 → v3.68

**Method:** CIDR-LPM lookup against authoritative cloud block map.
Any IPAM row whose NETWORK falls inside a known cloud /16 gets its
CANONICAL_LOCATION updated to the correct zone canonical.

**Impact: 1,768 rows across these current locations:**

| Current Location | Rows | Correct Resolution |
|---|---|---|
| `Cloud - GCP US-East4 - CVS` | 377 | Split: GCP East4 (134), West2 (97), East4 SecureHub (88), East4 PCI (54), SPLIT (4) |
| `Cloud - Azure CVS East US 2` | 362 | Split: SecureHub UE1 (323), Azure East US 2 (36), SPLIT (3) |
| `Cloud - Azure HCB - Aetna` | 253 | Split: SecureHub UE1 (232), AWS East1 Aetna (21) |
| `Cloud - Azure CVS Central US` | 166 | Split: SecureHub UE1 (150), Azure East US 2 (15), UE2 (1) |
| `Linthicum MD - Corporate` | 153 | Cloud zones (153) — on-prem label on cloud CIDRs |
| `Dallas TX - Equinix` | 126 | AWS East1 Aetna (81), Azure UE1 (45) |
| `Scottsdale AZ - Shea DC` | 66 | GCP zones (66) |
| `Ashburn VA - Equinix HCB` | 53 | Azure UE1 (28), AWS Aetna (25) |
| `Las Vegas NV - Switch Colo` | 44 | Azure SecureHub UE1 (44) |
| + 27 other locations | ~168 | Various cloud zones |

**Special cases:**
- `SPLIT - Azure/GCP` (10.243.0.0/16) — flag for manual /24 resolution
- `100.64.x.x` — tag DATA_QUALITY=Error, do not promote
- `10.53.x.x` (12 hosts) — tag LOCATION_NEEDS_REVIEW

---

## Step 3 — EHM ent_host_master r4 → r5

**Method:** Same CIDR-LPM lookup. For each EHM row, look up
IP_ADDRESS against cloud CIDR map. If match found and current
CANONICAL_LOCATION differs → update.

**Impact: 14,451 hosts**

Key corrections:
- `Cloud - Azure CVS East US 2` (8,487) → UE1 or Azure East US 2 by CIDR
- `Cloud - Azure CVS Central US` (2,885) → UE1 or Azure East US 2 by CIDR
- `Cloud - GCP US-East4 - CVS` (2,205) → correct GCP zone by CIDR
- `Cloud - Azure` (455) → UE1 or UE2 by CIDR
- `Cloud - Azure CVS` (443) → UE1 by CIDR
- `Cloud - GCP US-East4 - Aetna` (69) → GCP East4 or RxConnect by CIDR
- `Cloud - GCP` (20) → correct GCP zone by CIDR
- `Cloud - AWS` (1) → AWS East1 Prod

Special flags (do not auto-correct — tag only):
- `100.64.x.x` (26 hosts) → DATA_QUALITY=Error (CGNAT addresses)
- `10.53.x.x` (12 hosts) → LOCATION_NEEDS_REVIEW

---

## Step 4 — NDM ent_network_device_master patch

**Impact: 373 rows**

Auto-correct (stale names):
- `Las Vegas NV - Switch DC` (35) → `Las Vegas NV - Switch Colo`
- Any other stale name in stale list → CIDR lookup

Flag for manual review (do not auto-correct):
- `Linthicum MD - Corporate` in cloud CIDR blocks (121 rows) —
  likely virtual appliances, location should reflect managing team
  not cloud zone. Needs network team confirmation.

---

## Step 5 — Import Sequence (after all patches generated)

```bash
# 1. LM first — always
python3 ipam-db.py --import ./ipam-db/location_master_v4.5.csv --type location_master

# 2. Preflight check
python3 preflight_lm_check.py

# 3. IPAM
python3 ipam-db.py --import ./ipam-db/all_IP_networks_v3.68.csv --type all_IP_networks

# 4. EHM
python3 ipam-db.py --import ./ipam-db/ent_host_master_v20260427r5.csv --type ent_host_master

# 5. NDM
python3 ipam-db.py --import ./ipam-db/ent_network_device_master_v20260502.csv --type ent_network_device_master

# 6. Cross-check — must show 0 HIGH before continuing
python3 ipam-db.py --cross-check

# 7. Apply Qualys EHM enrichment (outputs already in ./Qualys_processed_results/)
python3 apply_ehm_enrichment.py \
    --ehm     ./ipam-db/ent_host_master_v20260427r5.csv \
    --patch   ./Qualys_processed_results/ehm_enrichment_patch_v20260504.csv \
    --out-dir ./ipam-db/
python3 ipam-db.py --import ./ipam-db/ent_host_master_v20260427r6.csv --type ent_host_master

# 8. Rebuild app subnet index
python3 build_app_inventory.py --ipam-dir ./ipam-db/ --out-dir ./app-inventory/
python3 build_app_subnet_index.py --inv-dir ./app-inventory/ --out-dir ./app-inventory/
python3 ipam-db.py --import ./app-inventory/app_subnet_index_v20260504.csv --type app_subnet_index

# 9. Re-run Qualys pipeline against clean data
python3 build_qualys_pipeline.py \
    --qualys-dir ./IP_Datasets_Raw/Risk-Reg_Files/ \
    --ipam-dir   ./ipam-db/ \
    --out-dir    ./Qualys_processed_results/

# 10. CSNA registry rebuild (resolves CX3/CX4 MEDIUM violations)
python3 build_csna_site_registry.py --ipam-dir ./ipam-db/
```

---

## Scripts To Build (not yet written)

| Script | Purpose | Status |
|---|---|---|
| `patch_location_master.py` | LM v4.4 → v4.5 | NOT BUILT |
| `patch_ipam_cloud_locations.py` | IPAM v3.67 → v3.68 | NOT BUILT |
| `patch_ehm_locations.py` | EHM r4 → r5 | NOT BUILT |
| `patch_ndm_locations.py` | NDM stale names | NOT BUILT |

All four scripts follow CCD versioning rules (SKILL). Each produces
a complete merged output file — never a delta patch for direct import.
Each runs preflight_lm_check.py equivalent validation before writing.

---

## Authoritative Cloud CIDR Map (from ccd-data-governance-SKILL.md)

```python
CLOUD_CIDR_MAP = {
    # Azure SecureHub UE1 (contain mode)
    "10.68.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.74.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.82.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.83.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.85.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.86.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.98.0.0/16":  "Cloud - Azure SecureHub UE1",
    "10.141.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.142.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.159.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.175.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.209.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.210.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.223.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.229.0.0/16": "Cloud - Azure SecureHub UE1",
    "10.242.0.0/16": "Cloud - Azure SecureHub UE1",
    # Azure SecureHub UE2 (active growth)
    "10.152.0.0/16": "Cloud - Azure SecureHub UE2",
    # Azure East US 2 (CVS Digital/PBM/MinuteClinic AKS)
    "10.155.0.0/16": "Cloud - Azure East US 2",
    # Split block
    "10.243.0.0/16": "SPLIT - Azure/GCP",
    # GCP
    "10.114.0.0/16": "Cloud - GCP East4 SecureHub",
    "10.236.0.0/16": "Cloud - GCP East4 SecureHub",
    "10.117.0.0/16": "Cloud - GCP East4 PCI",
    "10.112.0.0/16": "Cloud - GCP East4",
    "10.143.0.0/16": "Cloud - GCP East4",
    "10.149.0.0/16": "Cloud - GCP East4",
    "10.157.0.0/16": "Cloud - GCP East4",
    "10.247.0.0/16": "Cloud - GCP East4",
    "10.252.0.0/16": "Cloud - GCP East4",
    "10.158.0.0/16": "Cloud - GCP West2",
    # AWS CVS
    "10.207.0.0/18":   "Cloud - AWS East1 Prod",
    "10.207.64.0/19":  "Cloud - AWS East1 Prod",
    "10.207.96.0/19":  "Cloud - AWS East1 NonProd",
    "10.207.128.0/18": "Cloud - AWS East1 NonProd",
    "10.207.192.0/19": "Cloud - AWS East2 Prod",
    "10.207.224.0/19": "Cloud - AWS East2 NonProd",
    # AWS Aetna
    "10.208.0.0/16": "Cloud - AWS East1 Aetna",
}
```

---

## Open Items (deferred, not blocking current work)

- `update_retail.py` — not built, 4 retail hub candidates waiting
- `vv` double-version bug in `ipam-db.py`
- 1,270 app candidates skipped (location unmapped in Qualys run)
- `SPLIT - Azure/GCP` (10.243.0.0/16) — needs /24-level resolution
- `Linthicum MD - Corporate` in cloud blocks (121 NDM rows) — needs network team confirmation
- `10.53.x.x` (12 EHM hosts) — LOCATION_NEEDS_REVIEW, unknown block
- Cumberland RI Highland Lab (46 EHM hosts) — which building?
- 3 EHM hosts with stale location: 10.117.88.113, 10.223.32.71, 10.47.173.33
