# app_classifier.py — Subnet-to-Application Classifier

**Version:** v1.x  
**Type:** Python  
**Role:** Classifies enterprise IP subnets to applications using a multi-layer lookup pipeline across the IPAM, app_subnet_index, and ent_host_master datasets. Produces per-subnet application context used by the FW enrichment and CSNA import tools.

---

## Overview

```
IP subnet or host IP
    ↓
    ├── app_subnet_index LPM    → direct app→subnet mapping (highest priority)
    ├── all_IP_networks LPM     → IPAM context (location, heritage, PCI, FW zone)
    ├── ent_host_master lookup  → per-host app identity (APP_ACRONYMS, APM_IDS)
    └── app_subnet_index LPM    → /24 aggregated app context (cidr_24 abolished)
    ↓
Classified subnet record: APP_ACRONYM, APM_IDS, PRIMARY_ENV, HERITAGE, PCI, RISK_TIER
```

---

## Usage

```bash
# Classify a single IP
python3 app_classifier.py --ip 10.100.50.25 --db-dir ipam-db/

# Classify a CIDR block
python3 app_classifier.py --cidr 10.100.50.0/24 --db-dir ipam-db/

# Classify all subnets in a CSV file
python3 app_classifier.py --input subnets.csv --db-dir ipam-db/ --out classified.csv

# Verbose — show all lookup layers
python3 app_classifier.py --ip 10.100.50.25 --db-dir ipam-db/ -v
```

---

## Output Fields

| Field | Description |
|-------|-------------|
| `APP_ACRONYM` | Primary application acronym |
| `APM_IDS` | APM ID(s) |
| `APP_NAMES` | Application display names |
| `PRIMARY_ENV` | PROD / DEV / TEST / QA / UAT |
| `HERITAGE` | CVS / Aetna / HCB |
| `PCI_DESIGNATION` | PCI / Not-PCI / Mixed |
| `RISK_TIER` | Risk classification |
| `CANONICAL_LOCATION` | Canonical site name |
| `FW_POLICY` | FW zone policy |
| `ROUTING_DOMAIN` | IPAM routing domain |
| `CLASSIFICATION_SOURCE` | Which layer resolved the classification |

---

## LPM Implementation

Uses `/32 → /8` prefix walk — tries the most specific match first and walks up to the first IPAM hit. Does NOT use a flat /24-keyed dict (that was a bug fixed in v1.x — it missed /26 retail blocks and /21 enterprise blocks).
