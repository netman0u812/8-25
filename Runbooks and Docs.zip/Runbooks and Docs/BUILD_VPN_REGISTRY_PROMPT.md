# Rebuild Prompt: build_vpn_registry.py

## Objective
Rebuild `build_vpn_registry.py` to parse Cisco ASA VPN firewall configs and
produce three ipam-db compatible datasets with proper versioning, headers,
and DSR checksum registration.

---

## Source Data

Cisco ASA VPN config files stored in `IP_Datasets_Raw/VPN_CONFIGS/` (or similar).
Four known gateway devices:
- `mid-fw-vpn2XAact_*.config`   — Middletown CT (MDC) Aetna WDC gateway
- `win-fw-vpn1XAact_*.config`   — Windsor CT (WDC) Aetna WDC gateway
- `RRIWSDCSECEXXTEMPVPN-04*`    — Woonsocket RI (RI-One) gateway
- `pazshdcsecextempvpn-01v_*`   — Shea DC gateway

Script should auto-discover all `*.config` files in the raw dir.

---

## Output Datasets (ipam-db compatible format)

### 1. `ent-ipdataset-VPN-PEER-REGISTRY-vYYYYMMDD.csv`
One row per unique IPSec VPN peer IP.

| Column | Description | Example |
|---|---|---|
| PEER_IP | Remote peer IP address | 103.108.49.126 |
| PARTNER_NAME | ACL/tunnel-group name | BUPA_IPSEC |
| LOCAL_GATEWAY | CVS-side gateway IP | 206.213.251.41 |
| GATEWAY_SITE | Site code / friendly name | MDC |
| IKE_VERSION | 1 or 2 | 1 |
| PFS_GROUP | DH group if set | group14 |
| TRANSFORM_SET | Cipher transform set | aes256-md5 |
| ACL_NAME | Crypto map ACL name | bupa-ipsec |
| LOCAL_SUBNET_COUNT | Count of local protected subnets | 4 |
| REMOTE_SUBNET_COUNT | Count of remote protected subnets | 7 |
| CSNA_HOSTGROUP_PATH | CSNA host group path | /Root/Partner/MDC/BUPA_IPSEC |
| WEAK_CIPHER | True/False — DES/3DES/MD5/IKEv1 no PFS | False |
| DEVICE | Source config filename | mid-fw-vpn2XAact_20260422.config |
| IMPORT_DATE | Date config was parsed | 2026-04-27 |
| DATASET_VERSION | Dataset version stamp | 20260427 |

### 2. `ent-ipdataset-VPN-PROTECTED-SUBNETS-vYYYYMMDD.csv`
One row per protected subnet (local AND remote) per VPN tunnel.
This is the ipam-db compatible format — used for IPAM enrichment and FW rule qualification.

| Column | Description | Example |
|---|---|---|
| CIDR | Subnet in CIDR notation | 10.56.128.0/18 |
| IP | Network address only | 10.56.128.0 |
| PARTNER_NAME | VPN tunnel/partner name | BUPA_IPSEC |
| PEER_IP | Remote peer IP | 103.108.49.126 |
| GATEWAY | CVS-side gateway IP | 206.213.251.41 |
| GATEWAY_SITE | Gateway location | MDC |
| DIRECTION | LOCAL or REMOTE | LOCAL |
| IKE_VERSION | 1 or 2 | 1 |
| PFS_GROUP | DH group | |
| WEAK_CIPHER | True/False | False |
| CIPHER | Transform/cipher | aes256-sha |
| ACL_NAME | Source ACL name | bupa-ipsec |
| CSNA_HOSTGROUP_PATH | CSNA path | /Root/Partner/MDC/BUPA_IPSEC |
| SERVER_NAME | Same as PARTNER_NAME (ipam-db compat) | BUPA_IPSEC |
| APPLICATION | Same as PARTNER_NAME | BUPA_IPSEC |
| ROUTING_DOMAIN | Always VPN-Partner | VPN-Partner |
| FACILITY_TYPE | Always VPN | VPN |
| ASSET_FAMILY | Always VPN-Partner | VPN-Partner |
| OS_NORMALIZED | Always PartnerVPN | PartnerVPN |
| IN_QUALYS | Always N | N |
| IN_WIZ | Always N | N |
| IN_SNOW | Always N | N |
| DEVICE | Source config filename | mid-fw-vpn2XAact_20260422.config |
| IMPORT_DATE | Parse date | 2026-04-27 |
| DATASET_VERSION | Dataset version stamp | 20260427 |

### 3. `ent-ipdataset-VPN-RA-GROUPS-vYYYYMMDD.csv`
One row per remote access VPN group (tunnel-group / connection profile).

| Column | Description | Example |
|---|---|---|
| GROUP_NAME | tunnel-group name | cert_con_profile |
| LOCAL_GATEWAY | Gateway IP (if resolved) | 206.213.x.x |
| GATEWAY_SITE | Site name | WOONSOCKET |
| GROUP_TYPE | ipsec-ra or ssl-client | ssl-client |
| AUTH_METHOD | cert / aaa / both | cert |
| DEVICE | Source config filename | RRIWSDCSECEXXTEMPVPN-04.config |
| IMPORT_DATE | Parse date | 2026-04-22 |
| DATASET_VERSION | Dataset version stamp | 20260422 |

---

## ipam-db File Format Requirements

Every output file MUST have these comment headers before the CSV header row:
```
#STEM=ent-ipdataset-VPN-PEER-REGISTRY
#VERSION=20260427
#ROWS=551
#DESCRIPTION=IPSec VPN peer registry — parsed from Cisco ASA VPN gateway configs
#SOURCE_FILES=mid-fw-vpn2XAact_20260422.config,win-fw-vpn1XAact_20260422.config,...
#GENERATOR=build_vpn_registry.py v1.0.0
#GENERATED_AT=2026-04-27T19:34:00Z
```

---

## ASA Config Parsing Logic

### Peer registry (from `crypto map`)
```
crypto map outside_map 10 match address bupa-ipsec
crypto map outside_map 10 set peer 103.108.49.126
crypto map outside_map 10 set transform-set ESP-AES-256-MD5
crypto map outside_map 10 set pfs group14
```
→ Extract: peer IP, ACL name, transform set, PFS group, sequence number

### Protected subnets (from `ip access-list extended <acl_name>`)
```
ip access-list extended bupa-ipsec
 permit ip 10.56.128.0 0.0.63.255 103.108.49.0 0.0.0.255
 permit ip 10.56.192.0 0.0.63.255 103.108.49.0 0.0.0.255
```
→ Source = LOCAL subnet, Destination = REMOTE subnet
→ Convert wildcard masks to CIDR

### RA groups (from `tunnel-group`)
```
tunnel-group cert_con_profile type remote-access
tunnel-group cert_con_profile general-attributes
 authentication-server-group LDAP
tunnel-group cert_con_profile webvpn-attributes
 group-alias "Certificate Profile" enable
```
→ Extract: group name, type (remote-access/ipsec-l2l), auth method

### Weak cipher detection
Flag WEAK_CIPHER=True if ANY of:
- IKE version 1 with no PFS group
- Transform set contains DES, 3DES, or MD5
- DH group < 14 (group1, group2, group5)

---

## Versioning
- Script version: `SCRIPT_VERSION = '1.0.0'` in `__version__`
- Output version: `vYYYYMMDD` based on most recent config file import_date
- Same-day revision: `vYYYYMMDDrN`
- Filenames: `ent-ipdataset-VPN-PEER-REGISTRY-vYYYYMMDD.csv`

---

## DSR Integration
```python
import dsr as _dsr
# Register source configs before parsing
_dsr.register_many(config_files, pipeline='build_vpn_registry.py v1.0.0',
                   outputs=['VPN-PEER-REGISTRY','VPN-PROTECTED-SUBNETS','VPN-RA-GROUPS'])
# Register outputs after writing
_dsr.register(output_path, pipeline='build_vpn_registry.py v1.0.0')
```

---

## ipam-db Registration
After generating, register all three datasets:
```bash
python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-PEER-REGISTRY-vDATE.csv \
    --type VPN-PEER-REGISTRY --dry-run
python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-PEER-REGISTRY-vDATE.csv \
    --type VPN-PEER-REGISTRY

python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-PROTECTED-SUBNETS-vDATE.csv \
    --type VPN-PROTECTED-SUBNETS --dry-run
python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-PROTECTED-SUBNETS-vDATE.csv \
    --type VPN-PROTECTED-SUBNETS

python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-RA-GROUPS-vDATE.csv \
    --type VPN-RA-GROUPS --dry-run
python3 ipam-db.py --import ./processed_outputs/ent-ipdataset-VPN-RA-GROUPS-vDATE.csv \
    --type VPN-RA-GROUPS

python3 ipam-db.py --cross-check
```

---

## collect_session_files.py additions (DATASETS list)
```python
('VPN-PEER-REGISTRY',      'ent-ipdataset-VPN-PEER-REGISTRY-vLATEST.csv',      IPAM_DIR),
('VPN-PROTECTED-SUBNETS',  'ent-ipdataset-VPN-PROTECTED-SUBNETS-vLATEST.csv',  IPAM_DIR),
('VPN-RA-GROUPS',          'ent-ipdataset-VPN-RA-GROUPS-vLATEST.csv',          IPAM_DIR),
```

---

## CLI Interface
```
build_vpn_registry.py --raw-dir ./IP_Datasets_Raw/VPN_CONFIGS/
build_vpn_registry.py --raw-dir ./IP_Datasets_Raw/VPN_CONFIGS/ --dry-run
build_vpn_registry.py --raw-dir ./IP_Datasets_Raw/VPN_CONFIGS/ --out-dir ./processed_outputs/
build_vpn_registry.py --version
```
