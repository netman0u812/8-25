# build_ipam_promotion_candidates.py — IPAM Promotion Engine

**Version:** v1.1
**Type:** Python
**Role:** Analyses `ent_host_master` host inventory signals to identify subnets that are missing from or incorrectly tagged in `all_IP_networks`, and generates structured promotion candidates with confidence scoring, CIDR boundary analysis, and an interactive review session.

---

## Overview

`all_IP_networks` is the SSOT for IP→location mapping. Over time, new subnets are allocated that were never entered, HMR-sourced rows accumulate incorrect SOURCE stamps, and cloud or DC subnets that exist in the app inventory never make it into IPAM. This script closes those gaps systematically.

```
ent_host_master_v*.csv
    SOURCE_DECLARED_LOCATION + HOSTNAME_DERIVED_LOCATION (per-host signals)
        ↓
build_ipam_promotion_candidates.py
        ↓
  ├── Confidence scoring per /24 (dominant signal %)
  ├── ALREADY_CORRECT detection (normalized location comparison)
  ├── CIDR boundary analysis (/25, /26, /27 split detection)
  ├── DCI /32 overrides (interleaved subnets — no clean boundary)
  ├── Cloud multi-region detection
  └── Interactive review session [A/R/O/D/S/Q]
        ↓
  ipam-promoter-output/
      all_IP_networks_patch_v<N>.csv      ← delta patch, merge before import
      ipam_promotion_review.csv           ← full candidate list
      ipam_promotion_ambiguous.csv        ← needs human decision
      ipam_promotion_split_candidates.csv ← clean CIDR boundary found
      ipam_promotion_dci_32s.csv          ← /32 overrides for DCI subnets
      ipam_promotion_cloud_multiregion.csv← cloud multi-region review
      ipam_promotion_report.txt           ← human-readable summary
      review_session.json                 ← session state (persists between runs)
```

---

## Quick Start

```bash
cd ~/Documents/IP_Lookup

# Step 1 — dry run: see what will be promoted
./build_ipam_promotion_candidates.py --dry-run

# Step 2 — full run: generate all output files
./build_ipam_promotion_candidates.py

# Step 3 — interactive review of ambiguous candidates
./build_ipam_promotion_candidates.py --review

# Step 4 — merge patch into full dataset and import
python3 -c "
import csv
from datetime import datetime, timezone

with open('ipam-db/all_IP_networks_v3.43.csv', newline='', encoding='utf-8', errors='replace') as f:
    base = list(csv.DictReader(l for l in f if not l.startswith('#')))
patch = {}
with open('ipam-promoter-output/all_IP_networks_patch_v3.43.csv', newline='', encoding='utf-8', errors='replace') as f:
    for r in csv.DictReader(l for l in f if not l.startswith('#')):
        patch[r['CIDR'].strip()] = r
merged, updated, added = [], 0, 0
for r in base:
    cidr = r.get('CIDR','').strip()
    if cidr in patch:
        merged.append(patch.pop(cidr)); updated += 1
    else:
        merged.append(r)
for r in patch.values():
    merged.append(r); added += 1
fieldnames = list(base[0].keys())
with open('ipam-db/all_IP_networks_v3.43.csv', 'w', newline='', encoding='utf-8') as f:
    f.write('#VERSION=3.43\n')
    f.write(f'#ROWS={len(merged)}\n')
    w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore', lineterminator='\n')
    w.writeheader(); w.writerows(merged)
print(f'Merged: {len(merged)} rows ({updated} updated + {added} new)')
"
./ipam-db.py --import ipam-db/all_IP_networks_v3.43.csv --type all_IP_networks
```

---

## Recommendation Buckets

| Recommendation | Meaning | Action |
|---|---|---|
| `AUTO_APPROVE` | New location from host signals ≥70% confidence, ≥3 hosts | → patch CSV |
| `ALREADY_CORRECT` | Current location valid; SOURCE=HMR → IPAM_PROMOTER cleanup | → patch CSV |
| `SPLIT_CANDIDATE` | Clean /25–/27 boundary found between two sites | → split_candidates CSV |
| `DCI_32_OVERRIDE` | Interleaved MDC/WDC hosts, no clean boundary | → dci_32s CSV (/32 per minority host) |
| `CLOUD_MULTIREGION` | Two cloud region signals, no clean split | → cloud_multiregion CSV |
| `LOW_CONFIDENCE` | Dominant signal <70% | → ambiguous CSV, interactive review |
| `INSUFFICIENT_HOSTS` | <3 hosts with no valid current location | → ambiguous CSV |
| `NO_TRANSLATION` | Signal present, no matching translation entry | → ambiguous CSV |
| `NO_SIGNAL` | No host inventory signals at all | Nautobot / network team |
| `EXCLUDE` | Work-At-Home, offshore, or public cloud IP (20.x/40.x/52.x/104.x/13.x) | Skipped |

---

## Interactive Review Session

Run with `--review` to step through ambiguous candidates in the terminal:

```
════════════════════════════════════════════════════════════════════════
  [7/23]  10.47.64.0/24
════════════════════════════════════════════════════════════════════════
  Category:    MISSING_FROM_IPAM
  Confidence:  ██████████████████████████████ 100%  (2/2 signals, 2 hosts)

  Signal breakdown:
    2× Mauldin SC - Store MDN

  OS:     Windows(2)
  Apps:   SCOM  |  APM0008440
  Hosts:  mdnpscomgtw93 | mdnpscomgtw94

  Proposed:  (no translation)
  Current:   (none)

  [A]pprove  [R]eject  [O]verride  [D]etail  [S]kip  [Q]uit >
```

### Commands

| Key | Action |
|-----|--------|
| `A` | Approve proposed location → goes to patch |
| `R` | Reject — leave as Unknown |
| `O` | Override — search location_master by keyword, select from numbered list |
| `D` | Detail — show all hosts on subnet + /16 neighbor context from all_IP_networks |
| `S` | Skip — decide later |
| `Q` | Save session and exit |

Session state is saved after every decision to `ipam-promoter-output/review_session.json`. Run `--review` again to resume exactly where you left off.

### [D]etail view

The `[D]etail` command shows two things without leaving the review session:

1. **All hosts on the /24** — IP, hostname, OS, server class, declared location
2. **Neighboring subnets in the same /16** — grouped by CANONICAL_LOCATION, showing what other subnets are allocated around this one

The neighbor view is critical for identifying misattributed subnets. Example: a host declaring `Mauldin SC - Store MDN` in a /16 that is 90% `Las Vegas NV - Switch Colo` is almost certainly a SCOM management gateway — the subnet home is the COLO, not the managed store.

---

## Known Review Patterns

### SCOM Gateways (`mdnpscomgtw*`)

- Declared location = the **monitored site** (e.g. Mauldin SC)
- Subnet home = the **management network** (e.g. Las Vegas NV - Switch Colo)
- Action: **[O]verride** → search `las vegas` → `Las Vegas NV - Switch Colo`

### Enterprise App at Omnicare/Retail Store (Qumu, SCCM, etc.)

- Declared location = store code (e.g. `Medford OR - Store MDF`)
- Subnet is in Omnicare /24 block (check /16 neighbors with [D])
- Action: **[O]verride** → search `omnicare` or city name → correct Omnicare location

### Public Azure IPs (`20.x`, `40.x`, `52.x`, `104.x`, `13.x`)

- Azure public IPs that ended up in ent_host_master via ServiceNow registration
- Declared location = app owner's office, not the server's location
- Action: **[R]eject** — these do not belong in `all_IP_networks`

### Aetna-Owned Public IP Blocks

- `157.121.0.0/16`, `167.69.0.0/16`, `204.99.0.0/16`, `206.213.0.0/16`, `198.187.0.0/16`
- Legitimate internal routing — Aetna-owned ASN space used for internal DC traffic
- Action: **[A]pprove** or **[O]verride** to the correct DC location

---

## CLI Reference

| Flag | Default | Description |
|---|---|---|
| `--ipam-dir DIR` | `ipam-db/` | Directory containing all_IP_networks, ent_host_master, location_master |
| `--out-dir DIR` | `ipam-promoter-output/` | Output directory |
| `--min-hosts N` | `3` | Minimum hosts in /24 for auto-approval |
| `--confidence N` | `70` | Minimum dominant signal % for auto-approval |
| `--dry-run` | — | Analyse only — no files written |
| `--review` | — | Start interactive review of ambiguous candidates after analysis |
| `--review-all` | — | Step through ALL candidates including auto-approved |
| `--translations FILE` | bundled | JSON translation table override |

---

## Translation Table

The bundled translation table maps raw `SOURCE_DECLARED_LOCATION` strings (from ADL/SNOW) to canonical IPAM field values. Locations are matched by lowercase substring — longer patterns take priority.

To export and customise the bundled table:

```bash
# Export (flag to be added in v1.2)
./build_ipam_promotion_candidates.py --write-translations \
  ipam-promoter-output/translation_table.json

# Use customised table
./build_ipam_promotion_candidates.py \
  --translations ipam-promoter-output/translation_table.json
```

Current bundled entries cover: Azure East US 2, Azure Central US, Azure West US, AWS us-east-1/2, GCP us-east4, Phoenix Aetna DC, Scottsdale Shea DC, Las Vegas Switch Colo, Sparks Switch TRE, Aetna MDC, Aetna WDC, RI One, Mount Prospect IL, Buffalo Grove IL, Hartford Aetna HQ, Richardson TX, and WAH/offshore (EXCLUDE).

---

## Important: Patch CSV is a Delta

The patch output (`all_IP_networks_patch_v<N>.csv`) contains **only the changed rows** — it is not a full replacement file. Always merge it into the current all_IP_networks before importing:

```bash
# WRONG — never do this
./ipam-db.py --import ipam-promoter-output/all_IP_networks_patch_v3.43.csv \
  --type all_IP_networks

# CORRECT — merge first, then import the full file
python3 merge_ipam_patch.py  # or the inline merge snippet above
./ipam-db.py --import ipam-db/all_IP_networks_v3.43.csv --type all_IP_networks
```

After importing, always regenerate `location_master_table.csv`:

```bash
python3 -c "
import csv
with open('ipam-db/location_master_v3.20.csv', newline='', encoding='utf-8', errors='replace') as f:
    rows = list(csv.DictReader(l for l in f if not l.startswith('#')))
with open('ipam-db/location_master_table.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator='\n')
    w.writeheader(); w.writerows(rows)
print(f'Regenerated: {len(rows)} rows')
"
```

---

## Output File Reference

| File | Description |
|---|---|
| `ipam_promotion_review.csv` | All 1,483+ candidates with confidence score, host count, app data, OS breakdown, proposed location, and signal breakdown. Self-contained — no other files needed for review. |
| `all_IP_networks_patch_v<N>.csv` | **Delta patch** — auto-approved + manually-approved rows only. Merge before import. SOURCE=IPAM_PROMOTER_v1.1, DATA_QUALITY=Inferred. |
| `ipam_promotion_ambiguous.csv` | LOW_CONFIDENCE, NO_TRANSLATION, INSUFFICIENT_HOSTS candidates. Inputs for `--review` session. |
| `ipam_promotion_split_candidates.csv` | Subnets where a /25–/27 split produces two clean single-site halves. Add child rows manually or via pipeline. |
| `ipam_promotion_dci_32s.csv` | /32 overrides for minority-site hosts on interleaved DCI subnets. Parent /24 stays as dominant site; /32 wins via LPM. |
| `ipam_promotion_cloud_multiregion.csv` | Cloud subnets with mixed Azure/AWS/GCP region signals and no clean split boundary. |
| `ipam_promotion_report.txt` | Summary counts by recommendation type + full NO_SIGNAL list for Nautobot follow-up. |
| `review_session.json` | Interactive review session state — decisions persist between runs. |

---

## Downstream Rebuild

After importing the patch, rebuild the downstream datasets:

```bash
# 1. Rebuild ent_host_master against new all_IP_networks
python3 build_ent_host_dataset.py \
  --app   IP_Datasets_Raw/APP_DATA-4-14/ADL_APP_INFO_Report.csv \
  --ent   IP_Datasets_Raw/APP_DATA-4-14/ENT_APP_INFRA_REPORT.csv \
  --snow  IP_Datasets_Raw/APP_DATA-4-14/SNOW_SERVER-REPORT.csv \
  --all-ip-networks ipam-db/all_IP_networks_v3.43.csv \
  --loc-master      ipam-db/location_master_v3.20.csv \
  --out             ipam-db/ent_host_master_v20260419.csv

./ipam-db.py --import ipam-db/ent_host_master_v20260419r3.csv --type ent_host_master

# 2. Regenerate CSNA hostgroups and map
python3 generate_csna_hostgroups_v2.py \
  --ipam-dir ipam-db/ --nms-dir NMS-Invintory/ --out-dir csna_output/

python3 generate_csna_map_v2.py \
  --csv-dir csna_output/ --out-dir csna_output/
```

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.1 | 2026-04-19 | ALREADY_CORRECT detection with normalized string comparison. INSUFFICIENT_HOSTS with valid current location → ALREADY_CORRECT. Fixed GCP/Azure/Hartford canonical name mismatches vs location_master. Added [D]etail command to interactive review (host list + /16 neighbor context). DATA_QUALITY=Inferred (was Promoted). Azure public IP auto-exclude. Bundled GCP pattern fixes (us-east4-gcp hyphenated variant). |
| v1.0 | 2026-04-19 | Initial release. Confidence scoring, CIDR boundary analysis, DCI /32 support, SPLIT_CANDIDATE detection, CLOUD_MULTIREGION detection, interactive review with session persistence. |
