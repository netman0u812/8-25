# enrich_app_datasets.py — Enterprise Host Dataset Enrichment

**Version:** v1.0  
**Type:** Python  
**Role:** Enriches `ent_host_master` with `CANONICAL_LOCATION`, `FW_POLICY`, `ROUTING_DOMAIN`, and `HERITAGE` from the IPAM data layers. Fixes stale verbose location strings from the original normalization pipeline. Produces a clean versioned output.

---

## Overview

`ent_host_master` is built from ADL and ServiceNow exports which assign location in verbose format (`Scottsdale, AZ - 9501 East Shea Boulevard`). This script applies the canonical location mapping and enriches every host via LPM lookup against `all_IP_networks`, with `cidr_24` overlay for corrected values.

```
ent_host_master_v*.csv (61,886 hosts)
    ↓
    ├── Load all_IP_networks_v3.14 LPM (single source of truth)
    ├── For each host IP → LPM lookup → FW_POLICY, ROUTING_DOMAIN, HERITAGE, CANONICAL_LOCATION
    └── ESXi hosts: FW_POLICY populated from all_IP_networks LPM
    ↓
ent_host_master_v<DATE>.csv
enrich_app_datasets_report.txt
```

---

## When to Run

Run after any `all_IP_networks` update:

```
all_IP_networks updated
    → enrich_app_datasets.py   ← this script
    → reports and maps
```

---

## Usage

```bash
# Standard run
python3 enrich_app_datasets.py --db-dir ipam-db/

# Dry run — show what would change
python3 enrich_app_datasets.py --db-dir ipam-db/ --dry-run

# Explicit input
python3 enrich_app_datasets.py \
    --db-dir ipam-db/ \
    --input ipam-db/ent_host_master_v20260410.csv \
    --location-data CVS-Location-Data-11-25.csv
```

---

## CLI Reference

| Flag | Description |
|---|---|
| `--db-dir DIR` | IPAM directory (default: `ipam-db/`) |
| `--input FILE` | Explicit ent_host_master source (default: latest in db-dir) |
| `--dry-run` | Show stats without writing |

---

## What Gets Fixed

### CANONICAL_LOCATION — all 61,886 hosts
Stale verbose format replaced with canonical:

| Before | After |
|--------|-------|
| `Scottsdale, AZ - 9501 East Shea Boulevard` | `Scottsdale AZ - Shea DC` |
| `Cumberland, RI - 2100 Highland Corporate Park Drive` | `Cumberland RI - 2100 Highland` |
| `Windsor, CT - 570 Pigeon Hill Road` | `Windsor CT - Aetna WDC` |
| `Middletown, CT - 930 Middle Street` | `Middletown CT - Aetna MDC` |
| `Center TX` | `Irving TX - Corporate` |

### FW_POLICY — ESXi hosts (5,145)
All 5,145 ESXi hosts have blank FW_POLICY. Populated via CIDR_24 LPM lookup.

### ROUTING_DOMAIN — ~1,571 gaps
Populated from all_IP_networks LPM where blank.

### HERITAGE — ~4,028 gaps
Populated from all_IP_networks LPM where blank.

---

## Output

### ent_host_master_v\<DATE\>.csv

Same schema as input, with corrected/enriched values. Register with:
```bash
./ipam-db.py --import ipam-db/ent_host_master_v20260414.csv \
    --type ent_host_master \
    --description "CANONICAL_LOCATION and FW_POLICY enriched from IPAM"
```

### enrich_app_datasets_report.txt

Counts of rows fixed by field, location corrections applied, LPM hit/miss rates.

---

## ESXi Specific Notes

5,145 ESXi hypervisor hosts (OS_GROUP = `ESX-VMware`):
- `FW_POLICY` — populated via all_IP_networks LPM on host IP
- Top sites: Shea DC, Cumberland, MDC, WDC, Woonsocket
- `IS_VIRTUAL=N` (these are hypervisors, not VMs)
- `SERVER_CLASS=ESX Server`

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| v1.1 | 2026-04-14 | **cidr_24 overlay removed** — all_IP_networks v3.14 is single source of truth; location_master_table_v2 lookup replaced by CANONICAL_LOCATION from all_IP_networks |
| v1.0 | 2026-04-10 | Initial implementation |
