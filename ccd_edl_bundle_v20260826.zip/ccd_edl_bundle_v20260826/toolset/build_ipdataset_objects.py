#!/usr/bin/env python3
"""
build_ipdataset_objects.py  v1.0.0  —  CCD Platform

Stage 2.5 — Cloud Services EDL Object Builder

Generates granular per-service-per-region EDL address objects from the
ip_dataset.py registry. Restores the full AWS EC2/S3/CLOUDFRONT context
and Azure service tag breakdown that was lost when ip_dataset.py re-imported
from flat sources without preserving the SERVICE dimension.

Output goes to Net_Object/IPDATASET-vDATE/edl/ alongside geo-block objects
(Stage 2.6) — same flat directory, collected by collect_edl_bundle.sh.

Object naming:
  AWS:    AWS-{SERVICE}-{REGION}    e.g. AWS-EC2-USE1, AWS-S3-USW2
          AWS-ALL                   all AWS prefixes combined
  Azure:  AZURE-{SERVICE}-{REGION}  e.g. AZURE-CLOUD-USE2, AZURE-SQL-GLOBAL
          AZURE-ALL
  GCP:    GCP-{REGION}              e.g. GCP-USE1
          GCP-ALL
  SaaS:   {PROVIDER}-ALL            e.g. ZSCALER-ALL, CLOUDFLARE-ALL

Sources:
  ipdatasets/ip_dataset.json   — registry of all datasets
  ipdatasets/ip_dataset_*.csv  — dataset CSVs (auto-discovered via registry)

  Dataset CSV schema (confirmed 2026-08-23):
    IP_NETWORK, IP_DATASET_CLASS, SERVICE_TYPE_CODE, SERVICE_TYPE_LABEL,
    PROVIDER, PARTNER_NAME, SERVICE, HERITAGE, FQDN, PORTS, REGION, ...

Usage:
  python3 build_ipdataset_objects.py
  python3 build_ipdataset_objects.py --base /path/to/IP_Lookup
  python3 build_ipdataset_objects.py --dry-run
  python3 build_ipdataset_objects.py --provider aws
"""

__version__ = '1.1.0'
# v1.1.0  2026-08-23  Added EXCLUDE_STEMS: networksdb (BGP routing table,
#          318K rows → 318K objects), spamhaus-drop, tor-exit-nodes,
#          feodo-tracker, emerging-threats-compromised (threat intel
#          blocklists — belong in geo-block pipeline, not Cloud Services).
#          Added MIN_ROWS_FOR_SPLIT=50: datasets with < 50 rows generate
#          one {PROVIDER}-ALL object only — prevents edgio/servicenow/
#          workday/paloalto-cloud over-splitting 6-18 row datasets into
#          one object per row. Added MIN_CIDRS_PER_OBJECT=2: suppresses
#          single-CIDR service×region objects.
# v1.0.0  2026-08-23  Initial build.
#          generates per-service-per-region EDL objects from each STD
#          dataset CSV. Restores AWS EC2/S3/CLOUDFRONT/ROUTE53/etc. and
#          Azure service tag granularity. Output: Net_Object/IPDATASET-
#          vDATE/edl/ (flat, alongside geo-block objects). Registered as
#          Stage 2.5 in build_object_pipeline.py (previously placeholder).

import argparse
import csv
import json
import os
import re
import sys
from collections import defaultdict
from datetime import date

SEP = '─' * 62
TODAY = date.today().strftime('%Y%m%d')
SCRIPT_NAME = os.path.basename(__file__)
REGISTRY_FILE = 'ip_dataset.json'

# Datasets that must never generate EDL objects — threat intel blocklists,
# BGP routing tables, and other non-provider IP sources.
EXCLUDE_STEMS = {
    'networksdb',                    # BGP routing table, 200K+ rows — not a provider
    'spamhaus-drop',                 # threat intel blocklist → geo-block pipeline
    'tor-exit-nodes',                # threat intel
    'feodo-tracker',                 # threat intel / C2 tracker
    'emerging-threats-compromised',  # threat intel blocklist
}

# Only do per-service/per-region splitting when dataset has enough rows
# and enough unique services to justify the granularity. Tiny datasets
# (< 50 rows) become one {PROVIDER}-ALL object only.
MIN_ROWS_FOR_SPLIT = 50

# Minimum CIDRs in a service×region group to generate an object.
# Prevents one-CIDR objects from cluttering the catalog.
MIN_CIDRS_PER_OBJECT = 2


# ── Region abbreviation ───────────────────────────────────────────────────────

REGION_MAP = {
    'us-east-1': 'USE1',         'us-east-2': 'USE2',
    'us-west-1': 'USW1',         'us-west-2': 'USW2',
    'us-south-1': 'US-SOUTH-1',  'us-gov-west-1': 'USGOV-W',
    'us-gov-east-1': 'USGOV-E',
    'eu-west-1': 'EUW1',         'eu-west-2': 'EUW2',
    'eu-west-3': 'EUW3',         'eu-central-1': 'EUC1',
    'eu-central-2': 'EUC2',      'eu-north-1': 'EUN1',
    'eu-south-1': 'EUS1',        'eu-south-2': 'EUS2',
    'ap-northeast-1': 'APNE1',   'ap-northeast-2': 'APNE2',
    'ap-northeast-3': 'APNE3',   'ap-southeast-1': 'APSE1',
    'ap-southeast-2': 'APSE2',   'ap-southeast-3': 'APSE3',
    'ap-southeast-4': 'APSE4',   'ap-southeast-5': 'AP-SOUTHEAST-5',
    'ap-southeast-6': 'AP-SOUTHEAST-6', 'ap-southeast-7': 'AP-SOUTHEAST-7',
    'ap-south-1': 'APS1',        'ap-south-2': 'APS2',
    'ap-east-1': 'APE1',         'ap-east-2': 'AP-EAST-2',
    'ca-central-1': 'CAC1',      'ca-west-1': 'CAW1',
    'sa-east-1': 'SAE1',         'sa-west-1': 'SA-WEST-1',
    'me-south-1': 'MES1',        'me-central-1': 'MEC1',
    'me-west-1': 'ME-WEST-1',
    'af-south-1': 'AFS1',        'il-central-1': 'ILC1',
    'mx-central-1': 'MX-CENTRAL-1',
    'eusc-de-east-1': 'EUSC-DE-EAST-1',
    'cn-north-1': 'CN-NORTH-1',  'cn-northwest-1': 'CN-NORTHWEST-1',
    # Azure
    'eastus': 'EUS1',            'eastus2': 'EUS2',
    'westus': 'USW1',            'westus2': 'USW2',
    'westus3': 'USW3',           'centralus': 'USC',
    'northcentralus': 'USNC',    'southcentralus': 'USSC',
    'westcentralus': 'USWC',
    'northeurope': 'EUN',        'westeurope': 'EUW',
    'eastasia': 'APE',           'southeastasia': 'APSE',
    'japaneast': 'JPE',          'japanwest': 'JPW',
    'australiaeast': 'AUE',      'australiasoutheast': 'AUSE',
    'australiacentral': 'AUSTRALIACENTRAL',
    'australiacentral2': 'AUSTRALIACENTRAL2',
    'brazilsouth': 'BRS',        'canadacentral': 'CAC',
    'canadaeast': 'CAE',         'koreacentral': 'KRC',
    'koreasouth': 'KRS',         'southafricanorth': 'SAN',
    'southafricawest': 'SAW',    'uaenorth': 'UAE',
    'uaecentral': 'UAECENTRAL',  'switzerlandnorth': 'SWC',
    'germanywestcentral': 'GERMANYWC', 'germanynorth': 'GERMANYN',
    'norwayeast': 'NORWAYE',     'norwaywest': 'NORWAYW',
    'swedencentral': 'SWEDENCENTRAL',
    'francecentral': 'CENTRALFRANCE', 'francesouth': 'SOUTHFRANCE',
    'italynorth': 'ITN',         'israelcentral': 'ISRAELCENTRAL',
    'polandcentral': 'POC',      'spaincentral': 'ESC',
    'indonesiacentral': 'INDONESIACENTRAL',
    'malaysiasouth': 'MALAYSIASOUTH',
    'newzealandnorth': 'NEWZEALANDNORTH',
    'chinaeast': 'CHINAEAST',    'chinaeast2': 'CHINAEAST2',
    'chinaeast3': 'CHINAEAST3',  'chinanorth': 'CHINANORTH',
    'chinanorth2': 'CHINANORTH2','chinanorth3': 'CHINANORTH3',
    'qatarcentral': 'QATARCENTRAL',
    'mexicocentral': 'MEXICOCENTRAL',
    'jioindiawest': 'JIOINDIAWEST', 'jioindiacentral': 'JIOINDIACENTRAL',
    'indiasouthcentral': 'INDIASOUTHCENTRAL',
    # Generic
    'global': 'GLOBAL', 'GLOBAL': 'GLOBAL', '': 'GLOBAL',
}


def abbrev_region(region):
    if not region:
        return 'GLOBAL'
    r = str(region).strip()
    if r in REGION_MAP:
        return REGION_MAP[r]
    if r.lower() in REGION_MAP:
        return REGION_MAP[r.lower()]
    abbr = re.sub(r'[^A-Za-z0-9\-]', '-', r).upper().strip('-')
    abbr = re.sub(r'-+', '-', abbr)
    return abbr[:20] if abbr else 'GLOBAL'


PROVIDER_MAP = {
    'AMAZON WEB SERVICES': 'AWS', 'AMAZON': 'AWS', 'AWS': 'AWS',
    'MICROSOFT AZURE': 'AZURE',   'AZURE': 'AZURE', 'MICROSOFT': 'AZURE',
    'GOOGLE': 'GCP',              'GOOGLE CLOUD': 'GCP', 'GCP': 'GCP',
    'CLOUDFLARE': 'CLOUDFLARE',   'ZSCALER': 'ZSCALER',
    'OKTA': 'OKTA',               'CROWDSTRIKE': 'CROWDSTRIKE',
    'GITHUB': 'GITHUB',           'AKAMAI': 'AKAMAI',
    'FASTLY': 'FASTLY',           'IMPERVA': 'IMPERVA',
    'SALESFORCE': 'SALESFORCE',   'SERVICENOW': 'SERVICENOW',
    'WORKDAY': 'WORKDAY',         'PALO ALTO NETWORKS': 'PALOALTO',
    'TENCENT': 'TENCENT',         'ORACLE': 'ORACLE',
    'IBM': 'IBM',                 'ALIBABA': 'ALIBABA',
    'DIGITALOCEAN': 'DO',         'LINODE': 'LINODE',
    'VULTR': 'VULTR',             'HETZNER': 'HETZNER',
    'OVHCLOUD': 'OVH',
}


def abbrev_provider(provider, stem=''):
    p = str(provider).strip().upper()
    for key, abbr in PROVIDER_MAP.items():
        if key in p:
            return abbr
    if stem:
        return re.sub(r'[^A-Z0-9]', '', stem.upper())[:12]
    return re.sub(r'[^A-Z0-9]', '', p.split()[0])[:12] if p.split() else 'UNK'


AZURE_SVC_MAP = {
    'AzureCloud': 'CLOUD',
    'AzureActiveDirectory': 'AAD',
    'AzureMonitor': 'MONITOR',
    'AppService': 'APPSERVICE',
    'AzureCosmosDB': 'COSMOSDB',
    'AzureContainerRegistry': 'CONTAINERS',
    'AzureKeyVault': 'KEYVAULT',
    'AzureServiceBus': 'SERVICEBUS',
    'AzureStorage': 'STORAGE',
    'AzureBackup': 'BACKUP',
    'AzureFrontDoor': 'FRONTDOOR',
    'AzureDevOps': 'DEVOPS',
    'AzureIoT': 'IOT',
    'CognitiveServicesManagement': 'COGNITIVE',
    'MicrosoftCloudAppSecurity': 'MCAS',
    'PowerPlatformInfra': 'POWERPLATFORM',
    'PowerBI': 'POWERBI',
    'LogicApps': 'LOGICAPPS',
    'LogicAppsManagement': 'LOGICAPPS-MGT',
    'AzureActiveDirectory.ServiceEndpoint': 'AAD',
}


def clean_service(svc, prov):
    if not svc:
        return None
    s = str(svc).strip()
    if prov == 'AZURE':
        # Strip region suffix: AzureCloud.eastus2 → AzureCloud
        base = s.split('.')[0]
        if base in AZURE_SVC_MAP:
            return AZURE_SVC_MAP[base]
        if base != s:
            s = base
    s = s.replace('_', '-')
    s = re.sub(r'[^A-Za-z0-9\-]', '-', s).strip('-')
    s = re.sub(r'-+', '-', s).upper()
    return s[:30] if s else None


# ── EDL writing ───────────────────────────────────────────────────────────────

def write_edl(out_dir, name, source, cidrs, dry_run=False):
    cidrs = sorted(set(c.strip() for c in cidrs if c.strip()))
    if not cidrs:
        return None
    header = (
        f'# {name}\n'
        f'# Class: CLOUD_SERVICES\n'
        f'# Generated by {SCRIPT_NAME} v{__version__}\n'
        f'# Source: {source}\n'
        f'# CIDRs: {len(cidrs)}\n'
    )
    if not dry_run:
        with open(os.path.join(out_dir, f'{name}.txt'), 'w') as f:
            f.write(header + '\n'.join(cidrs) + '\n')
    return (name, len(cidrs))


# ── Per-dataset object generation ─────────────────────────────────────────────

def generate_objects(stem, ds_meta, dataset_dir, out_dir, dry_run=False):
    filename = ds_meta.get('filename', '')
    path = os.path.join(dataset_dir, filename)
    if not os.path.exists(path):
        return []

    with open(path, encoding='utf-8-sig', errors='replace') as f:
        lines = [l for l in f if not l.startswith('#')]
    rows = list(csv.DictReader(lines))
    if not rows:
        return []

    tags = ds_meta.get('tags', [])
    if 'ENTERPRISE' in tags:
        return []

    if stem in EXCLUDE_STEMS:
        return []

    sample_prov = next((r.get('PROVIDER', '') for r in rows if r.get('PROVIDER', '')), '')
    prov = abbrev_provider(sample_prov, stem)

    by_svc_region = defaultdict(list)
    all_cidrs = []

    for row in rows:
        cidr = row.get('IP_NETWORK', '').strip()
        if not cidr or ':' in cidr:
            continue
        svc    = clean_service(row.get('SERVICE', ''), prov)
        region = abbrev_region(row.get('REGION', ''))
        by_svc_region[(svc, region)].append(cidr)
        all_cidrs.append(cidr)

    if not all_cidrs:
        return []

    results = []
    unique_svcs = set(k[0] for k in by_svc_region if k[0])
    # Only split by service/region when dataset is large enough to warrant it
    multi_svc = len(unique_svcs) > 1 and len(all_cidrs) >= MIN_ROWS_FOR_SPLIT

    if multi_svc:
        # Per service × region
        for (svc, region), cidrs in sorted(by_svc_region.items()):
            if len(cidrs) < MIN_CIDRS_PER_OBJECT:
                all_cidrs_filtered = [c for c in cidrs]  # still goes to ALL
                continue
            if svc:
                name = f'{prov}-{svc}-{region}'
            else:
                name = f'{prov}-{region}' if region != 'GLOBAL' else f'{prov}-ALL'
            r = write_edl(out_dir, name, stem, cidrs, dry_run)
            if r:
                results.append(r)

        # Per service aggregate
        by_svc = defaultdict(list)
        for (svc, region), cidrs in by_svc_region.items():
            if svc:
                by_svc[svc].extend(cidrs)
        for svc, cidrs in sorted(by_svc.items()):
            r = write_edl(out_dir, f'{prov}-{svc}-ALL', stem, cidrs, dry_run)
            if r:
                results.append(r)

        # Per region aggregate
        by_region = defaultdict(list)
        for (svc, region), cidrs in by_svc_region.items():
            by_region[region].extend(cidrs)
        for region, cidrs in sorted(by_region.items()):
            if region != 'GLOBAL':
                r = write_edl(out_dir, f'{prov}-{region}', stem, cidrs, dry_run)
                if r:
                    results.append(r)

    # Provider ALL — always
    r = write_edl(out_dir, f'{prov}-ALL', stem, all_cidrs, dry_run)
    if r:
        results.append(r)

    return results


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='CCD Platform — Cloud Services EDL object builder (Stage 2.5)'
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    parser.add_argument('--base', default='.',
                        help='CCD Platform root directory (default: .)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Count objects without writing files')
    parser.add_argument('--skip-saas', action='store_true',
                        help='Skip SAAS datasets')
    parser.add_argument('--provider', default=None,
                        help='Process only this stem (e.g. aws, azure, gcp)')
    args = parser.parse_args()

    base        = os.path.abspath(args.base)
    dataset_dir = os.path.join(base, 'ipdatasets')
    registry    = os.path.join(dataset_dir, REGISTRY_FILE)

    print(f'\n{SCRIPT_NAME} v{__version__}')
    print(f'Base: {base}')
    if args.dry_run:
        print('DRY RUN — no files will be written')
    print()

    if not os.path.exists(registry):
        print(f'ERROR: Registry not found: {registry}', file=sys.stderr)
        sys.exit(1)

    with open(registry) as f:
        reg = json.load(f)
    datasets = reg.get('datasets', {})
    print(f'Registry: {len(datasets)} datasets  (schema v{reg.get("schema_version","?")})')
    print()

    version = f'IPDATASET-v{TODAY}'
    out_dir = os.path.join(base, 'Net_Object', version, 'edl')
    if not args.dry_run:
        os.makedirs(out_dir, exist_ok=True)

    total_objects = 0
    total_cidrs   = 0
    skipped       = 0

    for stem, ds_meta in sorted(datasets.items()):
        if args.provider and stem != args.provider:
            continue

        tags = ds_meta.get('tags', [])
        ds_class = next((t for t in tags if t in
                         ('IAAS','SAAS','PARTNER','CLOUD','ENTERPRISE','OTHER')), 'OTHER')

        if 'ENTERPRISE' in tags:
            skipped += 1
            continue
        if stem in EXCLUDE_STEMS:
            skipped += 1
            continue
        if args.skip_saas and ds_class == 'SAAS':
            skipped += 1
            continue

        print(f'  {stem:35s} ({ds_class:9s}  {ds_meta.get("row_count",0):>7,} rows)', end='  ')
        results = generate_objects(stem, ds_meta, dataset_dir, out_dir, args.dry_run)
        count  = len(results)
        cidrs  = sum(c for _, c in results)
        total_objects += count
        total_cidrs   += cidrs
        print(f'{count:>4} objects  {cidrs:>8,} CIDRs')

    print()
    if skipped:
        print(f'  Skipped: {skipped} datasets (ENTERPRISE or filtered)')
    print()

    print(SEP)
    print(f'  Before  :  Cloud Services objects: 0  (Stage 2.5 was placeholder)')
    print(f'  After   :  Cloud Services objects: {total_objects}  ({total_cidrs:,} CIDRs)')
    print(SEP)

    if not args.dry_run and total_objects > 0:
        print(f'\n  Output  : {out_dir}')
        print(f'\n  Next step: python3 build_object_pipeline.py --skip-obj --collect')
    elif args.dry_run:
        print(f'\n  Dry run complete — {total_objects} objects would be generated.')
    print()


if __name__ == '__main__':
    main()
