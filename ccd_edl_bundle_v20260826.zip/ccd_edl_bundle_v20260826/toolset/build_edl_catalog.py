#!/usr/bin/env python3
"""
build_edl_catalog.py  v1.7.0
CCD Platform — EDL Catalog Generator
CVS Health Information Security

Scans Net_Group/ and Net_Object/ for the latest versioned output directories,
reads the manifest/catalog CSVs, rebuilds the catalog index JSON, compresses
it, and emits a self-contained edl_catalog.html that requires no HTTP server.

Also scans Cloud_Services/ and External_FW/ if present (future dataset slots).

Usage:
    python3 build_edl_catalog.py                         # auto-discover, write edl_catalog.html
    python3 build_edl_catalog.py --out ~/Desktop/        # write to alternate directory
    python3 build_edl_catalog.py --dry-run               # print what would be indexed, no output

Run from ~/Documents/IP_Lookup/
"""

__version__ = '1.7.0'
# v1.7.0 — 2026-07-23  custom_objects and user_access now use
#          _find_import_verified_versioned_dir() instead of
#          _find_latest_versioned_dir(): cross-checks the candidate
#          directory's row count against what's actually registered in
#          ipam-db/ before trusting it, falling back to an older directory
#          (or warning loudly) on mismatch. Root cause fixed: those two
#          slots' build scripts write their versioned output dir BEFORE
#          the ipam-db.py --import step runs; if that import is later
#          blocked (e.g. by ipam-db's row-count collapse-safety check) or
#          fails, the newest-by-version directory reflects a run that
#          never became "current" -- but ipam-db/ itself still has the
#          last successfully-imported data. Confirmed live: exactly this
#          sequence (6-object build_custom_objects.py run blocked by
#          ipam-db against a registered 143) still showed 6 objects in
#          the catalog under the old newest-wins logic, despite ipam-db
#          itself being correct and untouched.
# v1.6.0 — 2026-07-23  New slot: custom_objects / 'Custom Objects' / Net_Object.
#          Reads Net_Object/CUS-YYYYMMDD_vN/canonical_custom_objects_v*.csv +
#          EDL/*.txt, written by the new build_custom_objects.py — same
#          schema and directory shape as user_access (OBJECT_NAME/
#          OBJECT_TYPE/OBJECT_CLASS/HERITAGE/ROUTING_DOMAIN/SUBNET_CIDRS/
#          MEMBER_IPS/...), so _build_custom_objects_dataset() is a direct
#          copy of _build_user_access_dataset()'s pattern, grouped by
#          OBJECT_CLASS the same way. Not required, not lifecycle-managed —
#          tab is simply absent if no CUS- dir exists yet, same as
#          cloud_services/geo_block/external_ng/partner_ng. Updated in three
#          places per this script's own documented bug history (v1.5.1/
#          v1.3.1) of a new slot missing one of these and silently breaking
#          discovery: _VER_RE (added CUS to the prefix alternation),
#          _SLOT_PREFIX (added 'custom_objects': 'CUS'), and the slot_id
#          dispatch chain in main().
#          same IPDATASET-v{date} directory naming but are populated by
#          two independent scripts that don't always run together.
#          Discovery matched on naming alone, so whichever script ran
#          most recently silently won for BOTH slots. Confirmed live:
#          build_ipdataset_objects.py ran alone, creating
#          IPDATASET-v20260710 with zero geo-block content — geo_block
#          still picked it (0 objects) over IPDATASET-v20260708, which
#          genuinely had real geo-block data. Now verifies each slot's
#          own marker file (geo_block_manifest_v*.csv /
#          ipdataset_manifest_v*.csv) actually exists before accepting a
#          candidate directory, falling back to an older one that
#          genuinely has this slot's data.

# v1.5.6 — 2026-07-09  BUG FIX: v1.5.3's edl_base=nested_name (e.g.
#          'Partner_NG') broke download paths — the client-side JS builds
#          them as `${edl_base}/${version}/${sub}/${file}`, a fixed
#          template with version always the second segment. That produced
#          the OLD pre-consolidation top-level path
#          (Partner_NG/NG-.../EDL/file), which no longer exists after
#          v1.5.3 nested Partner-NG/External-NG one level deeper.
#          Confirmed live: the UI's own "cannot load file" error showed
#          exactly that stale path. edl_base is now correctly 'Net_Group'
#          for both slots (matching internal_ng); the nested folder name
#          travels separately via the new edl_subdir field, and
#          edlFilePath() in the HTML template was updated to insert it
#          between version and sub.

# v1.5.5 — 2026-07-09  BUG FIX: partner_ng and external_ng still had
#          lifecycle_managed=True even after v1.5.3 gave them real,
#          working builder logic — confirmed live: the info panel and
#          catalog summary both correctly showed real EDL file counts
#          (Partner-NG: 80 EDL files, 9 objects), but clicking any object
#          still showed "No EDL export for this object yet... doesn't
#          have a dedicated EDL export step built" — wording that maps
#          directly to this flag's documented meaning ("tab shown as
#          placeholder until FW Rule Lifecycle populates it"). The
#          client-side UI evidently checks this dataset-level flag rather
#          than per-object EDL presence. Flipped to False for both slots
#          and descriptions updated to describe the real builder scripts
#          (build_partner_ng.py / build_external_ng.py) instead of the
#          old "FW Rule Lifecycle" framing.
# v1.5.4 — 2026-07-09  Fixed the "To view:" hint at end of run — referenced
#          a nonexistent './serve.sh' instead of the actual
#          object-viewer-web-service.sh, and didn't mention that direct
#          file:// open only renders the tree — EDL file downloads
#          specifically require the server (browsers block file://
#          fetches for the individual .txt objects).
# v1.5.3 — 2026-07-09  Consolidated Partner-NG and External-NG to read from
#          Net_Group/NG-YYYYMMDD_vN/Partner_NG/ and .../External_NG/ (nested
#          inside the SAME shared version directory internal_ng uses)
#          instead of separately-versioned top-level Partner_NG/ and
#          External_NG/ trees — a full platform export only needs
#          Net_Group/ and Net_Object/, not N additional directories.
#          DATASET_SLOTS subdir for both changed to 'Net_Group'; the
#          dispatcher now passes read_subdir so _build_net_group_dataset
#          knows which nested subfolder within the shared directory holds
#          each slot's own catalog + EDL. Writer-side half of this change
#          is build_partner_ng.py v1.0.2 / build_external_ng.py v1.0.1.
# v1.5.2 — 2026-07-09  BUG FIX: partner_ng and external_ng slots had no
#          dedicated builder in the dispatch chain and fell through to
#          _build_generic_dataset() — a stub (its own docstring says
#          "Minimal placeholder builder") that always returns tree: []
#          regardless of real data on disk. Confirmed live:
#          Partner_NG/NG-20260709_v1/ and External_NG/NG-20260709_v1/ both
#          had real, substantial catalog and EDL data that never appeared
#          in the UI because nothing ever read it — the directory-
#          discovery logic (_find_latest_versioned_dir, _SLOT_PREFIX) was
#          already correct and finding these directories fine; the bug
#          was entirely in what happened after. build_partner_ng.py and
#          build_external_ng.py both write the identical catalog CSV
#          schema _build_net_group_dataset already parses correctly for
#          Internal-NG (TIER/OBJECT_NAME/PARENT/CLASS/CIDR_COUNT) —
#          reused directly rather than duplicated, with edl_base now a
#          parameter instead of hardcoded to 'Net_Group' so the function
#          works correctly for all three NG-tier directories. Also fixed
#          a stale docstring header (said v1.3.1, __version__ was
#          already at 1.5.1) found while in here.
# v1.5.1 — Fixed real bug found via testing: _find_latest_versioned_dir matched
#          ANY of NG/SO/CS/EF/UA for every slot, meaning if a slot's own
#          directory was missing, another slot's directory could get picked
#          up by accident (confirmed: internal_no read a UA- dir in a test
#          sandbox with no SO- dir present). Added _SLOT_PREFIX mapping so
#          each slot only ever matches its own dedicated prefix.
# v1.3.1 — Fix _find_latest_versioned_dir: cloud_services and geo_block slots
#           were including SO- dirs in their candidate list (both use Net_Object/
#           as subdir). When dates matched, SO-YYYYMMDD_vN beat IPDATASET-vDATE
#           because vN > implicit v0, causing both tabs to resolve to SO- dir
#           and show 0 objects. Fix: dispatch by slot type — cloud_services and
#           geo_block scan for IPDATASET- dirs only; all other slots scan for
#           NG-/SO-/CS-/EF- dirs only. The two match sets are now disjoint.
# v1.3.0 — Eight-tab layout: Geo-Block tab added.
#           New DATASET_SLOT: geo_block / 'Geo-Block' / Net_Object.
#           New builder: _build_geo_block_dataset() reads geo_block_manifest_vDATE.csv
#           written by build_geo_block_objects.py. Groups by country with GEO-BLOCK-ALL
#           rollup. _find_latest_versioned_dir updated to accept geo_block slot_id
#           alongside cloud_services for IPDATASET-vDATE dir matching.
#           _GEO_BLOCK_COUNTRY_NAMES dict added (mirrors build_geo_block_objects.py).
# v1.2.0 — Seven-tab layout replacing two-tab layout:
#           Internal-NG, External-NG, Partner-NG (network group tiers)
#           Internal-NO, External-NO, Partner-NO (network object tiers)
#           Cloud Services (ip_dataset provider objects)
#           DATASET_SLOTS updated. External/Partner tabs are lifecycle-managed
#           placeholders until FW Rule Lifecycle populates them.
#           _build_cloud_services_dataset() added for IPDATASET-vDATE dirs.
#           _VER_RE updated to match NG-/SO-/CS-/EF-/IPDATASET- dirs.
# v1.1.2 — Added --base argument so build_object_pipeline.py can pass the
#           CCD Platform root directory explicitly. WORK_DIR now resolves from
#           --base rather than being hardcoded to os.getcwd() at import time.
#           Also fixed date injection ordering: _inject_date_into_edl_catalog()
#           now runs after the catalog file is written, not before.
# v1.1.0 — Fix _build_ng_tree_from_index: was using name-pattern heuristics
#           instead of TIER+PARENT columns from the catalog CSV. Rewrote to
#           walk the authoritative TIER=1/2/3 + PARENT hierarchy directly.
#           Fix catalog reader: now stores PARENT field in obj_index.
#           Fix net_object builder: reads OBJECT_TYPE (not CLASS) as the
#           group key, and uses correct group names matching the viewer.
# v1.0.0 — Initial build.

import argparse
import base64
import csv
csv.field_size_limit(10_000_000)
import gzip
import json
import os
import re
import sys
from datetime import date, datetime
from pathlib import Path

# ── Constants ─────────────────────────────────────────────────────────────────
# WORK_DIR is set in main() after --base is parsed.
OUTPUT_NAME = 'edl_catalog.html'

# Dataset slot definitions: (id, label, subdir, description, required, lifecycle_managed)
# lifecycle_managed=True → tab shown as placeholder until FW Rule Lifecycle populates it
DATASET_SLOTS = [
    # ── Network Groups ────────────────────────────────────────────────────────
    (
        'internal_ng',  'Internal-NG',  'Net_Group',
        'IPAM-derived internal network address groups — three-tier hierarchy: '
        'Class (DC/Retail/Corporate/COLO) → Site → Address Object. '
        'NG- files include sub-group references; AO- files contain CIDRs only.',
        True, False,
    ),
    (
        'external_ng',  'External-NG',  'Net_Group',
        'Bespoke internet-facing network groups — internet destinations, '
        'CDN ranges, and custom external address objects scoped for '
        'firewall policy use. Built by build_external_ng.py from '
        'ent-ipdataset-INTERNET-FACING.',
        False, False,
    ),
    (
        'partner_ng',   'Partner-NG',   'Net_Group',
        'Third-party B2B partner network groups — VPN peer subnets, '
        'protected partner CIDRs, and known external partner address '
        'spaces. Built by build_partner_ng.py from '
        'ent-ipdataset-VPN-PROTECTED-SUBNETS and '
        'ent-ipdataset-P2P-PROTECTED-SUBNETS.',
        False, False,
    ),
    # ── Network Objects ───────────────────────────────────────────────────────
    (
        'internal_no',  'Internal-NO',  'Net_Object',
        'Application and infrastructure service objects derived from the '
        'canonical app catalog, CPC core services, and VPN partner subnets. '
        'EDL files contain host-level (/32) and partner CIDRs.',
        True, False,
    ),
    # ── User Access ───────────────────────────────────────────────────────────
    (
        'user_access',  'User-Access',  'Net_Object',
        'User-origin traffic SOURCE objects derived from IPAM NET_TYPE and EHM '
        'Citrix host matching — LAN (Corporate/CarePlus/Omnicare/etc), Cisco RA '
        'VPN client pools, ZPA App Connector subnets, VDI (on-prem + Azure), '
        'Citrix (EHM-sourced host objects), and WLC-anchored WLAN subnets. '
        'Read from Net_Object/UA-YYYYMMDD_vN/ (canonical_user_access_objects '
        'catalog CSV + EDL/*.txt), same pattern as Internal-NO.',
        True, False,
    ),
    # ── Custom Objects ────────────────────────────────────────────────────────
    (
        'custom_objects', 'Custom Objects', 'Net_Object',
        'Curated network abstractions that don\'t fit any other object family — '
        'not IPAM-derived (unlike Network Groups) and not USER_ACCESS traffic '
        '(VPN/WLAN/LAN/Citrix/VDI/ZPA). First class: AETNA_HCB_172 (general '
        'Aetna-heritage DataCenter/campus subnets in 172.16.0.0/12). Read from '
        'Net_Object/CUS-YYYYMMDD_vN/ (canonical_custom_objects catalog CSV + '
        'EDL/*.txt), same pattern as Internal-NO / User-Access.',
        False, False,
    ),
    (
        'external_no',  'External-NO',  'External_NO',
        'Bespoke internet-facing network objects defined through the FW Rule '
        'Lifecycle — specific URLs, IP ranges, and named internet service '
        'objects scoped for policy use.',
        False, True,
    ),
    (
        'partner_no',   'Partner-NO',   'Partner_NO',
        'Third-party B2B partner network objects defined through the FW Rule '
        'Lifecycle — individual partner service endpoints, API gateways, '
        'and named partner IP objects.',
        False, True,
    ),
    # ── Cloud Services ────────────────────────────────────────────────────────
    (
        'cloud_services', 'Cloud Services', 'Net_Object',
        'Public cloud and SaaS provider IP ranges from ip_dataset — '
        'AWS (S3/EC2/CloudFront by region), Azure (service tags), GCP, '
        'Oracle OCI, Azure China (21Vianet), Tencent, Zscaler, CrowdStrike, '
        'Salesforce, SAP BTP, Okta, Cloudflare, Akamai, GitHub, and more.',
        False, False,
    ),
    # ── Geo-Block ─────────────────────────────────────────────────────────────
    (
        'geo_block', 'Geo-Block', 'Net_Object',
        'Country-level IP block lists generated from IP2Location LITE DB1 — '
        'Nigeria, Ghana, Kazakhstan, Senegal, Pakistan, Uzbekistan, Kyrgyzstan, '
        'Afghanistan, Tajikistan, Turkmenistan, Russia, Iran, China (Azure China '
        'CIDRs excluded). Each country is an EDL address object in Panorama; '
        'GEO-BLOCK-ALL is the deny-all rollup group.',
        False, False,
    ),
]

# Version directory patterns
_VER_RE        = re.compile(r'^(?:NG|SO|CS|EF|UA|CUS)-(\d{8})_v(\d+)$')
_IPDATASET_RE  = re.compile(r'^IPDATASET-v(\d{8})(?:r(\d+))?$')

# Each slot must only match ITS OWN directory prefix — matching any of
# NG/SO/CS/EF/UA interchangeably (the old behavior) meant that if a slot's
# real directory was missing, another slot's directory with a numerically
# higher version could silently get picked up instead. Confirmed as a real
# bug via testing, not a hypothetical: adding UA- caused internal_no to
# read a UA- directory in a sandbox where no SO- dir existed yet.
_SLOT_PREFIX = {
    'internal_ng': 'NG', 'external_ng': 'NG', 'partner_ng': 'NG',
    'internal_no': 'SO', 'external_no': 'SO', 'partner_no': 'SO',
    'user_access': 'UA',
    'custom_objects': 'CUS',
}


# ── Discovery helpers ──────────────────────────────────────────────────────────

def _find_latest_versioned_dir(base: Path, slot_id: str = '') -> Path | None:
    """Return the latest versioned subdir under base, or None.

    Dispatch by slot type:
      cloud_services / geo_block → IPDATASET-vDATE dirs ONLY.
        These slots live in Net_Object/ alongside SO- dirs. Mixing the two
        into the same candidate list causes SO- to win the sort when dates
        match (SO- has an explicit vN revision; IPDATASET- has none).
      all other slots → NG-/SO-/CS-/EF- dirs via _VER_RE.

    v1.5.7 — BUG FIX: cloud_services and geo_block share the exact same
    IPDATASET-v{date} directory naming, but are populated by two
    independent scripts (build_ipdataset_objects.py /
    build_geo_block_objects.py) that don't always run together. Matching
    on the naming pattern alone meant whichever script ran MOST RECENTLY
    silently won discovery for BOTH slots, even for the one it never
    touched. Confirmed live: build_ipdataset_objects.py ran alone,
    creating IPDATASET-v20260710 with zero geo-block content — geo_block
    still picked it as "latest" (0 objects) over IPDATASET-v20260708,
    which genuinely had real geo-block data. Now verifies each slot's own
    marker file actually exists in a candidate before accepting it,
    falling back to an older directory that genuinely has this slot's
    data if the newest doesn't.
    """
    if not base.is_dir():
        return None
    candidates = []

    if slot_id in ('cloud_services', 'geo_block'):
        # IPDATASET-only scan — do NOT include SO- dirs. Each slot also
        # requires its own marker file to be present (see v1.5.7 above) —
        # matching the directory-naming pattern alone isn't enough, since
        # both slots share it but are populated independently.
        marker_glob = 'geo_block_manifest_v*.csv' if slot_id == 'geo_block' \
            else 'ipdataset_manifest_v*.csv'
        for d in base.iterdir():
            if not d.is_dir():
                continue
            m2 = _IPDATASET_RE.match(d.name)
            if m2 and any(d.glob(marker_glob)):
                candidates.append((int(m2.group(1)), int(m2.group(2) or 0), d))
    else:
        # Standard scan — only match THIS slot's own prefix (NG/SO/UA),
        # never another slot's directory.
        expected_prefix = _SLOT_PREFIX.get(slot_id)
        for d in base.iterdir():
            if not d.is_dir():
                continue
            m = _VER_RE.match(d.name)
            if m and (expected_prefix is None or d.name.startswith(expected_prefix + '-')):
                candidates.append((int(m.group(1)), int(m.group(2)), d))

    if not candidates:
        return None
    candidates.sort(key=lambda x: (x[0], x[1]))
    return candidates[-1][2]


def _ipam_db_row_count(work_dir: Path, stem_glob: str) -> int | None:
    """Row count of the currently-registered copy in ipam-db/, or None if
    not found. This is the post-import source of truth -- distinct from
    whatever a versioned Net_Object/Net_Group directory holds on disk,
    which may have been written by a build script whose subsequent
    ipam-db.py --import was blocked or failed."""
    ipam_db_dir = work_dir / 'ipam-db'
    if not ipam_db_dir.is_dir():
        return None
    csv_path = _find_latest_csv(ipam_db_dir, stem_glob)
    if not csv_path:
        return None
    try:
        return len(_read_csv(csv_path))
    except Exception:
        return None


def _find_import_verified_versioned_dir(base: Path, slot_id: str, work_dir: Path,
                                          catalog_stem_glob: str) -> Path | None:
    """Like _find_latest_versioned_dir, but for slots that flow through an
    ipam-db.py --import step (custom_objects, user_access): verifies the
    candidate directory's own catalog CSV row count matches what's actually
    registered in ipam-db/ before accepting it. Falls back to progressively
    older versioned directories until one matches, or to the newest
    candidate with a loud warning if none do.

    Why this exists: build_custom_objects.py (and build_user_access_objects.py)
    write their versioned output directory BEFORE the ipam-db.py --import
    step runs. If that import is later blocked (e.g. by ipam-db's row-count
    collapse-safety check) or fails for any other reason, the newest
    directory on disk reflects a run that never actually became "current" --
    but ipam-db/ itself, the actual source of truth, still holds the last
    successfully-imported data. Confirmed live: a wrong --egress-dir caused
    build_custom_objects.py to emit 6 objects instead of 143; ipam-db's
    collapse-safety check correctly blocked importing those 6 over the
    registered 143; but picking "latest by version number" alone still
    showed the 6-object directory in the catalog despite ipam-db itself
    being untouched and correct.
    """
    if not base.is_dir():
        return None
    expected_prefix = _SLOT_PREFIX.get(slot_id)
    candidates = []
    for d in base.iterdir():
        if not d.is_dir():
            continue
        m = _VER_RE.match(d.name)
        if m and (expected_prefix is None or d.name.startswith(expected_prefix + '-')):
            candidates.append((int(m.group(1)), int(m.group(2)), d))
    if not candidates:
        return None
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)  # newest first
    newest = candidates[0][2]

    registered_count = _ipam_db_row_count(work_dir, catalog_stem_glob)
    if registered_count is None:
        # Nothing registered yet to verify against (e.g. first-ever run,
        # before any import has happened) -- fall back to newest-by-version.
        return newest

    for _, _, d in candidates:
        cat_path = _find_latest_csv(d, catalog_stem_glob)
        if cat_path is None:
            continue
        try:
            rows = _read_csv(cat_path)
        except Exception:
            continue
        if len(rows) == registered_count:
            if d != newest:
                print(f'  \u26a0 {newest.name} looks like a blocked/failed import '
                      f'({registered_count} rows expected in ipam-db) -- using '
                      f'{d.name} instead, which matches.')
            return d

    print(f'  \u26a0 No {slot_id} directory matches ipam-db\'s registered row count '
          f'({registered_count}) across {len(candidates)} candidate(s) -- showing '
          f'{newest.name} anyway, which may reflect a blocked/failed import.')
    return newest


def _find_latest_csv(directory: Path, stem_glob: str) -> Path | None:
    """Find most-recently-modified CSV matching a glob pattern in directory."""
    matches = sorted(directory.glob(stem_glob), key=lambda p: p.stat().st_mtime, reverse=True)
    return matches[0] if matches else None


def _numeric_version_key(name: str):
    """Sort key for vYYYYMMDDrN-style versioned filenames."""
    m = re.search(r'v(\d{8})(?:r(\d+))?', name)
    if m:
        return (int(m.group(1)), int(m.group(2) or 0))
    return (0, 0)


# ── CSV readers ───────────────────────────────────────────────────────────────

def _read_csv(path: Path, comment_char='#') -> list[dict]:
    rows = []
    with open(path, newline='', encoding='utf-8-sig') as f:
        # Skip comment lines, find header
        lines = [l for l in f if not l.startswith(comment_char)]
    reader = csv.DictReader(lines)
    for row in reader:
        rows.append({k.strip(): v.strip() for k, v in row.items() if k})
    return rows


# ── Net_Group dataset builder ─────────────────────────────────────────────────

def _build_net_group_dataset(slot_id, label, description, ver_dir: Path,
                              edl_base: str = 'Net_Group', read_subdir: str = '') -> dict:
    """
    Build the net_group dataset dict from Net_Group/NG-YYYYMMDD_vN/ (or,
    since v1.7, a nested Net_Group/NG-YYYYMMDD_vN/Partner_NG/ or
    .../External_NG/ subfolder within the SAME shared version directory —
    same catalog CSV schema, see build_partner_ng.py / build_external_ng.py
    column list). read_subdir, if given, is appended to ver_dir before
    reading — internal_ng leaves it empty and reads ver_dir directly.

    Expected files:
        ng_manifest.csv                    — one row per NG-/AO- file
        network_object_catalog_v*.csv      — full CIDR catalog
    """
    version = ver_dir.name
    read_dir = (ver_dir / read_subdir) if read_subdir else ver_dir

    # ── Scan EDL directory ────────────────────────────────────────────────────
    edl_files: set[str] = set()
    ng_edl_files: set[str] = set()
    ao_edl_files: set[str] = set()
    total_edl_files = 0

    # Always scan the EDL/ directory directly — ng_manifest.csv has summary
    # rows not per-file rows so it can't reliably enumerate EDL filenames.
    edl_dir = read_dir / 'EDL'
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl'):
                edl_files.add(f.name)
                if f.stem.startswith('NG-'):
                    ng_edl_files.add(f.name)
                elif f.stem.startswith('AO-'):
                    ao_edl_files.add(f.name)
        total_edl_files = len(edl_files)

    # ── Read network_object_catalog ───────────────────────────────────────────
    cat_path = _find_latest_csv(read_dir, 'network_object_catalog_v*.csv')
    if not cat_path:
        cat_path = _find_latest_csv(read_dir, 'ng_catalog*.csv')

    # Build a fast lookup: object_name → {cidr_count, has_ng_edl, has_ao_edl}
    obj_index: dict[str, dict] = {}
    total_sites = 0

    if cat_path and cat_path.exists():
        rows = _read_csv(cat_path)
        # Columns expected: OBJECT_NAME, CLASS, CIDR_COUNT, TIER, PARENT, SOURCE
        for r in rows:
            name   = r.get('OBJECT_NAME') or r.get('NAME') or r.get('name') or ''
            cls    = r.get('CLASS') or r.get('class') or ''
            tier   = r.get('TIER') or r.get('tier') or ''
            parent = r.get('PARENT') or r.get('parent') or ''
            try:
                cidrs = int(r.get('CIDR_COUNT') or r.get('CIDRS') or r.get('cidrs') or 0)
            except ValueError:
                cidrs = 0
            if name:
                obj_index[name] = {
                    'class':  cls,
                    'tier':   str(tier).strip(),
                    'parent': parent.strip(),
                    'cidrs':  cidrs,
                    'has_ng_edl': any(f.startswith(name) for f in ng_edl_files)
                                  or (name + '.txt') in edl_files
                                  or (name + '.edl') in edl_files,
                    'has_ao_edl': any(f.startswith(name.replace('NG-', 'AO-')) for f in ao_edl_files),
                }

    # ── Build tree from catalog or EDL filenames ──────────────────────────────
    tree = _build_ng_tree(obj_index, ng_edl_files, ao_edl_files)
    total_sites = sum(len(node.get('children', [])) for node in tree)

    return {
        'id':             slot_id,
        'label':          label,
        'description':    description,
        'version':        version,
        'generated':      date.today().isoformat(),
        'edl_base':       edl_base,
        'edl_subdir':     read_subdir,
        'total_sites':    total_sites,
        'total_edl_files': total_edl_files or len(edl_files),
        'tree':           tree,
    }


def _build_ng_tree(obj_index: dict, ng_edl_files: set, ao_edl_files: set) -> list:
    """
    Build the class→site→leaf hierarchy.

    If obj_index is populated from the catalog CSV, use it.
    Fall back to inferring structure from EDL filenames.
    """
    if obj_index:
        return _build_ng_tree_from_index(obj_index, ao_edl_files)
    else:
        return _build_ng_tree_from_filenames(ng_edl_files, ao_edl_files)


def _parse_ng_name(name: str):
    """
    Parse NG-CLASS-CITY-STATE-FUNCTION into (class, site_key, display_name).
    Returns (class_str, name) — class is first segment after NG-.
    """
    parts = name.split('-')
    if len(parts) < 2:
        return 'UNKNOWN', name
    # Strip leading NG- or AO-
    if parts[0] in ('NG', 'AO'):
        parts = parts[1:]
    cls = parts[0] if parts else 'UNKNOWN'
    return cls, name


def _build_ng_tree_from_index(obj_index: dict, ao_edl_files: set) -> list:
    """
    Build the Tier-1 → Tier-2 → Tier-3 tree directly from the catalog's
    TIER and PARENT columns, which are authoritative.

    The catalog structure:
      TIER=1  CLASS=DATACENTER  OBJECT_NAME=NG-DATACENTER  PARENT=''
      TIER=2  CLASS=DATACENTER  OBJECT_NAME=NG-DATACENTER-SHEA-DC  PARENT=NG-DATACENTER
      TIER=3  CLASS=''          OBJECT_NAME=AO-DATACENTER-SHEA-DC  PARENT=NG-DATACENTER-SHEA-DC
      TIER=2  CLASS=VPN-PARTNERS OBJECT_NAME=NG-VPN-MDC  PARENT=NG-VPN-PARTNERS
      TIER=3  ...               OBJECT_NAME=AO-VPN-MDC-...  PARENT=NG-VPN-MDC

    We build:
      Tier-1 class node  (one per CLASS)
        → Tier-2 site/group children  (NG- nodes parented to a Tier-1)
            → Tier-3 address objects  (AO- nodes parented to a Tier-2)
    """
    ao_base_names = {os.path.splitext(f)[0] for f in ao_edl_files}

    # Index all rows by name for fast parent lookup
    by_name = obj_index  # already keyed by OBJECT_NAME

    # Collect Tier-1, Tier-2, Tier-3 entries
    t1_nodes = {}   # name → info
    t2_nodes = {}   # name → info
    t3_nodes = {}   # name → info

    for name, info in by_name.items():
        tier = str(info.get('tier', '')).strip()
        if tier == '1':
            t1_nodes[name] = info
        elif tier == '2':
            t2_nodes[name] = info
        elif tier == '3':
            t3_nodes[name] = info
        # '4-inet', 'retail-region', etc. → skip for the main tree

    # Build parent→children maps using PARENT field stored in obj_index
    # (PARENT was stored in obj_index via the catalog reader)
    t2_by_parent = {}   # t1_name → [t2_name, ...]
    t3_by_parent = {}   # t2_name → [t3_name, ...]

    for name, info in t2_nodes.items():
        parent = info.get('parent', '')
        t2_by_parent.setdefault(parent, []).append(name)

    for name, info in t3_nodes.items():
        parent = info.get('parent', '')
        t3_by_parent.setdefault(parent, []).append(name)

    # Assemble tree
    tree = []
    for t1_name in sorted(t1_nodes.keys()):
        t1_info = t1_nodes[t1_name]
        cls = t1_info.get('class', '') or t1_name.replace('NG-', '')
        t1_cidrs = int(t1_info.get('cidrs', 0) or 0)

        children = []
        for t2_name in sorted(t2_by_parent.get(t1_name, [])):
            t2_info = t2_nodes[t2_name]
            t2_cidrs = int(t2_info.get('cidrs', 0) or 0)

            # Tier-3 leaves under this Tier-2
            leaves = []
            for t3_name in sorted(t3_by_parent.get(t2_name, [])):
                t3_info = t3_nodes[t3_name]
                t3_cidrs = int(t3_info.get('cidrs', 0) or 0)
                t3_base = os.path.splitext(t3_name)[0]
                leaves.append({
                    'name':    t3_name,
                    'cidrs':   t3_cidrs,
                    'has_edl': t3_base in ao_base_names,
                })
                # Sum Tier-3 CIDRs up to Tier-2 if Tier-2 CIDR_COUNT is blank
                if not t2_cidrs:
                    t2_cidrs += t3_cidrs

            ng_base = os.path.splitext(t2_name)[0]
            ao_base = 'AO-' + t2_name[3:] if t2_name.startswith('NG-') else t2_name
            children.append({
                'name':       t2_name,
                'class':      cls,
                'cidr_count': t2_cidrs,
                'leaf_count': len(leaves),
                'has_ng_edl': t2_info.get('has_ng_edl', ng_base in ao_base_names or
                                           (t2_name + '.txt') in ao_edl_files),
                'has_ao_edl': t2_info.get('has_ao_edl', ao_base in ao_base_names),
                'leaves':     leaves,
            })
            # Sum Tier-2 CIDRs up to Tier-1 if Tier-1 CIDR_COUNT is blank
            if not t1_cidrs:
                t1_cidrs += t2_cidrs

        if not children:
            continue

        tree.append({
            'name':        t1_name,
            'class':       cls,
            'total_cidrs': t1_cidrs,
            'site_count':  len(children),
            'has_edl':     any(c['has_ng_edl'] for c in children),
            'children':    children,
        })

    return tree


def _build_ng_tree_from_filenames(ng_edl_files: set, ao_edl_files: set) -> list:
    """
    Build tree purely from EDL filenames when no catalog CSV is present.
    NG-CLASS-CITY-STATE-FUNCTION.txt → class=CLASS, site=NG-CLASS-CITY-STATE-FUNCTION
    """
    ao_names = {os.path.splitext(f)[0] for f in ao_edl_files}
    classes: dict[str, dict] = {}

    for fname in sorted(ng_edl_files):
        name = os.path.splitext(fname)[0]
        if not name.startswith('NG-'):
            continue
        parts = name.split('-')
        if len(parts) < 3:
            continue
        cls = parts[1]  # NG-CLASS-...
        ao_name = 'AO-' + '-'.join(parts[1:])

        if cls not in classes:
            classes[cls] = {'total_cidrs': 0, 'site_count': 0, 'children': {}}

        leaf = {
            'name': ao_name,
            'cidrs': 0,   # unknown without catalog
            'has_edl': ao_name in ao_names,
        }
        child = {
            'name': name,
            'class': cls,
            'cidr_count': 0,
            'leaf_count': 1,
            'has_ng_edl': True,
            'has_ao_edl': ao_name in ao_names,
            'leaves': [leaf],
        }
        classes[cls]['children'][name] = child
        classes[cls]['site_count'] += 1

    tree = []
    for cls, data in sorted(classes.items()):
        children = sorted(data['children'].values(), key=lambda x: x['name'])
        tree.append({
            'name': f'NG-{cls}',
            'class': cls,
            'total_cidrs': 0,
            'site_count': data['site_count'],
            'has_edl': True,
            'children': children,
        })
    return tree


# ── Net_Object dataset builder ────────────────────────────────────────────────

def _build_net_object_dataset(slot_id, label, description, ver_dir: Path) -> dict:
    """
    Build the net_object dataset dict from Net_Object/SO-YYYYMMDD_vN/.

    Expected files:
        service_object_catalog_v*.csv    — one row per SVC_ object
    """
    version = ver_dir.name

    # Count EDL files
    edl_dir = ver_dir / 'EDL'
    total_edl_files = 0
    svc_edl_names: set[str] = set()
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl'):
                total_edl_files += 1
                svc_edl_names.add(os.path.splitext(f.name)[0])

    # Read service_object_catalog
    cat_path = _find_latest_csv(ver_dir, 'service_object_catalog_v*.csv')
    if not cat_path:
        cat_path = _find_latest_csv(ver_dir, 'so_catalog*.csv')

    tree = []
    total_objects = 0

    if cat_path and cat_path.exists():
        rows = _read_csv(cat_path)
        # Group SVC_ objects by CLASS/TYPE
        groups: dict[str, dict] = {}
        for r in rows:
            name = r.get('OBJECT_NAME') or r.get('NAME') or r.get('name') or ''
            # service_object_catalog uses OBJECT_TYPE for the class (APP/INFRA/SERVICE/etc)
            cls  = (r.get('OBJECT_TYPE') or r.get('object_type') or
                    r.get('CLASS') or r.get('class') or
                    r.get('TYPE') or r.get('type') or 'OTHER')
            heritage       = r.get('HERITAGE') or r.get('heritage') or ''
            routing_domain = r.get('ROUTING_DOMAIN') or r.get('routing_domain') or ''
            app_acronym    = (r.get('APP_ACRONYM') or r.get('app_acronym') or
                              r.get('ACRONYM') or r.get('acronym') or '')
            try:
                cidrs = int(r.get('CIDR_COUNT') or r.get('CIDRS') or r.get('cidrs') or 0)
            except ValueError:
                cidrs = 0

            if not name:
                continue
            total_objects += 1

            # Group key is just the OBJECT_TYPE (APP, INFRA, SERVICE, DELIVERY, CPC, VPN)
            # The viewer expects class == 'APP', 'INFRA' etc. — not 'NG-APP-SVC'
            grp_key = cls
            if grp_key not in groups:
                groups[grp_key] = {
                    'name':        f'NG-SVC-{cls}' if cls not in ('VPN',) else 'NG-VPN-SVC',
                    'class':       cls,
                    'total_cidrs': 0,
                    'object_count': 0,
                    'children':    [],
                }

            obj_base = os.path.splitext(name)[0]
            groups[grp_key]['children'].append({
                'name':           name,
                'class':          cls,
                'heritage':       heritage,
                'routing_domain': routing_domain,
                'app_acronym':    app_acronym,
                'cidrs':          cidrs,
                'has_edl':        obj_base in svc_edl_names,
            })
            groups[grp_key]['total_cidrs']  += cidrs
            groups[grp_key]['object_count'] += 1

        tree = sorted(groups.values(), key=lambda x: x['name'])
    else:
        # Fall back: infer from EDL filenames
        classes_seen: dict[str, list] = {}
        for name in sorted(svc_edl_names):
            parts = name.split('_')
            cls = parts[1] if len(parts) > 1 else 'OTHER'
            app_acronym = '_'.join(parts[2:]) if len(parts) > 2 else name
            classes_seen.setdefault(cls, []).append({
                'name': name,
                'class': cls,
                'heritage': '',
                'routing_domain': '',
                'app_acronym': app_acronym,
                'cidrs': 0,
                'has_edl': True,
            })
            total_objects += 1

        for cls, children in sorted(classes_seen.items()):
            tree.append({
                'name': f'NG-{cls}-SVC',
                'class': cls,
                'total_cidrs': 0,
                'object_count': len(children),
                'children': children,
            })

    return {
        'id':             slot_id,
        'label':          label,
        'description':    description,
        'version':        version,
        'generated':      date.today().isoformat(),
        'edl_base':       'Net_Object',
        'total_objects':  total_objects,
        'total_edl_files': total_edl_files,
        'tree':           tree,
    }


# ── User Access dataset builder ──────────────────────────────────────────────
# canonical_user_access_objects_vDATE.csv + EDL/*.txt now live in a versioned
# Net_Object/UA-YYYYMMDD_vN/ directory (build_user_access_objects.py v1.3.0+),
# same pattern as SO-YYYYMMDD_vN/ — discovered via the standard
# _find_latest_versioned_dir(), no special-casing needed.


def _build_user_access_dataset(slot_id, label, description, ver_dir: Path) -> dict:
    """
    Build the user_access dataset dict from Net_Object/UA-YYYYMMDD_vN/.

    Expected files:
        canonical_user_access_objects_v*.csv  — one row per USER_ACCESS_* object
        EDL/*.txt                              — real EDL export, one per object

    Schema (build_user_access_objects.py FIELDNAMES):
      OBJECT_NAME, OBJECT_TYPE, OBJECT_CLASS, APP_ACRONYM, SERVICE_ROLE,
      HERITAGE, ROUTING_DOMAIN, MEMBER_IPS, VIP_IPS, SUBNET_CIDRS, LOCATIONS,
      MEMBER_COUNT, VIP_COUNT, SOURCE_DATASETS, DATASET_VERSION, ...
    """
    version = ver_dir.name

    edl_dir = ver_dir / 'EDL'
    total_edl_files = 0
    ua_edl_names: set[str] = set()
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl'):
                total_edl_files += 1
                ua_edl_names.add(os.path.splitext(f.name)[0])

    cat_path = _find_latest_csv(ver_dir, 'canonical_user_access_objects_v*.csv')

    tree = []
    total_objects = 0

    if cat_path and cat_path.exists():
        rows = _read_csv(cat_path)
        groups: dict[str, dict] = {}
        for r in rows:
            name = r.get('OBJECT_NAME') or ''
            cls  = r.get('OBJECT_CLASS') or 'USER_ACCESS_UNKNOWN'
            heritage       = r.get('HERITAGE') or ''
            routing_domain = r.get('ROUTING_DOMAIN') or ''
            app_acronym    = r.get('APP_ACRONYM') or r.get('SERVICE_ROLE') or ''

            subnet_cidrs = r.get('SUBNET_CIDRS') or ''
            member_ips   = r.get('MEMBER_IPS') or ''
            cidrs = len(subnet_cidrs.split('|')) if subnet_cidrs else 0
            hosts = len(member_ips.split('|')) if member_ips else 0

            if not name:
                continue
            total_objects += 1

            grp_key = cls
            if grp_key not in groups:
                groups[grp_key] = {
                    'name':        cls,
                    'class':       cls,
                    'total_cidrs': 0,
                    'total_hosts': 0,
                    'object_count': 0,
                    'children':    [],
                }

            groups[grp_key]['children'].append({
                'name':           name,
                'class':          cls,
                'heritage':       heritage,
                'routing_domain': routing_domain,
                'app_acronym':    app_acronym,
                'cidrs':          cidrs,
                'hosts':          hosts,
                'has_edl':        name in ua_edl_names,
            })
            groups[grp_key]['total_cidrs']  += cidrs
            groups[grp_key]['total_hosts']  += hosts
            groups[grp_key]['object_count'] += 1

        tree = sorted(groups.values(), key=lambda x: x['name'])

    return {
        'id':              slot_id,
        'label':           label,
        'description':     description,
        'version':         version,
        'generated':       date.today().isoformat(),
        'edl_base':        'Net_Object',
        'total_objects':   total_objects,
        'total_edl_files': total_edl_files,
        'tree':            tree,
    }


# ── Custom Objects dataset builder ───────────────────────────────────────────

def _build_custom_objects_dataset(slot_id, label, description, ver_dir: Path) -> dict:
    """
    Build the custom_objects dataset dict from Net_Object/CUS-YYYYMMDD_vN/.

    Same catalog schema and directory shape as user_access — this is a
    direct copy of _build_user_access_dataset()'s pattern rather than a
    new implementation, since build_custom_objects.py's FIELDNAMES/
    CanonicalObject.to_dict() output matches build_user_access_objects.py's
    exactly (only OBJECT_TYPE differs: 'CUSTOM' instead of 'USER_ACCESS').

    Expected files:
        canonical_custom_objects_v*.csv  — one row per CUSTOM_* object
        EDL/*.txt                         — real EDL export, one per object

    Schema (build_custom_objects.py FIELDNAMES):
      OBJECT_NAME, OBJECT_TYPE, OBJECT_CLASS, APP_ACRONYM, SERVICE_ROLE,
      HERITAGE, ROUTING_DOMAIN, MEMBER_IPS, VIP_IPS, SUBNET_CIDRS, LOCATIONS,
      MEMBER_COUNT, VIP_COUNT, SOURCE_DATASETS, DATASET_VERSION, ...
    """
    version = ver_dir.name

    edl_dir = ver_dir / 'EDL'
    total_edl_files = 0
    cus_edl_names: set[str] = set()
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl'):
                total_edl_files += 1
                cus_edl_names.add(os.path.splitext(f.name)[0])

    cat_path = _find_latest_csv(ver_dir, 'canonical_custom_objects_v*.csv')

    tree = []
    total_objects = 0

    if cat_path and cat_path.exists():
        rows = _read_csv(cat_path)
        groups: dict[str, dict] = {}
        for r in rows:
            name = r.get('OBJECT_NAME') or ''
            cls  = r.get('OBJECT_CLASS') or 'CUSTOM_UNKNOWN'
            heritage       = r.get('HERITAGE') or ''
            routing_domain = r.get('ROUTING_DOMAIN') or ''
            app_acronym    = r.get('APP_ACRONYM') or r.get('SERVICE_ROLE') or ''

            subnet_cidrs = r.get('SUBNET_CIDRS') or ''
            member_ips   = r.get('MEMBER_IPS') or ''
            cidrs = len(subnet_cidrs.split('|')) if subnet_cidrs else 0
            hosts = len(member_ips.split('|')) if member_ips else 0

            if not name:
                continue
            total_objects += 1

            grp_key = cls
            if grp_key not in groups:
                groups[grp_key] = {
                    'name':        cls,
                    'class':       cls,
                    'total_cidrs': 0,
                    'total_hosts': 0,
                    'object_count': 0,
                    'children':    [],
                }

            groups[grp_key]['children'].append({
                'name':           name,
                'class':          cls,
                'heritage':       heritage,
                'routing_domain': routing_domain,
                'app_acronym':    app_acronym,
                'cidrs':          cidrs,
                'hosts':          hosts,
                'has_edl':        name in cus_edl_names,
            })
            groups[grp_key]['total_cidrs']  += cidrs
            groups[grp_key]['total_hosts']  += hosts
            groups[grp_key]['object_count'] += 1

        tree = sorted(groups.values(), key=lambda x: x['name'])

    return {
        'id':              slot_id,
        'label':           label,
        'description':     description,
        'version':         version,
        'generated':       date.today().isoformat(),
        'edl_base':        'Net_Object',
        'total_objects':   total_objects,
        'total_edl_files': total_edl_files,
        'tree':            tree,
    }


# ── Cloud Services dataset builder ───────────────────────────────────────────

def _build_cloud_services_dataset(slot_id, label, description, ver_dir: Path) -> dict:
    """
    Build the cloud_services dataset dict from Net_Object/IPDATASET-vDATE/.

    Expected files:
        ipdataset_manifest_vDATE.csv   — one row per object/group
        edl/                           — EDL flat files for large groups
    """
    version = ver_dir.name

    # Count EDL files
    edl_dir = ver_dir / 'edl'
    total_edl_files = 0
    edl_names: set[str] = set()
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl'):
                total_edl_files += 1
                edl_names.add(f.stem)

    # Read manifest
    manifest_path = _find_latest_csv(ver_dir, 'ipdataset_manifest_v*.csv')
    tree = []
    total_objects = 0

    if manifest_path and manifest_path.exists():
        rows = _read_csv(manifest_path)
        # Group by provider prefix (AWS-*, AZURE-*, GCP-*, etc.)
        groups: dict[str, dict] = {}
        PROVIDER_LABELS = {
            'AWS':          'Amazon Web Services',
            'AZURE':        'Microsoft Azure',
            'GCP':          'Google Cloud',
            'ZSCALER':      'Zscaler',
            'CROWDSTRIKE':  'CrowdStrike',
            'CLOUD':        'Cloud (All)',
        }
        for r in rows:
            name      = r.get('OBJECT_NAME', '').strip()
            obj_type  = r.get('OBJECT_TYPE', '').strip()
            try:
                cidrs = int(r.get('CIDR_COUNT') or 0)
            except ValueError:
                cidrs = 0
            source    = r.get('SOURCE', '').strip()
            if not name:
                continue
            total_objects += 1

            # Derive provider from name prefix (AWS-S3-USE1 → AWS)
            prefix = name.split('-')[0]
            label_str = PROVIDER_LABELS.get(prefix, prefix)

            if prefix not in groups:
                groups[prefix] = {
                    'name':         f'CS-{prefix}',
                    'class':        prefix,
                    'label':        label_str,
                    'total_cidrs':  0,
                    'object_count': 0,
                    'children':     [],
                }

            groups[prefix]['children'].append({
                'name':      name,
                'class':     prefix,
                'obj_type':  obj_type,
                'cidrs':     cidrs,
                'source':    source,
                'has_edl':   name in edl_names,
            })
            groups[prefix]['total_cidrs']  += cidrs
            groups[prefix]['object_count'] += 1

        tree = sorted(groups.values(), key=lambda x: x['name'])

    return {
        'id':              slot_id,
        'label':           label,
        'description':     description,
        'version':         version,
        'generated':       date.today().isoformat(),
        'edl_base':        'Net_Object',
        'total_objects':   total_objects,
        'total_edl_files': total_edl_files,
        'tree':            tree,
    }



# ── Geo-Block dataset builder ─────────────────────────────────────────────────

# Country code → display name (mirrors build_geo_block_objects.py)
_GEO_BLOCK_COUNTRY_NAMES: dict[str, str] = {
    'NG': 'Nigeria',        'GH': 'Ghana',          'KZ': 'Kazakhstan',
    'SN': 'Senegal',        'PK': 'Pakistan',        'UZ': 'Uzbekistan',
    'KG': 'Kyrgyzstan',     'AF': 'Afghanistan',     'TJ': 'Tajikistan',
    'TM': 'Turkmenistan',   'RU': 'Russia',          'IR': 'Iran',
    'CN': 'China',
}

def _build_geo_block_dataset(slot_id, label, description, ver_dir: Path) -> dict:
    """
    Build the geo_block dataset dict from Net_Object/IPDATASET-vDATE/.

    Reads geo_block_manifest_vDATE.csv (written by build_geo_block_objects.py).
    Groups entries by country code; GEO-BLOCK-ALL is shown as a summary row.

    Expected manifest columns: OBJECT_NAME, OBJECT_TYPE, CIDR_COUNT, SOURCE
    SOURCE format: geo_block/<CC>/<CountryName>  or  geo_block/ALL/combined
    """
    version = ver_dir.name

    # Count EDL files matching GEO-BLOCK-*
    edl_dir = ver_dir / 'edl'
    total_edl_files = 0
    edl_names: set[str] = set()
    if edl_dir.is_dir():
        for f in edl_dir.iterdir():
            if f.suffix in ('.txt', '.edl') and f.stem.startswith('GEO-BLOCK-'):
                total_edl_files += 1
                edl_names.add(f.stem)

    # Read manifest
    manifest_path = _find_latest_csv(ver_dir, 'geo_block_manifest_v*.csv')
    tree = []
    total_objects = 0
    total_cidrs_all = 0

    if manifest_path and manifest_path.exists():
        rows = _read_csv(manifest_path)

        country_rows = []
        all_row = None

        for r in rows:
            name     = r.get('OBJECT_NAME', '').strip()
            obj_type = r.get('OBJECT_TYPE', '').strip()
            source   = r.get('SOURCE', '').strip()
            try:
                cidrs = int(r.get('CIDR_COUNT') or 0)
            except ValueError:
                cidrs = 0
            if not name:
                continue

            if name == 'GEO-BLOCK-ALL':
                all_row = {'name': name, 'obj_type': obj_type,
                           'cidrs': cidrs, 'source': source,
                           'has_edl': name in edl_names}
                total_cidrs_all = cidrs
                continue

            # Extract country code from name: GEO-BLOCK-NG → NG
            cc = name.replace('GEO-BLOCK-', '')
            country_name = _GEO_BLOCK_COUNTRY_NAMES.get(cc, cc)
            country_rows.append({
                'name':         name,
                'class':        'GEO-BLOCK',
                'country_code': cc,
                'country_name': country_name,
                'obj_type':     obj_type,
                'cidrs':        cidrs,
                'source':       source,
                'has_edl':      name in edl_names,
            })
            total_objects += 1

        # Sort by country name for display
        country_rows.sort(key=lambda r: r['country_name'])

        # Build tree: one top-level group containing all countries
        if country_rows:
            tree.append({
                'name':         'GEO-BLOCK',
                'class':        'GEO-BLOCK',
                'label':        'Geo-Blocked Countries',
                'total_cidrs':  total_cidrs_all,
                'object_count': total_objects,
                'children':     country_rows,
            })

        # Append ALL summary as a second top-level entry if present
        if all_row:
            tree.append({
                'name':         'GEO-BLOCK-ALL',
                'class':        'GEO-BLOCK-ALL',
                'label':        'GEO-BLOCK-ALL (Rollup)',
                'total_cidrs':  all_row['cidrs'],
                'object_count': 1,
                'children':     [all_row],
            })

    return {
        'id':              slot_id,
        'label':           label,
        'description':     description,
        'version':         version,
        'generated':       date.today().isoformat(),
        'edl_base':        'Net_Object',
        'total_objects':   total_objects,
        'total_edl_files': total_edl_files,
        'tree':            tree,
    }


# ── Generic future-slot builder ───────────────────────────────────────────────

def _build_generic_dataset(slot_id, label, description, ver_dir: Path, edl_base: str) -> dict:
    """Minimal placeholder builder for Cloud_Services/ and External_FW/ slots."""
    version = ver_dir.name
    edl_dir = ver_dir / 'EDL'
    total_edl_files = 0
    if edl_dir.is_dir():
        total_edl_files = sum(1 for f in edl_dir.iterdir() if f.suffix in ('.txt', '.edl'))
    return {
        'id':             slot_id,
        'label':          label,
        'description':    description,
        'version':        version,
        'generated':      date.today().isoformat(),
        'edl_base':       edl_base,
        'total_edl_files': total_edl_files,
        'tree':           [],
    }


# ── HTML template reader (reference edl_catalog.html) ────────────────────────

def _get_html_template() -> str:
    """
    Load the HTML shell from edl_catalog.html in WORK_DIR, stripping the
    embedded catalog data so we can inject fresh data.
    Returns the full HTML with CATALOG_B64 replaced by a placeholder.
    """
    candidate = WORK_DIR / OUTPUT_NAME
    if not candidate.exists():
        # Try to find any edl_catalog*.html in work dir
        matches = sorted(WORK_DIR.glob('edl_catalog*.html'), key=lambda p: p.stat().st_mtime, reverse=True)
        candidate = matches[0] if matches else None

    if candidate and candidate.exists():
        html = candidate.read_text(encoding='utf-8')
        # Strip the existing CATALOG_B64 blob — replace with placeholder
        html = re.sub(
            r'const CATALOG_B64 = "[^"]*";',
            'const CATALOG_B64 = "__CATALOG_B64__";',
            html
        )
        return html
    else:
        # No reference HTML found — use embedded minimal template
        return _minimal_html_template()


def _minimal_html_template() -> str:
    """Minimal fallback HTML if no reference edl_catalog.html is present."""
    return r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CCD EDL Catalog</title>
<style>
  :root {
    --bg:#0d1117;--bg2:#161b22;--bg3:#1c2330;--border:#30363d;
    --navy:#17447C;--accent:#388bfd;--accent-dim:#1f4b8e;
    --green:#3fb950;--red:#f85149;--yellow:#d29922;
    --muted:#8b949e;--text:#c9d1d9;--text-hd:#e6edf3;
    --mono:'JetBrains Mono','Fira Code','Consolas',monospace;
    --sans:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--sans);font-size:13px}
  body{display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;padding:20px}
  h1{color:var(--text-hd);font-family:var(--mono);font-size:14px;color:var(--accent)}
  pre{background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:16px;
      font-family:var(--mono);font-size:12px;color:var(--text);white-space:pre-wrap;max-width:800px;width:100%}
</style>
</head>
<body>
<h1>CCD // EDL CATALOG</h1>
<pre id="out">Loading catalog...</pre>
<script>
const CATALOG_B64 = "__CATALOG_B64__";
async function decompress(b64){
  const bin=atob(b64);
  const buf=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++)buf[i]=bin.charCodeAt(i);
  const ds=new DecompressionStream('gzip');
  const w=ds.writable.getWriter();
  w.write(buf);w.close();
  const chunks=[];
  const r=ds.readable.getReader();
  while(true){const{done,value}=await r.read();if(done)break;chunks.push(value)}
  const out=new Uint8Array(chunks.reduce((a,b)=>a+b.length,0));
  let off=0;for(const c of chunks){out.set(c,off);off+=c.length}
  return JSON.parse(new TextDecoder().decode(out));
}
decompress(CATALOG_B64).then(catalog=>{
  document.getElementById('out').textContent=JSON.stringify(catalog,null,2).slice(0,4000)+'...';
});
</script>
</body>
</html>
"""


# ── Catalog serializer ────────────────────────────────────────────────────────

def _encode_catalog(catalog: dict) -> str:
    """gzip + base64 encode the catalog dict → ASCII string for embedding."""
    blob   = json.dumps(catalog, separators=(',', ':')).encode('utf-8')
    zipped = gzip.compress(blob, compresslevel=9)
    return base64.b64encode(zipped).decode('ascii')


# ── Version stamp injection ───────────────────────────────────────────────────

def _inject_version_stamp(html: str, datasets: list[dict]) -> str:
    """
    Update the <title> tag and any static version display in the HTML.
    Also stamps a build comment near the top.
    """
    today = date.today().isoformat()
    versions = ' | '.join(ds['version'] for ds in datasets)
    stamp = f'<!-- CCD EDL Catalog — built {today} — {versions} -->'

    # Replace existing build comment if present
    html = re.sub(r'<!-- CCD EDL Catalog —.*?-->', stamp, html)
    if stamp not in html:
        html = html.replace('<!DOCTYPE html>', f'<!DOCTYPE html>\n{stamp}', 1)

    # Update <title>
    html = re.sub(
        r'<title>.*?</title>',
        f'<title>CCD EDL Catalog — {today}</title>',
        html
    )
    return html


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(
        description=f'build_edl_catalog.py v{__version__} — CCD EDL Catalog Generator'
    )
    p.add_argument('--base', metavar='DIR', default='.',
                   help='CCD Platform root directory containing Net_Group/ and Net_Object/ '
                        '(default: current working directory)')
    p.add_argument('--out', metavar='DIR',
                   help='Output directory for edl_catalog.html '
                        '(default: same as --base)')
    p.add_argument('--dry-run', action='store_true',
                   help='Print what would be indexed without writing any files')
    p.add_argument('--version', action='version',
                   version=f'build_edl_catalog.py v{__version__}')
    args = p.parse_args()

    # Resolve WORK_DIR from --base; inject into module-level so all helpers see it
    global WORK_DIR
    WORK_DIR = Path(args.base).expanduser().resolve()
    out_dir  = Path(args.out).expanduser().resolve() if args.out else WORK_DIR

    print(f'build_edl_catalog.py v{__version__}  |  {date.today().isoformat()}')
    print(f'  Work dir : {WORK_DIR}')
    print(f'  Out dir  : {out_dir}')
    print()

    # ── Discover dataset versions ─────────────────────────────────────────────
    datasets     = []
    slot_summary = []

    for slot_id, label, subdir, description, required, lifecycle_managed in DATASET_SLOTS:
        base_dir = WORK_DIR / subdir
        if slot_id == 'custom_objects':
            ver_dir = _find_import_verified_versioned_dir(
                base_dir, slot_id, WORK_DIR, 'canonical_custom_objects_v*.csv')
        elif slot_id == 'user_access':
            ver_dir = _find_import_verified_versioned_dir(
                base_dir, slot_id, WORK_DIR, 'canonical_user_access_objects_v*.csv')
        else:
            ver_dir = _find_latest_versioned_dir(base_dir, slot_id)

        if ver_dir is None:
            if lifecycle_managed:
                # Lifecycle-managed tabs: show as placeholder, not an error
                print(f'  ○ {subdir:<20}  →  (lifecycle-managed — not yet populated)')
                slot_summary.append((label, subdir, None, 'Lifecycle-managed placeholder'))
                # Add placeholder dataset so the tab still appears in the UI
                datasets.append({
                    'id':              slot_id,
                    'label':           label,
                    'description':     description,
                    'version':         '—',
                    'generated':       date.today().isoformat(),
                    'edl_base':        subdir,
                    'total_edl_files': 0,
                    'total_objects':   0,
                    'lifecycle_managed': True,
                    'tree':            [],
                })
                continue
            if not required:
                print(f'  ○ {subdir:<20}  →  (not present — skipping)')
                slot_summary.append((label, subdir, None, 'Not present'))
                continue
            print(f'  ⚠ {subdir:<20}  →  no versioned subdir found — skipping')
            slot_summary.append((label, subdir, None, 'NOT FOUND'))
            continue

        print(f'  ✓ {subdir:<20}  →  {ver_dir.name}')

        if slot_id == 'internal_ng':
            ds = _build_net_group_dataset(slot_id, label, description, ver_dir)
        elif slot_id in ('partner_ng', 'external_ng'):
            # v1.5.6 — BUG FIX: v1.5.3 passed edl_base=nested_name (e.g.
            # 'Partner_NG') — but the client-side JS builds download paths
            # as `${edl_base}/${version}/${sub}/${file}`, a FIXED template
            # with version always the second segment right after
            # edl_base. edl_base='Partner_NG' produced
            # 'Partner_NG/NG-.../EDL/file' — the OLD pre-consolidation
            # top-level path, which no longer exists. Confirmed live: the
            # UI's own error message showed exactly that wrong path.
            # edl_base must be 'Net_Group' (matching internal_ng, since
            # that's genuinely the real top-level segment); the nested
            # folder name now travels separately via edl_subdir (see
            # _build_net_group_dataset's return dict) — the JS's
            # edlFilePath() was updated to insert it between version and
            # sub. read_subdir still controls where the PYTHON side reads
            # the catalog + EDL from — that part was always correct.
            nested_name = 'Partner_NG' if slot_id == 'partner_ng' else 'External_NG'
            ds = _build_net_group_dataset(slot_id, label, description, ver_dir,
                                           edl_base='Net_Group', read_subdir=nested_name)
        elif slot_id == 'internal_no':
            ds = _build_net_object_dataset(slot_id, label, description, ver_dir)
        elif slot_id == 'user_access':
            ds = _build_user_access_dataset(slot_id, label, description, ver_dir)
        elif slot_id == 'custom_objects':
            ds = _build_custom_objects_dataset(slot_id, label, description, ver_dir)
        elif slot_id == 'cloud_services':
            ds = _build_cloud_services_dataset(slot_id, label, description, ver_dir)
        elif slot_id == 'geo_block':
            ds = _build_geo_block_dataset(slot_id, label, description, ver_dir)
        else:
            ds = _build_generic_dataset(slot_id, label, description, ver_dir, subdir)

        datasets.append(ds)
        edl_count = ds.get('total_edl_files', 0)
        site_count = ds.get('total_sites') or ds.get('total_objects') or \
                     sum(len(n.get('children', [])) for n in ds.get('tree', []))
        slot_summary.append((label, subdir, ver_dir.name, f'{edl_count} EDL files, {site_count} objects'))

    print()

    if not datasets:
        print('ERROR: No datasets found. Ensure Net_Group/ and Net_Object/ exist under:')
        print(f'  {WORK_DIR}')
        sys.exit(1)

    # ── Print discovery summary ───────────────────────────────────────────────
    print('Catalog summary:')
    for label, subdir, version, detail in slot_summary:
        v = version or '—'
        print(f'  {label:<20}  {v:<25}  {detail}')
    print()

    if args.dry_run:
        print('[DRY-RUN] Would write:')
        print(f'  {out_dir / OUTPUT_NAME}')
        for ds in datasets:
            tree_nodes = sum(len(n.get('children', [])) for n in ds.get('tree', []))
            top_nodes  = len(ds.get('tree', []))
            print(f'    {ds["id"]:<20} version={ds["version"]}  '
                  f'top_groups={top_nodes}  children={tree_nodes}  '
                  f'edl_files={ds.get("total_edl_files",0)}')
        print()
        print('[DRY-RUN] No files written. Remove --dry-run to generate output.')
        return 0

    # ── Build catalog JSON + encode ───────────────────────────────────────────
    catalog = {
        'built':    datetime.now().isoformat(timespec='seconds'),
        'generator': f'build_edl_catalog.py v{__version__}',
        'datasets': datasets,
    }

    print('Encoding catalog...', end='', flush=True)
    b64 = _encode_catalog(catalog)
    json_size_kb = len(json.dumps(catalog).encode()) // 1024
    b64_size_kb  = len(b64) // 1024
    print(f'  {json_size_kb} KB JSON → {b64_size_kb} KB gzip+b64')

    # ── Load HTML template and inject catalog ─────────────────────────────────
    print('Loading HTML template...', end='', flush=True)
    html = _get_html_template()
    print('  OK')

    html = html.replace('"__CATALOG_B64__"', f'"{b64}"')
    html = _inject_version_stamp(html, datasets)

    # ── Write output ──────────────────────────────────────────────────────────
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / OUTPUT_NAME
    out_path.write_text(html, encoding='utf-8')

    out_size_kb = out_path.stat().st_size // 1024
    print(f'\n✓ Written: {out_path}  ({out_size_kb} KB)')
    print()
    print('To view:')
    print(f'  ./object-viewer-web-service.sh && open http://127.0.0.1:8080/edl_catalog.html')
    print(f'  # required for EDL file downloads — the catalog tree renders fine via')
    print(f'  # open "{out_path}" directly, but individual .txt object downloads')
    print(f'  # need an actual server (browsers block file:// fetches).')
    return 0


if __name__ == '__main__':
    sys.exit(main())
