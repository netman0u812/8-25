#!/usr/bin/env python3
"""
build_service_objects.py  v1.2.0

  v1.2.0 2026-07-07  Unmapped-type audit trail added. This is the general
                     fix behind the RA bug: any row whose OBJECT_TYPE isn't
                     APP/INFRA/SERVICE/DELIVERY and isn't a recognized RA
                     role now gets counted and reported by label + example
                     object names in the run summary (dry-run and real
                     runs both), instead of being silently continue'd.
                     Also reports the NON_PROD=Y exclusion count for the
                     same reason — visibility over silence.
                     This does NOT change what gets classified as a
                     service object — the RA whitelist (_RA_ROLES_NORM)
                     is still the sole source of truth for that, and stays
                     intentionally conservative. It only makes the next
                     unmapped type (Citrix VDI or otherwise) visible on
                     day one instead of requiring a multi-session debug
                     like the RA objects did.
                     No output schema change. No new required fields.
  v1.1.0 2026-07-07  RA (Remote Access) object handling fixed end-to-end.
                     Root cause: RA objects (ZPA App Connector / CSA pool /
                     HCB SNAT pool) were silently dropped from the catalog.
                     Two issues found and fixed:
                       1. Defensive OBJECT_TYPE normalization — if an
                          upstream builder writes the raw NET_TYPE label
                          (e.g. "RA-CONN-ZPA") into OBJECT_TYPE instead of
                          "SERVICE", that row now gets remapped to SERVICE
                          (with the original label preserved as
                          SERVICE_ROLE if SERVICE_ROLE was blank) instead
                          of being silently skipped by the type gate.
                       2. is_host_list is now role-aware, not just
                          class-aware. RA objects are class=SERVICE but
                          carry CIDR ranges (/18 pool blocks, /24 connector
                          subnets), not /32 hosts. Previously every RA
                          member was routed through the host-object branch
                          regardless of prefix length, producing
                          misleading "host-x_x_x_x" names on non-host
                          CIDRs. Now routed as cidr-list when the object's
                          SERVICE_ROLE (or OBJECT_CLASS) matches a known RA
                          role, regardless of TIER1 class.
                     The two previously-duplicated _ra_roles inline sets
                     (app-objects ingest + SUBNET_CIDRS block) are
                     consolidated into one normalized helper (is_ra_role())
                     so future RA role checks can't drift out of sync.
                     NOTE: if the diagnostic shows NON_PROD='Y' on RA rows
                     as the actual drop cause, that is a data issue in the
                     upstream builder (build_canonical_app_objects.py) and
                     must be fixed there — this script intentionally does
                     NOT bypass the NON_PROD policy gate.
                     Downstream impact: service_object_catalog_v*.csv and
                     service_objects_v*.set will now include RA objects
                     under NG-SVC-SERVICE with MEMBER_TYPE=cidr-list.
  v1.0.6 2026-07-06  SUBNET_CIDRS handling added for RA pool/connector
                     objects; /32 suffix stripping. (Incomplete — see
                     v1.1.0 above for the fix that actually surfaces them.)
  v1.0.3 2026-06-11  Output written to dated versioned subdir
                     Net_Object/SO-YYYYMMDD_vN/ (same pattern as
                     build_network_groups.py -> Net_Group/NG-YYYYMMDD_vN/).
  v1.0.2 (prior)
=================================
Builds the CCD Platform SERVICE OBJECT CATALOG — the destination side of
PA firewall policy rules. Produces a flat host-list and CIDR-list PAN-OS
address-group hierarchy for use alongside the location-based network groups
produced by build_network_groups.py.

WHAT THIS DOES
--------------
Reads six input sources and emits two outputs:

  service_objects_v*.set       PAN-OS set-format address objects + groups
  service_object_catalog_v*.csv  Tool-agnostic catalog for iplookup + report

SERVICE OBJECT TAXONOMY
-----------------------
  Tier-1              Tier-2 (type)      Tier-3 (named group)         Members
  NG-SVC-APP          APP                SVC_{APP_ACRONYM}            /32 host IPs
  NG-SVC-INFRA        INFRA              SVC_{INFRA_NAME}             /32 host IPs
  NG-SVC-SERVICE      SERVICE            SVC_{SERVICE_NAME}           /32 host IPs
  NG-SVC-DELIVERY     DELIVERY           SVC_{DELIVERY_NAME}          /32 host IPs
  NG-SVC-CPC          CPC                SVC_CPC_{SLUG}               /32 host IPs (from subnet)
  NG-EXT-INFRA        EXT_INFRA          EXT_INFRA_{PROVIDER}_{SVC}   CIDR ranges
  NG-EXT-SVC          EXT_SVC            EXT_SVC_{PROVIDER}_{SVC}     CIDR ranges
  NG-EXT-APP          EXT_APP            EXT_APP_{PROVIDER}_{SVC}     CIDR ranges
  NG-VPN-SVC          VPN                SVC_VPN_{PARTNER}            CIDR ranges (partner side)
  NG-P2P-SVC          P2P                SVC_P2P_{PARTNER}_{SITE}     CIDR ranges (partner side)

INPUT SOURCES
-------------
  canonical_app_objects_v*.csv          OBJECT_TYPE: APP/INFRA/SERVICE/DELIVERY
  ent-ipdataset-CPC-CORE-SERVICES-v*.csv  CPC service subnets
  ext_canonical_objects_v*.csv          OBJECT_TYPE: EXT_INFRA/EXT_SVC/EXT_APP
  ent-ipdataset-VPN-PROTECTED-SUBNETS*  partner-side VPN CIDRs
  ent-ipdataset-P2P-PROTECTED-SUBNETS*  partner-side P2P/MPLS CIDRs

USAGE
-----
  python3 build_service_objects.py                          # auto-discover all inputs
  python3 build_service_objects.py --base ~/Documents/IP_Lookup
  python3 build_service_objects.py --dry-run

Changelog:
  v1.0.0 2026-06-09  Initial build.
"""

import argparse
import csv
csv.field_size_limit(10_000_000)
import ipaddress
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone

__version__ = '1.2.1'
# v1.2.1 2026-07-08  Added RA_CONNECTOR_ZPA as a recognized alias for
#                    RA_CONN_ZPA — build_canonical_app_objects.py v1.9.1's
#                    new RA service-object step emits this label, and the
#                    6 objects were being silently dropped (correctly
#                    flagged by the v1.2.0 unmapped-type audit rather than
#                    lost invisibly). Root naming inconsistency belongs in
#                    build_canonical_app_objects.py; this is the defensive
#                    fix.
SCRIPT_NAME = f'build_service_objects.py v{__version__}'

def write_edl(name, cidrs, edl_dir, metadata=None):
    """Write a PA-compatible EDL .txt file — comment header + one CIDR per line."""
    import ipaddress as _ip
    safe = name.replace('/', '_').replace(' ', '-')
    path = os.path.join(edl_dir, f'{safe}.txt')
    try:
        sorted_cidrs = sorted(cidrs, key=lambda c: _ip.ip_network(c, strict=False))
    except Exception:
        sorted_cidrs = sorted(cidrs)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# {name}\n')
        if metadata:
            for k, v in metadata.items():
                f.write(f'# {k}: {v}\n')
        f.write(f'# Generated by {SCRIPT_NAME}\n')
        f.write(f'# CIDRs: {len(sorted_cidrs)}\n')
        for c in sorted_cidrs:
            f.write(f'{c}\n')


# ---------------------------------------------------------------------------
# File discovery helpers
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    """Return the most recent versioned file matching pattern in directory."""
    import glob
    def _key(p):
        m = re.search(r'v(\d{8})(?:r(\d+))?', os.path.basename(p))
        return (int(m.group(1)), int(m.group(2) or 0)) if m else (0, 0)
    matches = [f for f in glob.glob(os.path.join(directory, pattern))
               if '__MACOSX' not in f]
    return max(matches, key=_key) if matches else None


def discover_inputs(base='.'):
    ipam_dir = os.path.join(base, 'ipam-db')
    proc_dir = os.path.join(base, 'processed_outputs')
    return {
        'app_objects':  _latest(proc_dir,  'canonical_app_objects_v*.csv'),
        # ext_objects excluded — external partner objects not part of canonical build
        'cpc_services': _latest(ipam_dir,  'ent-ipdataset-CPC-CORE-SERVICES-v*.csv'),
        'vpn_subs':     _latest(ipam_dir,  'ent-ipdataset-VPN-PROTECTED-SUBNETS*.csv'),
        'p2p_subs':     _latest(ipam_dir,  'ent-ipdataset-P2P-PROTECTED-SUBNETS*.csv'),
    }


def resolve_input(cli_value, discovered, name, required=False):
    path = cli_value or discovered
    if path and os.path.exists(path):
        src = 'arg' if cli_value else 'auto'
        print(f'  {name:<28} {os.path.basename(path)}  [{src}]')
        return path
    if required:
        print(f'  {name:<28} NOT FOUND', file=sys.stderr)
        sys.exit(1)
    print(f'  {name:<28} not found — skipped')
    return None


def read_stamped_csv(path):
    if not path or not os.path.exists(path):
        return []
    with open(path, newline='', encoding='utf-8-sig', errors='replace') as f:
        lines = [l for l in f if not l.startswith('#')]
    return list(csv.DictReader(lines))


# ---------------------------------------------------------------------------
# Output schema
# ---------------------------------------------------------------------------

CATALOG_FIELDS = [
    'TIER', 'OBJECT_NAME', 'PARENT', 'CLASS', 'OBJECT_CLASS', 'MEMBER_TYPE',
    'VALUE', 'CIDR_COUNT', 'HERITAGE', 'ROUTING_DOMAIN',
    'APP_ACRONYM', 'SERVICE_ROLE', 'SOURCE', 'DATASET_VERSION',
]

# Tier-1 class → group name
TIER1_GROUPS = {
    'APP':       'NG-SVC-APP',
    'INFRA':     'NG-SVC-INFRA',
    'SERVICE':   'NG-SVC-SERVICE',
    'DELIVERY':  'NG-SVC-DELIVERY',
    'CPC':       'NG-SVC-CPC',
    'EXT_INFRA': 'NG-EXT-INFRA',
    'EXT_SVC':   'NG-EXT-SVC',
    'EXT_APP':   'NG-EXT-APP',
    'VPN':       'NG-VPN-SVC',
    'P2P':       'NG-P2P-SVC',
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def clean_name(s):
    """Make a string safe for use in PA object names."""
    return re.sub(r'[^A-Za-z0-9_\-]', '_', (s or '').strip())


def valid_ip(s):
    try:
        ipaddress.IPv4Address(s)
        return True
    except Exception:
        return False


def valid_cidr(s):
    try:
        ipaddress.IPv4Network(s, strict=False)
        return True
    except Exception:
        return False


def addr_obj_name(cidr):
    """Stable PAN-OS address object name for a CIDR."""
    return 'addr-' + cidr.replace('/', '_').replace('.', '_')


def host_obj_name(ip):
    """Stable PAN-OS address object name for a /32 host IP."""
    return 'host-' + ip.replace('.', '_')


# ---------------------------------------------------------------------------
# RA (Remote Access) role handling — v1.1.0
#
# RA objects (ZPA App Connector hosting subnets, CSA client pools, HCB SNAT
# pools) are class=SERVICE but carry CIDR ranges, not /32 hosts. They're
# identified by SERVICE_ROLE (or, defensively, OBJECT_CLASS/OBJECT_TYPE)
# matching one of the known RA role labels below. Comparison is
# case/separator-normalized (upper, '-' -> '_') so "RA-CONN-ZPA" and
# "RA_CONN_ZPA" are treated identically — single source of truth, used by
# both the ingest gate and the output-writer's host-list/cidr-list routing.
# ---------------------------------------------------------------------------

_RA_ROLES_NORM = {
    'RA_CONN_ZPA', 'RA_POOL_CSA', 'RA_SNAT_HCB',
    'RA_GATEWAY_CSA', 'RA_GATEWAY_NTX',
    'RA_CONNECTOR_ZPA',  # v1.2.1 — alias for RA_CONN_ZPA. build_canonical_app_objects.py
                         # v1.9.1's new "[8d/9] Remote Access service objects" step emits
                         # this label instead, caught by the unmapped-type audit rather
                         # than silently dropped. Root fix belongs in
                         # build_canonical_app_objects.py for naming consistency with
                         # the rest of the platform (IPAM NET_TYPE, ipam-db.py taxonomy,
                         # build_user_access_objects.py all use RA-CONN-ZPA/RA_CONN_ZPA) —
                         # this is the defensive fix so the 6 objects aren't lost meanwhile.
}


def _norm_role(s):
    return (s or '').strip().upper().replace('-', '_')


def is_ra_role(*labels):
    """True if any given label (role, obj_class, obj_type, ...) matches a
    known RA role once normalized."""
    return any(_norm_role(lbl) in _RA_ROLES_NORM for lbl in labels)


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

def build(args):
    # Keyed by class → {obj_name: {ips/cidrs, meta}}
    objects = {}  # class → {name → {'members': set, 'meta': dict}}

    def add(obj_class, obj_name, member, meta=None):
        if obj_class not in objects:
            objects[obj_class] = {}
        if obj_name not in objects[obj_class]:
            objects[obj_class][obj_name] = {'members': set(), 'meta': meta or {}}
        objects[obj_class][obj_name]['members'].add(member)
        if meta:
            objects[obj_class][obj_name]['meta'].update(
                {k: v for k, v in meta.items() if v})

    # ── 1. Canonical app objects (APP / INFRA / SERVICE / DELIVERY) ──────────
    if args.app_objects:
        rows = read_stamped_csv(args.app_objects)
        counts = defaultdict(int)
        skipped_type = defaultdict(int)          # v1.2.0 — unmapped-type audit
        skipped_type_examples = defaultdict(list)  # v1.2.0
        skipped_nonprod = 0                         # v1.2.0
        for row in rows:
            obj_name  = (row.get('OBJECT_NAME') or '').strip()
            obj_type  = (row.get('OBJECT_TYPE') or '').strip().upper()
            obj_class = (row.get('OBJECT_CLASS') or obj_type).strip().upper()
            member_ips = (row.get('MEMBER_IPS') or '').strip()
            vip_ips   = (row.get('VIP_IPS') or '').strip()
            heritage  = (row.get('HERITAGE') or '').strip()
            rd        = (row.get('ROUTING_DOMAIN') or '').strip()
            acronym   = (row.get('APP_ACRONYM') or '').strip()
            role      = (row.get('SERVICE_ROLE') or '').strip()
            non_prod  = (row.get('NON_PROD') or '').strip().upper()
            orig_obj_type = obj_type  # v1.2.0 — captured before any remap, for audit reporting

            # v1.1.0 — defensive remap: if OBJECT_TYPE itself is a raw RA
            # role label (upstream wrote the NET_TYPE straight through
            # instead of classifying as SERVICE + SERVICE_ROLE), normalize
            # here so the row isn't silently dropped by the gate below.
            # Original label is preserved as the role if SERVICE_ROLE was
            # blank.
            if obj_type not in ('APP', 'INFRA', 'SERVICE', 'DELIVERY') and is_ra_role(obj_type):
                if not role:
                    role = obj_type
                obj_type = 'SERVICE'

            if not obj_name or obj_type not in ('APP', 'INFRA', 'SERVICE', 'DELIVERY'):
                # v1.2.0 — unmapped-type audit: this is exactly how the RA
                # objects were lost for a full sprint. Any *future* new
                # service class (Citrix VDI, or anything else) that isn't
                # in the RA whitelist and isn't a canonical OBJECT_TYPE
                # lands here — track it so it's visible in the run summary
                # instead of discovered later via a missing-object hunt.
                if obj_name and orig_obj_type:
                    skipped_type[orig_obj_type] += 1
                    if len(skipped_type_examples[orig_obj_type]) < 3:
                        skipped_type_examples[orig_obj_type].append(obj_name)
                continue
            if non_prod == 'Y':
                skipped_nonprod += 1
                continue  # exclude NON_PROD objects from policy groups

            meta = {
                'heritage': heritage, 'routing_domain': rd,
                'app_acronym': acronym, 'service_role': role,
                'obj_class': obj_class,
            }

            # Member /32 host IPs — strip /32 suffix before valid_ip() check
            for ip in (member_ips.split('|') if member_ips else []):
                ip = ip.strip().split('/')[0]
                if ip and valid_ip(ip):
                    add(obj_type, obj_name, f'{ip}/32', meta)
                    counts[obj_type] += 1

            # SUBNET_CIDRS — RA pool/connector objects use CIDR ranges (v1.0.6)
            if is_ra_role(role, obj_class):
                subnet_cidrs = (row.get('SUBNET_CIDRS') or '').strip()
                for cidr in (subnet_cidrs.split('|') if subnet_cidrs else []):
                    cidr = cidr.strip()
                    if cidr and valid_cidr(cidr):
                        add(obj_type, obj_name, cidr, meta)
                        counts[obj_type] += 1

            # VIP IPs (F5 virtual server IPs — also /32 hosts, policy-relevant)
            for ip in (vip_ips.split('|') if vip_ips else []):
                ip = ip.strip()
                if ip and valid_ip(ip):
                    add(obj_type, obj_name, f'{ip}/32', meta)

        for ot, cnt in sorted(counts.items()):
            grp_count = len(objects.get(ot, {}))
            print(f'  {ot:<12} {grp_count:>5} objects  {cnt:>8,} host IPs')

        if skipped_nonprod:
            print(f'  {"[excluded]":<12} {skipped_nonprod:>5,} rows      NON_PROD=Y')

        if skipped_type:
            print()
            print('  \u26a0 UNMAPPED OBJECT_TYPE — rows excluded (not APP/INFRA/SERVICE/DELIVERY,')
            print('    not a recognized RA role either):')
            for ot, cnt in sorted(skipped_type.items(), key=lambda kv: -kv[1]):
                examples = ', '.join(skipped_type_examples[ot])
                more = '' if cnt <= 3 else f' (+{cnt - 3} more)'
                print(f'      {ot:<24} {cnt:>5,} rows   e.g. {examples}{more}')
            print('    -> If this is a new service class (e.g. Citrix VDI), add its label')
            print('       to _RA_ROLES_NORM (or fix OBJECT_TYPE upstream) and re-run.')

    # ── 2. CPC core services ──────────────────────────────────────────────────
    if args.cpc_services:
        rows = read_stamped_csv(args.cpc_services)
        cpc_count = 0
        for row in rows:
            slug   = clean_name(row.get('SERVICE_SLUG') or row.get('SERVICE_NAME') or '')
            subnet = (row.get('CPC_SUBNET') or row.get('CIDR') or '').strip()
            scope  = (row.get('SCOPE') or '').strip()
            ports  = (row.get('PORTS') or '').strip()
            proto  = (row.get('PROTOCOL') or '').strip()
            if not slug or not subnet: continue
            if not valid_cidr(subnet): continue
            obj_name = f'SVC_CPC_{slug}'
            meta = {'service_role': scope, 'app_acronym': slug}
            add('CPC', obj_name, subnet, meta)
            cpc_count += 1
        print(f'  {"CPC":<12} {len(objects.get("CPC", {})):>5} objects  '
              f'{cpc_count:>8,} subnets')

    # ── 3. External canonical objects (EXT_INFRA / EXT_SVC / EXT_APP) ────────
    if args.ext_objects:
        rows = read_stamped_csv(args.ext_objects)
        ext_counts = defaultdict(int)
        for row in rows:
            obj_name  = (row.get('OBJECT_NAME') or '').strip()
            obj_type  = (row.get('OBJECT_TYPE') or '').strip().upper()
            cidrs_raw = (row.get('MEMBER_CIDRS') or '').strip()
            provider  = (row.get('PROVIDER_ABBREV') or row.get('PROVIDER') or '').strip()
            role      = (row.get('SERVICE_ROLE') or '').strip()

            if not obj_name or obj_type not in ('EXT_INFRA', 'EXT_SVC', 'EXT_APP'):
                continue

            meta = {'service_role': role, 'app_acronym': provider}
            for cidr in (cidrs_raw.split('|') if cidrs_raw else []):
                cidr = cidr.strip()
                if cidr and valid_cidr(cidr):
                    add(obj_type, obj_name, cidr, meta)
                    ext_counts[obj_type] += 1

        for ot, cnt in sorted(ext_counts.items()):
            grp_count = len(objects.get(ot, {}))
            print(f'  {ot:<12} {grp_count:>5} objects  {cnt:>8,} CIDRs')

    # ── 4. VPN partner subnets (partner-side only) ────────────────────────────
    if args.vpn_subs:
        rows = read_stamped_csv(args.vpn_subs)
        vpn_count = 0
        for row in rows:
            cidr      = (row.get('IP_NETWORK') or row.get('CIDR') or '').strip()
            partner   = clean_name(row.get('PARTNER_NAME') or '')
            gw_site   = (row.get('gateway_site') or '').strip().upper()
            direction = (row.get('direction') or '').strip().upper()
            if not cidr or not partner: continue
            if not valid_cidr(cidr): continue
            # Only partner-side (REMOTE) — CVS-side already in IPAM location groups
            if direction not in ('REMOTE', 'PARTNER', ''):
                continue
            obj_name = f'SVC_VPN_{partner}'
            meta = {'service_role': gw_site, 'app_acronym': partner}
            add('VPN', obj_name, cidr, meta)
            vpn_count += 1
        print(f'  {"VPN":<12} {len(objects.get("VPN", {})):>5} objects  '
              f'{vpn_count:>8,} CIDRs')

    # ── 5. P2P/MPLS partner subnets (partner-side only) ──────────────────────
    if args.p2p_subs:
        rows = read_stamped_csv(args.p2p_subs)
        p2p_count = 0
        for row in rows:
            cidr      = (row.get('IP_NETWORK') or row.get('CIDR') or '').strip()
            partner   = clean_name(row.get('PARTNER_NAME') or '')
            gw_site   = (row.get('GATEWAY_SITE') or row.get('gateway_site') or '').strip().upper()
            direction = (row.get('DIRECTION') or '').strip().upper()
            link_type = (row.get('LINK_TYPE') or 'Dedicated').strip()
            if not cidr or not partner: continue
            if not valid_cidr(cidr): continue
            # Only partner-side
            if direction not in ('PARTNER', ''):
                continue
            obj_name = f'SVC_P2P_{partner}_{gw_site}'
            meta = {'service_role': f'{link_type}/{gw_site}', 'app_acronym': partner}
            add('P2P', obj_name, cidr, meta)
            p2p_count += 1
        print(f'  {"P2P":<12} {len(objects.get("P2P", {})):>5} objects  '
              f'{p2p_count:>8,} CIDRs')

    print()

    # ── Totals ────────────────────────────────────────────────────────────────
    total_objs = sum(len(v) for v in objects.values())
    total_members = sum(
        len(obj['members'])
        for cls in objects.values()
        for obj in cls.values()
    )
    print(f'Total service objects : {total_objs:,}')
    print(f'Total member entries  : {total_members:,}')
    print()

    if args.dry_run:
        print('[DRY-RUN] No files written.')
        for cls in sorted(objects):
            t1 = TIER1_GROUPS.get(cls, f'NG-{cls}')
            cnt = len(objects[cls])
            members = sum(len(o['members']) for o in objects[cls].values())
            print(f'  {t1:<22} {cnt:>4} objects  {members:>8,} members')
        return

    # ── Determine dataset version ─────────────────────────────────────────────
    today = datetime.now().strftime('%Y%m%d')
    # Derive from newest input file date, but never older than today
    dates = []
    for path in [args.app_objects, args.cpc_services,
                 args.vpn_subs, args.p2p_subs]:
        if path:
            m = re.search(r'v(\d{8})', os.path.basename(path))
            if m:
                dates.append(m.group(1))
    file_date = max(dates) if dates else today
    dataset_version = file_date if file_date >= today else today

    # ── Compute dated versioned output subdir: Net_Object/SO-YYYYMMDD_vN/ ────
    # Same pattern as build_network_groups.py -> Net_Group/NG-YYYYMMDD_vN/
    _so_base = args.out  # e.g. ./Net_Object
    _prefix  = f'SO-{dataset_version}_v'
    _existing = sorted(
        [d for d in (os.listdir(_so_base) if os.path.isdir(_so_base) else [])
         if re.match(rf'^SO-{dataset_version}_v(\d+)$', d)],
        key=lambda d: int(re.search(r'_v(\d+)$', d).group(1))
    )
    _next_n  = (int(re.search(r'_v(\d+)$', _existing[-1]).group(1)) + 1) if _existing else 1
    _so_dir  = os.path.join(_so_base, f'{_prefix}{_next_n}')
    args.out = _so_dir
    os.makedirs(args.out, exist_ok=True)
    print(f'  Versioned dir: {args.out}')

    # ── Write service_objects_v*.set ─────────────────────────────────────────
    set_path = os.path.join(args.out, f'service_objects_v{dataset_version}.set')
    catalog  = []
    source_files = []

    for path in [args.app_objects, args.cpc_services,
                 args.vpn_subs, args.p2p_subs]:
        if path:
            source_files.append(os.path.basename(path))

    with open(set_path, 'w', encoding='utf-8') as f:
        def w(s): f.write(s)

        w(f'# service_objects_v{dataset_version}.set\n')
        w(f'# Generated by {SCRIPT_NAME}\n')
        w(f'# {datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}\n')
        w(f'# Sources: {", ".join(source_files)}\n')
        w(f'#\n')
        w(f'# DESTINATION SIDE of PA policy rules.\n')
        w(f'# Use alongside network_groups_v*.set (source side).\n\n')

        t1_members = defaultdict(set)  # Tier-1 → set of Tier-3 group names

        for cls in sorted(objects):
            t1_name = TIER1_GROUPS.get(cls, f'NG-{cls}')

            w(f'\n# ===== {t1_name} — {cls} objects =====\n')

            for obj_name in sorted(objects[cls]):
                obj_data = objects[cls][obj_name]
                members  = sorted(obj_data['members'])
                meta     = obj_data['meta']
                heritage = meta.get('heritage', '')
                rd       = meta.get('routing_domain', '')
                acronym  = meta.get('app_acronym', '')
                role     = meta.get('service_role', '')

                if not members:
                    continue

                # v1.1.0 — role-aware: RA objects are class=SERVICE but
                # carry CIDR ranges (/18 pool blocks, /24 connector
                # subnets), not /32 hosts. Route by role first, class
                # second, so RA members don't get mangled into fake
                # "host-" names.
                is_host_list = (
                    cls in ('APP', 'INFRA', 'SERVICE', 'DELIVERY', 'CPC')
                    and not is_ra_role(role, meta.get('obj_class', ''))
                )

                # Emit individual address objects
                addr_names = []
                if is_host_list:
                    # /32 host objects
                    for cidr in members:
                        ip = cidr.rstrip('/32').rstrip('/32')
                        if '/' in cidr:
                            ip = cidr.split('/')[0]
                        aname = host_obj_name(ip)
                        w(f'set address {aname} ip-netmask {cidr}\n')
                        addr_names.append(aname)
                else:
                    # CIDR range objects
                    for cidr in members:
                        aname = addr_obj_name(cidr)
                        w(f'set address {aname} ip-netmask {cidr}\n')
                        addr_names.append(aname)

                # Emit address-group for this object
                w(f'set address-group {obj_name} static [ '
                  + ' '.join(addr_names) + ' ]\n')

                t1_members[t1_name].add(obj_name)

                # Catalog row
                catalog.append({
                    'TIER':           3,
                    'OBJECT_NAME':    obj_name,
                    'PARENT':         t1_name,
                    'CLASS':          cls,
                    'OBJECT_CLASS':   meta.get('obj_class', cls),
                    'MEMBER_TYPE':    'host-list' if is_host_list else 'cidr-list',
                    'VALUE':          ';'.join(members),
                    'CIDR_COUNT':     len(members),
                    'HERITAGE':       heritage,
                    'ROUTING_DOMAIN': rd,
                    'APP_ACRONYM':    acronym,
                    'SERVICE_ROLE':   role,
                    'SOURCE':         cls.lower(),
                    'DATASET_VERSION': dataset_version,
                })

        # Tier-1 groups
        w('\n# ===== Tier-1 service class rollups =====\n')
        for t1_name in sorted(t1_members):
            cls = next((k for k, v in TIER1_GROUPS.items() if v == t1_name), '')
            members = sorted(t1_members[t1_name])
            w(f'set address-group {t1_name} static [ '
              + ' '.join(members) + ' ]\n')
            catalog.insert(0, {
                'TIER':           1,
                'OBJECT_NAME':    t1_name,
                'PARENT':         '',
                'CLASS':          cls,
                'MEMBER_TYPE':    'group',
                'VALUE':          ';'.join(members),
                'CIDR_COUNT':     '',
                'HERITAGE':       '',
                'ROUTING_DOMAIN': '',
                'APP_ACRONYM':    '',
                'SERVICE_ROLE':   '',
                'SOURCE':         'derived',
                'DATASET_VERSION': dataset_version,
            })

    print(f'Wrote: {set_path}')

    # ── Write service_object_catalog_v*.csv ───────────────────────────────────
    cat_path = os.path.join(args.out, f'service_object_catalog_v{dataset_version}.csv')
    with open(cat_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM=service_object_catalog\n')
        f.write(f'#VERSION={dataset_version}\n')
        f.write(f'#ROWS={len(catalog)}\n')
        f.write(f'#GENERATOR={SCRIPT_NAME}\n')
        f.write(f'#GENERATED_AT={datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}\n')
        f.write(f'#SOURCE_FILES={",".join(source_files)}\n')
        writer = csv.DictWriter(f, fieldnames=CATALOG_FIELDS,
                                extrasaction='ignore', lineterminator='\n')
        writer.writeheader()
        writer.writerows(catalog)

    print(f'Wrote: {cat_path}  ({len(catalog):,} rows)')

    # ── EDL export ────────────────────────────────────────────────────────────
    edl_count = 0
    edl_dir   = None
    if getattr(args, 'edl', False):
        edl_dir = os.path.join(args.out, 'EDL')
        os.makedirs(edl_dir, exist_ok=True)

        # Tier-1 EDLs — all CIDRs rolled up under each class
        t1_cidrs = defaultdict(set)
        for row in catalog:
            if row['TIER'] == 3 and row.get('VALUE'):
                t1 = row.get('PARENT', '')
                for c in row['VALUE'].split(';'):
                    if c:
                        t1_cidrs[t1].add(c)

        for t1_name, cidrs in sorted(t1_cidrs.items()):
            if cidrs:
                write_edl(t1_name, cidrs, edl_dir, metadata={'Tier': '1'})
                edl_count += 1

        # Tier-3 EDLs — one per service object
        for row in catalog:
            if row['TIER'] == 3 and row.get('VALUE'):
                cidrs = [c for c in row['VALUE'].split(';') if c]
                if cidrs:
                    write_edl(row['OBJECT_NAME'], cidrs, edl_dir,
                              metadata={'Tier': '3', 'Class': row.get('CLASS','')})
                    edl_count += 1

        print(f'EDL export: {edl_count} files written to {edl_dir}/')

    print()
    print('Next steps:')
    print(f'  python3 build_svc_report.py --catalog {cat_path}')
    print(f'  # Load {set_path} alongside network_groups_v*.set in Panorama')


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description='Build CCD Platform service object catalog — '
                    'destination side of PA firewall policy rules.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument('--base', default='.',
                    help='CCD Platform root directory for auto-discovery (default: .)')
    ap.add_argument('--app-objects', default=None,
                    help='canonical_app_objects_v*.csv (auto-discovered if omitted)')
    ap.add_argument('--cpc-services', default=None,
                    help='ent-ipdataset-CPC-CORE-SERVICES-v*.csv (auto-discovered)')
    ap.add_argument('--vpn-subs', default=None,
                    help='ent-ipdataset-VPN-PROTECTED-SUBNETS*.csv (auto-discovered)')
    ap.add_argument('--p2p-subs', default=None,
                    help='ent-ipdataset-P2P-PROTECTED-SUBNETS*.csv (auto-discovered)')
    ap.add_argument('--out', default='./Net_Object',
                    help='Output directory (default: ./network-groups)')
    ap.add_argument('--dry-run', action='store_true',
                    help='Print counts without writing files')
    ap.add_argument('--edl', action='store_true', default=False,
                        help='Export EDL .txt files (one per Tier-1 class + one per service object) into EDL/ subdir of --out')
    ap.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    args = ap.parse_args()

    print(f'\n{SCRIPT_NAME}')
    print(f'  Base dir : {args.base}')
    print(f'  Out dir  : {args.out}')
    print(f'  Dry run  : {args.dry_run}')
    print()

    disc = discover_inputs(args.base)
    print('Input files:')
    args.app_objects  = resolve_input(args.app_objects,  disc['app_objects'],  'canonical_app_objects')
    args.ext_objects  = None  # excluded — external partner objects not part of canonical build
    args.cpc_services = resolve_input(args.cpc_services, disc['cpc_services'], 'cpc_core_services')
    args.vpn_subs     = resolve_input(args.vpn_subs,     disc['vpn_subs'],     'vpn_protected_subnets')
    args.p2p_subs     = resolve_input(args.p2p_subs,     disc['p2p_subs'],     'p2p_protected_subnets')
    print()

    build(args)


if __name__ == '__main__':
    main()
