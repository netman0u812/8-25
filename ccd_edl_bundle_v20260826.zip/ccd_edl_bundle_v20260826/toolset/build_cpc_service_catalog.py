#!/usr/bin/env python3
"""
build_cpc_service_catalog.py  v1.2.1
CCD Platform — CPC Service Catalog Builder
CVS Health Information Security

Derives a complete, normalized CPC service catalog from all available source
data. Replaces the manual/piecemeal assembly process that produced the current
ent-ipdataset-CPC-CORE-SERVICES.

Changelog:
  v1.1.0 2026-05-28  Per-domain AD service model. DOMAIN_HERITAGE_MAP replaced
                     with DOMAIN_SLUG_MAP — 46 domains, each generating a distinct
                     SERVICE/SERVICE_SLUG. _dc_record() derives slug from domain
                     FQDN. SVC_AD_* objects now 1:1 with AD domain boundaries.
  v1.2.0 2026-05-28  Initial build tool.

Sources consumed (all optional — script works with whatever is present):
  1. cpc_infra_services_v1_0.csv       — legacy v1.0 pipe-delimited IP records
  2. ent-ipdataset-CPC-CORE-SERVICES   — current expanded per-IP registry
  3. CPC Master Security Template xlsx — Foundation, hCVS, HCB sheets
  4. NW & FW Review xlsx               — NW & FW Requirements sheet

Outputs:
  ent-ipdataset-CPC-CORE-SERVICES-vDATE.csv        — normalized internal services
  ent-ipdataset-CPC-EXT-CANDIDATES-vDATE.csv       — external service candidates
                                                      for ext_canonical_objects
  cpc_catalog_gap_report_vDATE.csv                 — services with open questions,
                                                      no IPs, or no port profiles

Usage:
    python3 build_cpc_service_catalog.py \\
        --legacy-csv    ./cpc_infra_services_v1_0.csv \\
        --core-services ./ipam-db/ent-ipdataset-CPC-CORE-SERVICES-v20260526.csv \\
        --cpc-template  "./CPC-Services_Hosts/CPC Master Security Template v01ac.xlsx" \\
        --flows-xlsx    "./CPC-Services_Hosts/Network flows for foundational services - NW & FW Review.xlsx" \\
        --ipam-dir      ./ipam-db \\
        --out-dir       ./processed_outputs \\
        --dry-run

    # Minimal — existing CPC-CORE-SERVICES only (normalize + gap report)
    python3 build_cpc_service_catalog.py \\
        --core-services ./ipam-db/ent-ipdataset-CPC-CORE-SERVICES-v20260526.csv \\
        --out-dir ./processed_outputs

Changelog:
    v1.2.1  2026-06-15  ROLLUP_AGGREGATES trimmed to 5 CPC-sourced rollups.
                        EHM-sourced rollups (13 objects: IBM MQ, IIB/ACE,
                        Guardium, SCOM, Splunk, SCCM, ZIA Proxy, Tidal,
                        AppDynamics, Kafka, Venafi, DataPower, vCenter)
                        moved to build_canonical_app_objects.py step [8c/9]
                        where source SVC_* objects already exist.
    v1.2.0  2026-06-15  18 enterprise rollup aggregates (SVC_*_ALL) built in
                        step [3b]. Includes SVC_AD_ALL_ENTERPRISE, SVC_KERBEROS_ALL
                        (derived from AD DC fleet), and 16 per-service rollups.
                        KNOWN_GAPS registry: DNS/Infoblox gap, SMTP HCB gap,
                        legacy bare object deprecation queue.
    v1.1.6  2026-06-03  Add normalized name aliases to SERVICE_NORM so existing
                        CPC display names ('Tivoli ITM', 'CloudBees CI', 'Red Hat
                        Satellite 6', 'OBM', etc.) map to the same canonical slug
                        as the template raw names ('ITM', 'Cloudbees', 'SAT6',
                        'OBM PROD'), eliminating duplicate slug entries in output.
    v1.1.5  2026-06-03  Normalise SERVICE name in build_cpc_row() using
                        _SLUG_TO_CANONICAL reverse map so rows from different
                        sources sharing the same slug (e.g. 'ITM' vs 'Tivoli
                        ITM') all emit the same canonical SERVICE name, fixing
                        duplicate service names in the count display.
    v1.1.4  2026-06-03  Fix VIP duplicate rows: parse_existing_core_services()
                        now reclassifies 'domain.name VIP' entries to ad-*-vip
                        slug so they go into seen_ad_ips and dedup on IP alone,
                        matching parse_ad_xlsx() VIP output.
    v1.1.3  2026-06-03  Fix double-entry on CPC rebuild with --core-services:
                        - parse_existing_core_services() now reclassifies AD
                          domain entries (SERVICE=domain.name) to use ad-* slug
                          convention, matching parse_ad_xlsx() output so dedup
                          consolidates them instead of creating duplicates.
                        - domain_to_slug() strips leading 'ad.' subdomain to
                          prevent ad-ad-meritain double-prefix on ad.meritain.com.
    v1.1.2  2026-06-03  _resolve_loc rewritten to scan all hyphen-delimited
                        hostname tokens rather than only the prefix. Replaces
                        _HOSTNAME_PREFIX_LOC with _SITE_TOKEN_LOC. Fixes
                        MER-CO-DC1 (LV token at pos 2), PDCH-LV-DC01 (LV at
                        pos 2), MVME-AETDMZ900 (MVME at pos 1), HVCTHEHT01
                        (no delimiter). All 49 no-location rows now resolve.
    v1.1.1  2026-06-03  Hostname prefix and domain coverage fixes:
                        - _HOSTNAME_PREFIX_LOC expanded: MVME/MIDE→Middletown,
                          WINE→Windsor, HVC→Hartford, PAZ/MAZ→Scottsdale,
                          RRI→RI-One, LGS→Las Vegas Switch COLO.
                          Resolves all 49 no-location rows in gap analysis.
                        - ent.cvshealth.com added to DOMAIN_HERITAGE_MAP (CVS/PROD)
                          for LGSP-CVSH-900/901 DCs at Las Vegas Switch COLO.
    v1.1.0  2026-06-03  Heritage and location fixes:
                        - AETNA_DOMAIN_SUFFIXES expanded to include all affiliate
                          domains: Meritain, Cofinity, pdchs/pdcss/ppom/resource/
                          xauth/xtest, aetdmz, healthehost, ahm/ahmdmz.
                        - Replaced UNKNOWN heritage fallback with domain_heritage_env()
                          so all 332 previously UNKNOWN AD rows now emit correct
                          HCB or CVS heritage.
                        - Added _resolve_loc() helper: affiliate/PDC domains always
                          get Loc:LV-COLO; Loc:PDC on aeth.aetna.com stays Phoenix;
                          blank dc_loc derives location from hostname prefix
                          (MID→Middletown, WIN→Windsor, HFD/HLB→Hartford etc.).
                        - Secondary source NOTES normalised to Loc: format (was Site:).
    v1.0.1  2026-05-28  Add --ad-dir and --qualys-dir: parse AD DC XLSX
                        files (primary/secondary/tertiary three-pass with
                        dedup) and Qualys scanner XLSX files. Ports the
                        tested extraction logic from generate_cpc_supplement.py.
    v1.0.0  2026-05-28  Initial build. Parses all known source formats,
                        applies canonical service normalization, classifies
                        internal vs external services, deduplicates per-IP,
                        outputs split catalog + gap report.
"""

import argparse
import csv
import ipaddress
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_VERSION      = '1.2.3'
# v1.2.3 2026-08-04 Real gap fixed: this script wrote both real
#        ent-ipdataset outputs (CPC-CORE-SERVICES and CPC-EXT-
#        CANDIDATES) then just printed '✓ Done' -- no next-step
#        guidance at all, unlike every other build_*.py script in this
#        pipeline. Confirmed real: CPC-EXT-CANDIDATES had been rebuilt
#        roughly weekly since May and never once promoted to live --
#        plausibly connected to nothing ever telling the user the real
#        import command. Now prints both, using the same --type
#        derivation (ent_cpc_core_services / ent_cpc_ext_candidates)
#        already confirmed correct against a real ipam-db.py import
#        this session for the EXT-CANDIDATES side.
# v1.2.2 2026-06-19 --extra-rows CSV added: accepts one or more CSV files
#        containing pre-formatted CPC-CORE-SERVICES rows to merge in before
#        deduplication. Enables adding CI/CD infrastructure subnets, partner
#        connectivity entries, and other service records without touching the
#        raw CPC source files. Usage: --extra-rows path/to/patch.csv
#        --dry-run argument added to argparse (logic was present but arg was
#        missing, causing unrecognized argument error).
DEFAULT_CPC_RAW_DIR = os.path.join('IP_Datasets_Raw', 'CPC-Raw_Data_Files')
BUILD_DATE = datetime.now().strftime('%Y%m%d')

try:
    import openpyxl
except ImportError:
    print('ERROR: openpyxl required — pip install openpyxl --break-system-packages')
    sys.exit(1)

# ---------------------------------------------------------------------------
# Output schema (matches existing CPC-CORE-SERVICES exactly)
# ---------------------------------------------------------------------------
CPC_FIELDNAMES = [
    'IP_NETWORK', 'IP_DATASET_CLASS', 'SERVICE_TYPE_CODE', 'SERVICE_TYPE_LABEL',
    'PROVIDER', 'PARTNER_NAME', 'SERVICE', 'HERITAGE', 'FQDN', 'PORTS',
    'REGION', 'IP_AUTHORITY', 'DESCRIPTION', 'SOURCE_REF', 'IKE_VERSION',
    'CIPHER', 'PFS_GROUP', 'WEAK_CIPHER', 'GATEWAY', 'PEER_IP',
    'IMPORT_SOURCE', 'IMPORTED_AT', 'IP_ADDRESS', 'CIDR', 'SERVICE_SLUG',
    'SCOPE', 'SERVER_NAME', 'PROTOCOL', 'NOTES', 'DATASET_VERSION',
]

EXT_FIELDNAMES = [
    'SERVICE_NAME', 'SERVICE_SLUG', 'SERVICE_TYPE', 'ENDPOINT',
    'ENDPOINT_TYPE', 'PORTS', 'PROTOCOL', 'HERITAGE', 'NOTES',
    'SOURCE_REF', 'DATASET_VERSION',
]

GAP_FIELDNAMES = [
    'SERVICE_NAME', 'SERVICE_SLUG', 'ISSUE', 'DETAIL', 'SOURCE',
]

# ---------------------------------------------------------------------------
# Canonical service normalization map
#
# Maps every raw SERVICE name variant found across all sources to a canonical
# (SERVICE_NAME, SERVICE_SLUG, CLASSIFICATION) triple.
#
# CLASSIFICATION values:
#   INTERNAL    — server IPs are on the enterprise network → CPC-CORE-SERVICES
#   EXTERNAL    — SaaS/cloud endpoint reached via proxy → ext_canonical_objects
#   DELIVERY    — CIDR-type delivery infrastructure (GitHub runners, GKE CAP)
#   FLOW        — describes a flow direction, not a distinct service; deduplicate
#                 into the named service's CORE-SERVICES entry
# ---------------------------------------------------------------------------
SERVICE_NORM = {
    # Active Directory — normalise all variants
    'Active Directory':          ('Active Directory', 'active-directory', 'INTERNAL'),
    'Active Directory (NONPROD)':('Active Directory', 'active-directory-nonprod', 'INTERNAL'),
    'Active Directory VIP':      ('Active Directory VIP', 'active-directory-vip', 'INTERNAL'),

    # Qualys — two distinct products
    'Qualys':                    ('Qualys Scanner', 'qualys-scanner', 'INTERNAL'),
    'Qulays Integration':        ('Qualys Scanner', 'qualys-scanner', 'INTERNAL'),   # typo fix
    'LINUX servers to Qulays agents': ('Qualys Cloud Agent', 'qualys-cloud-agent', 'EXTERNAL'),

    # Centrify
    'CENTRIFY':                  ('Centrify', 'centrify', 'INTERNAL'),
    'Centrify':                  ('Centrify', 'centrify', 'INTERNAL'),

    # NTP
    'NTP':                       ('NTP', 'ntp', 'INTERNAL'),

    # Splunk
    'SPLUNK':                    ('Splunk', 'splunk', 'INTERNAL'),

    # AD Ops tools
    'UCMDB':                     ('UCMDB', 'ucmdb', 'INTERNAL'),
    'ITM':                       ('Tivoli ITM', 'itm', 'INTERNAL'),
    'OBM PROD':                  ('OBM', 'obm-prod', 'INTERNAL'),
    'OBM NON-PROD':              ('OBM', 'obm-nonprod', 'INTERNAL'),
    'SITESCOPE':                 ('SiteScope', 'sitescope', 'INTERNAL'),
    'Netcool':                   ('Netcool', 'netcool', 'INTERNAL'),
    'Lpar2rrd':                  ('LPAR2RRD', 'lpar2rrd', 'INTERNAL'),

    # Config management
    'Ansible':                   ('Ansible', 'ansible', 'INTERNAL'),
    'CHEF':                      ('Chef', 'chef', 'INTERNAL'),
    'SAT6':                      ('Red Hat Satellite 6', 'satellite6', 'INTERNAL'),
    'SATTELLITE':                ('Red Hat Satellite 6', 'satellite6', 'INTERNAL'),  # typo fix
    'Bootstrap Nexus':           ('Nexus Repository', 'nexus', 'INTERNAL'),
    'Bootstrap':                 ('Nexus Repository', 'nexus', 'INTERNAL'),
    'repo-man-nexus':            ('Nexus Repository', 'nexus', 'INTERNAL'),

    # CI/CD
    'Cloudbees/Jenkins':         ('CloudBees CI', 'cloudbees', 'INTERNAL'),
    'Cloudbees':                 ('CloudBees CI', 'cloudbees', 'INTERNAL'),
    'GitHub Action Runners Azure':('GitHub Action Runners', 'gh-runners', 'DELIVERY'),
    'GitHub Action Runners GCP': ('GitHub Action Runners', 'gh-runners', 'DELIVERY'),
    'Github Automation (Linux to Github)': ('GitHub.com', 'github-com', 'EXTERNAL'),

    # Access / identity
    'IAM':                       ('IAM', 'iam', 'INTERNAL'),
    'Beyond Trust':              ('BeyondTrust', 'beyondtrust', 'INTERNAL'),
    'JUMP Servers':              ('Jump Servers', 'jump', 'INTERNAL'),
    'Rear & Linux Jump':         ('REAR / Linux Jump', 'rear-jump', 'INTERNAL'),

    # Security tooling
    'CROWDSTRIKE':               ('CrowdStrike Falcon', 'crowdstrike', 'EXTERNAL'),
    'Crowdstrike':               ('CrowdStrike Falcon', 'crowdstrike', 'EXTERNAL'),
    'BigFix':                    ('BigFix', 'bigfix', 'INTERNAL'),
    'FIM':                       ('FIM', 'fim', 'INTERNAL'),

    # Infra ops
    'Linux Admin':               ('Linux Admin', 'linux-admin', 'INTERNAL'),
    'KDUMP':                     ('KDUMP', 'kdump', 'INTERNAL'),
    'Rear/KDUMP':                ('KDUMP', 'kdump', 'INTERNAL'),
    'CAP Infrastructure':        ('CAP Infrastructure', 'cap-infra', 'DELIVERY'),

    # Misc
    'DNS':                       ('DNS', 'dns', 'INTERNAL'),
    'SYSLOG ':                   ('Syslog', 'syslog', 'INTERNAL'),
    'SYSLOG':                    ('Syslog', 'syslog', 'INTERNAL'),
    'NiFi':                      ('Apache NiFi', 'nifi', 'INTERNAL'),
    'LINUX servers to NiFi Servers\n(Submit CVS firewall too)': ('Apache NiFi', 'nifi', 'FLOW'),
    'PPDM(GCP)':                 ('Dell PPDM', 'ppdm', 'INTERNAL'),

    # Normalized name aliases — existing CPC files store the canonical display
    # name (e.g. 'Tivoli ITM') rather than the raw template name ('ITM').
    # These aliases ensure parse_existing_core_services() maps them to the
    # same slug as the template raw names, preventing duplicate slug entries.
    'Tivoli ITM':            ('Tivoli ITM', 'itm', 'INTERNAL'),
    'OBM':                   ('OBM', 'obm-prod', 'INTERNAL'),
    'SiteScope':             ('SiteScope', 'sitescope', 'INTERNAL'),
    'CloudBees CI':          ('CloudBees CI', 'cloudbees', 'INTERNAL'),
    'Red Hat Satellite 6':   ('Red Hat Satellite 6', 'satellite6', 'INTERNAL'),
    'REAR / Linux Jump':     ('REAR / Linux Jump', 'rear-jump', 'INTERNAL'),
    'Jump Servers':          ('Jump Servers', 'jump', 'INTERNAL'),
    'Nexus Repository':      ('Nexus Repository', 'nexus', 'INTERNAL'),
    'Qualys Scanner':        ('Qualys Scanner', 'qualys-scanner', 'INTERNAL'),
    'Apache NiFi':           ('Apache NiFi', 'nifi', 'INTERNAL'),
    'Dell PPDM':             ('Dell PPDM', 'ppdm', 'INTERNAL'),
    'CrowdStrike Falcon':    ('CrowdStrike Falcon', 'crowdstrike', 'EXTERNAL'),
    'GitHub Action Runners': ('GitHub Action Runners', 'gh-runners', 'DELIVERY'),
    'BeyondTrust':           ('BeyondTrust', 'beyondtrust', 'INTERNAL'),
    'LINUX servers to NiFi Servers': ('Apache NiFi', 'nifi', 'FLOW'),
    'LINUX servers to Qulays agents':('Qualys Cloud Agent', 'qualys-cloud-agent', 'EXTERNAL'),
}

# Reverse map: slug → canonical service name (built from SERVICE_NORM)
# Used in build_cpc_row() to normalise SERVICE field regardless of source.
_SLUG_TO_CANONICAL = {v[1]: v[0] for v in SERVICE_NORM.values() if v[1]}

# Service type labels for SERVICE_TYPE_LABEL column
SERVICE_TYPE_LABELS = {
    'active-directory':       'Directory Services',
    'active-directory-nonprod': 'Directory Services',
    'active-directory-vip':   'Directory Services',
    'centrify':               'Identity / PAM',
    'qualys-scanner':         'Vulnerability Management',
    'qualys-cloud-agent':     'Vulnerability Management',
    'ntp':                    'Time Services',
    'splunk':                 'SIEM / Logging',
    'ucmdb':                  'CMDB / Discovery',
    'itm':                    'Infrastructure Monitoring',
    'obm-prod':               'Operations Bridge',
    'obm-nonprod':            'Operations Bridge',
    'sitescope':              'Infrastructure Monitoring',
    'netcool':                'Network Event Management',
    'lpar2rrd':               'Capacity Management',
    'ansible':                'Configuration Management',
    'chef':                   'Configuration Management',
    'satellite6':             'Patch Management',
    'nexus':                  'Artifact Repository',
    'cloudbees':              'CI/CD',
    'gh-runners':             'CI/CD',
    'github-com':             'Source Control (External)',
    'iam':                    'Identity Management',
    'beyondtrust':            'Privileged Access Management',
    'jump':                   'Secure Access / Jump',
    'rear-jump':              'Backup / Secure Access',
    'crowdstrike':            'Endpoint Detection & Response',
    'bigfix':                 'Endpoint Management',
    'fim':                    'File Integrity Monitoring',
    'linux-admin':            'Infrastructure Administration',
    'kdump':                  'Crash Diagnostics',
    'cap-infra':              'Cloud Platform Infrastructure',
    'dns':                    'DNS Services',
    'syslog':                 'Logging / SIEM',
    'nifi':                   'Data Integration',
    'ppdm':                   'Data Protection',
}

# Domain → SERVICE_SLUG and SVC_* name — derived from domain FQDN
# No lookup table — any domain in the source data gets a slug automatically.
import re as _re

def domain_to_slug(domain):
    """corp.cvscaremark.com → ad-corp-cvscaremark
    ad.meritain.com → ad-meritain  (strip leading 'ad.' to avoid ad-ad- prefix)
    """
    d = domain.lower().strip()
    d = _re.sub(r'\.(com|net|local|info|corp|ltd|org)$', '', d)
    # Strip leading 'ad.' subdomain to avoid double ad-ad- prefix
    if d.startswith('ad.'):
        d = d[3:]
    d = d.replace('.', '-')
    return f'ad-{d}'

def domain_from_fqdn(fqdn):
    """Derive domain from FQDN: LGSP-ENT-900.ent.cvshealth.com → ent.cvshealth.com"""
    if not fqdn: return ''
    parts = str(fqdn).strip().split('.')
    return '.'.join(parts[1:]) if len(parts) >= 2 else ''

def slug_to_svc(slug):
    """ad-corp-cvscaremark → SVC_AD_CORP_CVSCAREMARK"""
    return 'SVC_' + slug.replace('-', '_').upper()

# Heritage: Middletown (MDC) or Windsor (WDC) hosted → HCB, everything else → CVS
AETNA_DOMAIN_SUFFIXES = (
    # Core Aetna domains
    '.aetna.com', '.aetnat.com', '.aetnaq.com', '.aetnae.com',
    '.aetnaet.com', '.aetnaeq.com',
    # Aetna internal / HCB-hosted domains
    'ahm.corp', 'ahmdmz.corp',
    'aetdmz.com', 'aetdmzq.com', 'aetdmzt.com',
    'healthehost.com', 'healthehostt.com', 'healthds.com',
    # Aetna affiliates (historically Phoenix PDC, now Las Vegas Switch COLO)
    '.meritain.com', 'ad.meritain.com', 'dmz.meritain.com',
    'cust.meritain.com', 'custtest.cust.meritain.com',
    '.cofinity.net', 'xauth.cofinity.net', 'xtest.cofinity.net',
    'ppom.info', 'resource.info',
    'pdchs.local', 'pdcss.local', 'pdc-dmz.local',
)

def domain_heritage(domain):
    """Derive heritage from domain name — Aetna-managed domains → HCB, else CVS."""
    d = domain.lower().strip()
    if any(d == s.lstrip('.') or d.endswith(s) for s in AETNA_DOMAIN_SUFFIXES):
        return 'HCB'
    return 'CVS'

# Keep DOMAIN_HERITAGE_MAP as thin shim for ENV only
DOMAIN_HERITAGE_MAP = {d: (domain_heritage(d), v) for d, v in {
    'test.cvscaremark.com': 'NONPROD', 'coe.caremarkrx.net': 'NONPROD',
    'healthehostt.com': 'NONPROD',
    'aett.aetnat.com': 'NONPROD', 'aethQ.aetnaq.com': 'NONPROD',
    'aethEQ.aetnaeq.com': 'NONPROD', 'aethET.aetnaet.com': 'NONPROD',
    'aetDMZQ.com': 'NONPROD', 'aetDMZT.com': 'NONPROD',
    'aetnaEQ.com': 'NONPROD', 'aetnaET.com': 'NONPROD',
    'aetnaQ.com': 'NONPROD', 'aetnaT.com': 'NONPROD',
    'aetnsdq.aethq.aetnaq.com': 'NONPROD', 'aetnsdt.aett.aetnat.com': 'NONPROD',
    'xtest.cofinity.net': 'NONPROD', 'custtest.cust.meritain.com': 'NONPROD',
    'ent.cvshealth.com': 'PROD',   # CVS Health enterprise domain — new DCs at LGS
}.items()}
# All other domains default to PROD

def domain_heritage_env(domain):
    """Return (heritage, env) for a domain — used as the fallback for
    DOMAIN_HERITAGE_MAP.get() so we never emit UNKNOWN heritage.
    Heritage is derived from AETNA_DOMAIN_SUFFIXES; env defaults to PROD."""
    return (domain_heritage(domain or ''), 'PROD')



# ---------------------------------------------------------------------------
# Standard port profiles
# ---------------------------------------------------------------------------
AD_PORTS     = "88,123,135,137,138,139,389,445,464,636,3268,3269,3389,49152-65535"
AD_PROTOCOL  = "TCP | UDP"


# ---------------------------------------------------------------------------
# Enterprise rollup aggregates  (defined after AD_PORTS / AD_PROTOCOL)
# ---------------------------------------------------------------------------
ROLLUP_AGGREGATES = [
    # CPC-sourced rollups only — services whose authoritative source is the
    # CPC template, AD xlsx, or Qualys xlsx.
    # EHM-sourced rollups (IBM MQ, IIB/ACE, Guardium, SCOM, Splunk, SCCM,
    # ZIA Proxy, Tidal, AppDynamics, Kafka, Venafi, DataPower, vCenter) are
    # built in build_canonical_app_objects.py step [8c/9] where the source
    # SVC_* objects already exist.

    # AD DC fleet — prefix match covers all per-domain slugs automatically
    ('svc-ad-all-enterprise',   'SVC_AD_ALL_ENTERPRISE',
     'Directory Services',       AD_PORTS, AD_PROTOCOL,
     'MIXED', 'Enterprise',      'ad-', 'prefix'),

    # Kerberos — same DC IP set as AD, different ports (TCP/UDP 88,464)
    ('svc-kerberos-all',        'SVC_KERBEROS_ALL',
     'Kerberos / Authentication','88,464', 'TCP | UDP',
     'MIXED', 'Enterprise',      'ad-', 'prefix'),

    # Qualys scanners — CPC template + Qualys xlsx source
    ('svc-qualys-all',          'SVC_QUALYS_ALL',
     'Vulnerability Management', '443,8443', 'HTTPS',
     'MIXED', 'Enterprise',
     ['qualys-scanner', 'qualys-scanner-cvs', 'qualys-scanner-hcb'], 'exact'),

    # NTP — Foundation sheet source
    ('svc-ntp-all',             'SVC_NTP_ALL',
     'Time Services',            '123', 'UDP',
     'MIXED', 'Enterprise',
     ['ntp', 'ntp-cvs', 'ntp-hcb'], 'exact'),

    # Jump servers — CPC template source
    ('svc-jump-all',            'SVC_JUMP_ALL',
     'Secure Access / Jump',     '22,3389', 'TCP',
     'MIXED', 'Enterprise',
     ['jump', 'jump-cvs', 'jump-hcb'], 'exact'),
]

KNOWN_GAPS = [
    {
        'SERVICE_NAME': 'SVC_DNS_ALL_ENTERPRISE',
        'SERVICE_SLUG': 'svc-dns-all-enterprise',
        'ISSUE':        'KNOWN_GAP_INFOBLOX_MISSING',
        'DETAIL': (
            'DNS resolver fleet (Infoblox grid) not in CPC catalog. '
            'Action: obtain Infoblox primary/secondary/anycast VIPs from '
            'network team and add to CPC Master Security Template Foundation '
            'sheet. Known partial: 10.20.255.20 (RI2100 transitional HA), '
            '10.217.144.215 (Shea transitional HA), '
            '10.159.67.192/28 (Azure resolver subnet — in IPAM, not in catalog). '
            '294 AD DCs run DNS and are covered by SVC_AD_ALL_ENTERPRISE. '
            'Infoblox grid IPs are enterprise resolver VIPs and are MISSING. '
            'P1 — must resolve before Cloud and PCI firewall policy build.'
        ),
        'SOURCE': 'known-gap-registry',
    },
    {
        'SERVICE_NAME': 'SVC_SMTP_HCB',
        'SERVICE_SLUG': 'svc-smtp-hcb',
        'ISSUE':        'KNOWN_GAP_SMTP_HCB_MISSING',
        'DETAIL': (
            'SVC_SMTP_CVS has 140 IPs. No SVC_SMTP_HCB exists. '
            'Verify: do Aetna/HCB mail relays route through CVS mail '
            'post-merger, or does a separate HCB SMTP relay fleet exist? '
            'If separate fleet exists, add to CPC Template HCB sheet. '
            'Required before SVC_SMTP_ALL rollup can be built.'
        ),
        'SOURCE': 'known-gap-registry',
    },
    {
        'SERVICE_NAME': 'Legacy bare service objects — deprecation queue',
        'SERVICE_SLUG': 'deprecation-queue',
        'ISSUE':        'DEPRECATION_QUEUE',
        'DETAIL': (
            'Pre-merger bare objects (no heritage suffix) should be deprecated '
            'once _ALL rollups are deployed and Panorama policy references updated: '
            'SVC_IBM_MQ, SVC_IIB_ACE, SVC_SCOM, SVC_SPLUNK, SVC_NTP, SVC_KAFKA, '
            'SVC_INFORMATICA, SVC_JAMF, SVC_NEXUS, SVC_DATAPOWER. '
            'Do not delete until policy references are verified clean.'
        ),
        'SOURCE': 'known-gap-registry',
    },
]
QUALYS_PORTS = "443,8443"
QUALYS_PROTOCOL = "HTTPS"

def now_utc():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def normalize_ip(raw):
    """Parse IP string, return clean IP or None."""
    if not raw:
        return None
    raw = raw.strip().split('/')[0].strip()
    try:
        return str(ipaddress.ip_address(raw))
    except ValueError:
        return None


def heritage_from_fqdn(fqdn):
    if not fqdn:
        return ''
    # Extract domain from FQDN and derive heritage
    parts = fqdn.strip().lower().split('.')
    for i in range(len(parts)):
        candidate = '.'.join(parts[i:])
        if candidate in DOMAIN_HERITAGE_MAP:
            return DOMAIN_HERITAGE_MAP[candidate][0]
    return domain_heritage(fqdn)


def heritage_from_ip(ip_str):
    """Infer heritage from IP address — rough heuristic."""
    if not ip_str:
        return ''
    try:
        ip = ipaddress.ip_address(ip_str)
        # 167.69.x.x and 157.121.x.x are Aetna/HCB public BGP space
        if ip in ipaddress.ip_network('167.69.0.0/16') or \
           ip in ipaddress.ip_network('157.121.0.0/16'):
            return 'HCB'
        # 204.99.x.x is CVS public BGP space
        if ip in ipaddress.ip_network('204.99.0.0/16'):
            return 'CVS'
    except ValueError:
        pass
    return ''


def normalize_service(raw_name):
    """Return (canonical_name, slug, classification) from raw service name."""
    if not raw_name:
        return None, None, None
    raw_name = raw_name.strip()
    if raw_name in SERVICE_NORM:
        return SERVICE_NORM[raw_name]
    # Fallback: slugify the raw name
    slug = re.sub(r'[^a-z0-9]+', '-', raw_name.lower()).strip('-')
    return raw_name, slug, 'INTERNAL'


def blank_row(timestamp, dataset_version):
    return {f: '' for f in CPC_FIELDNAMES} | {
        'IP_DATASET_CLASS': 'ENTERPRISE',
        'SOURCE_REF':       'CPC-Security-Template',
        'IMPORTED_AT':      timestamp,
        'DATASET_VERSION':  dataset_version,
    }


# ---------------------------------------------------------------------------
# Source parsers
# ---------------------------------------------------------------------------


def discover_cpc_files(cpc_raw_dir):
    """Auto-discover all CPC source files under cpc_raw_dir by glob pattern.
    Returns dict: cpc_template, flows_xlsx, ad_dir, qualys_dir, legacy_csv.
    ad_dir / qualys_dir are the directory containing the matched files
    (may be cpc_raw_dir itself when all files are flat).
    """
    import glob as _g

    def _find(*patterns):
        for pat in patterns:
            hits = (_g.glob(os.path.join(cpc_raw_dir, '**', pat), recursive=True) +
                    _g.glob(os.path.join(cpc_raw_dir, pat)))
            hits = [h for h in hits
                    if '__MACOSX' not in h and not os.path.basename(h).startswith('.')]
            if hits:
                return max(hits, key=os.path.getmtime)
        return None

    def _dir(*patterns):
        f = _find(*patterns)
        return os.path.dirname(os.path.abspath(f)) if f else None

    return {
        'cpc_template': _find('CPC Master Security Template*.xlsx',
                               'CPC*Template*.xlsx'),
        'flows_xlsx':   _find('Network flows for foundational services*.xlsx',
                               '*NW*FW*Review*.xlsx', '*foundational*services*.xlsx'),
        'legacy_csv':   _find('cpc_infra_services_v1_0.csv',
                               'cpc_infra_services*.csv'),
        'ad_dir':       _dir('*DClist*.xlsx', '*DC*Inventory*.xlsx',
                              '*firewall*dc*.xlsx', '*dc*list*.xlsx'),
        'qualys_dir':   _dir('Qualys_Scanners*.xlsx', 'Qualys_scanner*.xlsx',
                              'qualys*.xlsx'),
    }


def parse_legacy_csv(path):
    """Parse cpc_infra_services_v1_0.csv — pipe-delimited SERVER_IPS."""
    records = []
    if not path or not os.path.isfile(path):
        return records
    with open(path, encoding='utf-8-sig', errors='replace') as f:
        rows = list(csv.DictReader(l for l in f if not l.startswith('#')))
    for row in rows:
        svc_raw  = (row.get('SERVICE_NAME') or '').strip()
        ips_raw  = (row.get('SERVER_IPS') or '').strip()
        ports    = (row.get('PORTS') or '').strip()
        protocol = (row.get('PROTOCOL') or '').strip()
        notes    = (row.get('NOTES') or '').strip()
        scope    = (row.get('SCOPE') or '').strip()
        svc_name, slug, classification = normalize_service(svc_raw)
        if not svc_name:
            continue
        ips = [normalize_ip(x) for x in re.split(r'[\|\n,]+', ips_raw) if x.strip()]
        ips = [ip for ip in ips if ip]
        for ip in ips:
            records.append({
                'SERVICE': svc_name, 'SERVICE_SLUG': slug,
                'CLASSIFICATION': classification,
                'IP_ADDRESS': ip, 'FQDN': '',
                'PORTS': ports, 'PROTOCOL': protocol,
                'HERITAGE': heritage_from_ip(ip),
                'SCOPE': scope, 'NOTES': notes,
                'SOURCE': 'legacy-v1.0',
            })
        if not ips:
            records.append({
                'SERVICE': svc_name, 'SERVICE_SLUG': slug,
                'CLASSIFICATION': classification,
                'IP_ADDRESS': '', 'FQDN': '',
                'PORTS': ports, 'PROTOCOL': protocol,
                'HERITAGE': '', 'SCOPE': scope, 'NOTES': notes,
                'SOURCE': 'legacy-v1.0',
                '_NO_IPS': True,
            })
    return records


def parse_existing_core_services(path):
    """Load current ent-ipdataset-CPC-CORE-SERVICES — already per-IP.

    AD domain entries (SERVICE = a domain name like corp.cvscaremark.com)
    are reclassified to use the ad-* slug convention so they match what
    the new AD parse produces and dedup correctly instead of doubling up.
    """
    records = []
    if not path or not os.path.isfile(path):
        return records
    with open(path, encoding='utf-8-sig', errors='replace') as f:
        rows = list(csv.DictReader(l for l in f if not l.startswith('#')))
    for row in rows:
        svc_raw  = (row.get('SERVICE') or '').strip()
        ip       = normalize_ip(row.get('IP_ADDRESS') or row.get('IP_NETWORK') or '')
        svc_name, slug, classification = normalize_service(svc_raw)
        if not svc_name:
            continue
        # If SERVICE looks like an AD domain (has dots, no spaces, not a VIP),
        # reclassify to use the ad-* slug so it deduplicates correctly against
        # entries produced by parse_ad_xlsx() for the same domain.
        if '.' in svc_raw and ' ' not in svc_raw:
            slug = domain_to_slug(svc_raw)
            classification = 'INTERNAL'
        # VIP entries: 'aeth.aetna.com VIP' → ad-aeth-aetna-vip
        elif '.' in svc_raw and svc_raw.endswith(' VIP'):
            domain_part = svc_raw[:-4].strip()  # strip ' VIP'
            slug = domain_to_slug(domain_part) + '-vip'
            classification = 'INTERNAL'
        heritage = (row.get('HERITAGE') or heritage_from_ip(ip) or
                    heritage_from_fqdn(row.get('FQDN') or ''))
        records.append({
            'SERVICE': svc_name, 'SERVICE_SLUG': slug,
            'CLASSIFICATION': classification,
            'IP_ADDRESS': ip or '',
            'FQDN':       (row.get('FQDN') or '').strip(),
            'PORTS':      (row.get('PORTS') or '').strip(),
            'PROTOCOL':   (row.get('PROTOCOL') or '').strip(),
            'HERITAGE':   heritage,
            'SCOPE':      (row.get('SCOPE') or '').strip(),
            'NOTES':      (row.get('NOTES') or '').strip(),
            'SOURCE':     'existing-core-services',
            '_orig': row,
        })
    return records


def _parse_hcvs_sheet(ws):
    """Parse On-Prem hCVS -- LINUX sheet.
    Format: service-name header row (col0=name, col1=None),
    then IP rows (col0=IP, col1=mask, col2=dest, col3=dest_mask,
                  col4=port, col5=service_label, col6=protocol, col7=notes).
    Server IPs are in the SOURCE column (col0) — these are the service
    provider addresses that own the rule.
    """
    records = []
    current_svc = None
    for row in ws.iter_rows(values_only=True):
        col0 = str(row[0]).strip() if row[0] is not None else ''
        col1 = row[1]
        # Service header: col0 has name, col1 is None
        if col0 and col1 is None and col0 not in ('Source', ''):
            current_svc = col0
            continue
        if not current_svc or not col0:
            continue
        # Data row: col0 = source IP(s), col4 = port, col6 = protocol
        ip_raw  = col0
        ports   = str(row[4]).strip() if row[4] is not None else ''
        notes   = str(row[7]).strip() if row[7] is not None else ''
        svc_name, slug, classification = normalize_service(current_svc)
        if not svc_name:
            continue
        for raw_ip in re.split(r'[\n,]+', ip_raw):
            ip = normalize_ip(raw_ip)
            if ip:
                records.append({
                    'SERVICE': svc_name, 'SERVICE_SLUG': slug,
                    'CLASSIFICATION': classification,
                    'IP_ADDRESS': ip, 'FQDN': '',
                    'PORTS': ports,
                    'PROTOCOL': str(row[6]).strip() if row[6] else '',
                    'HERITAGE': heritage_from_ip(ip),
                    'SCOPE': 'hCVS', 'NOTES': notes,
                    'SOURCE': 'cpc-template-hcvs',
                })
    return records


def _parse_hcb_sheet(ws):
    """Parse On-Prem HCB -- LINUX sheet.
    Format: RULE, SOURCE, DESTINATION, PORT, notes.
    Service IPs are in DESTINATION (col2) for client→server rules,
    or SOURCE (col1) for server→client rules following the main rule row.
    The rule row starts with 'Rule N - ServiceName'.
    """
    records = []
    current_svc = None
    current_ports = ''
    rows_list = list(ws.iter_rows(values_only=True))
    for row in rows_list:
        col0 = str(row[0]).strip() if row[0] is not None else ''
        if not col0:
            continue
        # Rule header
        m = re.match(r'Rule\s+\d+\s*[-–]\s*(.+)', col0, re.IGNORECASE | re.DOTALL)
        if m:
            current_svc = m.group(1).strip()
            src  = str(row[1]).strip() if row[1] else ''
            dst  = str(row[2]).strip() if row[2] else ''
            port = str(row[3]).strip() if row[3] else ''
            current_ports = port
            svc_name, slug, classification = normalize_service(current_svc)
            if not svc_name:
                continue
            # Destination is typically the service servers
            for raw_ip in re.split(r'[\n,\s]+', dst):
                ip = normalize_ip(raw_ip)
                if ip:
                    records.append({
                        'SERVICE': svc_name, 'SERVICE_SLUG': slug,
                        'CLASSIFICATION': classification,
                        'IP_ADDRESS': ip, 'FQDN': '',
                        'PORTS': port,
                        'PROTOCOL': '',
                        'HERITAGE': heritage_from_ip(ip),
                        'SCOPE': 'HCB', 'NOTES': '',
                        'SOURCE': 'cpc-template-hcb',
                    })
        # Continuation row (blank rule col, reversed direction)
        elif current_svc and col0 and not col0.startswith('Rule'):
            svc_name, slug, classification = normalize_service(current_svc)
            if not svc_name:
                continue
            # col0 is source in reversed direction — skip; service IPs already captured
    return records


def _parse_foundation_sheet(ws):
    """Parse Foundation sheet: Service, Source, Destination, Environment, Port,
    Protocol, Notes. Destination has individual IP or FQDN rows per service.
    """
    records = []
    current_svc = None
    current_ports = ''
    current_protocol = ''
    for row in ws.iter_rows(values_only=True):
        svc_col  = str(row[0]).strip() if row[0] else ''
        dst_col  = str(row[2]).strip() if row[2] else ''
        env_col  = str(row[3]).strip() if row[3] else ''
        port_col = str(row[4]).strip() if row[4] else ''
        prot_col = str(row[5]).strip() if row[5] else ''
        if svc_col and svc_col != 'Service':
            current_svc = svc_col
            current_ports = port_col
            current_protocol = prot_col
        if not current_svc or not dst_col:
            continue
        svc_name, slug, classification = normalize_service(current_svc)
        if not svc_name:
            continue
        # Destination may be IP, FQDN, or CIDR
        for raw in re.split(r'[\n]+', dst_col):
            raw = raw.strip()
            if not raw or raw.startswith('Dedicated') or raw.startswith('http'):
                continue
            # FQDN row (contains letters and dots, no pure IP)
            ip = normalize_ip(raw)
            fqdn = raw if not ip and '.' in raw else ''
            if not ip and not fqdn:
                continue
            # Try to resolve FQDN to heritage
            heritage = (heritage_from_ip(ip) if ip else
                        heritage_from_fqdn(fqdn))
            records.append({
                'SERVICE': svc_name, 'SERVICE_SLUG': slug,
                'CLASSIFICATION': classification,
                'IP_ADDRESS': ip or '',
                'FQDN': fqdn,
                'PORTS': current_ports,
                'PROTOCOL': current_protocol,
                'HERITAGE': heritage,
                'SCOPE': env_col or 'Foundation',
                'NOTES': '',
                'SOURCE': 'cpc-template-foundation',
            })
    return records


def parse_cpc_template_xlsx(path):
    """Parse all sheets from CPC Master Security Template xlsx."""
    records = []
    if not path or not os.path.isfile(path):
        return records
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as e:
        print(f'  [WARN] Could not open CPC template: {e}')
        return records
    if 'On-Prem hCVS -- LINUX' in wb.sheetnames:
        r = _parse_hcvs_sheet(wb['On-Prem hCVS -- LINUX'])
        records.extend(r)
        print(f'    hCVS sheet        : {len(r)} raw records')
    if 'On-Prem HCB -- LINUX' in wb.sheetnames:
        r = _parse_hcb_sheet(wb['On-Prem HCB -- LINUX'])
        records.extend(r)
        print(f'    HCB sheet         : {len(r)} raw records')
    if 'Foundation' in wb.sheetnames:
        r = _parse_foundation_sheet(wb['Foundation'])
        records.extend(r)
        print(f'    Foundation sheet  : {len(r)} raw records')
    return records


def parse_flows_xlsx(path):
    """Parse NW & FW Requirements sheet — produces FLOW records (not IP records).
    These inform SERVICE-FLOWS, not CORE-SERVICES IP registry.
    Returns list of flow dicts for gap analysis."""
    flows = []
    if not path or not os.path.isfile(path):
        return flows
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as e:
        print(f'  [WARN] Could not open flows xlsx: {e}')
        return flows
    sheet_name = 'NW & FW Requirements (2)'
    if sheet_name not in wb.sheetnames:
        return flows
    ws = wb[sheet_name]
    header = None
    for row in ws.iter_rows(values_only=True):
        vals = [str(v).strip() if v else '' for v in row]
        if not header:
            if 'Foundational Service Name' in vals:
                header = vals
            continue
        if not any(vals):
            continue
        row_dict = dict(zip(header, vals))
        svc_raw = row_dict.get('Foundational Service Name', '').strip()
        if not svc_raw:
            continue
        svc_name, slug, classification = normalize_service(svc_raw)
        flows.append({
            'SERVICE': svc_name or svc_raw,
            'SERVICE_SLUG': slug or '',
            'FLOW_ID': row_dict.get('Identifier', ''),
            'PATH': row_dict.get('Path', ''),
            'SRC': row_dict.get('Source Service Name', ''),
            'DST': row_dict.get('Destination Endpoint Name', ''),
            'PORTS': row_dict.get('Ports', ''),
            'PROTOCOL': row_dict.get('Protocols', ''),
            'STATUS': row_dict.get('Status', ''),
        })
    return flows


# ---------------------------------------------------------------------------
# Deduplication and assembly
# ---------------------------------------------------------------------------

GENERIC_AD_SLUGS = {'active-directory', 'active-directory-nonprod', 'active-directory-vip', 'ad-unknown'}

def deduplicate(all_records):
    """Deduplicate on IP_ADDRESS for AD records, (SERVICE_SLUG, IP_ADDRESS) for all others.
    Per-domain AD slugs (ad-*) take priority over generic active-directory slugs.
    This prevents the same DC IP appearing under both a generic and per-domain slug.
    """
    seen_ad_ips = {}   # ip → record  (AD records keyed on IP alone)
    seen = {}          # (slug, ip) → record  (non-AD records)
    no_ip = []

    def is_per_domain_ad(rec):
        return rec.get('SERVICE_SLUG', '').startswith('ad-') and                rec.get('SERVICE_SLUG') not in GENERIC_AD_SLUGS

    def is_generic_ad(rec):
        return rec.get('SERVICE_SLUG') in GENERIC_AD_SLUGS

    for rec in all_records:
        if rec.get('_NO_IPS') or not rec.get('IP_ADDRESS'):
            no_ip.append(rec)
            continue

        ip = rec['IP_ADDRESS']

        if is_per_domain_ad(rec) or is_generic_ad(rec):
            # AD records: deduplicate on IP alone; per-domain wins over generic
            if ip not in seen_ad_ips:
                seen_ad_ips[ip] = rec.copy()
            else:
                existing = seen_ad_ips[ip]
                # Per-domain slug always beats generic
                if is_generic_ad(existing) and is_per_domain_ad(rec):
                    seen_ad_ips[ip] = rec.copy()
                elif is_per_domain_ad(existing) and is_generic_ad(rec):
                    pass  # keep per-domain
                else:
                    # Same type — gap-fill
                    for field in ('FQDN', 'PORTS', 'PROTOCOL', 'HERITAGE', 'NOTES'):
                        if not existing.get(field) and rec.get(field):
                            existing[field] = rec[field]
        else:
            key = (rec['SERVICE_SLUG'], ip)
            if key not in seen:
                seen[key] = rec.copy()
            else:
                existing = seen[key]
                if existing.get('SOURCE') != 'existing-core-services' and \
                   rec.get('SOURCE') == 'existing-core-services':
                    seen[key] = rec.copy()
                else:
                    for field in ('FQDN', 'PORTS', 'PROTOCOL', 'HERITAGE', 'NOTES'):
                        if not existing.get(field) and rec.get(field):
                            existing[field] = rec[field]

    return list(seen_ad_ips.values()) + list(seen.values()), no_ip


def build_cpc_row(rec, timestamp, dataset_version):
    """Convert internal record dict to CPC_FIELDNAMES output row."""
    orig = rec.get('_orig', {})
    ip   = rec.get('IP_ADDRESS', '')
    slug = rec.get('SERVICE_SLUG', '')
    # Use canonical service name from SERVICE_NORM if available for this slug,
    # so rows from different sources (existing vs template) share the same name.
    canonical_name = _SLUG_TO_CANONICAL.get(slug) or rec.get('SERVICE', '')
    row  = {f: '' for f in CPC_FIELDNAMES}
    row.update({
        'IP_NETWORK':         f'{ip}/32' if ip else '',
        'IP_DATASET_CLASS':   orig.get('IP_DATASET_CLASS') or 'ENTERPRISE',
        'SERVICE_TYPE_CODE':  '',
        'SERVICE_TYPE_LABEL': SERVICE_TYPE_LABELS.get(slug, ''),
        'PROVIDER':           f'build_cpc_service_catalog.py v{SCRIPT_VERSION}',
        'SERVICE':            canonical_name,
        'HERITAGE':           rec.get('HERITAGE') or orig.get('HERITAGE', ''),
        'FQDN':               rec.get('FQDN') or orig.get('FQDN', ''),
        'PORTS':              rec.get('PORTS') or orig.get('PORTS', ''),
        'DESCRIPTION':        orig.get('DESCRIPTION', ''),
        'SOURCE_REF':         orig.get('SOURCE_REF') or rec.get('SOURCE', ''),
        'IMPORTED_AT':        timestamp,
        'IP_ADDRESS':         ip,
        'CIDR':               f'{ip}/32' if ip else '',
        'SERVICE_SLUG':       slug,
        'SCOPE':              rec.get('SCOPE') or orig.get('SCOPE', ''),
        'SERVER_NAME':        orig.get('SERVER_NAME', ''),
        'PROTOCOL':           rec.get('PROTOCOL') or orig.get('PROTOCOL', ''),
        'NOTES':              rec.get('NOTES') or orig.get('NOTES', ''),
        'DATASET_VERSION':    dataset_version,
    })
    return row


def build_ext_row(rec, dataset_version):
    """Build external service candidate row."""
    return {
        'SERVICE_NAME':  rec.get('SERVICE', ''),
        'SERVICE_SLUG':  rec.get('SERVICE_SLUG', ''),
        'SERVICE_TYPE':  SERVICE_TYPE_LABELS.get(rec.get('SERVICE_SLUG', ''), ''),
        'ENDPOINT':      rec.get('IP_ADDRESS') or rec.get('FQDN', ''),
        'ENDPOINT_TYPE': 'hostname' if not rec.get('IP_ADDRESS') else 'ip',
        'PORTS':         rec.get('PORTS', ''),
        'PROTOCOL':      rec.get('PROTOCOL', ''),
        'HERITAGE':      rec.get('HERITAGE', ''),
        'NOTES':         rec.get('NOTES', ''),
        'SOURCE_REF':    rec.get('SOURCE', ''),
        'DATASET_VERSION': dataset_version,
    }


def write_ccd_csv(path, rows, fieldnames, stem, version, tool):
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)
    ts = now_utc()
    with open(path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM={stem}\n')
        f.write(f'#VERSION={version}\n')
        f.write(f'#ROWS={len(rows)}\n')
        f.write(f'#CREATED={ts}\n')
        f.write(f'#TOOL={tool}\n')
        f.write('#END_HEADER\n')
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)



def parse_ad_xlsx(ad_dir):
    """Parse AD Domain Controller XLSX files.
    Primary:   2026-05-21-DClist.xlsx       (315 DCs + 33 VIPs) — most current
    Secondary: 2026-03-20 CVS DC Inventory  (381 DCs) — catches retired/unlisted
    Tertiary:  2026 - firewall dc list 1    (323 DCs) — FW-specific list
    Deduplicates on IP across all three sources.
    """
    records = []
    seen_ips = set()

    def _dc_record(ip, fqdn, domain, env_out, heritage, source, notes=''):
        # Per-domain AD service — slug derived directly from domain FQDN
        svc_slug = domain_to_slug(domain or 'unknown')
        return {
            'SERVICE': domain or 'unknown',
            'SERVICE_SLUG': svc_slug,
            'CLASSIFICATION': 'INTERNAL',
            'IP_ADDRESS': ip, 'FQDN': fqdn,
            'PORTS': AD_PORTS, 'PROTOCOL': AD_PROTOCOL,
            'HERITAGE': heritage, 'SCOPE': 'HCB' if heritage == 'HCB' else 'hCVS',
            'NOTES': notes, 'SOURCE': source,
        }

    def _vip_record(ip, fqdn, heritage, ports, source):
        # Derive domain from FQDN for per-domain VIP slug
        domain = domain_from_fqdn(str(fqdn or ''))
        if domain:
            svc_slug = domain_to_slug(domain) + '-vip'
            svc_name = f'{domain} VIP'
        else:
            svc_slug = 'active-directory-vip'
            svc_name = 'Active Directory VIP'
        return {
            'SERVICE': svc_name,
            'SERVICE_SLUG': svc_slug,
            'CLASSIFICATION': 'INTERNAL',
            'IP_ADDRESS': ip, 'FQDN': fqdn,
            'PORTS': ports or AD_PORTS, 'PROTOCOL': AD_PROTOCOL,
            'HERITAGE': heritage, 'SCOPE': 'HCB' if heritage == 'HCB' else 'hCVS',
            'NOTES': 'AD VIP', 'SOURCE': source,
        }


    # ── Affiliate/PDC domains hosted at Las Vegas Switch COLO ────────────────
    # These historically terminated at Phoenix Aetna DC ("PDC") and have since
    # been migrated to Las Vegas Switch COLO (US_LAS_NV_CI).
    _LV_COLO_DOMAINS = {
        'ad.meritain.com', 'dmz.meritain.com',
        'cust.meritain.com', 'custtest.cust.meritain.com',
        'xauth.cofinity.net', 'xtest.cofinity.net',
        'ppom.info', 'resource.info',
        'pdchs.local', 'pdcss.local', 'pdc-dmz.local',
        'ahm.corp', 'ahmdmz.corp',
    }

    # Site token → canonical location.
    # Location is encoded in the hostname — scan all hyphen-delimited tokens
    # rather than only the prefix, so MER-CO-DC1, PDCH-LV-DC01, MVME-AETDMZ900
    # all resolve correctly regardless of token position.
    _SITE_TOKEN_LOC = {
        # Las Vegas NV - Switch COLO  (LV token in affiliate hostnames)
        'LV':   'LV-COLO',   'LGS':  'LV-COLO',
        # Middletown CT - Aetna MDC
        'MVME': 'Middletown', 'MIDE': 'Middletown',
        'MID':  'Middletown', 'MVM':  'Middletown', 'MVCP': 'Middletown',
        # Windsor CT - Aetna WDC
        'WVCP': 'Windsor',    'WINE': 'Windsor',
        'WIN':  'Windsor',    'WVM':  'Windsor',
        # Hartford CT - Aetna HQ
        'HFD':  'Hartford',   'HLB':  'Hartford',
        'HVT':  'Hartford',   'HVM':  'Hartford',   'HVC':  'Hartford',
        # Phoenix AZ / Scottsdale AZ - Shea DC
        'PAZ':  'Scottsdale', 'MAZ':  'Scottsdale',
        # Woonsocket RI - RI One
        'RRI':  'RI-One',
    }

    def _resolve_loc(dc_loc, domain, hostname):
        """
        Normalise the spreadsheet Loc: value to a canonical location tag.
        Returns the string to embed after 'Loc:' in NOTES.

        Rules (in priority order):
          1. Affiliate/PDC domains always → LV-COLO regardless of dc_loc.
          2. dc_loc provided and not blank/PDC → use as-is (Shea, Middletown…).
          3. dc_loc == 'PDC' and domain is aeth.aetna.com → Phoenix (genuine PDC).
          4. dc_loc blank → scan all hyphen/underscore tokens in hostname for a
             known site token (longest match wins). Handles MER-CO-DC1,
             PDCH-LV-DC01, MVME-AETDMZ900, HVCTHEHT01, etc.
        """
        d = (domain or '').lower().strip()
        # Rule 1: affiliate domains → always LV COLO
        if any(d == af or d.endswith('.' + af) for af in _LV_COLO_DOMAINS):
            return 'LV-COLO'
        # Rule 2: non-blank, non-PDC dc_loc → trust it
        loc = (dc_loc or '').strip()
        if loc and loc.upper() not in ('PDC', ''):
            return loc
        # Rule 3: dc_loc == PDC on a genuine Aetna DC domain → Phoenix
        if loc.upper() == 'PDC':
            return 'Phoenix'
        # Rule 4: scan hostname tokens for site code (longest match first)
        hn = (hostname or '').upper()
        tokens = re.split(r'[-_]', hn)
        for key in sorted(_SITE_TOKEN_LOC, key=len, reverse=True):
            for tok in tokens:
                if tok == key or tok.startswith(key):
                    return _SITE_TOKEN_LOC[key]
            if hn.startswith(key):
                return _SITE_TOKEN_LOC[key]
        return ''

    # Primary: 2026-05-21-DClist.xlsx
    primary = os.path.join(ad_dir, '2026-05-21-DClist.xlsx')
    if os.path.isfile(primary):
        wb = openpyxl.load_workbook(primary, data_only=True)
        ws = wb['Domain Controllers']
        added = 0
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0: continue
            fqdn, hostname, ip, domain, dc_util, dc_loc, env, prod_np, os_ver, *_ = row
            if not ip: continue
            ip = str(ip).strip()
            if ip in seen_ips: continue
            heritage, env_out = DOMAIN_HERITAGE_MAP.get(domain or '', domain_heritage_env(domain))
            seen_ips.add(ip)
            records.append(_dc_record(ip, fqdn or '', domain or '',
                env_out, heritage, 'ad-dclist-2026-05-21',
                f"Domain:{domain} DC_Type:{dc_util or 'DC'} Loc:{_resolve_loc(dc_loc, domain, hostname)} Env:{env_out}"))
            added += 1
        print(f"    AD primary (2026-05-21):  {added} DCs")

        # VIP sheet
        ws2 = wb['VIP Load Balancers']
        vip_added = 0
        for i, row in enumerate(ws2.iter_rows(values_only=True)):
            if i == 0: continue
            if not row[0] or not row[1]: continue
            vip_name, vip_ip_raw, location, pool_members, ports = (row + (None,)*5)[:5]
            for raw_vip in str(vip_ip_raw or '').split('\n'):
                ip = normalize_ip(raw_vip)
                if not ip or ip in seen_ips or '\u200b' in raw_vip: continue
                name_l = str(vip_name or '').lower()
                heritage = 'HCB' if ('aeth' in name_l or 'aetna' in name_l) else                            'CVS' if ('corp' in name_l or 'cvs' in name_l) else 'MIXED'
                seen_ips.add(ip)
                records.append(_vip_record(ip, str(vip_name or '').strip(),
                    heritage, str(ports or ''), 'ad-dclist-2026-05-21-vips'))
                vip_added += 1
        print(f"    AD VIPs (2026-05-21):     {vip_added} VIPs")

    # Secondary: 2026-03-20 CVS DC Inventory
    secondary_glob = os.path.join(ad_dir, '2026-03-20*.xlsx')
    import glob as _glob
    sec_paths = _glob.glob(secondary_glob)
    if sec_paths:
        wb2 = openpyxl.load_workbook(sec_paths[0], data_only=True)
        ws3 = wb2['Domain Controllers']
        hdr = next(ws3.iter_rows(values_only=True))
        hdr = [str(h).strip() if h else '' for h in hdr]
        added2 = 0
        for row in ws3.iter_rows(values_only=True):
            row_d = dict(zip(hdr, row))
            ip = str(row_d.get('IP Address') or '').strip()
            if not ip: continue
            ip = normalize_ip(ip)
            if not ip or ip in seen_ips: continue
            domain = str(row_d.get('Domain') or '').strip()
            fqdn   = str(row_d.get('FQDN') or '').strip()
            heritage, env_out = DOMAIN_HERITAGE_MAP.get(domain, domain_heritage_env(domain))
            prod_np = str(row_d.get('Prod/Nonprod') or '').lower()
            if 'non' in prod_np: env_out = 'NONPROD'
            seen_ips.add(ip)
            hn_sec = str(row_d.get('Hostname') or row_d.get('Server Name') or fqdn or '').split('.')[0]
            records.append(_dc_record(ip, fqdn, domain, env_out, heritage,
                'ad-inventory-2026-03-20',
                f"Domain:{domain} Loc:{_resolve_loc(row_d.get('Site',''), domain, hn_sec)} Env:{env_out}"))
            added2 += 1
        print(f"    AD secondary (2026-03-20): {added2} new DCs (not in primary)")

    # Tertiary: firewall dc list
    fw_path = os.path.join(ad_dir, '2026 - firewall dc list 1.xlsx')
    if os.path.isfile(fw_path):
        wb3 = openpyxl.load_workbook(fw_path, data_only=True)
        ws4 = wb3['Sheet2']
        added3 = 0
        for i, row in enumerate(ws4.iter_rows(values_only=True)):
            if i == 0: continue
            fqdn, ip, domain = (row + (None,)*3)[:3]
            if not ip: continue
            ip = str(ip).strip()
            if ip in seen_ips: continue
            heritage, env_out = DOMAIN_HERITAGE_MAP.get(domain or '', domain_heritage_env(domain))
            seen_ips.add(ip)
            records.append(_dc_record(ip, fqdn or '', domain or '', env_out,
                heritage, 'ad-fw-list-2026',
                f"Domain:{domain or 'unknown'} Source:FW-list"))
            added3 += 1
        print(f"    AD tertiary (FW list):     {added3} new DCs (not in primary/secondary)")

    return records


def parse_qualys_xlsx(qualys_dir):
    """Parse Qualys scanner XLSX files.
    Uses Qualys_Scanners_data-mjm-12-23.xlsx as authoritative (more recent).
    Falls back to Qualys_scanner_data-MJM-12-9.xlsx (uses Sheet2 = combined).
    CLD instance → CVS (Internal-PBM)
    HCD instance → HCB (Internal-HCB)
    """
    import glob as _glob
    records = []
    seen_ips = set()

    # Prefer Dec-23 (Scanners_data) over Dec-9 (scanner_data)
    paths = (sorted(_glob.glob(os.path.join(qualys_dir, 'Qualys_Scanners_data*.xlsx')), reverse=True) or
             sorted(_glob.glob(os.path.join(qualys_dir, 'Qualys_scanner_data*.xlsx')), reverse=True))
    if not paths:
        print(f"    [WARN] No Qualys XLSX found in {qualys_dir}")
        return records

    # Load all files, deduplicate on IP
    for path in paths:
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = 'Sheet2' if 'Sheet2' in wb.sheetnames else wb.sheetnames[0]
        ws = wb[sheet]
        added = 0
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0: continue
            if len(row) < 3: continue
            instance, name, ip = row[0], row[1], row[2]
            if not ip: continue
            ip = normalize_ip(str(ip))
            if not ip or ip in seen_ips: continue
            inst = str(instance or '').upper()
            heritage = 'HCB' if 'HCD' in inst else 'CVS'
            seen_ips.add(ip)
            records.append({
                'SERVICE': 'Qualys Scanner',
                'SERVICE_SLUG': 'qualys-scanner',
                'CLASSIFICATION': 'INTERNAL',
                'IP_ADDRESS': ip,
                'FQDN': str(name or '').strip(),
                'PORTS': QUALYS_PORTS, 'PROTOCOL': QUALYS_PROTOCOL,
                'HERITAGE': heritage,
                'SCOPE': 'HCB' if heritage == 'HCB' else 'hCVS',
                'NOTES': f"Qualys instance:{instance} Scanner:{name}",
                'SOURCE': f'qualys-{os.path.basename(path)}',
            })
            added += 1
        print(f"    Qualys ({os.path.basename(path)} / {sheet}): {added} scanners")

    return records


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build_rollup_aggregates(deduped, timestamp, dataset_ver):
    """
    Step [3b]: Build enterprise rollup aggregate objects.
    Unions IPs from per-heritage service variants into SVC_*_ALL objects.
    AD and Kerberos rollups use prefix match 'ad-'; others use exact slug matching.
    """
    slug_index = {}
    for rec in deduped:
        slug_norm = rec.get('SERVICE_SLUG', '').lower().replace('_', '-')
        slug_index.setdefault(slug_norm, []).append(rec)

    rollup_rows    = []
    rollup_summary = []

    for (rollup_slug, rollup_name, svc_type_label, ports, protocol,
         heritage, scope, match_spec, match_mode) in ROLLUP_AGGREGATES:

        source_recs = []
        if match_mode == 'prefix':
            prefix = match_spec.lower().replace('_', '-')
            for slug_norm, recs in slug_index.items():
                if slug_norm.startswith(prefix):
                    source_recs.extend(recs)
        else:
            for slug_spec in match_spec:
                slug_norm = slug_spec.lower().replace('_', '-')
                source_recs.extend(slug_index.get(slug_norm, []))

        if not source_recs:
            rollup_summary.append((rollup_name, 0, 0, 'NO SOURCE RECORDS'))
            continue

        seen_ips   = {}
        for rec in source_recs:
            ip = rec.get('IP_ADDRESS', '').strip()
            if ip and ip not in seen_ips:
                seen_ips[ip] = rec

        total_source = len(source_recs)
        unique_ips   = len(seen_ips)
        n_variants   = len(set(r.get('SERVICE_SLUG', '') for r in source_recs))

        for ip, src_rec in sorted(seen_ips.items()):
            row = {f: '' for f in CPC_FIELDNAMES}
            row.update({
                'IP_NETWORK':         f'{ip}/32',
                'IP_DATASET_CLASS':   'ENTERPRISE',
                'SERVICE_TYPE_LABEL': svc_type_label,
                'PROVIDER':           f'build_cpc_service_catalog.py v{SCRIPT_VERSION}',
                'SERVICE':            rollup_name,
                'HERITAGE':           heritage,
                'FQDN':               src_rec.get('FQDN', ''),
                'PORTS':              ports,
                'DESCRIPTION':        (f'Enterprise rollup — union of all '
                                       f'{rollup_name.replace("_ALL", "")}* objects'),
                'SOURCE_REF':         'aggregate-rollup',
                'IMPORTED_AT':        timestamp,
                'IP_ADDRESS':         ip,
                'CIDR':               f'{ip}/32',
                'SERVICE_SLUG':       rollup_slug,
                'SCOPE':              scope,
                'PROTOCOL':           protocol,
                'NOTES':              (f'Rollup: {total_source} source records across '
                                       f'{n_variants} variants → {unique_ips} unique IPs'),
                'DATASET_VERSION':    dataset_ver,
            })
            rollup_rows.append(row)

        rollup_summary.append((rollup_name, unique_ips, total_source, 'OK'))

    return rollup_rows, rollup_summary


def main():
    p = argparse.ArgumentParser(
        description=f'build_cpc_service_catalog.py v{SCRIPT_VERSION}')
    p.add_argument('--legacy-csv',    default=None,
                   help='cpc_infra_services_v1_0.csv')
    p.add_argument('--core-services', default=None,
                   help='ent-ipdataset-CPC-CORE-SERVICES-vDATE.csv (current)')
    p.add_argument('--cpc-raw-dir',   default=DEFAULT_CPC_RAW_DIR,
                   help='Root directory containing all CPC raw source files '
                        f'(default: {DEFAULT_CPC_RAW_DIR})')
    p.add_argument('--cpc-template',  default=None,
                   help='CPC Master Security Template xlsx (overrides auto-discovery)')
    p.add_argument('--flows-xlsx',    default=None,
                   help='NW & FW Review xlsx (overrides auto-discovery)')
    p.add_argument('--ad-dir',        default=None,
                   help='Directory containing AD DC XLSX files (overrides auto-discovery)')
    p.add_argument('--qualys-dir',    default=None,
                   help='Directory containing Qualys scanner XLSX files (overrides auto-discovery)')
    p.add_argument('--ipam-dir',      default='./ipam-db',
                   help='ipam-db directory (for ROUTING_DOMAIN LPM)')
    p.add_argument('--out-dir',       default='./processed_outputs')
    p.add_argument('--extra-rows',    default=None, nargs='+', metavar='CSV',
                   help='One or more CSV files containing pre-formatted '
                        'CPC-CORE-SERVICES rows to merge in before deduplication. '
                        'Use for CI/CD infrastructure, partner entries, etc. '
                        'File must have the same column schema as CPC-CORE-SERVICES.')
    p.add_argument('--dry-run',       action='store_true',
                   help='Show what would be written without writing any files.')
    p.add_argument('-V', '--version', action='version',
                   version=f'build_cpc_service_catalog.py v{SCRIPT_VERSION}')
    args = p.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    timestamp    = now_utc()
    dataset_ver  = f'v{BUILD_DATE}'
    tool_stamp   = f'build_cpc_service_catalog.py v{SCRIPT_VERSION}'

    print(f'build_cpc_service_catalog.py  v{SCRIPT_VERSION}  {BUILD_DATE}')
    if args.dry_run:
        print('  DRY-RUN: no files written')
    print()

    # ── Load all sources ──────────────────────────────────────────────────
    print('[1/5] Loading source data ...')
    all_records = []

    # Auto-discover from --cpc-raw-dir unless individual flags override
    raw_dir = args.cpc_raw_dir
    if raw_dir and os.path.isdir(raw_dir):
        discovered = discover_cpc_files(raw_dir)
        print(f'  Auto-discovery from: {raw_dir}')
        for k, v in discovered.items():
            label = os.path.relpath(v) if v else '(not found)'
            print(f'    {k:<16}: {label}')
        print()
        if not args.legacy_csv   and discovered['legacy_csv']:
            args.legacy_csv   = discovered['legacy_csv']
        if not args.cpc_template and discovered['cpc_template']:
            args.cpc_template = discovered['cpc_template']
        if not args.flows_xlsx   and discovered['flows_xlsx']:
            args.flows_xlsx   = discovered['flows_xlsx']
        if not args.ad_dir       and discovered['ad_dir']:
            args.ad_dir       = discovered['ad_dir']
        if not args.qualys_dir   and discovered['qualys_dir']:
            args.qualys_dir   = discovered['qualys_dir']
    elif raw_dir:
        print(f'  [WARN] --cpc-raw-dir not found: {raw_dir}')
        print(f'         Continuing with explicitly provided files only.')
        print()

    if args.legacy_csv:
        r = parse_legacy_csv(args.legacy_csv)
        all_records.extend(r)
        print(f'  legacy v1.0 CSV   : {len(r)} records')

    if args.core_services:
        r = parse_existing_core_services(args.core_services)
        all_records.extend(r)
        print(f'  existing CPC-CORE : {len(r)} records')

    if args.cpc_template:
        print(f'  CPC template xlsx :')
        r = parse_cpc_template_xlsx(args.cpc_template)
        all_records.extend(r)
        print(f'    Total            : {len(r)} records')

    if args.flows_xlsx:
        flows = parse_flows_xlsx(args.flows_xlsx)
        print(f'  NW & FW flows xlsx: {len(flows)} flow requirements')
    else:
        flows = []

    if args.ad_dir:
        print(f'  AD DC xlsx dir    :')
        r = parse_ad_xlsx(args.ad_dir)
        all_records.extend(r)
        print(f'    Total            : {len(r)} AD records')

    if args.qualys_dir:
        print(f'  Qualys xlsx dir   :')
        r = parse_qualys_xlsx(args.qualys_dir)
        all_records.extend(r)
        print(f'    Total            : {len(r)} Qualys records')

    # ── Extra rows (pre-formatted CPC-CORE-SERVICES CSV patches) ─────────
    if args.extra_rows:
        import csv as _csv
        for extra_path in args.extra_rows:
            if not os.path.isfile(extra_path):
                print(f'  [WARN] --extra-rows file not found: {extra_path} — skipped')
                continue
            extra = []
            with open(extra_path, newline='', encoding='utf-8-sig') as ef:
                reader = _csv.DictReader(
                    l for l in ef if not l.startswith('#'))
                for row in reader:
                    # Wrap into internal record format for deduplication
                    rec = {
                        'IP':             row.get('IP_ADDRESS', row.get('CIDR','').split('/')[0]),
                        'CIDR':           row.get('CIDR', row.get('IP_NETWORK','')),
                        'FQDN':           row.get('FQDN',''),
                        'SERVICE':        row.get('SERVICE',''),
                        'SLUG':           row.get('SERVICE_SLUG',''),
                        'PORTS':          row.get('PORTS',''),
                        'HERITAGE':       row.get('HERITAGE',''),
                        'SCOPE':          row.get('SCOPE',''),
                        'PROTOCOL':       row.get('PROTOCOL','TCP'),
                        'NOTES':          row.get('NOTES',''),
                        'DESCRIPTION':    row.get('DESCRIPTION',''),
                        'SOURCE_REF':     row.get('SOURCE_REF','extra-rows'),
                        'CLASSIFICATION': 'DELIVERY',
                        '_raw_row':       row,  # preserve full row for passthrough
                    }
                    extra.append(rec)
            all_records.extend(extra)
            print(f'  extra-rows        : {len(extra)} records from {os.path.basename(extra_path)}')

    print(f'\n  Total raw records : {len(all_records)}')

    # ── Classify ──────────────────────────────────────────────────────────
    print('\n[2/5] Classifying records ...')
    internal  = [r for r in all_records if r['CLASSIFICATION'] == 'INTERNAL']
    external  = [r for r in all_records if r['CLASSIFICATION'] == 'EXTERNAL']
    delivery  = [r for r in all_records if r['CLASSIFICATION'] == 'DELIVERY']
    flow_only = [r for r in all_records if r['CLASSIFICATION'] == 'FLOW']

    print(f'  INTERNAL          : {len(internal)}')
    print(f'  EXTERNAL          : {len(external)}')
    print(f'  DELIVERY (CIDRs)  : {len(delivery)}')
    print(f'  FLOW (description): {len(flow_only)}')

    # ── Deduplicate internal services ─────────────────────────────────────
    print('\n[3/5] Deduplicating internal service IPs ...')
    deduped, no_ip_records = deduplicate(internal)
    # Drop remaining generic active-directory slugs — per-domain records are authoritative
    pre_drop = len(deduped)
    deduped = [r for r in deduped if r.get('SERVICE_SLUG') not in GENERIC_AD_SLUGS]
    dropped = pre_drop - len(deduped)
    if dropped:
        print(f'  Dropped {dropped} residual generic active-directory entries')
    print(f'  Unique (slug, IP) pairs : {len(deduped)}')
    print(f'  Service records w/no IP : {len(no_ip_records)}')

    svc_counts = Counter(r['SERVICE_SLUG'] for r in deduped)
    print(f'  Unique services         : {len(svc_counts)}')
    print()
    for slug, cnt in sorted(svc_counts.items(), key=lambda x: -x[1]):
        svc_name = (_SLUG_TO_CANONICAL.get(slug)
                    or next((r['SERVICE'] for r in deduped if r['SERVICE_SLUG'] == slug), slug))
        print(f'    {cnt:>4}  {svc_name}')

    # ── Step 3b: Enterprise rollup aggregates ─────────────────────────────
    print('\n[3b/5] Building enterprise rollup aggregates ...')
    rollup_rows, rollup_summary = build_rollup_aggregates(
        deduped, timestamp, dataset_ver)
    for rname, uips, srcs, status in rollup_summary:
        if status == 'OK':
            print(f'  {rname:<45} {uips:>5} IPs  ({srcs} source records)')
        else:
            print(f'  {rname:<45} — {status}')
    print(f'  Total rollup rows  : {len(rollup_rows)}')

    # ── Build gap report ──────────────────────────────────────────────────
    print('\n[4/5] Building gap report ...')
    gap_rows = []

    # Services with no IPs
    for rec in no_ip_records:
        gap_rows.append({
            'SERVICE_NAME': rec['SERVICE'],
            'SERVICE_SLUG': rec['SERVICE_SLUG'],
            'ISSUE': 'NO_IPS',
            'DETAIL': 'Service found in source data but no server IPs resolved',
            'SOURCE': rec['SOURCE'],
        })

    # External services — need ext_canonical_objects entries
    ext_slugs_seen = set()
    for rec in external:
        if rec['SERVICE_SLUG'] not in ext_slugs_seen:
            gap_rows.append({
                'SERVICE_NAME': rec['SERVICE'],
                'SERVICE_SLUG': rec['SERVICE_SLUG'],
                'ISSUE': 'EXTERNAL_SERVICE',
                'DETAIL': f'Routes via proxy/SaaS — needs ext_canonical_objects entry. '
                          f'Endpoints: {rec.get("IP_ADDRESS") or rec.get("FQDN", "")}',
                'SOURCE': rec['SOURCE'],
            })
            ext_slugs_seen.add(rec['SERVICE_SLUG'])

    # Services in flows but no IPs in registry
    flow_services = {r['SERVICE_SLUG'] for r in flows}
    registered_slugs = {r['SERVICE_SLUG'] for r in deduped}
    for slug in flow_services - registered_slugs:
        svc_name = next((r['SERVICE'] for r in flows if r['SERVICE_SLUG'] == slug), slug)
        gap_rows.append({
            'SERVICE_NAME': svc_name,
            'SERVICE_SLUG': slug,
            'ISSUE': 'IN_FLOWS_NOT_IN_REGISTRY',
            'DETAIL': 'Service has flow requirements but no IPs in CORE-SERVICES',
            'SOURCE': 'flows-xlsx',
        })

    # Services in registry but no flow profile
    for slug in registered_slugs - flow_services:
        svc_name = next((r['SERVICE'] for r in deduped if r['SERVICE_SLUG'] == slug), slug)
        gap_rows.append({
            'SERVICE_NAME': svc_name,
            'SERVICE_SLUG': slug,
            'ISSUE': 'NO_FLOW_PROFILE',
            'DETAIL': 'Service has IPs registered but no entry in CPC-SERVICE-FLOWS',
            'SOURCE': 'gap-analysis',
        })

    gap_rows.extend(KNOWN_GAPS)
    print(f'  Gap items         : {len(gap_rows)}')
    print(f'  (includes {len(KNOWN_GAPS)} known infrastructure gaps)')
    by_issue = Counter(r['ISSUE'] for r in gap_rows)
    for issue, cnt in by_issue.most_common():
        print(f'    {cnt:>3}  {issue}')

    # ── Write outputs ─────────────────────────────────────────────────────
    print('\n[5/5] Writing outputs ...')

    core_rows = [build_cpc_row(r, timestamp, dataset_ver) for r in deduped]
    core_rows.extend(rollup_rows)  # enterprise _ALL rollup objects
    ext_rows  = [build_ext_row(r, dataset_ver) for r in external]

    core_path = os.path.join(args.out_dir, f'ent-ipdataset-CPC-CORE-SERVICES-{dataset_ver}.csv')
    ext_path  = os.path.join(args.out_dir, f'ent-ipdataset-CPC-EXT-CANDIDATES-{dataset_ver}.csv')
    gap_path  = os.path.join(args.out_dir, f'cpc_catalog_gap_report_{dataset_ver}.csv')

    if not args.dry_run:
        write_ccd_csv(core_path, core_rows, CPC_FIELDNAMES,
                      'ent-ipdataset-CPC-CORE-SERVICES', dataset_ver, tool_stamp)
        print(f'  ✓ {os.path.basename(core_path)}  ({len(core_rows)} rows)')

        write_ccd_csv(ext_path, ext_rows, EXT_FIELDNAMES,
                      'ent-ipdataset-CPC-EXT-CANDIDATES', dataset_ver, tool_stamp)
        print(f'  ✓ {os.path.basename(ext_path)}  ({len(ext_rows)} rows)')

        with open(gap_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=GAP_FIELDNAMES)
            w.writeheader()
            w.writerows(gap_rows)
        print(f'  ✓ {os.path.basename(gap_path)}  ({len(gap_rows)} items)')
    else:
        print(f'  [DRY-RUN] Would write:')
        print(f'    {os.path.basename(core_path)}  ({len(core_rows)} rows)')
        print(f'    {os.path.basename(ext_path)}  ({len(ext_rows)} rows)')
        print(f'    {os.path.basename(gap_path)}  ({len(gap_rows)} items)')

    if not args.dry_run:
        print(f'\n  Next step:')
        print(f'    python3 ipam-db.py --import {core_path} --type ent_cpc_core_services')
        print(f'    python3 ipam-db.py --import {ext_path} --type ent_cpc_ext_candidates')

    print(f'\n  ✓ Done')


if __name__ == '__main__':
    main()
