#!/usr/bin/env python3
"""
build_geo_block_objects.py  v1.0.1  2026-06-23
CCD Platform — CVS Health Information Security

Generates PA-OS EDL text files and address object .set commands for
geo-blocking a defined list of high-risk countries, sourced from the
IP2Location LITE DB1 CIDR CSV dataset on disk.

Special handling:
  - GEO-BLOCK-CN (China): Azure China (21Vianet) CIDRs are subtracted
    from the country block before output. Azure China is a legitimate
    CVS SaaS/cloud endpoint and must not be blocked.
  - All other countries: straight IP2Location extraction, no carve-outs.

Outputs (all under Net_Object/IPDATASET-vDATE/):
  edl/GEO-BLOCK-<CC>.txt          one CIDR per line per country
  edl/GEO-BLOCK-ALL.txt           union of all country CIDRs
  geo_block_objects_vDATE.set     PA set commands: EDL address objects +
                                  static address-group for each country +
                                  GEO-BLOCK-ALL rollup group
  geo_block_manifest_vDATE.csv    manifest for build_edl_catalog.py

EDL address objects reference:
  http://edl.cvs.internal/ipdatasets/GEO-BLOCK-<CC>.txt

Usage:
  python3 build_geo_block_objects.py
  python3 build_geo_block_objects.py --base ~/Documents/IP_Lookup
  python3 build_geo_block_objects.py --dry-run
  python3 build_geo_block_objects.py --geo-dir ./ip_geo
  python3 build_geo_block_objects.py --no-summarize   # skip CIDR summarization

Changelog:
  v1.0.2  2026-06-24  Add ipdatasets/ to IP2Location DB search path —
                      on Yggdrasil the DB lives in ipdatasets/ not ip_geo/.
  v1.0.1  2026-06-23  Fix log() missing default arg — log() called with no arguments
                      caused TypeError on startup.
  v1.0.0  2026-06-23  Initial build.
                      Countries: NG, GH, KZ, SN, PK, UZ, KG, AF, TJ, TM, RU, IR, CN.
                      China carve-out: Azure China (21Vianet) CIDRs subtracted.
                      Source: IP2LOCATION-LITE-DB1.CIDR.CSV in ip_geo/.
                      Output: Net_Object/IPDATASET-vDATE/edl/ + .set + manifest.
                      Summarize flag: --no-summarize disables ipaddress supernet collapse.
"""
from __future__ import annotations

__version__ = '1.0.2'

import argparse
import csv
import ipaddress
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

# ── Country list ──────────────────────────────────────────────────────────────
# ISO-3166-1 alpha-2 → display name
GEO_BLOCK_COUNTRIES: dict[str, str] = {
    'NG': 'Nigeria',
    'GH': 'Ghana',
    'KZ': 'Kazakhstan',
    'SN': 'Senegal',
    'PK': 'Pakistan',
    'UZ': 'Uzbekistan',
    'KG': 'Kyrgyzstan',
    'AF': 'Afghanistan',
    'TJ': 'Tajikistan',
    'TM': 'Turkmenistan',
    'RU': 'Russia',
    'IR': 'Iran',
    'CN': 'China',
}

# Countries requiring carve-out of registered ip_dataset entries
# Maps country_code -> list of ip_dataset stems to subtract
CARVE_OUTS: dict[str, list[str]] = {
    'CN': ['azure-china'],
}

# EDL base URL
EDL_BASE_URL = 'http://edl.cvs.internal/ipdatasets'

# ANSI colours
GRN = '\033[0;32m'; YEL = '\033[0;33m'; RED = '\033[0;31m'
CYN = '\033[0;36m'; BLD = '\033[1m';    RST = '\033[0m'


# ── Helpers ───────────────────────────────────────────────────────────────────

def log(msg: str = '', color: str = '') -> None:
    print(f'{color}{msg}{RST}' if color else msg)


def now_utc() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def summarize_cidrs(nets: list[ipaddress.IPv4Network]) -> list[ipaddress.IPv4Network]:
    """Collapse a list of IPv4Network objects into minimal supernets."""
    try:
        return list(ipaddress.collapse_addresses(nets))
    except Exception:
        return sorted(set(nets))


def cidr_name(cidr: str) -> str:
    """Convert CIDR to PA address object name: 10.0.0.0/8 → addr-10-0-0-0_8"""
    ip, prefix = cidr.split('/')
    return 'addr-' + ip.replace('.', '-') + '_' + prefix


# ── IP2Location CIDR CSV loader ───────────────────────────────────────────────

def load_ip2location_cidr(db_path: str) -> dict[str, list[ipaddress.IPv4Network]]:
    """
    Parse IP2LOCATION-LITE-DB1.CIDR.CSV.

    Expected column formats (auto-detected):
      Format A (CIDR variant):  ip_cidr,country_code,country_name
      Format B (range variant): ip_from,ip_to,country_code,country_name
        where ip_from/ip_to are integers (IP2Location standard range format).

    Returns dict: country_code (uppercase) → list of IPv4Network objects.
    """
    by_country: dict[str, list[ipaddress.IPv4Network]] = defaultdict(list)
    skipped = 0

    with open(db_path, newline='', encoding='utf-8', errors='replace') as f:
        # Peek at first data line to detect format
        raw_lines = [l for l in f if not l.startswith('#') and l.strip()]

    if not raw_lines:
        return {}

    # Detect delimiter and format from header or first data row
    sample = raw_lines[0]
    delimiter = ',' if ',' in sample else '\t'

    # Try to parse as CSV
    import io
    reader = csv.reader(io.StringIO('\n'.join(raw_lines)), delimiter=delimiter)
    rows = list(reader)

    if not rows:
        return {}

    # Detect format from first row
    first = rows[0]
    # Skip header rows (non-numeric first field)
    data_start = 0
    for i, row in enumerate(rows):
        if row and row[0].strip().lstrip('-').isdigit():
            data_start = i
            break

    # Determine format: CIDR (contains '/') vs range (integers)
    sample_row = rows[data_start] if data_start < len(rows) else rows[0]
    is_cidr_format = '/' in sample_row[0]

    log(f'  Format: {"CIDR" if is_cidr_format else "integer range"}  '
        f'  Rows: {len(rows):,}  Data starts at row {data_start}')

    for row in rows[data_start:]:
        if not row:
            continue
        try:
            if is_cidr_format:
                # Format A: cidr, country_code, country_name
                cidr_str    = row[0].strip().strip('"')
                country_code = row[1].strip().strip('"').upper()
            else:
                # Format B: ip_from_int, ip_to_int, country_code, country_name
                ip_from = int(row[0].strip().strip('"'))
                ip_to   = int(row[1].strip().strip('"'))
                country_code = row[2].strip().strip('"').upper()
                # Convert integer range to CIDRs
                start = ipaddress.IPv4Address(ip_from)
                end   = ipaddress.IPv4Address(ip_to)
                for net in ipaddress.summarize_address_range(start, end):
                    by_country[country_code].append(net)
                continue

            if ':' in cidr_str:   # skip IPv6
                continue
            net = ipaddress.ip_network(cidr_str, strict=False)
            by_country[country_code].append(net)
        except Exception:
            skipped += 1
            continue

    if skipped:
        log(f'  {YEL}Skipped {skipped:,} unparseable rows{RST}')

    return dict(by_country)


# ── ip_dataset carve-out loader ───────────────────────────────────────────────

def load_carve_out_cidrs(stems: list[str], ipdatasets_dir: str,
                         registry_path: str) -> list[ipaddress.IPv4Network]:
    """
    Load CIDRs from registered ip_dataset entries by stem name.
    Returns list of IPv4Network objects to subtract from the country block.
    """
    carve_nets: list[ipaddress.IPv4Network] = []

    if not os.path.isfile(registry_path):
        log(f'  {YEL}Warning: ip_dataset.json not found at {registry_path} — '
            f'carve-out skipped{RST}')
        return carve_nets

    with open(registry_path, encoding='utf-8') as f:
        registry = json.load(f)

    datasets = registry.get('datasets', {})

    for stem in stems:
        ds = datasets.get(stem)
        if not ds:
            log(f'  {YEL}Warning: carve-out stem "{stem}" not registered — skipped{RST}')
            continue
        fname = ds.get('filename', '')
        fpath = os.path.join(ipdatasets_dir, fname)
        if not os.path.isfile(fpath):
            log(f'  {YEL}Warning: carve-out file not found: {fpath} — skipped{RST}')
            continue
        cidr_col = ds.get('cidr_col', 'IP_NETWORK')
        loaded = 0
        with open(fpath, newline='', encoding='utf-8', errors='replace') as f:
            for row in csv.DictReader(l for l in f if not l.startswith('#')):
                val = row.get(cidr_col, '').strip()
                if not val or ':' in val:
                    continue
                try:
                    carve_nets.append(ipaddress.ip_network(val, strict=False))
                    loaded += 1
                except Exception:
                    continue
        log(f'  Carve-out "{stem}": {loaded:,} CIDRs loaded from {fname}')

    return carve_nets


def subtract_cidrs(
    country_nets: list[ipaddress.IPv4Network],
    carve_nets: list[ipaddress.IPv4Network],
) -> list[ipaddress.IPv4Network]:
    """
    Remove any network in country_nets that overlaps with any network in carve_nets.
    Uses exact + subnet matching: if a country CIDR is a subnet of or equal to a
    carve-out CIDR, it is removed. Supernet splitting is not performed — this is a
    conservative block-level exclusion.
    """
    if not carve_nets:
        return country_nets

    # Build a sorted list of carve-out nets for fast overlap check
    carve_set = list(ipaddress.collapse_addresses(carve_nets))

    result = []
    for net in country_nets:
        overlaps = False
        for carve in carve_set:
            # Remove if net is a subnet of or equal to a carve-out CIDR
            if net.subnet_of(carve) or net == carve:
                overlaps = True
                break
        if not overlaps:
            result.append(net)

    return result


# ── Output writers ────────────────────────────────────────────────────────────

def write_edl(path: str, nets: list[ipaddress.IPv4Network],
              country_code: str, country_name: str,
              generated_at: str, version: str) -> None:
    """Write a single-country EDL text file."""
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# GEO-BLOCK-{country_code} — {country_name}\n')
        f.write(f'# Generated by build_geo_block_objects.py v{version}\n')
        f.write(f'# Generated at: {generated_at}\n')
        f.write(f'# CIDRs: {len(nets)}\n')
        f.write(f'# Source: IP2Location LITE DB1 CIDR\n')
        for net in sorted(nets, key=lambda n: (int(n.network_address), n.prefixlen)):
            f.write(str(net) + '\n')


def write_edl_all(path: str, all_nets: list[ipaddress.IPv4Network],
                  generated_at: str, version: str) -> None:
    """Write the combined GEO-BLOCK-ALL EDL text file."""
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# GEO-BLOCK-ALL — All geo-blocked countries combined\n')
        f.write(f'# Generated by build_geo_block_objects.py v{version}\n')
        f.write(f'# Generated at: {generated_at}\n')
        f.write(f'# CIDRs: {len(all_nets)}\n')
        for net in sorted(all_nets, key=lambda n: (int(n.network_address), n.prefixlen)):
            f.write(str(net) + '\n')


def write_set_file(
    path: str,
    country_nets: dict[str, list[ipaddress.IPv4Network]],
    generated_at: str,
    version: str,
) -> int:
    """
    Write PA .set command file.

    Structure:
      # ===== EDL ADDRESS OBJECTS =====
      set address GEO-BLOCK-<CC> fqdn <EDL_URL>   (one per country + ALL)

      # ===== STATIC ADDRESS GROUPS =====
      set address-group GEO-BLOCK-<CC> static [ addr-... addr-... ]
      set address-group GEO-BLOCK-ALL  static [ GEO-BLOCK-NG GEO-BLOCK-RU ... ]

    Returns total static address object count.
    """
    total_addr_objs = 0
    all_addr_obj_names: list[str] = []   # individual addr-* names across all countries
    country_group_names: list[str] = []  # GEO-BLOCK-CC names for the ALL group

    # Collect all unique address objects across countries (for deduplication)
    addr_obj_set: dict[str, str] = {}   # cidr_str → addr_name
    for cc, nets in country_nets.items():
        for net in nets:
            cidr_str = str(net)
            addr_obj_set[cidr_str] = cidr_name(cidr_str)

    total_addr_objs = len(addr_obj_set)

    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# GEO-BLOCK Address Objects and Groups\n')
        f.write(f'# Generated by build_geo_block_objects.py v{version}\n')
        f.write(f'# Generated at: {generated_at}\n')
        f.write(f'# Countries: {len(country_nets)}\n')
        f.write(f'# Static address objects: {total_addr_objs}\n')
        f.write(f'# EDL objects: {len(country_nets) + 1}\n')
        f.write('\n')

        # ── Static address objects ────────────────────────────────────────────
        f.write('# ===== ADDRESS OBJECTS =====\n')
        for cidr_str, addr_name in sorted(addr_obj_set.items(),
                                          key=lambda x: (int(ipaddress.ip_network(
                                              x[0], strict=False).network_address),
                                              ipaddress.ip_network(
                                              x[0], strict=False).prefixlen)):
            f.write(f'set address {addr_name} ip-netmask {cidr_str}\n')
        f.write('\n')

        # ── EDL address objects ───────────────────────────────────────────────
        f.write('# ===== EDL ADDRESS OBJECTS =====\n')
        for cc in GEO_BLOCK_COUNTRIES:
            if cc not in country_nets:
                continue
            obj_name = f'GEO-BLOCK-{cc}'
            url = f'{EDL_BASE_URL}/GEO-BLOCK-{cc}.txt'
            cidr_count = len(country_nets[cc])
            f.write(f'set address {obj_name} fqdn {url}\n')
            f.write(f'# ^ EDL: {cidr_count} CIDRs — {url}\n')
            country_group_names.append(obj_name)

        # GEO-BLOCK-ALL EDL
        all_count = sum(len(v) for v in country_nets.values())
        f.write(f'set address GEO-BLOCK-ALL fqdn {EDL_BASE_URL}/GEO-BLOCK-ALL.txt\n')
        f.write(f'# ^ EDL: {all_count} CIDRs (union, summarized) — '
                f'{EDL_BASE_URL}/GEO-BLOCK-ALL.txt\n')
        f.write('\n')

        # ── Static address groups per country ─────────────────────────────────
        f.write('# ===== ADDRESS GROUPS =====\n')
        for cc in GEO_BLOCK_COUNTRIES:
            if cc not in country_nets:
                continue
            nets = country_nets[cc]
            group_name = f'GEO-BLOCK-{cc}'
            member_names = [cidr_name(str(n)) for n in
                            sorted(nets, key=lambda n: (int(n.network_address),
                                                        n.prefixlen))]
            members_str = ' '.join(member_names)
            f.write(f'set address-group {group_name} static [ {members_str} ]\n')

        # GEO-BLOCK-ALL rollup group (references the per-country EDL objects)
        f.write(f'set address-group GEO-BLOCK-ALL static '
                f'[ {" ".join(country_group_names)} ]\n')

    return total_addr_objs


def write_manifest(path: str,
                   country_nets: dict[str, list[ipaddress.IPv4Network]],
                   all_count: int) -> None:
    """Write manifest CSV for build_edl_catalog.py pickup."""
    fieldnames = ['OBJECT_NAME', 'OBJECT_TYPE', 'CIDR_COUNT', 'SOURCE']
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for cc, nets in country_nets.items():
            name = GEO_BLOCK_COUNTRIES.get(cc, cc)
            w.writerow({
                'OBJECT_NAME': f'GEO-BLOCK-{cc}',
                'OBJECT_TYPE': 'EDL',
                'CIDR_COUNT':  len(nets),
                'SOURCE':      f'geo_block/{cc}/{name}',
            })
        w.writerow({
            'OBJECT_NAME': 'GEO-BLOCK-ALL',
            'OBJECT_TYPE': 'EDL',
            'CIDR_COUNT':  all_count,
            'SOURCE':      'geo_block/ALL/combined',
        })


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(
        description=f'build_geo_block_objects.py v{__version__}')
    p.add_argument('--base', default=None,
                   help='CCD Platform root (default: script directory)')
    p.add_argument('--geo-dir', default=None,
                   help='Directory containing IP2LOCATION-LITE-DB1.CIDR.CSV '
                        '(default: <base>/ip_geo/)')
    p.add_argument('--out-dir', default=None,
                   help='Output root — Net_Object/IPDATASET-vDATE/ written here '
                        '(default: <base>/Net_Object/)')
    p.add_argument('--dry-run', action='store_true',
                   help='Parse and report counts without writing any files')
    p.add_argument('--no-summarize', action='store_true',
                   help='Skip CIDR summarization (collapse_addresses). '
                        'Default: summarize to reduce object count.')
    p.add_argument('-V', '--version', action='version',
                   version=f'%(prog)s v{__version__}')
    args = p.parse_args()

    base_dir  = Path(args.base).resolve() if args.base else Path(__file__).parent.resolve()
    geo_dir   = Path(args.geo_dir).resolve() if args.geo_dir else base_dir / 'ip_geo'
    out_root  = Path(args.out_dir).resolve() if args.out_dir else base_dir / 'Net_Object'
    ipdatasets_dir = base_dir / 'ipdatasets'
    registry_path  = str(ipdatasets_dir / 'ip_dataset.json')

    today     = datetime.now().strftime('%Y%m%d')
    out_dir   = out_root / f'IPDATASET-v{today}'
    edl_dir   = out_dir / 'edl'
    gen_ts    = now_utc()

    log(f'\n{BLD}build_geo_block_objects.py  v{__version__}  {today}{RST}')
    log(f'  Base dir:      {base_dir}')
    log(f'  GeoIP dir:     {geo_dir}')
    log(f'  Output dir:    {out_dir}')
    log(f'  Summarize:     {not args.no_summarize}')
    log(f'  Dry run:       {args.dry_run}')
    log()

    # ── Step 1: Locate IP2Location DB ────────────────────────────────────────
    log('[1/5] Locating IP2Location DB ...')
    db_candidates = [
        geo_dir / 'IP2LOCATION-LITE-DB1.CIDR.CSV',
        geo_dir / 'IP2LOCATION-LITE-DB11.CIDR.CSV',
        base_dir / 'ipdatasets' / 'IP2LOCATION-LITE-DB1.CIDR.CSV',
        base_dir / 'ipdatasets' / 'IP2LOCATION-LITE-DB11.CIDR.CSV',
        base_dir / 'IP2LOCATION-LITE-DB1.CIDR.CSV',
    ]
    db_path = None
    for c in db_candidates:
        if c.is_file():
            db_path = c
            break
    if not db_path:
        log(f'  {RED}ERROR: IP2LOCATION-LITE-DB1.CIDR.CSV not found in:{RST}')
        for c in db_candidates:
            log(f'    {c}')
        log(f'  Download from: https://lite.ip2location.com/database/ip-country')
        sys.exit(1)
    log(f'  {GRN}Found:{RST} {db_path}')
    log()

    # ── Step 2: Load IP2Location ──────────────────────────────────────────────
    log('[2/5] Loading IP2Location CIDR data ...')
    all_country_data = load_ip2location_cidr(str(db_path))
    log(f'  Loaded {len(all_country_data)} country codes  '
        f'({sum(len(v) for v in all_country_data.values()):,} total CIDRs)')

    missing = [cc for cc in GEO_BLOCK_COUNTRIES if cc not in all_country_data]
    if missing:
        log(f'  {YEL}Warning: No data for: {", ".join(missing)}{RST}')
    log()

    # ── Step 3: Load carve-outs ───────────────────────────────────────────────
    log('[3/5] Loading carve-out datasets ...')
    carve_out_nets: dict[str, list[ipaddress.IPv4Network]] = {}
    for cc, stems in CARVE_OUTS.items():
        if cc not in GEO_BLOCK_COUNTRIES:
            continue
        log(f'  {cc} — carve-out stems: {stems}')
        nets = load_carve_out_cidrs(stems, str(ipdatasets_dir), registry_path)
        carve_out_nets[cc] = nets
    log()

    # ── Step 4: Build per-country CIDR lists ─────────────────────────────────
    log('[4/5] Building per-country CIDR lists ...')
    country_nets: dict[str, list[ipaddress.IPv4Network]] = {}

    for cc, country_name in GEO_BLOCK_COUNTRIES.items():
        raw = all_country_data.get(cc, [])
        if not raw:
            log(f'  {YEL}{cc:<4} {country_name:<20} — NO DATA{RST}')
            continue

        # Apply carve-outs
        if cc in carve_out_nets and carve_out_nets[cc]:
            before = len(raw)
            raw = subtract_cidrs(raw, carve_out_nets[cc])
            carved = before - len(raw)
            carve_note = f'  ({carved} CIDRs carved out)'
        else:
            carve_note = ''

        # Summarize
        if not args.no_summarize:
            raw = summarize_cidrs(raw)

        country_nets[cc] = raw
        log(f'  {GRN}{cc:<4}{RST} {country_name:<20} {len(raw):>6,} CIDRs{carve_note}')

    # Build combined ALL list
    all_nets_raw: list[ipaddress.IPv4Network] = []
    for nets in country_nets.values():
        all_nets_raw.extend(nets)
    all_nets = summarize_cidrs(all_nets_raw) if not args.no_summarize else all_nets_raw
    all_count = len(all_nets)

    log()
    log(f'  Total countries: {len(country_nets)}')
    log(f'  Total CIDRs (individual): {sum(len(v) for v in country_nets.values()):,}')
    log(f'  GEO-BLOCK-ALL (summarized): {all_count:,}')
    log()

    if args.dry_run:
        log(f'{YEL}  DRY RUN — no files written.{RST}')
        return

    # ── Step 5: Write outputs ─────────────────────────────────────────────────
    log('[5/5] Writing outputs ...')

    edl_dir.mkdir(parents=True, exist_ok=True)

    # Per-country EDL files
    for cc, nets in country_nets.items():
        edl_path = edl_dir / f'GEO-BLOCK-{cc}.txt'
        write_edl(str(edl_path), nets, cc,
                  GEO_BLOCK_COUNTRIES[cc], gen_ts, __version__)
        log(f'  {GRN}✓{RST}  {edl_path.name:<30} {len(nets):>6,} CIDRs')

    # GEO-BLOCK-ALL EDL
    all_edl_path = edl_dir / 'GEO-BLOCK-ALL.txt'
    write_edl_all(str(all_edl_path), all_nets, gen_ts, __version__)
    log(f'  {GRN}✓{RST}  {all_edl_path.name:<30} {all_count:>6,} CIDRs')
    log()

    # .set file
    set_path = out_dir / f'geo_block_objects_v{today}.set'
    addr_obj_count = write_set_file(
        str(set_path), country_nets, gen_ts, __version__)
    log(f'  {GRN}✓{RST}  {set_path.name}')
    log(f'       {addr_obj_count:,} static address objects')
    log(f'       {len(country_nets)} EDL address objects + GEO-BLOCK-ALL')
    log(f'       {len(country_nets) + 1} address groups')
    log()

    # Manifest CSV
    manifest_path = out_dir / f'geo_block_manifest_v{today}.csv'
    write_manifest(str(manifest_path), country_nets, all_count)
    log(f'  {GRN}✓{RST}  {manifest_path.name}')
    log()

    # Summary
    log(f'{GRN}{BLD}  Complete.{RST}')
    log(f'  Output: {out_dir}')
    log()
    log(f'  Next steps:')
    log(f'    1. Copy EDL files to your local HTTP server root:')
    log(f'       cp {edl_dir}/*.txt <http-root>/ipdatasets/')
    log(f'    2. Import .set into Panorama:')
    log(f'       Panorama → Objects → Import → {set_path.name}')
    log(f'    3. Rebuild EDL catalog:')
    log(f'       python3 build_edl_catalog.py')
    log(f'    4. Build policy rule referencing GEO-BLOCK-ALL:')
    log(f'       source: any  dest: GEO-BLOCK-ALL  action: deny  log: yes')
    log()


if __name__ == '__main__':
    main()
