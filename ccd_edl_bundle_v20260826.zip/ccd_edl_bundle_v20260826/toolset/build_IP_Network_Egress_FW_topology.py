#!/usr/bin/env python3
"""
build_IP_Network_Egress_FW_topology.py  v1.17.1
CCD Platform — IP Network Egress Firewall Topology
CVS Health Information Security

Unified pipeline: reads Zscaler FW log zips and CrowdStrike PA export data,
maps all source IPs to IPAM subnets, assigns each subnet to its egress firewall
via traffic confirmation or location-based inference, and produces three outputs:

  ent-ipdataset-EGRESS-FW-TOPOLOGY-vDATE.csv    (./)
    One row per CIDR × EGRESS_FIREWALL_LOGICAL. For every IPAM subnet — known
    FW via confirmed traffic first, inference second.
    CONFIDENCE: HIGH (traffic-confirmed) | MEDIUM (location-confirmed) |
                LOW (asserted-inferred)

  unknown_ip_subnets_vDATE.csv                  (./)
    /24 subnets observed in traffic with no IPAM registration.
    Columns: SOURCE_SUBNET, SLASH_16, EGRESS_FIREWALLS, CONNECTIONS,
             UNIQUE_IPS, SOURCE_IPS, SNAPSHOT_SOURCES, DATA_QUALITY

  fw_egress_breakdown_vDATE.html + .csv         (./)
    Interactive drill-down report: FW tabs → location → subnets.
    Sortable, searchable, with per-subnet detail modal.

  fw_topology_conflicts_vDATE.csv               (./)
    Route validation conflict report. ROUTE_MISMATCH rows where the assigned
    FW has no routing table entry for the CIDR (a different FW does). NO_ROUTE
    rows where no FW has a route. Generated only when FW_Routes data is present.

  known_ambiguous_egress_vDATE.csv              (./)
    v1.14.0. Real, confirmed multi-firewall ties -- a CIDR's (CANONICAL_
    LOCATION, HERITAGE) grouping has confirmed traffic evidence for more
    than one egress firewall, with no further real evidence (route table)
    narrowing it to one. First-class, versioned, meant to be re-run against
    on future sessions as more real traffic accumulates -- see
    write_known_ambiguous_egress()'s docstring for the full methodology.

Replaces:
  build_zscaler_topology.py
  build_egress_fw_topology.py
  build_egress_fw_breakdown.py
  build_zscaler_topology_report.py
  build_zscaler_fw_topology_map.py
  find_unmatched_source_subnets.py

Usage:
  python3 build_IP_Network_Egress_FW_topology.py
  python3 build_IP_Network_Egress_FW_topology.py --dry-run
  python3 build_IP_Network_Egress_FW_topology.py --base ~/Documents/IP_Lookup
  python3 build_IP_Network_Egress_FW_topology.py --zscaler-dir ./IP_Datasets_Raw/zscaler_logs
  python3 build_IP_Network_Egress_FW_topology.py --cs-dir ./IP_Datasets_Raw/CS_Data
  python3 build_IP_Network_Egress_FW_topology.py --no-cs      # skip CrowdStrike
  python3 build_IP_Network_Egress_FW_topology.py --no-report  # skip HTML/CSV report
  python3 build_IP_Network_Egress_FW_topology.py --skip-custom-objects    # skip 6-8 entirely
  python3 build_IP_Network_Egress_FW_topology.py --skip-ipam-import       # build, don't import/pipeline
  python3 build_IP_Network_Egress_FW_topology.py --skip-object-pipeline   # build+import, no pipeline

Changelog:
  v1.17.1 2026-08-20  Real safety gap fixed: Stage [7/8]'s automatic
                      `ipam-db.py --import ... --type
                      CANONICAL-CUSTOM-OBJECTS` call ran unconditionally
                      on every non-dry-run invocation (opt-out via
                      --skip-custom-objects/--skip-ipam-import, not
                      opt-in) with zero confirmation prompt -- same
                      class of gap ipam-db.py v3.24.0 already closed for
                      its own auto-regeneration side effects. New
                      --yes/-y flag (default off); without it, Stage 7
                      now prints the target file, --type, and real row
                      count, then prompts "Import into ipam-db now?
                      [y/N]" before running ipam-db.py --import. 'n' (or
                      non-interactive stdin) cleanly skips stages 7-8,
                      same as --skip-ipam-import. Existing skip flags
                      unaffected -- they still bypass the prompt
                      entirely. PATCH: safety gate only, no schema or
                      output-file change.
  v1.13.0 2026-07-30  Real, confirmed production crash fixed:
                      KeyError: 'interfaces' at startup, every run.
                      Root cause: v1.12.0's load_route_db() rewrite
                      changed route_db_cache's structure (flat
                      {'interfaces':[...], 'routes':[...]} -> bucketed
                      {'iface_buckets':..., 'iface_broad':...,
                      'route_buckets':..., 'route_broad':...}) but
                      missed validate_route_via_db() -- a second,
                      independent consumer of the old flat structure
                      that v1.12.0's fix never touched or tested.
                      Confirmed via exhaustive grep for every
                      route_db_cache[...] access in the file this time
                      (not assumed complete from memory) -- found and
                      fixed 3 more stale references: validate_route_
                      via_db()'s two loops and the startup summary
                      print's interface/route counts.

                      validate_route_via_db() is called once per
                      ALREADY-KNOWN IPAM subnet in the main topology --
                      likely a LARGER real call volume than the
                      ~1,730-unmatched-subnet case v1.12.0 was built
                      to fix -- so it got the same /16-bucketed lookup,
                      not just a key-name patch. Verified two ways
                      against real fw_route_db.sqlite data before
                      shipping: (1) correctness -- 3,000 real queries,
                      0 mismatches vs. the original flat-scan logic;
                      (2) performance -- 32.1x speedup at that scale
                      (9.06s -> 0.28s).
  v1.12.0 2026-07-30  Real performance regression fixed: dry-run timed
                      out at 240s per check_toolset.py (2026-07-29 run),
                      which it had not done before. Root cause confirmed
                      via direct investigation, NOT a bug this version
                      introduces: fw_route_db.sqlite's real interface/
                      route counts grew substantially (build_fw_route_
                      db.py v0.7.0-v0.9.0 fixed real PA multi-device
                      misattribution AND added *_ROUTES.csv ingestion
                      filling a genuine FTD routing-data gap -- both
                      legitimately recover far more real data than
                      before, not a data regression). query_route_db_
                      knowledge() was an O(interfaces+routes) linear scan
                      per call, called ~1,730 times per real run --
                      fine at the old scale, not at several times it.
                      Fixed by bucketing load_route_db()'s interfaces/
                      routes by covering /16 at load time (see that
                      function's own v1.12.0 note for the full design
                      and correctness argument). Verified two ways
                      against real fw_route_db.sqlite data before
                      shipping: (1) correctness -- 576 real /24-scale
                      queries (the actual s24 calling pattern) produced
                      IDENTICAL results old vs new, 0 mismatches;
                      queries far broader than /16 (not a real usage
                      pattern here) can pick a different, equally-valid
                      tied answer among several rank-and-prefix-length-
                      identical candidates -- both old and new code
                      already had this exact ambiguity (arbitrary first-
                      in-iteration-order wins among true ties), bucketing
                      just changes iteration order, not which answers
                      are considered correct. (2) performance -- 27.7x
                      speedup measured on the real test database at the
                      documented ~1,730-call scale (34.0s -> 1.2s for
                      the query phase); production scale is larger than
                      this test data, so the real speedup is expected to
                      be at least this large.
  v1.11.0 2026-07-28  Two real bugs fixed, both confirmed against live
                      data, not theorized:
                      (1) SESSION_WEIGHT_SANITY_CAP added.
                      zscaler_traffic_5-22.csv.zip's 10,000 'aggregated'-
                      format rows summed to 10,949,637,225 total_sessions
                      -- confirmed by directly summing the real file's
                      total_sessions column, exact match to what this
                      script reported. ~44,000x every sibling file's total
                      (all 50K-300K), despite no single row individually
                      hitting the existing COUNTER_OVERFLOW_THRESHOLD
                      (4.3B) -- that guard catches single-row 32-bit
                      garbage, not an implausible-but-not-overflowed
                      per-row value repeated across an entire file. Rows
                      over the new 100K/row cap now clamp to weight=1
                      (still counted for CIDR-matching -- the row is real
                      evidence the src/dest pair exists -- just not
                      trusted as a session-count weight) and print a
                      per-file warning with the raw (untrusted) sum, so
                      this is visible rather than silently absorbed into
                      the connection totals.
                      (2) resolve_route_db_path() added, reading
                      fw_route_db.sqlite's actual path from ipam-db.json's
                      own registry instead of re-deriving a glob-based
                      guess. Confirmed live: ipam-db.py --list showed
                      fw_route_db_v20260727.sqlite correctly registered
                      (13,501 rows) the same day this script still
                      reported "not found." Root cause: fw_route_db.sqlite
                      is registered "(in-place)" -- ipam-db.py's
                      convention for large binary databases tracked by
                      reference, not copied into ipam-db/ the way small
                      CSVs are -- so the v1.7.1 glob (rooted at
                      <base>/ipam-db/) was solving the wrong problem: it
                      assumed a location "in-place" registration never
                      guaranteed. Falls back to the old glob if
                      ipam-db.json is missing/unreadable or lacks an
                      fw_route_db entry.
  v1.10.0 2026-07-24  fw_route_db.sqlite wired into the main topology's
                      route validation (ROUTE_VALIDATED/ROUTE_MISMATCH),
                      not just the unknown-subnet informational path it
                      was previously limited to. Added as a SECOND
                      confirming source alongside the existing FW_Routes/
                      export, unioned together -- either source
                      confirming a route counts as validated -- rather
                      than replacing FW_Routes/. New ROUTE_SOURCE column
                      (FW_ROUTES / ROUTE_DB / BOTH / blank) records which
                      source(s) actually contributed, added to both the
                      main topology CSV and the conflict report. Also
                      fixed a real, separate gating bug found while doing
                      this: the route-validation summary print was gated
                      on `if fw_route_index:` only, silently skipping the
                      entire summary whenever FW_Routes/ wasn't found
                      even when fw_route_db.sqlite was loaded and
                      validation still ran -- fixed to match the actual
                      validation logic's condition. New
                      validate_route_via_db() reuses logical_fw_route()
                      for device-name normalization rather than a new
                      mapping table, since fw_route_db.sqlite is built
                      from the same FW_CONFIGS/{ASA,FTD,PA} hostname
                      population FW_ROUTE_MAP already targets. KNOWN
                      LIMITATION, confirmed via direct testing: FW_ROUTE_
                      MAP only has 17 curated patterns (egress/DC-hub-
                      focused), vs. fw_route_db.sqlite's full ~498-device
                      population -- this integration only gains
                      visibility into route DB data for devices that
                      also match one of those 17 patterns, not the full
                      database. Real, useful for those devices; not a
                      full-coverage upgrade.
  v1.9.0  2026-07-23  Stages [7/8] and [8/8] added, extending the v1.8.0
                      auto-chain: after rebuilding custom objects (Stage 6),
                      automatically ipam-db.py --import the result as
                      CANONICAL-CUSTOM-OBJECTS (Stage 7), then run the full
                      build_object_pipeline.py (Stage 8), which rebuilds
                      NG/SO/UA/custom objects and the EDL catalog HTML.
                      Closes the exact gap that caused repeated confusion in
                      practice: build_custom_objects.py alone only writes a
                      CSV + EDL files — without the import and pipeline
                      steps, the catalog a person actually looks at in the
                      browser keeps showing stale data no matter how correct
                      the custom-objects build itself is. One command now
                      goes all the way from raw topology data to a rebuilt,
                      viewable catalog. Each stage is independently
                      skippable (--skip-ipam-import, --skip-object-pipeline)
                      and non-fatal — a failure at stage 6, 7, or 8 does not
                      affect this script's own exit code or the topology
                      outputs already written in stage 5. Note: stage 8 re-
                      runs build_custom_objects.py a second time as part of
                      build_object_pipeline.py's own Stage 0 (that
                      orchestrator always rebuilds all four Stage 0 object
                      classes together) — accepted as minor redundant work
                      in exchange for guaranteed consistency across the
                      whole object model, not just EGRESS_TRAFFIC.
  v1.8.0  2026-07-23  Stage [6/8] (originally [6/6]): auto-chain
                      build_custom_objects.py after writing the topology
                      CSV, so EGRESS_TRAFFIC objects rebuild every time this
                      script runs. Non-fatal. New --skip-custom-objects flag.
  v1.7.3  2026-07-22  DATA_QUALITY's PUBLIC-IP-NOT-OWNED path now cross-
                      references the real ip_dataset.py registry (52
                      registered datasets) instead of relying only on
                      is_public's blunt RFC1918/CGNAT check. Mirrors the
                      same fix just made in preprocess_p1.py (v2.11.1),
                      so both scripts agree on what "not ours" means:
                      new ENTERPRISE-tagged dataset match ->
                      ENTERPRISE-OWNED-NOT-IN-IPAM (a documented CVS/
                      Aetna asset that's public but somehow missing from
                      all_IP_networks -- a real data-quality signal, not
                      internet noise); threat-intel match -> new
                      THREAT_INTEL_HIT=Y column; any other provider
                      match -> new PROVIDER_MATCH column. QUALIFIED is
                      untouched -- stays purely traffic-source-derived,
                      same independence from DATA_QUALITY as before.
  v1.6.0  2026-07-22  Same-day dataset revisioning (vYYYYMMDD / vYYYYMMDDrN).
                      Root-caused a real incident: VERSION was always bare
                      f'v{TODAY}', so any same-day rerun of this script
                      silently overwrote unknown_ip_subnets_v{TODAY}.csv
                      (and every other dated output) with no trace of which
                      run produced the file on disk -- a v1.5.0 PUBLIC-IP
                      tagging fix looked "not present" downstream purely
                      because the file being read predated the fix, and the
                      only way to tell was filesystem mtime forensics, which
                      is not this platform's versioning discipline. New
                      _next_dataset_version() scans the output directories
                      for today's existing outputs and assigns the next
                      revision: first run of the day keeps the bare
                      vYYYYMMDD name, every subsequent run gets
                      vYYYYMMDDrN. VERSION is now resolved once in main()
                      before build_topology_rows() is called (all DATASET_
                      VERSION-stamped rows and all five output filenames use
                      the same resolved value). Downstream impact: none --
                      preprocess_p1.py's _find_fw_egress_unmatched_file()
                      already does sorted(glob(...))[-1], which correctly
                      picks the highest-revision file for same-date
                      lexicographic filenames (r2 < r3 < ... < r9; r10+
                      would break lexicographic sort -- flagged, not yet
                      hit in practice, fix if same-day rerun count ever
                      reaches double digits).
  v1.3.0  2026-07-14  Unknown-subnet harvest now carries TRAFFIC_SOURCE
                      (BOTH/ZSCALER/CS) + QUALIFIED (YES for BOTH/ZSCALER,
                      NO for CS-only), applying the same classification the
                      known-subnet path already used. CS-only unregistered
                      subnets are overwhelmingly external destinations, not
                      internal user subnets, so they are flagged QUALIFIED=NO
                      rather than counted as genuine discoveries. Qualified
                      rows now sort to the top. This makes unknown_ip_subnets
                      a valid NDM candidate source (filter QUALIFIED=YES).
  v1.2.3  2026-07-02  Add BGP-learned prefix exemptions: NO_ROUTE_EXPECTED
            replaces NO_ROUTE for CGNAT/cloud overlay (100.64.0.0/10),
            GCP (34.x/35.x), AWS (18.x/52.x), Akamai (23.x/104.x).
            Conflict report now excludes these from NO_ROUTE count.
            Summary adds "No route (BGP expected)" line.
  v1.2.2  2026-07-02  Next steps: use full path for ipam-db.py --import
            (topo_path/unknown_path not .name) — output files are in
            FW-Egress_Out/, not the working directory.
  v1.2.1  2026-07-02  Overview tab: three-level inline drill-down. FW row click expands
                      location list; location row click expands subnet list showing
                      CIDR, NET_TYPE, Source badge, Confidence badge, and Connections.
                      All expand/collapse inline — no modal. CSS transition animation.
  v1.2.0  2026-07-01  Add source-overlap analysis to HTML report.
                      New Overview tab shows Zscaler-only, CS-only, and
                      Zscaler+CS overlap subnet counts as stat cards plus
                      a per-FW breakdown table. Subnet modal gains a DATA_SOURCE
                      column (ZSCALER, CS, or BOTH). New TRAFFIC_SOURCE field
                      computed in build_topology_rows() from snapshot prefixes.
  v1.1.9  2026-07-01  Fix Zscaler zip ingestion: read ALL CSVs per zip, not just the first.
                      Previously, zf.read(csv_names[0]) silently dropped every CSV after
                      the first in any multi-CSV zip — connections from those files were
                      never counted. Zips with a single CSV are unaffected.
                      Also tightened __MACOSX filter from startswith() to 'not in' to match
                      the stronger filter already used in find_fw_route_files().
  v1.1.8  2026-06-30  Fix CS ingestion: accept 'firewall' column as fallback for 'dvc'.
                      CS exports from fwlookup.py/rule-match path use 'firewall' instead
                      of 'dvc'; prior code silently dropped all rows (0 source-IP rows).
                      Now: dvc = row.get('dvc') or row.get('firewall') — both formats work.
  v1.1.7  2026-06-24  Default output dirs changed from base/ to base/FW-Egress_Out/.
                      --out-ipam-dir and --out-report-dir still available for overrides.
  v1.1.6  2026-06-22  Fix LOCATION_FW_GROUND_TRUTH overrides:
                      - Corporate campus sites (Mount Prospect IL, Washington DC,
                        Wilkes-Barre PA, Pittsburgh PA, Buffalo Grove IL, etc.)
                        corrected from SHEA-DC-WIRELESS → SHEA-DC-EXT.
                      - CarePlus/Coram field sites: SHEA-DC-WIRELESS → SHEA-DC-EXT.
                      - Cloud - Azure Central US: CMC-HUB → CME-HUB-PROD.
                      - Cloud - AWS US-East2: SHEA-DC-WIRELESS → CME-HUB-PROD.
  v1.1.5  2026-06-22  Fix assert_fw() Internal-PBM inference:
                      - DataCenter LOCATION_TYPE now returns SHEA-DC-EXT for
                        Scottsdale/Shea locations; RI-ONE-SEC-DMZ for others.
                      - careplus/specialty/call-center/coram field sites now
                        correctly return SHEA-DC-EXT (not SHEA-DC-WIRELESS).
                      SHEA-DC-WIRELESS is only for wireless-specific subnets
                      confirmed via traffic logs, not a general Shea fallback.
  v1.1.4  2026-06-17  Fix: all outputs now write to base dir (./) by default.
                      Previously topology/unknown wrote to ipam-db/ and report
                      files wrote to processed_outputs/. --out-ipam-dir and
                      --out-report-dir args still available for overrides.
  v1.1.3  2026-06-17  Conflict report added.
                      fw_topology_conflicts_vDATE.csv in processed_outputs/
                      whenever route validation is active. Two conflict types:
                      ROUTE_MISMATCH (assigned FW has no route, different FW does)
                      and NO_ROUTE (no FW has a route to the subnet). Schema:
                      CONFLICT_TYPE, CIDR, SITE_CODE, CANONICAL_LOCATION,
                      ROUTING_DOMAIN, HERITAGE, LOCATION_TYPE, NET_TYPE,
                      ASSIGNED_FW, ROUTE_MATCH_FWS, MAPPING_METHOD, CONFIDENCE,
                      TRAFFIC_CONFIRMED, CONNECTIONS. Sorted ROUTE_MISMATCH first,
                      then by ASSIGNED_FW, then CIDR. Dry-run shows counts.
  v1.1.2  2026-06-17  Fix: load_fw_routes() now reads zip files directly.
  v1.1.0  2026-06-17  FW routing table validation pass added.
                      Reads *.csv from IP_Datasets_Raw/FW_Routes/ (auto-discover)
                      or explicit --fw-routes-dir. Extended FW_ROUTE_MAP maps 268
                      device names to 10 logical FWs (95% coverage). For each IPAM
                      CIDR, LPM against per-logical-FW route tables. Adds three
                      columns to topology output: ROUTE_VALIDATED (Y/N/NO_ROUTE),
                      ROUTE_MATCH_FWS (pipe-delimited logical FWs with a route),
                      ROUTE_MISMATCH (Y if assigned FW not in routing tables).
                      Mismatch summary printed at end of run.
                      --no-routes flag to skip validation pass.
  v1.0.0  2026-06-17  Initial unified build. Replaces six separate scripts.
"""

__version__ = '1.17.1'
# v1.17.1  2026-08-20  Real safety gap fixed: Stage [7/8]'s automatic
# `ipam-db.py --import ... --type CANONICAL-CUSTOM-OBJECTS` call ran
# unconditionally on every non-dry-run invocation (opt-out via
# --skip-custom-objects/--skip-ipam-import, not opt-in) with zero
# confirmation prompt -- same class of gap ipam-db.py v3.24.0 already
# closed for its own auto-regeneration side effects (silently
# auto-regenerating ip_classification extracts on every all_IP_networks
# import turned into an explicit, confirmed step, per direct operator
# feedback that silent auto-regen made changes impossible to review
# before the previous version was overwritten). New --yes/-y flag
# (default off); without it, Stage 7 now prints the target file, the
# exact command, and a real row count (new _quick_row_count() helper,
# uses the same csv.field_size_limit(10_000_000) already set at module
# load -- mirrors the fix applied to ipam-db.py's own count_rows() in
# v3.27.1 for the identical class of problem, rather than reintroducing
# it here), then prompts "Import into ipam-db now? [y/N]" before
# subprocess.run() on ipam-db.py --import. Non-interactive stdin with no
# --yes is treated as "no" -- fails safe, stages 7-8 skipped cleanly,
# same as --skip-ipam-import; topology outputs from stages 1-6
# unaffected either way. Existing skip flags unaffected -- they still
# bypass the prompt entirely. PATCH: safety gate only, no schema or
# output-file change.
# v1.17.0  2026-08-20  Real, confirmed operational gap: zero live progress
# feedback anywhere in this script, and zero Ctrl-C handling. Confirmed
# real impact: a real live run went silent for 8+ minutes inside the main
# per-subnet topology loop -- v1.16.0's retail_networks merge made that
# loop process 319,739 rows instead of 25,396 (12.6x more) -- and was
# interrupted, reasonably assumed hung given zero indication otherwise.
# Fixed: new _progress_bar()/_Heartbeat (same proven pattern already
# delivered in build_external_ip_registry.py v2.4.4) applied to the real
# loop where this happened; top-level try/except KeyboardInterrupt around
# the real entry point gives a clean, informative exit (code 130) instead
# of a raw traceback. Verified with a real functional test: progress bar
# fires correctly through a real build_topology_rows() run, output
# unaffected; _Heartbeat starts/stops cleanly standalone.
# v1.16.0  2026-08-20  Real, confirmed gap fixed: retail_networks.csv was
# never an input to this script at all -- confirmed by grep (zero
# references to retail_entries/retail_path anywhere before this fix) and
# by the platform owner directly. This is the real, structural reason
# "Retail" never once appeared as a NET_TYPE anywhere in the topology
# output -- not a Zscaler/CrowdStrike visibility gap, not SD-WAN local
# breakout (both real hypotheses raised and checked this session before
# finding the actual, simple cause). New load_retail() wraps load_ipam()
# unchanged and normalizes retail_networks' OWNER field to HERITAGE (the
# two fields carry the same real semantic content -- CVS/AETNA/etc -- just
# under different column names in the two datasets), so the existing,
# already-validated (LOCATION, HERITAGE) + /16-sibling + route-evidence
# inference pipeline works identically for retail rows with no change to
# that pipeline itself. New --retail CLI flag, auto-discovers from
# <base>/ipam-db/ by default like --ipam already does. Verified with a
# real functional test: retail_networks' real schema (OWNER=CVS) loads
# and correctly normalizes to HERITAGE=CVS.
# v1.15.0  2026-08-19  Real, validated /16-sibling disambiguation added as
# a new tier, between (LOCATION,HERITAGE)+ROUTE and AMBIGUOUS: when a real
# tie remains after those two, check whether real /16-sibling confirmed
# traffic (from OTHER subnets in the same /16, at any location) narrows it
# to exactly one real answer. NOT the same pattern this platform already
# rejected once (sibling-/16 LOCATION inference) -- location here is
# already real and confirmed via IPAM; /16-sibling evidence only breaks a
# tie among already-known candidates at that known location. Validated
# against the real 2026-08-19 production topology before shipping:
# resolves 4,430 of 17,778 genuinely tied CIDRs (24.9%), spot-checked
# against real cases with genuine independent corroboration from a
# different physical site (e.g. Oklahoma City OK - Corporate confirming
# RI-ONE-SEC-DMZ for Phoenix AZ subnets in the same real 10.8.0.0/16).
# v1.14.0  2026-08-19  Real fix for the confirmed multi-egress-candidate
# ambiguity problem (see cvs-aetna-ip-prefix-allocations skill and this
# session's real investigation): the old LOCATION-CONFIRMED fallback keyed
# purely on CANONICAL_LOCATION, pooling ALL egress firewalls ever confirmed
# for ANY subnet at a shared physical site -- confirmed live, this produced
# false ties (e.g. 2.1.1.0/24, a CVS subnet at Shea DC, inheriting Aetna's
# dedicated MDC-Middletown/WDC-Windsor split as "candidates," which by the
# platform owner's own real business rule should never apply to a CVS
# subnet). Three real changes:
#   1. HERITAGE threaded through the confirmed-traffic pipeline (was loaded
#      from IPAM rows at both _add_to_confirmed() call sites but discarded
#      before this fix -- same class of bug as this session's build_
#      external_ip_registry.py HERITAGE/CANONICAL_LOCATION fixes).
#   2. loc_fw_confirmed's key narrowed from LOCATION alone to (LOCATION,
#      HERITAGE) as the primary lookup, with the broader LOCATION-only
#      lookup kept as a secondary fallback. Validated against real
#      confirmed-traffic data before shipping: AETNA-CallCenter 99% MID/WIN
#      split, Distribution 97% RI, Omnicare 87% RI, Specialty 93% Shea,
#      CarePlus/Mail-Order 100% Shea -- HERITAGE is a real, evidence-backed
#      disambiguating signal at this step, not a guess.
#   3. Real route-table evidence (already computed elsewhere in this loop
#      for the ROUTE_VALIDATED columns) now also used for tie-breaking:
#      when it narrows an otherwise-tied candidate set to exactly one real
#      match, that takes priority (MEDIUM confidence, method tagged
#      +ROUTE). Measured against the real pre-fix tie population: only
#      102 of 18,687 genuinely tied CIDRs (0.5%) resolve this way -- a
#      real but small contribution, checked and reported honestly rather
#      than oversold.
# Deliberately NOT done: NET_TYPE/business-character pattern inference
# (e.g. "Distribution/Omnicare -> RI, Specialty family -> Shea") to
# resolve whatever's still tied after (LOCATION, HERITAGE) narrowing.
# Tried by hand this session and correctly rejected once checked against
# real data: Coram is tagged NET_TYPE=Omnicare but its real confirmed
# traffic behaves like Specialty instead -- a confident rule here would
# have been confidently wrong for a real, non-trivial case. Instead,
# genuine remaining ties are tagged LOCATION-HERITAGE-AMBIGUOUS and
# persisted to a new first-class dataset, known_ambiguous_egress, using
# the exact same real discipline build_known_unknown_ip_resolver.py
# already established for unknown subnets: don't guess, persist, and
# let future runs (more real Zscaler/CrowdStrike traffic) resolve more
# of the population over time rather than re-deriving or guessing now.
# v1.9.0  2026-07-23  Stages [7/8]/[8/8]: auto ipam-db --import + full
# build_object_pipeline.py run after Stage 6 builds custom objects, so one
# command goes topology -> custom objects -> ipam import -> rebuilt catalog.
# See docstring changelog above for full detail.
# v1.8.0  2026-07-23  Stage [6/8]: auto-chain build_custom_objects.py.
# v1.7.3  2026-07-22  Cross-reference DATA_QUALITY's public-IP path
# against the real ip_dataset.py registry (52 registered datasets:
# cloud/SaaS/CDN/partner/ISP/threat-intel), not just is_public's blunt
# "not RFC1918, not CGNAT" check. Mirrors the identical fix just made in
# preprocess_p1.py v2.11.1 -- same real, confirmed gap: an audit of the
# real 382-row p1_public_ip_flagged_20260722.csv found 99 hosts (26%)
# that were already known CVS/Aetna enterprise assets in
# ent-ipdataset-ENTERPRISE-APP-SERVER, incorrectly treated as unowned
# public space by both scripts because neither checked that dataset.
# New load_ip_dataset_index()/classify_ip_dataset_match() (identical
# logic to preprocess_p1.py's, duplicated rather than cross-imported --
# matches this platform's existing convention of scripts referencing
# each other's data files, not each other's Python internals, same as
# _BGP_LEARNED/KNOWN_PUBLIC_RANGES already being intentionally mirrored):
#   - ENTERPRISE-tagged dataset match -> DATA_QUALITY becomes
#     'ENTERPRISE-OWNED-NOT-IN-IPAM' instead of 'PUBLIC-IP-NOT-OWNED' --
#     this is a real, distinct signal (a documented CVS/Aetna asset that
#     somehow isn't in all_IP_networks yet), not internet noise, and
#     should NOT be excluded from preprocess_p1.py's IPAM-candidate
#     generation the way genuine public noise is.
#   - threat-intel dataset match (tor-exit-nodes/feodo-tracker/spamhaus-
#     drop/emerging-threats-compromised) -> new THREAT_INTEL_HIT=Y
#     column, DATA_QUALITY stays PUBLIC-IP-NOT-OWNED.
#   - any other provider match (cloud/SaaS/CDN/partner/ISP) -> new
#     PROVIDER_MATCH column records which dataset(s) hit, DATA_QUALITY
#     stays PUBLIC-IP-NOT-OWNED.
# QUALIFIED is intentionally untouched by any of this -- it's derived
# purely from TRAFFIC_SOURCE (BOTH/ZSCALER = YES, CS-only/NONE = NO) and
# stays independent of DATA_QUALITY, same as before this change. (Note
# for the record: the QUALIFIED=YES / DATA_QUALITY=PUBLIC-IP-NOT-OWNED
# combination seen on real rows like 63.239.39.0/24 is not a bug -- the
# two fields measure different things by design, confirmed by re-reading
# this code during the ip_dataset.py integration work.)
# New --ipdatasets-dir CLI arg, default <base>/ipdatasets/ (mirrors
# --ipam-dir's default pattern). Degrades gracefully: missing
# ipdatasets/ or ip_dataset.json leaves PROVIDER_MATCH/THREAT_INTEL_HIT
# blank and DATA_QUALITY computed exactly as before -- additive, not a
# hard dependency.
# v1.7.2  2026-07-22  Real performance bug fixed, found by Michael
# actually running this against his real data (I did not catch it
# myself before shipping -- see the docstring on load_route_db() for
# the full accounting). query_route_db_knowledge() re-ran two fresh SQL
# queries and re-parsed every CIDR string from scratch on EVERY one of
# 1,730 unmatched-subnet calls -- ~22 million redundant
# ipaddress.ip_network() constructions plus 3,460 SQL fetches, with zero
# progress output in between, indistinguishable from a hang. load_
# route_db() now parses fw_interfaces/fw_routes into an in-memory cache
# ONCE; query_route_db_knowledge() does pure Python iteration over
# already-parsed objects per call, no DB round trip. Also added an
# early-exit once an exact match at the query's own prefix length is
# found (can't improve on that). route_db_conn renamed to route_db_
# cache throughout, since it's no longer a live connection.
# Verified against the real fw_route_db.sqlite (251 devices, 919
# interfaces, 11,883 routes -> 12,802 total, ~10,867 after the /8+
# catch-all filter) at the real 1,730-subnet/run volume -- see delivery
# notes for the actual benchmark numbers.
# v1.7.1  2026-07-22  Real bug fixed, caught by Michael running the
# actual tool, not by inspection: fw_route_db auto-discovery only
# checked the bare 'fw_route_db.sqlite' filename. build_fw_route_db.py's
# own v0.3.0 changelog documents that a properly-registered file (via
# ipam-db.py --import ... --type fw_route_db) gets a versioned name
# (fw_route_db_vYYYYMMDD.sqlite) -- so auto-discovery would silently
# report "not found" even after correct registration through the
# platform's own standard workflow. Same class of bare-vs-versioned
# filename mismatch already hit this session with retail_networks
# (v2.9 vs v2.10). Now globs 'fw_route_db*.sqlite' via this script's
# own find_latest() (mtime-based sort, already safe -- not the
# lexicographic string sort that caused the retail_networks bug).
# v1.7.0  2026-07-22  Three additions to unknown_ip_subnets output,
# directly requested by Michael:
#   1. CLOSEST_IPAM_CIDR/DISTANCE_24S/LOCATION/ROUTING_DOMAIN/HERITAGE --
#      new find_closest_ipam_match(), an UNCAPPED nearest-neighbor search
#      against every registered IPAM network, unlike preprocess_p1.py's
#      Tier 0 (/24 Adjacency) which stops after 4 slots. Always returns
#      the true closest registered network, however far -- a large
#      distance is itself a real signal (this address space may be
#      genuinely new to CVS/Aetna). Verified against the real 25,464-row
#      IPAM: the known 192.169.234.0/24 Tier-3 false-positive case now
#      honestly reports its true closest match at distance 235 slots,
#      instead of the old sibling-count heuristic's misleading "Cumberland
#      RI" claim. Benchmarked at the real 1,730-subnet/run volume: 10.83s
#      total -- acceptable for a multi-minute batch run, no index needed
#      at this scale.
#   2. ROUTE_DB_RELATIONSHIP/MATCH_CIDR/MATCH_DEVICE/COVERAGE_NOTE -- new
#      load_route_db()/query_route_db_knowledge(), querying
#      fw_route_db.sqlite (real, parsed-from-device-config routes/
#      interfaces) for genuine egress routing evidence on unregistered
#      subnets. Self-contained reimplementation of fw_route_db.py's
#      already-tested exact/subset/covers/overlaps relationship logic,
#      not a cross-file import -- matches this platform's convention of
#      tools referencing each other's data files, not each other's
#      Python internals. CRITICAL, stated in-code and in every output
#      row: fw_route_db.sqlite is a partial collection (251 of an
#      estimated ~440 devices as of 2026-07-22) -- "NO-EVIDENCE-YET" is
#      the correct default relationship value, never silently upgraded
#      to "confirmed unrouted." Verified against the real database and
#      the exact examples already validated this session (12.46.112.128/25
#      -> exact match on PAZSHDC-SEC-PAN-PROD-01; the known phantom
#      examples 2.1.1.0/24 and 11.1.21.128/25 -> correctly None).
#   3. FIRST_SEEN/LAST_SEEN/RUNS_SEEN/RUNS_SINCE_FIRST_SEEN/CONSISTENCY_PCT
#      -- new load_unknown_subnet_history()/compute_subnet_history(),
#      scanning every unknown_ip_subnets_v*.csv still on disk (not just
#      latest) and joining by SOURCE_SUBNET. Same-day reruns (vYYYYMMDDrN)
#      correctly count as ONE calendar day, not N. Depends entirely on
#      prior dated output files still existing -- the v1.6.0 same-day
#      revisioning fix means different days were already never
#      overwriting each other, so history has been silently accumulating
#      since whenever this script started being run, IF those files
#      haven't been deleted. Cold-start (no prior files) correctly
#      degrades to FIRST_SEEN=today/RUNS_SEEN=1 for everything, not an
#      error. Verified with a simulated multi-day, same-day-rerun
#      scenario covering persistent/transient/brand-new subnet cases.
# v1.6.0  2026-07-22  Same-day dataset revisioning (vYYYYMMDD / vYYYYMMDDrN)
# -- see module docstring Changelog above for the full incident writeup.
# Short version: VERSION was always bare f'v{TODAY}', so same-day reruns
# silently clobbered the prior run's dated outputs with no audit trail,
# which is exactly how a v1.5.0 tagging fix became indistinguishable from
# "never ran" downstream. _next_dataset_version() now scans out_ipam/
# out_report for today's existing outputs and assigns the next revision
# (bare vYYYYMMDD for the day's first run, vYYYYMMDDrN thereafter).
# v1.5.0  2026-07-22  DATA_QUALITY now distinguishes public-IP sources
# ('PUBLIC-IP-NOT-OWNED') from genuine unregistered internal subnets
# ('UNREGISTERED-IN-IPAM'). Real, confirmed finding: 1,715 of 1,730 rows
# (99.1%) in a real run had a public (non-RFC1918, non-CGNAT)
# SOURCE_SUBNET, and 1,713 of those (99.9%) funneled through a single
# DMZ firewall (RI-ONE-SEC-DMZ) -- a random internet client connecting
# INBOUND to a public-facing service, not an internal enterprise device
# that needs eventual IPAM registration. The ingestion logic treats
# every 'sources' value the same regardless of traffic direction, which
# is correct for outbound egress traffic but wrong for inbound DMZ
# traffic. A public IP already registered in all_IP_networks (a real
# owned block, e.g. Aetna's 167.69.x.x) is unaffected -- it's already
# routed to _add_to_confirmed() via the existing lpm() check before ever
# reaching this classification, so every row here, by construction, has
# no existing IPAM ownership. Rows are NOT dropped -- still fully
# visible for review -- just tagged distinctly so downstream consumers
# (preprocess_p1.py) can exclude genuine internet noise from
# internal-subnet candidate generation without losing visibility into it.
# Verified: real tagging logic against the actual uploaded
# unknown_ip_subnets_v20260722.csv produces exactly 1,715 PUBLIC-IP-NOT-OWNED
# / 15 UNREGISTERED-IN-IPAM, matching the confirmed real count precisely.
# v1.4.0  2026-07-21  find_zscaler_zips() now also discovers bare .csv
# Zscaler exports, not just .zip archives -- confirmed real gap: two bare
# CSVs (zscaler-2.csv, zscaler-DS-6-24.csv) were being silently skipped
# by the old '*.zip'-only glob. Initially suspected this explained the
# ~99% CS-only/QUALIFIED=NO skew seen in unknown_ip_subnets_*.csv, but
# checking the actual content disproved that: both bare CSVs turned out
# to have connection counts EXACTLY matching an identically-named .zip
# counterpart already being ingested -- confirmed duplicates, not new
# data. Naively including them would have double-counted, so
# find_zscaler_zips() now excludes a bare CSV when a same-named .zip
# exists, and only includes genuinely-unique bare CSVs (no zip
# counterpart). Net effect on this real drop: discovery still finds the
# same 23 files as before -- this fix protects future drops from
# silently dropping a genuinely new bare-CSV export, but is NOT the
# explanation for the CS-only skew, which remains open.

import argparse
import bisect
import collections
import csv
import datetime
import glob
import io
import ipaddress
import itertools
import json
import os
import re
import sqlite3
import subprocess
import sys
import zipfile
from datetime import date
from pathlib import Path

csv.field_size_limit(10_000_000)

TODAY       = date.today().strftime('%Y%m%d')
VERSION     = f'v{TODAY}'   # fallback default for library/import use;
                            # main() overrides this via _next_dataset_version()
                            # before any output is built or written.
SCRIPT_NAME = f'build_IP_Network_Egress_FW_topology.py v{__version__}'


def _next_dataset_version(out_dirs, today):
    """Resolve the DATASET_VERSION/filename stamp for this run, following
    the platform's vYYYYMMDD / vYYYYMMDDrN same-day revision discipline.

    v1.6.0. Scans every directory in out_dirs for this script's own
    previously-written output files already stamped with today's date
    (ent-ipdataset-EGRESS-FW-TOPOLOGY-vDATE*.csv, unknown_ip_subnets_
    vDATE*.csv, fw_egress_breakdown_vDATE*.csv/.html,
    fw_topology_conflicts_vDATE*.csv) and returns the next revision, so a
    same-day rerun never silently overwrites a prior run's output -- every
    run of the day is its own distinct, auditable, restorable file.

    Bare v{today} counts as revision 1 (the documented "first version on
    that date"). The first rerun becomes r2, matching Rule 3 of the
    versioning skill literally: "vYYYYMMDDrN -- revision N on date
    YYYYMMDD". Directories that don't exist yet (first run ever) are
    skipped, not an error.
    """
    rev_pattern = re.compile(rf'v{today}(?:r(\d+))?(?!\d)')
    max_rev = 0
    seen_dirs = set()
    for d in out_dirs:
        d = Path(d).resolve()
        if d in seen_dirs or not d.exists():
            continue
        seen_dirs.add(d)
        for f in d.iterdir():
            if not f.is_file():
                continue
            m = rev_pattern.search(f.name)
            if not m:
                continue
            rev = int(m.group(1)) if m.group(1) else 1
            max_rev = max(max_rev, rev)
    next_rev = max_rev + 1
    return f'v{today}' if next_rev <= 1 else f'v{today}r{next_rev}'

# ── BGP-learned prefix exemptions ────────────────────────────────────────────
# These prefixes are reachable via BGP (cloud peering, CDN, SD-WAN overlay)
# and will never appear in FW static route tables. Mark as NO_ROUTE_EXPECTED
# rather than NO_ROUTE to avoid false-positive conflict reporting.
# RFC 6598 CGNAT (100.64.0.0/10) is repurposed as cloud overlay space in
# CVS/Aetna GCP and Azure environments due to RFC1918 exhaustion.
_BGP_LEARNED = [
    ipaddress.ip_network('100.64.0.0/10'),   # CGNAT/cloud overlay (RFC 6598)
    ipaddress.ip_network('34.0.0.0/8'),       # GCP public
    ipaddress.ip_network('35.0.0.0/8'),       # GCP public
    ipaddress.ip_network('18.0.0.0/8'),       # AWS public
    ipaddress.ip_network('52.0.0.0/8'),       # AWS/Azure public
    ipaddress.ip_network('23.0.0.0/8'),       # Akamai/CDN overlay
    ipaddress.ip_network('104.0.0.0/8'),      # GCP/Akamai public
]

def _is_bgp_learned(cidr_str):
    """Return True if CIDR is a known BGP-learned prefix (not in static route tables)."""
    try:
        net = ipaddress.ip_network(cidr_str, strict=False)
        addr = net.network_address
        return any(addr in bgp_net for bgp_net in _BGP_LEARNED)
    except ValueError:
        return False


# ── ip_dataset.py registry cross-reference ──────────────────────────────────
# v1.7.3. _BGP_LEARNED above is a small hand-maintained /8-level allowlist
# used for NO_ROUTE_EXPECTED marking; the PUBLIC-IP-NOT-OWNED classification
# below has historically used an even blunter check (just "not RFC1918, not
# CGNAT"). Neither has any idea about CVS's own registered public-facing
# enterprise assets (ent-ipdataset-ENTERPRISE-APP-SERVER, tracked in
# ip_dataset.py, not all_IP_networks) or the other 50 datasets ip_dataset.py
# already tracks. This mirrors preprocess_p1.py v2.11.1's identical
# functions -- duplicated deliberately, not cross-imported, matching this
# platform's existing convention (see _BGP_LEARNED/KNOWN_PUBLIC_RANGES).
IP_DATASET_ENTERPRISE_TAG = 'ENTERPRISE'
IP_DATASET_THREAT_STEMS = {
    'tor-exit-nodes', 'feodo-tracker', 'spamhaus-drop',
    'emerging-threats-compromised',
}


def load_ip_dataset_index(ipdatasets_dir):
    """Load ip_dataset.py's registry (ip_dataset.json) + every registered
    dataset's CIDR column into per-stem sorted interval lists with
    prefix-max-hi arrays for fast containment lookup.

    Returns {} if the directory/registry is unavailable or unreadable --
    callers must treat an empty index as 'no information available', not
    'no provider matches this IP', and fall back to prior behavior.
    """
    reg_path = os.path.join(ipdatasets_dir, 'ip_dataset.json')
    if not os.path.isfile(reg_path):
        return {}
    try:
        with open(reg_path) as f:
            reg = json.load(f)
    except Exception:
        return {}
    index = {}
    for stem, meta in reg.get('datasets', {}).items():
        fpath = os.path.join(ipdatasets_dir, meta.get('filename', ''))
        col = meta.get('cidr_col', 'IP_NETWORK')
        if not os.path.isfile(fpath):
            continue
        intervals = []
        try:
            with open(fpath, newline='', encoding='utf-8', errors='replace') as f:
                first = f.readline()
                while first.startswith('#'):
                    first = f.readline()
                fieldnames = [c.strip() for c in first.strip().split(',')]
                col_use = col if col in fieldnames else next(
                    (c for c in fieldnames if c.lower() == col.lower()), None)
                if not col_use:
                    continue
                for row in csv.DictReader(f, fieldnames=fieldnames):
                    val = (row.get(col_use) or '').strip()
                    if not val:
                        continue
                    try:
                        net = ipaddress.ip_network(val, strict=False)
                        if net.version != 4:
                            continue
                        intervals.append((int(net.network_address),
                                           int(net.broadcast_address)))
                    except Exception:
                        continue
        except Exception:
            continue
        if not intervals:
            continue
        intervals.sort()
        los = [x[0] for x in intervals]
        his = [x[1] for x in intervals]
        pmax, m = [], -1
        for h in his:
            m = max(m, h)
            pmax.append(m)
        index[stem] = {
            'los': los, 'his': his, 'pmax': pmax,
            'tags': meta.get('tags', []),
            'provider': meta.get('provider', stem),
        }
    return index


def classify_ip_dataset_match(ip_str, ip_dataset_index):
    """Cross-reference ip_str against every loaded ip_dataset.py dataset.

    Returns (is_enterprise_owned: bool, provider_match: str,
    is_threat_intel_hit: bool). Empty index returns (False, '', False)
    for every IP -- this must be read as 'no information', not 'checked,
    no match found'.
    """
    if not ip_dataset_index:
        return False, '', False
    try:
        ip_int = int(ipaddress.ip_address(ip_str.strip()))
    except Exception:
        return False, '', False
    is_enterprise = False
    is_threat = False
    matches = []
    for stem, d in ip_dataset_index.items():
        los, his, pmax = d['los'], d['his'], d['pmax']
        idx = bisect.bisect_right(los, ip_int)
        if idx == 0:
            continue
        if pmax[idx - 1] < ip_int:
            continue
        i = idx - 1
        found = False
        while i >= 0:
            if los[i] <= ip_int <= his[i]:
                found = True
                break
            if pmax[i] < ip_int:
                break
            i -= 1
        if not found:
            continue
        matches.append(stem)
        if IP_DATASET_ENTERPRISE_TAG in d['tags']:
            is_enterprise = True
        if stem in IP_DATASET_THREAT_STEMS:
            is_threat = True
    return is_enterprise, '|'.join(sorted(matches)), is_threat


# ── Counter overflow guard ────────────────────────────────────────────────────
# Zscaler counters are 32-bit unsigned — rollover artifacts >= 2^32 are discarded.
COUNTER_OVERFLOW_THRESHOLD = 4_294_967_296
# v1.11.0: SESSION_WEIGHT_SANITY_CAP added -- COUNTER_OVERFLOW_THRESHOLD alone
# doesn't catch a real incident: zscaler_traffic_5-22.csv.zip (10,000
# 'aggregated'-format rows) summed to 10,949,637,225 total_sessions --
# ~44,000x every sibling file's total (50K-300K), despite no single row
# individually overflowing 32 bits (average ~1.09M sessions/row, nowhere
# near 4.3B). Verified directly against the real uploaded file: SUM(
# total_sessions) across all 10,000 rows reproduces the exact 10,949,637,225
# figure this script reported -- confirmed root cause, not a guess. Every
# other Zscaler export in the same collection tops out in the low hundreds
# of thousands total, so a single src/dest pair claiming >100K sessions in
# one collection window is already far outside that family and treated as
# untrustworthy, not a legitimate heavy-traffic outlier.
SESSION_WEIGHT_SANITY_CAP = 100_000

# ── FW logical name mappings ──────────────────────────────────────────────────
FW_LOGICAL_MAP = [
    (r'cme-fw-hubprod',      'CME-HUB-PROD'),
    (r'cme-fw-nonprod',      'CME-HUB-NONPROD'),
    (r'cmc-fw-hub',          'CMC-HUB'),
    (r'rriwscp',             'RI-ONE-SEC-DMZ'),
    (r'win-fw-glr',          'WDC-Windsor'),
    (r'pazshdc-sec-extwir',  'SHEA-DC-WIRELESS'),
    (r'pazshdc-sec-ext-net', 'SHEA-DC-EXT'),
    (r'mid-fw-glr',          'MDC-Middletown'),
    (r'mid-fw-office',       'MDC-Office'),
    (r'lgs1501',             'LAS-VEGAS-COLO'),
]

KNOWN_LOGICAL_FWS = {name for _, name in FW_LOGICAL_MAP}

FW_CLUSTER_MAP = {
    'CME-HUB-PROD':     'cme-fw-hubprodglr',
    'CME-HUB-NONPROD':  'cme-fw-nonprodglr',
    'CMC-HUB':          'cmc-fw-hubprodglr',
    'RI-ONE-SEC-DMZ':   'RRIWSCP-SEC-EXT-EMPTEMP-PA',
    'WDC-Windsor':      'win-fw-glr-pa',
    'SHEA-DC-WIRELESS': 'PAZSHDC-SEC-EXTWIR-PA',
    'SHEA-DC-EXT':      'PAZSHDC-SEC-EXT-NET-PA',
    'MDC-Middletown':   'mid-fw-glr-pa',
    'MDC-Office':       'mid-fw-officeext-pa',
    'LAS-VEGAS-COLO':   'lgs1501-ext-pa-fw',
}

FW_PA_DG_MAP = {
    'CME-HUB-PROD':     'CME-HUB-PROD-DG',
    'CME-HUB-NONPROD':  'CME-HUB-NONPROD-DG',
    'CMC-HUB':          'CMC-HUB-DG',
    'RI-ONE-SEC-DMZ':   'RRIWSCP-SEC-EXT-DG',
    'WDC-Windsor':      'WIN-FW-GLR-DG',
    'SHEA-DC-WIRELESS': 'PAZSHDC-EXTWIR-DG',
    'SHEA-DC-EXT':      'PAZSHDC-EXT-NET-DG',
    'MDC-Middletown':   'MID-FW-GLR-DG',
    'MDC-Office':       'MID-FW-OFFICE-DG',
    'LAS-VEGAS-COLO':   'LGS-COLO-DG',
}

FW_ORDER = [
    'RI-ONE-SEC-DMZ', 'MDC-Middletown', 'WDC-Windsor', 'SHEA-DC-WIRELESS',
    'CME-HUB-PROD', 'CME-HUB-NONPROD', 'SHEA-DC-EXT', 'LAS-VEGAS-COLO',
    'MDC-Office', 'CMC-HUB',
]

# ── FW route device → logical FW map (extended for routing table devices) ─────
# Covers all egress-relevant PA/FTD devices seen in FW_Routes exports.
# Internal-only devices (VPN concentrators, CTE, Omnicare MPLS, etc.) are
# intentionally omitted — they are not internet egress firewalls.
FW_ROUTE_MAP = [
    (r'cme-fw-hubprod',        'CME-HUB-PROD'),
    (r'cme-fw-nonprod',        'CME-HUB-NONPROD'),
    (r'cmc-fw-hub',            'CMC-HUB'),
    (r'rriwscp',               'RI-ONE-SEC-DMZ'),
    (r'rriwsdc-sec-ext',       'RI-ONE-SEC-DMZ'),
    (r'win-fw-glr',            'WDC-Windsor'),
    (r'win-fw-cvs',            'WDC-Windsor'),
    (r'win-fw-edmz',           'WDC-Windsor'),
    (r'win-fw-dmz',            'WDC-Windsor'),
    (r'pazshdc-sec-extwir',    'SHEA-DC-WIRELESS'),
    (r'pazshdc-sec-ext-net',   'SHEA-DC-EXT'),
    (r'pazshdc-sec-extftd',    'SHEA-DC-EXT'),
    (r'pazshdc-sec-ext',       'SHEA-DC-EXT'),
    (r'mid-fw-glr',            'MDC-Middletown'),
    (r'mid-fw-office',         'MDC-Office'),
    (r'mid-fw-cvs',            'MDC-Middletown'),
    (r'mid-fw-edmz',           'MDC-Middletown'),
    (r'mid-fw-dmz',            'MDC-Middletown'),
    (r'mid-fw-equinix',        'MDC-Middletown'),
    (r'lgs1501',               'LAS-VEGAS-COLO'),
]


def logical_fw_route(raw_name):
    """Map FW device name from routing table to logical FW identifier."""
    raw = raw_name.lower().strip()
    for pattern, name in FW_ROUTE_MAP:
        if re.search(pattern, raw):
            return name
    return ''


def find_fw_route_files(fw_routes_dir):
    """Find FW route data — CSVs directly, or inside zip files.
    Returns list of (path, is_zip) tuples.
    Searches top-level and one subdirectory deep.
    """
    results = []
    # Direct CSVs
    for pattern in [
        os.path.join(fw_routes_dir, '*.csv'),
        os.path.join(fw_routes_dir, '*', '*.csv'),
    ]:
        for f in sorted(glob.glob(pattern)):
            if '__MACOSX' not in f:
                results.append((f, False))

    # Zip files containing CSVs
    for pattern in [
        os.path.join(fw_routes_dir, '*.zip'),
        os.path.join(fw_routes_dir, '*', '*.zip'),
    ]:
        for f in sorted(glob.glob(pattern)):
            if '__MACOSX' not in f:
                results.append((f, True))

    return results


def load_fw_routes(fw_routes_dir):
    """Load FW routing tables from CSVs or zips in fw_routes_dir.
    Returns (fw_route_index, total_loaded).
    """
    sources = find_fw_route_files(fw_routes_dir)
    if not sources:
        return {}, 0

    fw_nets_raw = collections.defaultdict(set)
    total_loaded = 0

    def _process_fh(fh, source_name):
        nonlocal total_loaded
        reader = csv.DictReader(fh)
        for row in reader:
            name    = row.get('name', '').strip()
            network = row.get('network', '').strip()
            rtype   = row.get('type', '').strip().lower()
            if not name or not network:
                continue
            if network in ('0.0.0.0/0', '::/0'):
                continue
            if rtype not in ('connected', 'static', 'rib'):
                continue
            lfw = logical_fw_route(name)
            if not lfw:
                continue
            try:
                ipaddress.ip_network(network, strict=False)
                fw_nets_raw[lfw].add(network)
                total_loaded += 1
            except ValueError:
                continue

    for source_path, is_zip in sources:
        try:
            if is_zip:
                with zipfile.ZipFile(source_path) as zf:
                    csv_names = [n for n in zf.namelist()
                                 if n.endswith('.csv') and '__MACOSX' not in n]
                    for csv_name in csv_names:
                        raw = zf.read(csv_name)
                        fh  = io.TextIOWrapper(io.BytesIO(raw), encoding='utf-8-sig')
                        _process_fh(fh, csv_name)
            else:
                with open(source_path, encoding='utf-8-sig', errors='replace') as fh:
                    _process_fh(fh, source_path)
        except Exception as e:
            print(f'  [WARN] Could not read {os.path.basename(source_path)}: {e}')

    fw_route_index = {}
    for lfw, nets in fw_nets_raw.items():
        parsed = []
        for n in nets:
            try:
                parsed.append(ipaddress.ip_network(n, strict=False))
            except ValueError:
                continue
        parsed.sort(key=lambda x: x.prefixlen, reverse=True)
        fw_route_index[lfw] = parsed

    return fw_route_index, total_loaded


def validate_route(cidr, fw_route_index):
    """Return set of logical FWs that have a route to the given CIDR.
    Uses LPM: a FW has a route if any routing table entry contains the
    CIDR's network address.
    """
    try:
        target_addr = ipaddress.ip_network(cidr, strict=False).network_address
    except ValueError:
        return set()

    matching = set()
    for lfw, nets in fw_route_index.items():
        for net in nets:
            if target_addr in net:
                matching.add(lfw)
                break
    return matching


def validate_route_via_db(cidr, route_db_cache):
    """Same interface and LPM semantics as validate_route(), but sourced
    from fw_route_db.sqlite (route_db_cache, see load_route_db()) instead
    of the separate FW_Routes/ CSV/zip export. Reuses logical_fw_route()
    for device-name normalization -- fw_route_db.sqlite is built from the
    same FW_CONFIGS/{ASA,FTD,PA} hostname population FW_ROUTE_MAP's
    patterns already target, so no new mapping table is needed.

    v1.10.0: added to let fw_route_db.sqlite -- the authoritative,
    actively-maintained route database -- act as a SECOND confirming
    source for the main topology's ROUTE_VALIDATED/ROUTE_MISMATCH
    columns, alongside the existing FW_Routes/ source, rather than
    replacing it. Previously fw_route_db.sqlite was only consulted for
    the unknown-subnet informational path (query_route_db_knowledge()),
    never for validating the main, already-known-IPAM-subnet topology.

    v1.13.0: real, confirmed production crash fixed --
    KeyError: 'interfaces'. load_route_db()'s v1.12.0 rewrite changed
    route_db_cache's structure from flat {'interfaces': [...], 'routes':
    [...]} to bucketed {'iface_buckets':..., 'iface_broad':...,
    'route_buckets':..., 'route_broad':...} (see that function's own
    v1.12.0 note), to fix query_route_db_knowledge()'s O(interfaces+
    routes)-per-call scan. This function was an independent, SEPARATE
    consumer of the old flat structure that v1.12.0 missed entirely --
    confirmed via exhaustive grep for every route_db_cache[...] access
    in the file after this crash, not assumed fixed from memory this
    time. This function is called once per ALREADY-KNOWN IPAM subnet in
    the main topology (not just the ~1,730 unmatched ones
    query_route_db_knowledge() handles) -- almost certainly a LARGER
    real call volume than the case v1.12.0 was built to fix, so this
    also gets the same bucketed lookup, not just a key-name patch.
    target_addr is always a single address (not a range like
    query_route_db_knowledge()'s query_net can be), so it only ever
    needs to check exactly one bucket -- no multi-bucket-spanning case
    to handle here.
    """
    if route_db_cache is None:
        return set()
    try:
        target_addr = ipaddress.ip_network(cidr, strict=False).network_address
    except ValueError:
        return set()

    bucket_id = int(target_addr) >> 16
    matching = set()
    for entry_net, device in route_db_cache['iface_broad']:
        if target_addr in entry_net:
            lfw = logical_fw_route(device)
            if lfw:
                matching.add(lfw)
    for entry_net, device in route_db_cache['iface_buckets'].get(bucket_id, ()):
        if target_addr in entry_net:
            lfw = logical_fw_route(device)
            if lfw:
                matching.add(lfw)
    for entry_net, device, _next_hop in route_db_cache['route_broad']:
        if target_addr in entry_net:
            lfw = logical_fw_route(device)
            if lfw:
                matching.add(lfw)
    for entry_net, device, _next_hop in route_db_cache['route_buckets'].get(bucket_id, ()):
        if target_addr in entry_net:
            lfw = logical_fw_route(device)
            if lfw:
                matching.add(lfw)
    return matching


RD_COLOURS = {
    'Internal-PBM':    '#2563EB',
    'Internal-HCB':    '#7C3AED',
    'Internal-Retail': '#D97706',
    'Cloud-Azure':     '#0EA5E9',
    'Cloud-GCP':       '#10B981',
    'Cloud-AWS':       '#F59E0B',
    'COLO':            '#6B7280',
    'Partner':         '#EC4899',
    'Internet-Facing': '#EF4444',
}

# ── Ground truth: confirmed location → FW set ────────────────────────────────
LOCATION_FW_GROUND_TRUTH = {
    'Southfield MI - Corporate':               {'WDC-Windsor', 'MDC-Middletown'},
    'Blue Bell PA - Corporate':                {'WDC-Windsor', 'MDC-Middletown'},
    'Moon Township PA - Call Center':          {'WDC-Windsor', 'MDC-Middletown'},
    'Falls Church VA - Corporate':             {'WDC-Windsor', 'MDC-Middletown'},
    'Fresno CA - Corporate':                   {'WDC-Windsor', 'MDC-Middletown'},
    'Irving TX - Corporate':                   {'WDC-Windsor', 'MDC-Middletown'},
    'Alpharetta GA - Corporate':               {'WDC-Windsor', 'MDC-Middletown'},
    'Parsippany NJ - Corporate':               {'WDC-Windsor'},
    # Caremark legacy corporate/mail-order sites egress SHEA-DC-EXT (NET4WIR/EXTFTD)
    'Mount Prospect IL - Corporate':           {'SHEA-DC-EXT'},
    'Mount Prospect IL - Mail Order':          {'SHEA-DC-EXT'},
    'Washington DC - Corporate':               {'SHEA-DC-EXT'},
    'Wilkes-Barre PA - Corporate':             {'SHEA-DC-EXT'},
    'Wilkes-Barre PA - Mail Order':            {'SHEA-DC-EXT'},
    'Pittsburgh PA - Corporate':               {'SHEA-DC-EXT'},
    'Buffalo Grove IL - Corporate':            {'SHEA-DC-EXT'},
    'Lees Summit MO - Call Center':            {'SHEA-DC-EXT'},
    'Northbrook IL - Sanders Road Corporate':  {'SHEA-DC-EXT'},
    'Florham Park NJ - Corporate':             {'SHEA-DC-EXT'},
    'Philadelphia PA - SunGard DR':            {'SHEA-DC-EXT'},
    'La Habra CA - Distribution Center':       {'RI-ONE-SEC-DMZ'},
    'Ennis TX - Distribution Center':          {'RI-ONE-SEC-DMZ'},
    'Tualatin OR - Corporate':                 {'RI-ONE-SEC-DMZ'},
    'Spokane WA - Corporate':                  {'RI-ONE-SEC-DMZ'},
    # CarePlus/Coram field sites egress SHEA-DC-EXT
    'Honolulu HI - CarePlus':                  {'SHEA-DC-EXT'},
    'San Diego CA - Coram':                    {'SHEA-DC-EXT'},
    # Cloud — all egress CME-HUB-PROD
    'Cloud - Azure East US 2':                 {'CME-HUB-PROD'},
    'Cloud - Azure Central US':                {'CME-HUB-PROD'},
    'Cloud - AWS US-East2':                    {'CME-HUB-PROD'},
    'Cloud - GCP US-East4':                    {'CME-HUB-PROD'},
    'Las Vegas NV - Switch Colo':              {'LAS-VEGAS-COLO', 'RI-ONE-SEC-DMZ'},
    'Atlanta GA - Aetna DC':                   {'WDC-Windsor', 'MDC-Middletown'},
}


# ── FW name resolution ────────────────────────────────────────────────────────

def logical_fw(raw_fw):
    """Map raw device/cluster name to logical FW identifier."""
    raw = raw_fw.lower().strip()
    for pattern, name in FW_LOGICAL_MAP:
        if re.search(pattern, raw):
            return name
    return raw_fw.strip()


def assert_fw(rd, loc_type, loc, heritage=''):
    """Infer egress FW from routing domain + location type + location name.
    Returns (set_of_logical_fws, method_string, confidence_tier).
    Confidence: HIGH=traffic / MEDIUM=location-confirmed / LOW=asserted.
    """
    if loc in LOCATION_FW_GROUND_TRUTH:
        return LOCATION_FW_GROUND_TRUTH[loc], 'GROUND-TRUTH-OVERRIDE', 'MEDIUM'

    loc_l = loc.lower() if loc else ''

    if rd == 'Cloud-Azure':
        return {'CME-HUB-PROD'}, 'ASSERTED-CLOUD-AZURE', 'LOW'
    if rd == 'Cloud-GCP':
        return {'CME-HUB-PROD'}, 'ASSERTED-CLOUD-GCP', 'LOW'
    if rd == 'Cloud-AWS':
        return {'SHEA-DC-WIRELESS'}, 'ASSERTED-CLOUD-AWS', 'LOW'
    if rd == 'COLO':
        return {'LAS-VEGAS-COLO'}, 'ASSERTED-COLO', 'LOW'
    if rd == 'Internal-HCB':
        return {'WDC-Windsor', 'MDC-Middletown'}, 'ASSERTED-HCB-AP-PAIR', 'LOW'
    if rd == 'Internal-Retail':
        return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-RETAIL', 'LOW'
    if rd == 'Internal-PBM':
        if loc_type in ('DC', 'DataCenter'):
            # Shea DC is in Scottsdale AZ — all other DCs egress RI-ONE
            if any(x in loc_l for x in ['scottsdale', 'shea']):
                return {'SHEA-DC-EXT'}, 'ASSERTED-PBM-SHEA-DC', 'LOW'
            return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-PBM-DC', 'LOW'
        if any(x in loc_l for x in ['distribution', 'omnicare', 'mail order']):
            return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-PBM-DISTRIB', 'LOW'
        # Field sites (careplus, specialty, call center, coram) egress SHEA-DC-EXT
        # not SHEA-DC-WIRELESS — wireless is only for wireless-confirmed subnets
        if any(x in loc_l for x in ['careplus', 'specialty', 'call center', 'coram']):
            return {'SHEA-DC-EXT'}, 'ASSERTED-PBM-SHEA', 'LOW'
        return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-PBM-DEFAULT', 'LOW'
    if rd in ('Partner', 'Offshore'):
        return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-PARTNER', 'LOW'
    if rd == 'Internet-Facing':
        return {'RI-ONE-SEC-DMZ'}, 'ASSERTED-INTERNET-FACING', 'LOW'

    return set(), 'NO-ASSERTION', 'NONE'


# ── IPAM loading ──────────────────────────────────────────────────────────────

def load_ipam(ipam_path):
    """Load IPAM into LPM-sorted list of (network, row_dict)."""
    nets = []
    with open(ipam_path, encoding='utf-8-sig', errors='replace') as f:
        for line in f:
            if line.startswith('#'):
                continue
            reader = csv.DictReader(itertools.chain([line], f))
            for r in reader:
                cidr = r.get('CIDR', '').strip()
                if not cidr:
                    continue
                try:
                    net = ipaddress.ip_network(cidr, strict=False)
                    nets.append((net, r))
                except ValueError:
                    continue
            break
    nets.sort(key=lambda x: x[0].prefixlen, reverse=True)
    return nets


def load_retail(retail_path):
    """v1.16.0: real, confirmed gap fixed -- retail_networks.csv was never
    an input to this script's main topology loop at all (confirmed by the
    platform owner and independently verified: zero references to
    retail_entries/retail_path anywhere in this file before this fix).
    This is the actual, structural reason 'Retail' never once appeared as
    a real NET_TYPE anywhere in the topology output -- not a Zscaler/
    CrowdStrike visibility gap, not SD-WAN local breakout (both real
    hypotheses raised and checked this session before finding the real,
    simple cause).

    retail_networks.csv uses the same real semantic fields as
    all_IP_networks (CANONICAL_LOCATION, ROUTING_DOMAIN, LOCATION_TYPE,
    SITE_CODE, NET_TYPE) but names the heritage field OWNER, not
    HERITAGE. Reuses load_ipam() unchanged, then normalizes OWNER into a
    real HERITAGE key on each row so the existing, already-validated
    (LOCATION, HERITAGE) + /16-sibling + route-evidence inference
    pipeline (see build_topology_rows()) works identically for retail
    rows without any change to that pipeline itself.
    """
    nets = load_ipam(retail_path)
    for net, row in nets:
        if 'HERITAGE' not in row or not row.get('HERITAGE'):
            row['HERITAGE'] = row.get('OWNER', '')
    return nets


def lpm(ip_str, ipam_nets):
    """LPM lookup — returns IPAM row dict or None."""
    try:
        addr = ipaddress.ip_address(ip_str.strip())
        for net, row in ipam_nets:
            if addr in net:
                return row
    except ValueError:
        pass
    return None


def find_closest_ipam_match(cidr, ipam_nets):
    """Uncapped nearest-neighbor search against every registered IPAM
    network, by numeric distance between /24-aligned network addresses.

    v1.7.0. Real, direct request from Michael (2026-07-22): "can we have
    the tool provide a closest IPAM IP match" for unknown subnets.
    Deliberately NOT the same as preprocess_p1.py's Tier 0 (/24
    Adjacency) resolver, which stops searching after 4 slots either
    direction (a narrow-window check, not a true nearest-neighbor
    search) -- this scans the full IPAM and always returns the actual
    closest registered network, however far away that turns out to be,
    so "no result" never happens (only "the closest one is far away,"
    which is itself useful information -- a huge distance is a signal
    this address space may be genuinely new to CVS/Aetna, not just
    unregistered).

    Returns (closest_row, distance_in_24_slots) or (None, None) if
    ipam_nets is empty. O(n) per call -- benchmarked against the real
    25,464-row IPAM at up to 1,730 calls/run (the real FW-Egress unknown-
    subnet volume): ~44M integer comparisons total, well under a second
    in practice. Not worth a spatial index at this scale; revisit if
    IPAM size or unknown-subnet volume grows an order of magnitude.
    """
    try:
        target_net = ipaddress.ip_network(cidr, strict=False)
    except Exception:
        return None, None
    if not ipam_nets:
        return None, None
    target = int(target_net.network_address) & 0xFFFFFF00

    best_row = None
    best_dist = None
    for ipam_net, row in ipam_nets:
        ipam_addr = int(ipam_net.network_address) & 0xFFFFFF00
        dist = abs(target - ipam_addr) // 256
        if best_dist is None or dist < best_dist:
            best_dist = dist
            best_row = row
            if best_dist == 0:
                break  # can't get closer than the same /24 slot
    return best_row, best_dist


# ── fw_route_db.sqlite egress validation ─────────────────────────────────────
# v1.7.0. Real, direct request from Michael (2026-07-22): "use the routing
# DB to validate IP egress routing." Reimplements (not imports) the core
# exact/subset/covers/overlaps relationship logic already tested and
# shipped in fw_route_db.py's find_prefix_knowledge() -- kept self-
# contained here rather than a cross-file import dependency, matching
# this platform's existing convention of tools referencing each other's
# data files (ipam-db.json registry, versioned CSVs) rather than
# importing each other's Python modules directly, so a future change to
# fw_route_db.py's internal API can't silently break this script.
#
# CRITICAL CAVEAT, stated up front because it matters: fw_route_db.sqlite
# is built incrementally as Michael collects real device configs, and was
# at roughly 50% device coverage (251 of an estimated ~440 devices) as of
# 2026-07-22. "No routing knowledge found" from this function means
# EXACTLY that -- it does NOT mean "this address space is illegitimate."
# Every result this produces is qualified with the coverage percentage
# at query time, and callers must not silently upgrade "no evidence yet"
# to "confirmed absent."

def resolve_route_db_path(base):
    """Resolve fw_route_db.sqlite's real path, preferring ipam-db.json's own
    registered 'source' field over re-deriving a guess via glob.

    Why: ipam-db.py registers large binary databases like fw_route_db.sqlite
    "(in-place)" -- tracked by reference at wherever they actually live,
    not copied into ipam-db/ the way small CSVs are. A glob rooted at
    <base>/ipam-db/ can miss it entirely if the real file lives elsewhere,
    exactly the failure confirmed live: ipam-db.py --list showed
    fw_route_db_v20260727.sqlite correctly registered (13,501 rows) the
    same day this script reported "not found." Reading the registry
    directly can't drift from wherever ipam-db.py itself thinks the file
    is, since it IS that same source of truth.

    Falls back to the old glob-based guess (bare + versioned names under
    <base>/ipam-db/) if ipam-db.json is missing, unreadable, or doesn't
    have an 'fw_route_db' entry -- e.g. a standalone environment without
    the full ipam-db.py registry.
    """
    registry_path = base / 'ipam-db' / 'ipam-db.json'
    if registry_path.is_file():
        try:
            with open(registry_path, encoding='utf-8') as f:
                registry = json.load(f)
            entry = registry.get('files', {}).get('fw_route_db', {})
            source = entry.get('source', '')
            if source and os.path.exists(source):
                return source
        except (OSError, ValueError, json.JSONDecodeError):
            pass  # fall through to glob-based guess below

    return find_latest(str(base / 'ipam-db' / 'fw_route_db*.sqlite'))


def load_route_db(db_path):
    """Open fw_route_db.sqlite, load and pre-parse every interface/route
    into memory ONCE, and return (cache_dict, coverage_note) or
    (None, reason) if unavailable.

    v1.12.0: real performance regression found via Michael's own
    check_toolset.py run (2026-07-29): this dry-run timed out at 240s,
    which it had not done before. Root cause confirmed, NOT a bug this
    version introduces -- fw_route_db.sqlite's real device/interface/
    route counts grew substantially between the v1.7.2 fix below (251
    devices, 919 interfaces, 11,883 routes) and now (build_fw_route_db.py
    v0.7.0-v0.9.0 fixed real PA multi-device misattribution AND added
    real *_ROUTES.csv ingestion filling a genuine FTD routing-data gap --
    both legitimately recover far more real route/interface data than
    before, not a regression in the data itself). query_route_db_
    knowledge() was a flat O(interfaces + routes) linear scan per call,
    called once per unmatched subnet (~1,730 calls per the v1.7.2 note
    below) -- O(unmatched * total_entries) was fine at the old scale
    (~22M overlap checks) and is not at several times that scale.

    Fixed by bucketing interfaces/routes by their covering /16 (first
    two octets) at load time, so a query only scans entries that could
    plausibly overlap it, not the entire table. Entries broader than /16
    (prefixlen 9-15 -- rare in real data: direct-connected interfaces and
    specific routes are almost always /24-/32, confirmed against the
    real db) go in a small separate 'broad' list checked against every
    query regardless of bucket, since they can span multiple buckets.
    Entries at prefixlen<=8 remain excluded exactly as before (v1.7.0's
    catch-all/default-route exclusion, unchanged). A query wider than /16
    checks every /16 bucket it covers, not just one -- correctness is
    unchanged from the old flat scan, only which entries get compared
    against which queries changes (fewer, not different -- every entry
    the old scan would have found still gets found here, confirmed via
    a direct old-vs-new comparison across a full unmatched-subnet run
    before shipping this version, see this version's own test notes).

    v1.7.2. Real performance bug found by Michael actually running this
    against his real data (not caught by my own benchmarking before
    shipping v1.7.0/1.7.1 -- I benchmarked find_closest_ipam_match() at
    realistic scale but did NOT do the same for this function, the exact
    "test at realistic scale" mistake this codebase's own v2.9.16
    changelog already documents once). The original version re-ran two
    fresh SQL queries (919 interfaces + 11,883 routes) AND re-parsed
    every CIDR string with ipaddress.ip_network() from scratch, on EVERY
    one of 1,730 unmatched-subnet calls -- ~22 million redundant
    ip_network() constructions plus 3,460 SQL fetches, with zero
    progress output, looking indistinguishable from a hang. Fixed the
    same way the v2.9.16 resolver was fixed: parse everything into an
    in-memory cache ONCE here, so query_route_db_knowledge() does pure
    Python iteration over already-parsed objects, not a live DB round
    trip, per call.
    """
    if not db_path or not os.path.exists(db_path):
        return None, 'fw_route_db.sqlite not found — egress validation skipped'
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM fw_devices')
        device_count = cur.fetchone()[0]

        # v1.12.0: bucketed by covering /16 (network_address >> 16) instead
        # of one flat list -- see this function's own v1.12.0 note above.
        iface_buckets = collections.defaultdict(list)
        iface_broad = []
        n_ifaces = 0
        cur.execute('SELECT device, cidr FROM fw_interfaces')
        for device, entry_cidr in cur.fetchall():
            try:
                net = ipaddress.ip_network(entry_cidr, strict=False)
            except Exception:
                continue
            n_ifaces += 1
            if net.prefixlen < 16:
                iface_broad.append((net, device))
            else:
                iface_buckets[int(net.network_address) >> 16].append((net, device))

        route_buckets = collections.defaultdict(list)
        route_broad = []
        n_routes = 0
        cur.execute('SELECT device, dest_cidr, next_hop FROM fw_routes')
        for device, dest_cidr, next_hop in cur.fetchall():
            try:
                net = ipaddress.ip_network(dest_cidr, strict=False)
            except Exception:
                continue
            if net.prefixlen <= 8:
                continue  # exclude default/catch-all routes -- see phantom-IPAM audit finding
            n_routes += 1
            if net.prefixlen < 16:
                route_broad.append((net, device, next_hop))
            else:
                route_buckets[int(net.network_address) >> 16].append((net, device, next_hop))

        conn.close()
        cache = {
            'iface_buckets': iface_buckets, 'iface_broad': iface_broad,
            'route_buckets': route_buckets, 'route_broad': route_broad,
        }
        return cache, (f'{device_count} devices, {n_ifaces:,} interfaces, {n_routes:,} '
                        f'specific routes loaded from fw_route_db.sqlite (partial collection — treat '
                        f'"no match" as "no evidence yet," not "confirmed unrouted")')
    except Exception as e:
        return None, f'fw_route_db.sqlite unreadable ({e}) — egress validation skipped'


def _relationship(entry_net, query_net):
    if entry_net == query_net:
        return 'exact'
    if query_net.subnet_of(entry_net):
        return 'covers'
    if entry_net.subnet_of(query_net):
        return 'subset'
    return 'overlaps'


def query_route_db_knowledge(route_db_cache, cidr):
    """For a CIDR, find the best-matching real firewall interface/route
    already loaded into route_db_cache (see load_route_db() -- pure
    in-memory iteration, no DB round trip per call), ranked exact-first
    then by prefix specificity (mirrors fw_route_db.py's
    find_prefix_knowledge() exactly). Returns the single best match
    dict, or None if the query CIDR doesn't parse or nothing overlaps
    at all -- 'nothing overlaps' is itself a real, meaningful result
    given the coverage caveat, not an error.

    v1.12.0: only scans the /16 bucket(s) the query could actually
    overlap, plus the small 'broad' (prefixlen 9-15) list -- see
    load_route_db()'s v1.12.0 note for the full rationale and the
    correctness argument (same entries an unbucketed scan would find,
    just without touching entries that provably can't overlap).
    """
    try:
        query_net = ipaddress.ip_network(cidr, strict=False)
    except Exception:
        return None

    best = None
    best_rank = 99
    rel_rank = {'exact': 0, 'subset': 1, 'covers': 2, 'overlaps': 3}

    # Which /16 bucket(s) could this query overlap? A query at /16 or
    # narrower lives entirely within one bucket. A query broader than
    # /16 (rare for a real unmatched-subnet lookup, but must stay
    # correct) spans every /16 bucket between its network and broadcast
    # address -- bounded (at most 2^(16-prefixlen) buckets) and still
    # far cheaper than scanning every entry in the whole table.
    if query_net.prefixlen >= 16:
        bucket_ids = [int(query_net.network_address) >> 16]
    else:
        lo = int(query_net.network_address) >> 16
        hi = int(query_net.broadcast_address) >> 16
        bucket_ids = range(lo, hi + 1)

    def _consider(entry_net, device, kind):
        nonlocal best, best_rank
        if not entry_net.overlaps(query_net):
            return False
        rel = _relationship(entry_net, query_net)
        rank = rel_rank[rel]
        if rank < best_rank or (rank == best_rank and entry_net.prefixlen > (best['prefix_len'] if best else -1)):
            best_rank = rank
            best = {'device': device, 'kind': kind, 'matched_cidr': str(entry_net),
                    'prefix_len': entry_net.prefixlen, 'relationship': rel}
            if best_rank == 0 and best['prefix_len'] == query_net.prefixlen:
                return True  # exact match at the query's own prefix length -- can't improve further
        return False

    for entry_net, device in route_db_cache['iface_broad']:
        if _consider(entry_net, device, 'directly-connected'):
            return best
    for bucket_id in bucket_ids:
        for entry_net, device in route_db_cache['iface_buckets'].get(bucket_id, ()):
            if _consider(entry_net, device, 'directly-connected'):
                return best

    for entry_net, device, next_hop in route_db_cache['route_broad']:
        if _consider(entry_net, device, f'route (next-hop {next_hop})'):
            return best
    for bucket_id in bucket_ids:
        for entry_net, device, next_hop in route_db_cache['route_buckets'].get(bucket_id, ()):
            if _consider(entry_net, device, f'route (next-hop {next_hop})'):
                return best

    return best


def load_unknown_subnet_history(out_dir):
    """Scan out_dir for every historical unknown_ip_subnets_v*.csv (not
    just the latest) and build per-subnet run-date history.

    v1.7.0. Real, direct request from Michael (2026-07-22): "do we have
    history on when we saw the network and have we consistently seen
    it." This is entirely dependent on prior runs' dated output files
    still being present on disk -- the v1.6.0 same-day revisioning fix
    (vYYYYMMDD/vYYYYMMDDrN) means different days were ALREADY never
    overwriting each other, so if these files haven't been manually
    deleted, the history has been silently accumulating since whenever
    this script started being run. If none exist yet, this returns an
    empty history and every subnet in today's run correctly starts at
    FIRST_SEEN=today, RUNS_SEEN=1 -- not an error, the correct starting
    state for a cold start.

    Same-day reruns (vYYYYMMDDr2, r3, ...) count as ONE calendar day, not
    N -- a subnet appearing in both v20260722 and v20260722r2 was seen
    on one day, re-examined, not seen on two separate occasions.

    Returns (subnet_dates, all_run_dates):
      subnet_dates  -- {SOURCE_SUBNET: set of 'YYYYMMDD' strings}
      all_run_dates -- set of every distinct 'YYYYMMDD' this script has
                       ever produced output for (the run-date universe,
                       used to compute consistency -- "seen in N of the
                       M runs since first spotted," not just a raw count)
    """
    files = sorted(glob.glob(os.path.join(out_dir, 'unknown_ip_subnets_v*.csv')))
    subnet_dates = collections.defaultdict(set)
    all_run_dates = set()

    for path in files:
        base = os.path.basename(path)
        m = re.search(r'_v(\d{8})', base)
        if not m:
            continue
        run_date = m.group(1)
        all_run_dates.add(run_date)
        try:
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                lines = [l for l in f if not l.startswith('#')]
            for row in csv.DictReader(lines):
                subnet = row.get('SOURCE_SUBNET', '').strip()
                if subnet:
                    subnet_dates[subnet].add(run_date)
        except Exception as e:
            print(f'  [WARN] Could not read history from {base}: {e}', file=sys.stderr)

    return subnet_dates, all_run_dates


def compute_subnet_history(s24, subnet_dates, all_run_dates, today):
    """Per-subnet FIRST_SEEN/LAST_SEEN/RUNS_SEEN/CONSISTENCY, including
    today's run in the calculation (today hasn't been written to disk
    yet at call time, so it won't already be in subnet_dates/all_run_dates).
    """
    dates = set(subnet_dates.get(s24, set()))
    dates.add(today)
    all_dates = set(all_run_dates)
    all_dates.add(today)

    first_seen = min(dates)
    last_seen = max(dates)
    runs_seen = len(dates)
    runs_since_first = len([d for d in all_dates if d >= first_seen])
    consistency = runs_seen / runs_since_first if runs_since_first else 1.0

    return {
        'FIRST_SEEN': first_seen,
        'LAST_SEEN': last_seen,
        'RUNS_SEEN': runs_seen,
        'RUNS_SINCE_FIRST_SEEN': runs_since_first,
        'CONSISTENCY_PCT': round(consistency * 100, 1),
    }


def find_latest(pattern):
    matches = sorted(glob.glob(pattern), key=os.path.getmtime, reverse=True)
    return matches[0] if matches else None


# ── Progress + heartbeat ────────────────────────────────────────────────────
# v1.17.0: real, confirmed gap -- this script had zero live progress
# feedback anywhere and zero Ctrl-C handling. Confirmed real impact:
# retail_networks now being a genuine input (v1.16.0) means the main
# per-subnet topology loop processes 319,739 rows instead of 25,396
# (12.6x more) -- a real, live run went silent for 8+ minutes mid-loop
# with no indication of progress and was interrupted, assumed hung.
# Same proven pattern already delivered in build_external_ip_registry.py
# v2.4.4 -- see that script's own v2.4.4 changelog for the full design.
import threading
import time as _time

def _progress_bar(label, current, total, width=20):
    if total <= 0:
        return
    pct = 100 * current // total
    bar = '█' * (pct // (100 // width)) + '░' * (width - pct // (100 // width))
    print(f"\r  {label}  [{bar}] {pct:>3}%  {current:,} / {total:,}", end='', flush=True)
    if current >= total:
        print()


class _Heartbeat:
    """Real wall-clock 'still running' feedback for phases with no natural
    iteration point to report incremental progress from. Prints an update
    every `interval` seconds until stopped."""
    def __init__(self, label, interval=10):
        self.label = label
        self.interval = interval
        self._stop = threading.Event()
        self._thread = None

    def _run(self):
        elapsed = 0
        while not self._stop.wait(self.interval):
            elapsed += self.interval
            print(f"  ... still running ({self.label}, {elapsed}s elapsed)", flush=True)

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1)


# ── Zscaler zip ingestion ─────────────────────────────────────────────────────

def find_zscaler_zips(zscaler_dir):
    """Find Zscaler log files -- both .zip archives and bare .csv exports.

    v1.4.0 fix: real bug found 2026-07-21 -- this only ever globbed
    '*.zip', silently skipping any bare CSV export sitting in the same
    directory. Confirmed against a real drop: two bare CSVs
    (zscaler-2.csv, zscaler-DS-6-24.csv) totaling 381,522 rows and
    roughly 23,000 unique source IPs each -- comparable in scale to the
    individually-zipped files that WERE being read -- were silently
    dropped from every run. This is very likely the dominant cause of
    the ~99% CS-only/QUALIFIED=NO skew seen in unknown_ip_subnets_*.csv:
    a large fraction of the Zscaler evidence that would have confirmed
    many of these subnets as BOTH/ZSCALER was never ingested at all.

    Also excludes a bare CSV when an identically-named '<name>.zip'
    counterpart exists -- confirmed against the real data that
    zscaler-2.csv/zscaler-2.csv.zip and zscaler-DS-6-24.csv/
    zscaler-DS-6-24.csv.zip are exact duplicates (identical connection
    counts down to the row), not two different exports. Including both
    would double-count that data. Genuinely unique bare CSVs (no zip
    counterpart) are still included.
    """
    zips = glob.glob(os.path.join(zscaler_dir, '*.zip'))
    csvs = glob.glob(os.path.join(zscaler_dir, '*.csv'))
    zip_basenames = {os.path.basename(z) for z in zips}
    csvs = [c for c in csvs if f'{os.path.basename(c)}.zip' not in zip_basenames]
    return sorted(zips + csvs)


def parse_firewalls(fw_str):
    if ',' in fw_str:
        return [f.strip() for f in fw_str.split(',') if f.strip()]
    return [f.strip() for f in fw_str.split() if f.strip()]


def ingest_zscaler_zips(zip_files, ipam_nets, subnet24_cache, confirmed, unmatched_raw):
    """Read all Zscaler zips AND bare CSVs, populate confirmed dict and
    unmatched_raw dict.

    v1.4.0: now also handles bare .csv files, not just .zip archives --
    see find_zscaler_zips() for why. Function name and signature kept
    unchanged for compatibility with existing call sites; 'zip_files' may
    now contain a mix of .zip and .csv paths. The per-row parsing logic
    below is completely unchanged from before this fix -- only the
    "how do I get a list of (csv_name, raw_bytes) sources from this
    path" step at the top of the loop was generalized, to avoid touching
    logic that was already correct and tested.
    """
    total_conns = matched = unmatched_count = skipped_overflow = 0

    for path in zip_files:
        snap_name = os.path.basename(path)

        if path.lower().endswith('.zip'):
            try:
                zf = zipfile.ZipFile(path)
            except Exception as e:
                print(f'  [WARN] Cannot open {snap_name}: {e}')
                continue
            csv_sources = [(n, zf.read(n)) for n in zf.namelist()
                           if n.endswith('.csv') and '__MACOSX' not in n]
            if not csv_sources:
                print(f'  [WARN] No CSV in {snap_name} — skipping')
                continue
        else:
            # Bare CSV -- read directly from disk, no archive to open.
            try:
                with open(path, 'rb') as fh_raw:
                    csv_sources = [(snap_name, fh_raw.read())]
            except Exception as e:
                print(f'  [WARN] Cannot open {snap_name}: {e}')
                continue

        file_conns = 0
        file_anomaly_rows = 0
        file_anomaly_raw_total = 0
        for csv_name, raw in csv_sources:
            fh    = io.TextIOWrapper(io.BytesIO(raw), encoding='utf-8-sig')
            rdr   = csv.DictReader(fh)
            fields = [f.strip().lower() for f in (rdr.fieldnames or [])]

            # Detect format
            if 'src_ip' in fields:
                src_col, fmt = 'src_ip', 'raw'
            elif 'src_ips' in fields:
                src_col, fmt = 'src_ips', 'aggregated'
            else:
                print(f'  [WARN] Unknown schema in {snap_name}/{csv_name}: {rdr.fieldnames}')
                continue

            for row in rdr:
                src  = row.get(src_col, '').strip().strip('"')
                dest = row.get('dest_ip', '').strip().strip('"')
                fws  = parse_firewalls(row.get('firewalls', '').strip())
                if not src:
                    continue

                weight = 1
                if fmt == 'aggregated':
                    try:
                        weight = int(row.get('total_sessions', '1').strip().strip('"'))
                    except ValueError:
                        weight = 1

                if weight >= COUNTER_OVERFLOW_THRESHOLD:
                    skipped_overflow += weight
                    continue

                # v1.11.0: a single src/dest pair claiming an implausible
                # session count (see SESSION_WEIGHT_SANITY_CAP above) is
                # untrustworthy as a WEIGHT, but the row itself is still
                # real evidence this src/dest pair exists -- clamp to 1
                # (simple presence) rather than skipping the row entirely,
                # so CIDR-matching still benefits from it without letting
                # one anomalous number dominate the connection total.
                if fmt == 'aggregated' and weight > SESSION_WEIGHT_SANITY_CAP:
                    file_anomaly_rows += 1
                    file_anomaly_raw_total += weight
                    weight = 1

                total_conns += weight
                file_conns  += weight

                s24 = _slash24(src)
                if s24 not in subnet24_cache:
                    subnet24_cache[s24] = lpm(s24.replace('.0/24', '.1'), ipam_nets)

                ipam_row = subnet24_cache[s24]

                if not fws:
                    fws = ['UNKNOWN']

                if ipam_row is not None:
                    matched += weight
                    for fw in fws:
                        lfw = logical_fw(fw)
                        _add_to_confirmed(confirmed, s24, lfw, weight, snap_name,
                                          ipam_row.get('CANONICAL_LOCATION', ''),
                                          ipam_row.get('ROUTING_DOMAIN', ''),
                                          ipam_row.get('HERITAGE', ''))
                else:
                    unmatched_count += weight
                    for fw in fws:
                        lfw = logical_fw(fw)
                        _add_to_unmatched(unmatched_raw, s24, lfw, weight, src, dest, snap_name)

        print(f'  {snap_name:<50}  {file_conns:>10,} connections')
        if file_anomaly_rows:
            print(f'  [WARN] {snap_name}: {file_anomaly_rows:,} row(s) had implausible '
                  f'total_sessions values (raw sum {file_anomaly_raw_total:,}, cap '
                  f'{SESSION_WEIGHT_SANITY_CAP:,}/row) -- clamped to weight=1 each. This '
                  f'file\'s schema/export may differ from the others; verify at the source '
                  f'before trusting its connection counts.')

    if skipped_overflow:
        print(f'  [INFO] Skipped {skipped_overflow:,} connections (32-bit counter overflow)')

    return total_conns, matched, unmatched_count


def _slash24(ip):
    parts = ip.strip().split('.')
    return '.'.join(parts[:3]) + '.0/24'


def _add_to_confirmed(confirmed, s24, lfw, weight, snap_name, loc, rd, her=''):
    if s24 not in confirmed:
        confirmed[s24] = {
            'loc': loc if loc not in ('UNKNOWN', '') else '',
            'rd':  rd,
            'her': her,
            'fws': set(),
            'connections': 0,
            'snapshots': set(),
        }
    e = confirmed[s24]
    if lfw and lfw in KNOWN_LOGICAL_FWS:
        e['fws'].add(lfw)
    e['connections'] += weight
    e['snapshots'].add(snap_name)
    if loc and loc not in ('UNKNOWN', '') and not e['loc']:
        e['loc'] = loc
    if rd and not e['rd']:
        e['rd'] = rd
    if her and not e['her']:
        e['her'] = her


def _add_to_unmatched(unmatched_raw, s24, lfw, weight, src_ip, dest_ip, snap_name):
    if s24 not in unmatched_raw:
        parts = s24.split('.')
        unmatched_raw[s24] = {
            'slash16': f'{parts[0]}.{parts[1]}.0.0/16',
            'fws': set(),
            'connections': 0,
            'src_ips': set(),
            'dest_ips': set(),
            'snapshots': set(),
        }
    u = unmatched_raw[s24]
    if lfw and lfw in KNOWN_LOGICAL_FWS:
        u['fws'].add(lfw)
    u['connections'] += weight
    u['src_ips'].add(src_ip)
    u['dest_ips'].add(dest_ip)
    u['snapshots'].add(snap_name)


# ── CrowdStrike ingestion ─────────────────────────────────────────────────────

def find_cs_files(cs_dir):
    """Find all CSVs in the CS_Data directory."""
    return sorted(glob.glob(os.path.join(cs_dir, '*.csv')))


def ingest_cs_files(cs_files, ipam_nets, subnet24_cache, confirmed, unmatched_raw):
    """Ingest CrowdStrike PA exports. Only action=allowed rows."""
    total_rows = new_subnets = 0

    for cs_path in cs_files:
        snap_name = 'cs_' + os.path.basename(cs_path)
        file_rows = 0
        try:
            with open(cs_path, encoding='utf-8-sig', errors='replace') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    action = row.get('action', '').strip().lower()
                    if action != 'allowed':
                        continue
                    dvc = row.get('dvc', '').strip() or row.get('firewall', '').strip()
                    if not dvc:
                        continue
                    lfw = logical_fw(dvc)
                    if lfw not in KNOWN_LOGICAL_FWS:
                        continue  # unresolvable management IP — skip

                    sources_raw = row.get('sources', '').strip()
                    if not sources_raw:
                        continue

                    for ip in sources_raw.split():
                        ip = ip.strip()
                        if not ip:
                            continue
                        s24 = _slash24(ip)
                        if s24 not in subnet24_cache:
                            subnet24_cache[s24] = lpm(s24.replace('.0/24', '.1'), ipam_nets)
                        ipam_row = subnet24_cache[s24]

                        if ipam_row is not None:
                            _add_to_confirmed(confirmed, s24, lfw, 1, snap_name,
                                              ipam_row.get('CANONICAL_LOCATION', ''),
                                              ipam_row.get('ROUTING_DOMAIN', ''),
                                              ipam_row.get('HERITAGE', ''))
                        else:
                            dest = row.get('destinations', '').strip()
                            _add_to_unmatched(unmatched_raw, s24, lfw, 1, ip, dest, snap_name)

                        file_rows += 1
                        if s24 not in confirmed and s24 not in unmatched_raw:
                            new_subnets += 1

        except Exception as e:
            print(f'  [WARN] Could not parse {os.path.basename(cs_path)}: {e}')
            continue

        total_rows += file_rows
        print(f'  {os.path.basename(cs_path):<50}  {file_rows:>10,} source-IP rows')

    return total_rows


# ── Build topology rows ───────────────────────────────────────────────────────

def build_topology_rows(ipam_rows, confirmed, unmatched_raw, fw_route_index=None,
                         ipam_nets=None, route_db_cache=None, route_db_note='',
                         subnet_dates=None, all_run_dates=None,
                         ip_dataset_index=None):
    """
    For every IPAM row: assign FW via confirmed traffic first,
    then location-confirmed, then assertion inference.
    Returns (out_rows, unmatched_rows).
    """
    out_rows  = []
    stats     = collections.Counter()

    # Build (location, heritage) → FW lookup from confirmed traffic. v1.14.0:
    # narrower key than location alone -- a real, confirmed problem: a single
    # physical site (e.g. Shea DC) legitimately hosts multiple different
    # business units/heritages, each deliberately pinned to a DIFFERENT
    # egress path (a real business decision, not physical topology). Pure
    # location-keyed inheritance pooled ALL of them together, producing false
    # ties -- confirmed live: 2.1.1.0/24 (CVS, Shea DC) inherited MDC-
    # Middletown and WDC-Windsor as "candidates" even though those are
    # Aetna's dedicated split, never a real path for a CVS subnet. Real
    # validation against the actual confirmed-traffic data (2026-08-19):
    # AETNA-CallCenter 99% MID/WIN, Distribution 97% RI, Omnicare 87% RI,
    # Specialty 93% Shea, CarePlus/Mail-Order 100% Shea -- HERITAGE is a
    # real, validated disambiguating signal at this location-pooling step,
    # not a guess. Broader location-only lookup KEPT as a secondary
    # fallback for subnets whose specific (location, heritage) combination
    # has no confirmed traffic of its own at all.
    loc_her_fw_confirmed = collections.defaultdict(set)
    loc_fw_confirmed = collections.defaultdict(set)
    for sn, data in confirmed.items():
        if data['loc'] and data['fws']:
            loc_fw_confirmed[data['loc']] |= data['fws']
            if data.get('her'):
                loc_her_fw_confirmed[(data['loc'], data['her'])] |= data['fws']

    # v1.15.0: real, validated /16-sibling disambiguation -- when (LOCATION,
    # HERITAGE) narrowing still leaves a genuine tie, check what OTHER real
    # subnets within the same /16 supernet (at ANY location, not just this
    # one) are confirmed to use. This is deliberately NOT the same pattern
    # build_known_unknown_ip_resolver.py explicitly rejected (sibling-/16
    # inference of LOCATION from address-space proximity, which produced
    # confident-but-wrong answers on real cases) -- here LOCATION is already
    # real and confirmed via IPAM; /16-sibling evidence is used only to
    # break a tie among already-known candidate firewalls at that known
    # location, a meaningfully different use of the same address-space
    # signal. Validated against the real 2026-08-19 production topology
    # before shipping: resolved 4,430 of 17,778 genuinely tied CIDRs (24.9%)
    # to exactly one real answer, spot-checked against real cases where the
    # confirming sibling subnet was at a DIFFERENT physical site than the
    # one being resolved (e.g. Oklahoma City OK - Corporate confirming
    # RI-ONE-SEC-DMZ for Phoenix AZ subnets in the same 10.8.0.0/16) --
    # genuine independent corroboration, not circular reuse of the same
    # site's own data.
    slash16_confirmed = collections.defaultdict(set)
    for sn, data in confirmed.items():
        if not data['fws']:
            continue
        try:
            net = ipaddress.ip_network(sn, strict=False)
            s16 = str(ipaddress.ip_network(f'{net.network_address}/16', strict=False))
        except ValueError:
            continue
        slash16_confirmed[s16] |= data['fws']

    ipam_cidrs = set()
    ambiguous_rows = []   # v1.14.0: persisted for known_ambiguous_egress

    _total_ipam_rows = len(ipam_rows)
    _interval = max(1, _total_ipam_rows // 100)
    for _i, r in enumerate(ipam_rows):
        if (_i + 1) % _interval == 0 or (_i + 1) == _total_ipam_rows:
            _progress_bar('Building topology', _i + 1, _total_ipam_rows)
        cidr = r.get('CIDR', '').strip()
        if not cidr:
            continue
        ipam_cidrs.add(cidr)

        loc  = r.get('CANONICAL_LOCATION', '').strip()
        rd   = r.get('ROUTING_DOMAIN', '').strip()
        lt   = r.get('LOCATION_TYPE', '').strip()
        sc   = r.get('SITE_CODE', '').strip()
        her  = r.get('HERITAGE', '').strip()
        nt   = r.get('NET_TYPE', '').strip()

        conf_data = confirmed.get(cidr, {})
        conn      = conf_data.get('connections', 0)
        snaps     = '|'.join(sorted(conf_data.get('snapshots', set())))
        traffic_confirmed = bool(conf_data.get('fws'))

        # Classify traffic source: ZSCALER / CS / BOTH / NONE
        if traffic_confirmed:
            snaps_set  = conf_data.get('snapshots', set())
            has_zsc    = any(not s.startswith('cs_') for s in snaps_set)
            has_cs     = any(s.startswith('cs_')     for s in snaps_set)
            if has_zsc and has_cs:
                traffic_source = 'BOTH'
            elif has_zsc:
                traffic_source = 'ZSCALER'
            else:
                traffic_source = 'CS'
        else:
            traffic_source = 'NONE'

        # Enrich blank IPAM location from traffic data
        if (not loc or loc in ('UNKNOWN', 'Unknown')) and conf_data.get('loc'):
            loc = conf_data['loc']
        if not rd and conf_data.get('rd'):
            rd = conf_data['rd']

        # v1.14.0: route validation moved earlier in the loop -- combined_fws
        # is now needed for tie-breaking BEFORE the FW-assignment decision
        # below, not just for the ROUTE_VALIDATED output columns further
        # down (which now reuse these same values instead of recomputing).
        route_fws = validate_route(cidr, fw_route_index) if fw_route_index else set()
        route_db_fws = validate_route_via_db(cidr, route_db_cache)
        combined_fws = route_fws | route_db_fws

        # Determine FW and confidence
        if traffic_confirmed:
            fws        = conf_data['fws']
            method     = 'TRAFFIC-CONFIRMED'
            confidence = 'HIGH'
            stats['confirmed'] += 1
        elif (her and loc and loc not in ('UNKNOWN', 'Unknown', '')
              and (loc, her) in loc_her_fw_confirmed):
            fws = loc_her_fw_confirmed[(loc, her)]
            # v1.14.0: real route-table evidence, when it narrows a tie to
            # exactly one real candidate, is genuine direct evidence and
            # takes priority over the narrowed-but-still-tied inheritance.
            route_narrowed = fws & combined_fws
            if len(fws) > 1 and len(route_narrowed) == 1:
                fws        = route_narrowed
                method     = 'LOCATION-HERITAGE-CONFIRMED+ROUTE'
                confidence = 'MEDIUM'
                stats['location_heritage_route_confirmed'] += 1
            elif len(fws) == 1:
                method     = 'LOCATION-HERITAGE-CONFIRMED'
                confidence = 'MEDIUM'
                stats['location_heritage_confirmed'] += 1
            else:
                # v1.15.0: real route evidence didn't narrow it -- try real
                # /16-sibling confirmed traffic before falling back to
                # AMBIGUOUS. See slash16_confirmed's own docstring above for
                # why this is a real, validated, different use of address-
                # space proximity than the pattern this platform already
                # rejected once for location inference.
                try:
                    cidr_net = ipaddress.ip_network(cidr, strict=False)
                    s16 = str(ipaddress.ip_network(f'{cidr_net.network_address}/16', strict=False))
                except ValueError:
                    s16 = None
                sibling16_narrowed = (fws & slash16_confirmed.get(s16, set())) if s16 else set()
                if len(sibling16_narrowed) == 1:
                    fws        = sibling16_narrowed
                    method     = 'LOCATION-HERITAGE-CONFIRMED+SIBLING16'
                    confidence = 'MEDIUM'
                    stats['location_heritage_sibling16_confirmed'] += 1
                else:
                    # v1.14.0: real, confirmed ambiguity even after narrowing
                    # to (location, heritage) and checking real /16-sibling
                    # evidence. See build_known_unknown_ip_resolver.py's own
                    # precedent for this exact discipline: a confident-but-
                    # wrong guess was tried by hand this session and
                    # correctly rejected as too fragile -- NET_TYPE/business-
                    # character pattern matching looked promising
                    # (Distribution/Omnicare -> RI, Specialty family -> Shea)
                    # until Coram broke it: tagged NET_TYPE=Omnicare, but
                    # real confirmed traffic behaves like Specialty instead.
                    # Do NOT silently pick one here. Tag explicitly and
                    # persist for re-evaluation as more real traffic
                    # accumulates -- the same iterative-visibility model
                    # build_known_unknown_ip_resolver.py already uses for
                    # unknown subnets.
                    method     = 'LOCATION-HERITAGE-AMBIGUOUS'
                    confidence = 'LOW-AMBIGUOUS'
                    stats['location_heritage_ambiguous'] += 1
                    ambiguous_rows.append({
                        'CIDR': cidr, 'CANONICAL_LOCATION': loc, 'HERITAGE': her,
                        'NET_TYPE': nt, 'ROUTING_DOMAIN': rd,
                        'CANDIDATE_FIREWALLS': '|'.join(sorted(fws)),
                        'CANDIDATE_COUNT': len(fws),
                    })
        elif loc and loc not in ('UNKNOWN', 'Unknown', '') and loc in loc_fw_confirmed:
            fws = loc_fw_confirmed[loc]
            route_narrowed = fws & combined_fws
            if len(fws) > 1 and len(route_narrowed) == 1:
                fws        = route_narrowed
                method     = 'LOCATION-CONFIRMED+ROUTE'
                confidence = 'MEDIUM'
                stats['location_route_confirmed'] += 1
            else:
                method     = 'LOCATION-CONFIRMED'
                confidence = 'MEDIUM'
                stats['location_confirmed'] += 1
        elif loc and loc not in ('UNKNOWN', 'Unknown', ''):
            fws, method, confidence = assert_fw(rd, lt, loc, her)
            stats[f'asserted'] += 1
        else:
            fws, method, confidence = set(), 'NO-LOCATION', 'NONE'
            stats['no_location'] += 1

        base_row = {
            'CIDR':                    cidr,
            'SITE_CODE':               sc,
            'CANONICAL_LOCATION':      loc,
            'ROUTING_DOMAIN':          rd,
            'LOCATION_TYPE':           lt,
            'HERITAGE':                her,
            'NET_TYPE':                nt,
            'MAPPING_METHOD':          method,
            'CONFIDENCE':              confidence,
            'TRAFFIC_CONFIRMED':       'Y' if traffic_confirmed else 'N',
            'TRAFFIC_SOURCE':          traffic_source,
            'CONNECTIONS':             conn,
            'SNAPSHOT_SOURCES':        snaps,
            'DATASET_VERSION':         VERSION,
        }

        # ── Route validation ──────────────────────────────────────────────
        # v1.10.0: fw_route_db.sqlite unioned in as a second confirming
        # source alongside FW_Routes/, rather than replacing it -- either
        # source confirming a route is meaningful evidence toward
        # ROUTE_VALIDATED. ROUTE_SOURCE records which source(s) actually
        # contributed, so a human can tell "confirmed by the newer,
        # authoritative fw_route_db.sqlite" apart from "confirmed only by
        # the older FW_Routes/ export" apart from "confirmed by both."
        # Backward compatible: when route_db_cache is None (not loaded),
        # route_db_fws is always empty and the decision logic is
        # unchanged from pre-v1.10.0 behavior.
        # v1.14.0: route_fws/route_db_fws/combined_fws are now computed
        # ONCE, earlier in this loop (needed there for tie-breaking before
        # the FW-assignment decision above) -- reused here rather than
        # recomputed, so this section keeps its original real behavior for
        # everything below unchanged.

        if fw_route_index or route_db_cache is not None:
            if route_fws and route_db_fws:
                base_row['ROUTE_SOURCE'] = 'BOTH'
            elif route_fws:
                base_row['ROUTE_SOURCE'] = 'FW_ROUTES'
            elif route_db_fws:
                base_row['ROUTE_SOURCE'] = 'ROUTE_DB'
            else:
                base_row['ROUTE_SOURCE'] = ''

            if combined_fws:
                base_row['ROUTE_MATCH_FWS'] = '|'.join(sorted(combined_fws))
                if fws:
                    # Validated if ANY assigned FW has a route to this CIDR
                    # from EITHER source
                    base_row['ROUTE_VALIDATED'] = 'Y' if (fws & combined_fws) else 'N'
                    base_row['ROUTE_MISMATCH']  = 'Y' if not (fws & combined_fws) else 'N'
                else:
                    base_row['ROUTE_VALIDATED'] = 'NO-FW-ASSIGNED'
                    base_row['ROUTE_MISMATCH']  = 'N'
            else:
                # Distinguish expected BGP-learned gaps from genuine missing routes
                if _is_bgp_learned(cidr):
                    base_row['ROUTE_VALIDATED'] = 'NO_ROUTE_EXPECTED'
                else:
                    base_row['ROUTE_VALIDATED'] = 'NO_ROUTE'
                base_row['ROUTE_MATCH_FWS'] = ''
                base_row['ROUTE_MISMATCH']  = 'N'
        else:
            base_row['ROUTE_VALIDATED'] = ''
            base_row['ROUTE_MATCH_FWS'] = ''
            base_row['ROUTE_MISMATCH']  = ''
            base_row['ROUTE_SOURCE'] = ''

        if not fws:
            out_rows.append({**base_row,
                             'EGRESS_FIREWALL_LOGICAL': '',
                             'EGRESS_FIREWALL_CLUSTER': '',
                             'PA_DEVICE_GROUP':         ''})
        else:
            for fw in sorted(fws):
                out_rows.append({**base_row,
                                 'EGRESS_FIREWALL_LOGICAL': fw,
                                 'EGRESS_FIREWALL_CLUSTER': FW_CLUSTER_MAP.get(fw, ''),
                                 'PA_DEVICE_GROUP':         FW_PA_DG_MAP.get(fw, '')})

    # Unknown subnets — in traffic, not in IPAM
    #
    # TRAFFIC_SOURCE qualification applied here identically to the known-subnet
    # path above: a CrowdStrike snapshot is any whose name starts with 'cs_'
    # (set in ingest_cs_files); anything else is Zscaler. The harvest is a
    # candidate source for unregistered *user* subnets, and per the established
    # rule CS-only traffic does NOT qualify for that purpose — CrowdStrike runs
    # on endpoints logging outbound to huge numbers of external/internet
    # destinations, so a CS-only unregistered /24 is overwhelmingly an external
    # destination, not an internal user subnet we're trying to discover. Only
    # BOTH and ZSCALER-only are QUALIFIED. CS-only rows are still emitted (not
    # silently dropped — they're real observations) but flagged QUALIFIED=NO so
    # the "new subnets discovered" signal reflects genuine qualified discoveries
    # rather than being drowned by CS-only external-destination noise.
    #
    # v1.5.0: DATA_QUALITY now distinguishes public-IP sources from genuine
    # unregistered internal subnets. Real, confirmed finding 2026-07-22:
    # 1,715 of 1,730 rows (99.1%) in a real run had a public (non-RFC1918,
    # non-CGNAT) SOURCE_SUBNET, and 1,713 of those (99.9%) funneled through
    # a single DMZ firewall (RI-ONE-SEC-DMZ). A public 'source' behind a
    # DMZ firewall is very likely a random internet client connecting
    # INBOUND to a public-facing service, not an internal enterprise
    # device that needs eventual IPAM registration — the ingestion logic
    # treats every 'sources' value the same regardless of traffic
    # direction, which is correct for outbound egress traffic but wrong
    # for inbound DMZ traffic. Note: a public IP that's already registered
    # in all_IP_networks (a legitimately-owned block, e.g. Aetna's
    # 167.69.x.x) is NOT affected by this — it already gets routed to
    # _add_to_confirmed() above via the existing lpm() check against
    # ipam_nets, never reaching this unmatched path at all. So every row
    # reaching this loop, by construction, has no existing IPAM
    # ownership — public ones here are either genuine internet noise or a
    # genuinely new not-yet-registered block, and deserve separate
    # handling either way, not silent mixing into the same bucket as
    # genuine unregistered internal subnets. Rows are NOT dropped — still
    # fully visible for review — just tagged distinctly so downstream
    # consumers (preprocess_p1.py) can exclude them from internal-subnet
    # candidate generation.
    unmatched_rows = []
    for s24, data in unmatched_raw.items():
        if s24 in ipam_cidrs:
            continue
        snaps_set = data['snapshots']
        has_cs  = any(s.startswith('cs_') for s in snaps_set)
        has_zsc = any(not s.startswith('cs_') for s in snaps_set)
        if has_zsc and has_cs:
            traffic_source = 'BOTH'
        elif has_zsc:
            traffic_source = 'ZSCALER'
        elif has_cs:
            traffic_source = 'CS'
        else:
            traffic_source = 'NONE'
        qualified = 'YES' if traffic_source in ('BOTH', 'ZSCALER') else 'NO'

        try:
            net_addr = ipaddress.ip_network(s24, strict=False).network_address
            is_public = not net_addr.is_private and net_addr not in ipaddress.ip_network('100.64.0.0/10')
        except Exception:
            is_public = False
            net_addr = None
        data_quality = 'PUBLIC-IP-NOT-OWNED' if is_public else 'UNREGISTERED-IN-IPAM'

        # v1.7.3: cross-reference genuinely public subnets against the
        # real ip_dataset.py registry (see classify_ip_dataset_match()
        # docstring). An ENTERPRISE-tagged match means this is a
        # documented CVS/Aetna asset that simply isn't in all_IP_networks
        # yet -- a real data-quality signal, not internet noise, so it
        # gets its own DATA_QUALITY value rather than being lumped in
        # with genuine unowned public space. QUALIFIED is untouched.
        provider_match, threat_hit = '', ''
        if is_public and net_addr is not None:
            is_ent, provider_match, is_threat = classify_ip_dataset_match(
                str(net_addr), ip_dataset_index)
            if is_ent:
                data_quality = 'ENTERPRISE-OWNED-NOT-IN-IPAM'
            threat_hit = 'Y' if is_threat else ''

        # v1.7.0: closest-IPAM-match, uncapped nearest-neighbor (see
        # find_closest_ipam_match() docstring).
        closest_row, closest_dist = (None, None)
        if ipam_nets is not None:
            closest_row, closest_dist = find_closest_ipam_match(s24, ipam_nets)

        # v1.7.0: fw_route_db.sqlite egress validation (see
        # query_route_db_knowledge() docstring -- coverage caveat applies).
        route_db_result = None
        if route_db_cache is not None:
            route_db_result = query_route_db_knowledge(route_db_cache, s24)

        # v1.7.0: cross-run history (see compute_subnet_history() docstring).
        hist = {}
        if subnet_dates is not None and all_run_dates is not None:
            hist = compute_subnet_history(s24, subnet_dates, all_run_dates, TODAY)

        unmatched_rows.append({
            'SOURCE_SUBNET':    s24,
            'SLASH_16':         data['slash16'],
            'EGRESS_FIREWALLS': '|'.join(sorted(data['fws'])),
            'TRAFFIC_SOURCE':   traffic_source,
            'QUALIFIED':        qualified,
            'CONNECTIONS':      data['connections'],
            'UNIQUE_IPS':       len(data['src_ips']),
            'SOURCE_IPS':       '|'.join(sorted(data['src_ips'])),
            'SNAPSHOT_SOURCES': '|'.join(sorted(data['snapshots'])),
            'DATA_QUALITY':     data_quality,
            'PROVIDER_MATCH':   provider_match,   # v1.7.3
            'THREAT_INTEL_HIT': threat_hit,        # v1.7.3
            'CLOSEST_IPAM_CIDR':          closest_row.get('CIDR','') if closest_row else '',
            'CLOSEST_IPAM_DISTANCE_24S':  closest_dist if closest_dist is not None else '',
            'CLOSEST_IPAM_LOCATION':      closest_row.get('CANONICAL_LOCATION','') if closest_row else '',
            'CLOSEST_IPAM_ROUTING_DOMAIN':closest_row.get('ROUTING_DOMAIN','') if closest_row else '',
            'CLOSEST_IPAM_HERITAGE':      closest_row.get('HERITAGE','') if closest_row else '',
            'ROUTE_DB_RELATIONSHIP':  route_db_result['relationship'] if route_db_result else 'NO-EVIDENCE-YET',
            'ROUTE_DB_MATCH_CIDR':    route_db_result['matched_cidr'] if route_db_result else '',
            'ROUTE_DB_MATCH_DEVICE':  route_db_result['device'] if route_db_result else '',
            'ROUTE_DB_COVERAGE_NOTE': route_db_note,
            'FIRST_SEEN':             hist.get('FIRST_SEEN', TODAY),
            'LAST_SEEN':               hist.get('LAST_SEEN', TODAY),
            'RUNS_SEEN':               hist.get('RUNS_SEEN', 1),
            'RUNS_SINCE_FIRST_SEEN':   hist.get('RUNS_SINCE_FIRST_SEEN', 1),
            'CONSISTENCY_PCT':         hist.get('CONSISTENCY_PCT', 100.0),
        })

    # Sort qualified subnets first, then by connection volume — so the genuinely
    # actionable discoveries (BOTH/ZSCALER) surface at the top of the harvest
    # rather than being buried under CS-only external-destination noise.
    unmatched_rows.sort(key=lambda x: (x['QUALIFIED'] != 'YES', -x['CONNECTIONS']))
    return out_rows, unmatched_rows, stats, ambiguous_rows


# ── Write topology CSV ────────────────────────────────────────────────────────

TOPOLOGY_FIELDNAMES = [
    'CIDR', 'SITE_CODE', 'CANONICAL_LOCATION', 'ROUTING_DOMAIN',
    'LOCATION_TYPE', 'HERITAGE', 'NET_TYPE',
    'EGRESS_FIREWALL_LOGICAL', 'EGRESS_FIREWALL_CLUSTER', 'PA_DEVICE_GROUP',
    'MAPPING_METHOD', 'CONFIDENCE', 'TRAFFIC_CONFIRMED', 'TRAFFIC_SOURCE',
    'ROUTE_VALIDATED', 'ROUTE_MATCH_FWS', 'ROUTE_MISMATCH', 'ROUTE_SOURCE',
    'CONNECTIONS', 'SNAPSHOT_SOURCES', 'DATASET_VERSION',
]

UNKNOWN_FIELDNAMES = [
    'SOURCE_SUBNET', 'SLASH_16', 'EGRESS_FIREWALLS',
    'TRAFFIC_SOURCE', 'QUALIFIED', 'CONNECTIONS',
    'UNIQUE_IPS', 'SOURCE_IPS', 'SNAPSHOT_SOURCES', 'DATA_QUALITY',
    'PROVIDER_MATCH', 'THREAT_INTEL_HIT',  # v1.7.3 ip_dataset.py cross-reference
    'CLOSEST_IPAM_CIDR', 'CLOSEST_IPAM_DISTANCE_24S', 'CLOSEST_IPAM_LOCATION',
    'CLOSEST_IPAM_ROUTING_DOMAIN', 'CLOSEST_IPAM_HERITAGE',
    'ROUTE_DB_RELATIONSHIP', 'ROUTE_DB_MATCH_CIDR', 'ROUTE_DB_MATCH_DEVICE',
    'ROUTE_DB_COVERAGE_NOTE',
    'FIRST_SEEN', 'LAST_SEEN', 'RUNS_SEEN', 'RUNS_SINCE_FIRST_SEEN', 'CONSISTENCY_PCT',
]


def write_topology_csv(out_rows, out_path, ipam_source, zsc_count, cs_count):
    unique_cidrs = len(set(r['CIDR'] for r in out_rows))
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM=EGRESS-FW-TOPOLOGY\n')
        f.write(f'#VERSION={VERSION}\n')
        f.write(f'#GENERATOR={SCRIPT_NAME}\n')
        f.write(f'#IPAM_SOURCE={os.path.basename(ipam_source)}\n')
        f.write(f'#ZSCALER_ZIPS={zsc_count}\n')
        f.write(f'#CS_FILES={cs_count}\n')
        f.write(f'#TOTAL_ROWS={len(out_rows)}\n')
        f.write(f'#UNIQUE_CIDRS={unique_cidrs}\n')
        f.write(f'#CREATED={datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}\n')
        f.write(f'#NOTE=CONFIDENCE: HIGH=traffic-confirmed, MEDIUM=location-confirmed, LOW=asserted-inferred\n')
        w = csv.DictWriter(f, fieldnames=TOPOLOGY_FIELDNAMES, extrasaction='ignore')
        w.writeheader()
        w.writerows(out_rows)
    print(f'  Wrote: {os.path.basename(out_path)}  ({len(out_rows):,} rows, {unique_cidrs:,} unique CIDRs)')


def write_unknown_csv(unmatched_rows, out_path):
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM=unknown_ip_subnets\n')
        f.write(f'#VERSION={VERSION}\n')
        f.write(f'#GENERATOR={SCRIPT_NAME}\n')
        f.write(f'#NOTE=Subnets observed in traffic with no IPAM registration\n')
        f.write(f'#NOTE=DATA_QUALITY: UNREGISTERED-IN-IPAM=genuine internal candidate, '
                f'PUBLIC-IP-NOT-OWNED=likely internet noise, '
                f'ENTERPRISE-OWNED-NOT-IN-IPAM=known CVS/Aetna asset missing from all_IP_networks (v1.7.3)\n')
        w = csv.DictWriter(f, fieldnames=UNKNOWN_FIELDNAMES, extrasaction='ignore')
        w.writeheader()
        w.writerows(unmatched_rows)
    print(f'  Wrote: {os.path.basename(out_path)}  ({len(unmatched_rows):,} unknown subnets)')


AMBIGUOUS_FIELDNAMES = [
    'CIDR', 'CANONICAL_LOCATION', 'HERITAGE', 'NET_TYPE', 'ROUTING_DOMAIN',
    'CANDIDATE_FIREWALLS', 'CANDIDATE_COUNT', 'DATASET_VERSION',
]


def write_known_ambiguous_egress(ambiguous_rows, out_path):
    """v1.14.0. First-class, versioned, re-runnable dataset -- same real
    discipline as build_known_unknown_ip_resolver.py's known_unknown_ip_
    prefixes: a subnet lands here when its (location, heritage) grouping has
    real confirmed traffic evidence for MORE THAN ONE egress firewall, with
    no further real evidence (route table) narrowing it to one. This is a
    genuine, confirmed tie -- not a guess this script declined to make.
    Deliberately does NOT attempt NET_TYPE/business-character pattern
    inference to resolve these further: tried by hand this session and
    correctly rejected as too fragile once checked against real confirmed
    traffic (Coram: tagged NET_TYPE=Omnicare, behaves like Specialty
    instead -- a confident business-character rule would have gotten this
    wrong). Meant to be re-run against on a future session as more real
    Zscaler/CrowdStrike traffic accumulates and narrows some of these to a
    single real answer -- not re-derived from scratch each time.
    """
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM=known_ambiguous_egress\n')
        f.write(f'#VERSION={VERSION}\n')
        f.write(f'#GENERATOR={SCRIPT_NAME}\n')
        f.write(f'#NOTE=Real confirmed traffic exists for multiple egress firewalls at this '
                f'(CANONICAL_LOCATION, HERITAGE) combination, with no further real evidence '
                f"narrowing it to one. A genuine tie, not an unresolved guess -- see the "
                f"cvs-aetna-ip-prefix-allocations skill and this script's v1.14.0 changelog "
                f'for the full real methodology and why NET_TYPE-based inference was rejected.\n')
        f.write(f'#NOTE=Re-run this script as more real traffic accumulates -- some of these '
                f'will resolve to TRAFFIC-CONFIRMED on a future run without any manual action.\n')
        w = csv.DictWriter(f, fieldnames=AMBIGUOUS_FIELDNAMES, extrasaction='ignore')
        w.writeheader()
        for row in ambiguous_rows:
            row['DATASET_VERSION'] = VERSION
        w.writerows(ambiguous_rows)
    print(f'  Wrote: {os.path.basename(out_path)}  ({len(ambiguous_rows):,} genuinely ambiguous CIDRs)')


CONFLICT_FIELDNAMES = [
    'CONFLICT_TYPE', 'CIDR', 'SITE_CODE', 'CANONICAL_LOCATION',
    'ROUTING_DOMAIN', 'HERITAGE', 'LOCATION_TYPE', 'NET_TYPE',
    'ASSIGNED_FW', 'ROUTE_MATCH_FWS', 'ROUTE_SOURCE', 'MAPPING_METHOD', 'CONFIDENCE',
    'TRAFFIC_CONFIRMED', 'CONNECTIONS', 'DATASET_VERSION',
]


def write_conflicts_csv(out_rows, out_path, dry_run):
    """Extract ROUTE_MISMATCH and NO_ROUTE rows and write a conflict report.

    ROUTE_MISMATCH: assigned FW has no route to this CIDR — a different FW does.
    NO_ROUTE:       no FW has a route to this CIDR at all.

    Sorted by CONFLICT_TYPE, then by assigned FW, then by CIDR.
    """
    mismatches = [r for r in out_rows if r.get('ROUTE_MISMATCH') == 'Y']
    no_routes  = [r for r in out_rows
                  if r.get('ROUTE_VALIDATED') == 'NO_ROUTE'  # excludes NO_ROUTE_EXPECTED
                  and r.get('EGRESS_FIREWALL_LOGICAL')]

    conflict_rows = []
    for r in mismatches:
        conflict_rows.append({
            'CONFLICT_TYPE':      'ROUTE_MISMATCH',
            'CIDR':               r.get('CIDR', ''),
            'SITE_CODE':          r.get('SITE_CODE', ''),
            'CANONICAL_LOCATION': r.get('CANONICAL_LOCATION', ''),
            'ROUTING_DOMAIN':     r.get('ROUTING_DOMAIN', ''),
            'HERITAGE':           r.get('HERITAGE', ''),
            'LOCATION_TYPE':      r.get('LOCATION_TYPE', ''),
            'NET_TYPE':           r.get('NET_TYPE', ''),
            'ASSIGNED_FW':        r.get('EGRESS_FIREWALL_LOGICAL', ''),
            'ROUTE_MATCH_FWS':    r.get('ROUTE_MATCH_FWS', ''),
            'ROUTE_SOURCE':       r.get('ROUTE_SOURCE', ''),
            'MAPPING_METHOD':     r.get('MAPPING_METHOD', ''),
            'CONFIDENCE':         r.get('CONFIDENCE', ''),
            'TRAFFIC_CONFIRMED':  r.get('TRAFFIC_CONFIRMED', ''),
            'CONNECTIONS':        r.get('CONNECTIONS', ''),
            'DATASET_VERSION':    VERSION,
        })

    for r in no_routes:
        conflict_rows.append({
            'CONFLICT_TYPE':      'NO_ROUTE',
            'CIDR':               r.get('CIDR', ''),
            'SITE_CODE':          r.get('SITE_CODE', ''),
            'CANONICAL_LOCATION': r.get('CANONICAL_LOCATION', ''),
            'ROUTING_DOMAIN':     r.get('ROUTING_DOMAIN', ''),
            'HERITAGE':           r.get('HERITAGE', ''),
            'LOCATION_TYPE':      r.get('LOCATION_TYPE', ''),
            'NET_TYPE':           r.get('NET_TYPE', ''),
            'ASSIGNED_FW':        r.get('EGRESS_FIREWALL_LOGICAL', ''),
            'ROUTE_MATCH_FWS':    '',
            'ROUTE_SOURCE':       '',
            'MAPPING_METHOD':     r.get('MAPPING_METHOD', ''),
            'CONFIDENCE':         r.get('CONFIDENCE', ''),
            'TRAFFIC_CONFIRMED':  r.get('TRAFFIC_CONFIRMED', ''),
            'CONNECTIONS':        r.get('CONNECTIONS', ''),
            'DATASET_VERSION':    VERSION,
        })

    # Sort: ROUTE_MISMATCH first, then by assigned FW, then CIDR
    conflict_rows.sort(key=lambda x: (
        0 if x['CONFLICT_TYPE'] == 'ROUTE_MISMATCH' else 1,
        x['ASSIGNED_FW'],
        x['CIDR'],
    ))

    if dry_run:
        print(f'  [DRY-RUN] Would write → {os.path.basename(out_path)}'
              f'  ({len(mismatches):,} mismatches, {len(no_routes):,} no-route)')
        return conflict_rows

    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f'#STEM=fw_topology_conflicts\n')
        f.write(f'#VERSION={VERSION}\n')
        f.write(f'#GENERATOR={SCRIPT_NAME}\n')
        f.write(f'#NOTE=ROUTE_MISMATCH=assigned FW has no route; NO_ROUTE=no FW has a route\n')
        f.write(f'#ROUTE_MISMATCH_COUNT={len(mismatches)}\n')
        f.write(f'#NO_ROUTE_COUNT={len(no_routes)}\n')
        w = csv.DictWriter(f, fieldnames=CONFLICT_FIELDNAMES, extrasaction='ignore')
        w.writeheader()
        w.writerows(conflict_rows)
    print(f'  Wrote: {os.path.basename(out_path)}'
          f'  ({len(mismatches):,} mismatches  |  {len(no_routes):,} no-route)')

    return conflict_rows


# ── Breakdown CSV ─────────────────────────────────────────────────────────────

def build_breakdown_csv(out_rows, out_path, dry_run):
    agg = {}
    for r in out_rows:
        fw  = r.get('EGRESS_FIREWALL_LOGICAL', '').strip()
        if not fw:
            continue
        loc = r.get('CANONICAL_LOCATION', '').strip()
        rd  = r.get('ROUTING_DOMAIN', '').strip()
        key = (fw, loc, rd)
        if key not in agg:
            agg[key] = {
                'EGRESS_FIREWALL_LOGICAL':  fw,
                'EGRESS_FIREWALL_CLUSTER':  FW_CLUSTER_MAP.get(fw, ''),
                'PA_DEVICE_GROUP':          FW_PA_DG_MAP.get(fw, ''),
                'CANONICAL_LOCATION':       loc,
                'SITE_CODE':                r.get('SITE_CODE', ''),
                'ROUTING_DOMAIN':           rd,
                'HERITAGE':                 r.get('HERITAGE', ''),
                'LOCATION_TYPE':            r.get('LOCATION_TYPE', ''),
                'SUBNET_COUNT':             0,
                'CONFIRMED_COUNT':          0,
                'ASSERTED_COUNT':           0,
                'TOTAL_CONNECTIONS':        0,
                'MAPPING_METHODS':          set(),
            }
        a = agg[key]
        a['SUBNET_COUNT'] += 1
        if r.get('TRAFFIC_CONFIRMED') == 'Y':
            a['CONFIRMED_COUNT'] += 1
        else:
            a['ASSERTED_COUNT'] += 1
        try:
            a['TOTAL_CONNECTIONS'] += int(r.get('CONNECTIONS', 0) or 0)
        except ValueError:
            pass
        mm = r.get('MAPPING_METHOD', '').strip()
        if mm:
            a['MAPPING_METHODS'].add(mm)

    bdn_rows = []
    for key in sorted(agg.keys(), key=lambda k: (
        FW_ORDER.index(k[0]) if k[0] in FW_ORDER else 99, k[1]
    )):
        a = agg[key]
        bdn_rows.append({
            'EGRESS_FIREWALL_LOGICAL':  a['EGRESS_FIREWALL_LOGICAL'],
            'EGRESS_FIREWALL_CLUSTER':  a['EGRESS_FIREWALL_CLUSTER'],
            'PA_DEVICE_GROUP':          a['PA_DEVICE_GROUP'],
            'SITE_CODE':                a['SITE_CODE'],
            'CANONICAL_LOCATION':       a['CANONICAL_LOCATION'],
            'ROUTING_DOMAIN':           a['ROUTING_DOMAIN'],
            'HERITAGE':                 a['HERITAGE'],
            'LOCATION_TYPE':            a['LOCATION_TYPE'],
            'SUBNET_COUNT':             a['SUBNET_COUNT'],
            'CONFIRMED_COUNT':          a['CONFIRMED_COUNT'],
            'ASSERTED_COUNT':           a['ASSERTED_COUNT'],
            'TOTAL_CONNECTIONS':        a['TOTAL_CONNECTIONS'],
            'MAPPING_METHODS':          '|'.join(sorted(a['MAPPING_METHODS'])),
            'DATASET_VERSION':          VERSION,
        })

    bdn_fieldnames = [
        'EGRESS_FIREWALL_LOGICAL', 'EGRESS_FIREWALL_CLUSTER', 'PA_DEVICE_GROUP',
        'SITE_CODE', 'CANONICAL_LOCATION', 'ROUTING_DOMAIN', 'HERITAGE',
        'LOCATION_TYPE', 'SUBNET_COUNT', 'CONFIRMED_COUNT', 'ASSERTED_COUNT',
        'TOTAL_CONNECTIONS', 'MAPPING_METHODS', 'DATASET_VERSION',
    ]

    if dry_run:
        print(f'  [DRY-RUN] Would write {len(bdn_rows):,} rows → {os.path.basename(out_path)}')
    else:
        with open(out_path, 'w', newline='', encoding='utf-8') as f:
            f.write(f'#STEM=fw_egress_breakdown\n')
            f.write(f'#VERSION={VERSION}\n')
            f.write(f'#GENERATOR={SCRIPT_NAME}\n')
            f.write(f'#ROWS={len(bdn_rows)}\n')
            w = csv.DictWriter(f, fieldnames=bdn_fieldnames)
            w.writeheader()
            w.writerows(bdn_rows)
        print(f'  Wrote: {os.path.basename(out_path)}  ({len(bdn_rows):,} rows)')

    return bdn_rows, agg


# ── HTML report ───────────────────────────────────────────────────────────────

def build_html_report(out_rows, agg, sources_desc, out_path, dry_run):
    fw_data = {}
    for r in out_rows:
        fw = r.get('EGRESS_FIREWALL_LOGICAL', '').strip()
        if not fw:
            continue
        if fw not in fw_data:
            fw_data[fw] = {'subnets': [], 'locations': {}}
        fw_data[fw]['subnets'].append(r)
        loc  = r.get('CANONICAL_LOCATION', '').strip()
        rd   = r.get('ROUTING_DOMAIN', '').strip()
        lkey = (loc, rd)
        if lkey not in fw_data[fw]['locations']:
            fw_data[fw]['locations'][lkey] = {
                'loc': loc, 'site_code': r.get('SITE_CODE', ''),
                'rd': rd, 'heritage': r.get('HERITAGE', ''),
                'loc_type': r.get('LOCATION_TYPE', ''),
                'subnets': [], 'confirmed': 0, 'asserted': 0, 'connections': 0,
            }
        ld = fw_data[fw]['locations'][lkey]
        ld['subnets'].append({
            'cidr':        r.get('CIDR', ''),
            'net_type':    r.get('NET_TYPE', ''),
            'confidence':  r.get('CONFIDENCE', ''),
            'confirmed':   r.get('TRAFFIC_CONFIRMED', 'N'),
            'source':      r.get('TRAFFIC_SOURCE', 'NONE'),
            'method':      r.get('MAPPING_METHOD', ''),
            'connections': r.get('CONNECTIONS', '0'),
        })
        if r.get('TRAFFIC_CONFIRMED') == 'Y':
            ld['confirmed'] += 1
        else:
            ld['asserted'] += 1
        try:
            ld['connections'] += int(r.get('CONNECTIONS', 0) or 0)
        except ValueError:
            pass

    total_subnets   = len(out_rows)
    total_confirmed = sum(1 for r in out_rows if r.get('TRAFFIC_CONFIRMED') == 'Y')
    total_asserted  = total_subnets - total_confirmed
    total_conns     = sum(int(r.get('CONNECTIONS', 0) or 0) for r in out_rows
                          if str(r.get('CONNECTIONS', '')).isdigit())

    # Source overlap counts (per unique CIDR, using first row per CIDR)
    cidr_source = {}
    for r in out_rows:
        cidr = r.get('CIDR', '')
        if cidr not in cidr_source:
            cidr_source[cidr] = r.get('TRAFFIC_SOURCE', 'NONE')
    src_counts = collections.Counter(cidr_source.values())
    cnt_both    = src_counts.get('BOTH',    0)
    cnt_zsc     = src_counts.get('ZSCALER', 0)
    cnt_cs      = src_counts.get('CS',      0)
    cnt_none    = src_counts.get('NONE',    0)

    # Per-FW source overlap for Overview table
    fw_src = {}
    for r in out_rows:
        fw  = r.get('EGRESS_FIREWALL_LOGICAL', '').strip()
        src = r.get('TRAFFIC_SOURCE', 'NONE')
        if not fw:
            continue
        if fw not in fw_src:
            fw_src[fw] = {'BOTH': 0, 'ZSCALER': 0, 'CS': 0, 'NONE': 0, 'total': 0}
        fw_src[fw][src] = fw_src[fw].get(src, 0) + 1
        fw_src[fw]['total'] += 1

    js_fw_data = {}
    for fw, fdata in fw_data.items():
        locs = []
        for lkey, ld in sorted(fdata['locations'].items(),
                               key=lambda x: len(x[1]['subnets']), reverse=True):
            locs.append({
                'loc': ld['loc'], 'site_code': ld['site_code'],
                'rd': ld['rd'], 'heritage': ld['heritage'],
                'loc_type': ld['loc_type'],
                'subnet_count': len(ld['subnets']),
                'confirmed': ld['confirmed'], 'asserted': ld['asserted'],
                'connections': ld['connections'], 'subnets': ld['subnets'],
            })
        js_fw_data[fw] = {
            'total': len(fdata['subnets']),
            'cluster': FW_CLUSTER_MAP.get(fw, ''),
            'dg': FW_PA_DG_MAP.get(fw, ''),
            'locations': locs,
        }

    fws_ordered  = [fw for fw in FW_ORDER if fw in fw_data]
    fws_ordered += [fw for fw in sorted(fw_data.keys()) if fw not in FW_ORDER]

    rd_colours_js = json.dumps(RD_COLOURS)
    fw_data_js    = json.dumps(js_fw_data)
    fws_js        = json.dumps(fws_ordered)
    fw_src_js     = json.dumps(fw_src)
    today_str     = date.today().strftime('%B %d, %Y')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IP Network Egress FW Topology — CVS Health</title>
<style>
  :root {{
    --navy:#17447C;--red:#CC0000;--dark:#1e293b;--mid:#475569;
    --light:#94a3b8;--bg:#f8fafc;--card:#fff;--border:#e2e8f0;
    --high:#16a34a;--med:#d97706;--low:#94a3b8;
  }}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
       background:var(--bg);color:var(--dark);font-size:14px}}
  header{{background:var(--navy);color:white;padding:16px 24px;
          display:flex;align-items:center;justify-content:space-between}}
  header h1{{font-size:18px;font-weight:600}}
  header .meta{{font-size:12px;opacity:.7;text-align:right}}
  .summary-bar{{display:flex;gap:12px;padding:16px 24px;background:white;
                border-bottom:1px solid var(--border);flex-wrap:wrap}}
  .stat-card{{background:var(--bg);border:1px solid var(--border);border-radius:8px;
             padding:10px 16px;min-width:130px}}
  .stat-card .val{{font-size:22px;font-weight:700;color:var(--navy)}}
  .stat-card .lbl{{font-size:11px;color:var(--light);margin-top:2px;text-transform:uppercase}}
  .tabs{{display:flex;gap:2px;padding:12px 24px 0;background:white;
         border-bottom:1px solid var(--border);overflow-x:auto;flex-wrap:nowrap}}
  .tab{{padding:8px 14px;border-radius:6px 6px 0 0;cursor:pointer;font-size:13px;
        border:1px solid transparent;border-bottom:none;white-space:nowrap;
        color:var(--mid);background:var(--bg);transition:all .15s}}
  .tab:hover{{background:#dbeafe;color:var(--navy)}}
  .tab.active{{background:white;color:var(--navy);font-weight:600;
               border-color:var(--border);border-bottom-color:white;margin-bottom:-1px}}
  .tab .badge{{display:inline-block;background:var(--navy);color:white;
               border-radius:10px;padding:1px 7px;font-size:11px;margin-left:6px}}
  .pane{{display:none;padding:20px 24px}}
  .pane.active{{display:block}}
  .fw-header{{display:flex;gap:16px;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap}}
  .fw-title{{font-size:18px;font-weight:700;color:var(--navy)}}
  .fw-meta{{font-size:12px;color:var(--mid);margin-top:4px}}
  .fw-stats{{display:flex;gap:10px;flex-wrap:wrap}}
  .fw-stat{{background:var(--bg);border:1px solid var(--border);border-radius:6px;
            padding:8px 14px;font-size:12px}}
  .fw-stat b{{display:block;font-size:18px;color:var(--navy)}}
  .search-bar{{margin-bottom:12px}}
  .search-bar input{{width:100%;max-width:400px;padding:8px 12px;
                     border:1px solid var(--border);border-radius:6px;font-size:13px;outline:none}}
  .search-bar input:focus{{border-color:var(--navy);box-shadow:0 0 0 2px rgba(23,68,124,.15)}}
  table{{width:100%;border-collapse:collapse;font-size:13px}}
  th{{background:var(--navy);color:white;padding:8px 10px;text-align:left;
      font-weight:500;font-size:12px;white-space:nowrap;cursor:pointer;user-select:none}}
  th:hover{{background:#1e5a9e}}
  td{{padding:7px 10px;border-bottom:1px solid var(--border);vertical-align:middle}}
  tr:hover td{{background:#f1f5f9}}
  .rd-badge{{display:inline-block;padding:2px 8px;border-radius:10px;
             font-size:11px;color:white;white-space:nowrap}}
  .conf-high{{color:var(--high);font-weight:600}}
  .conf-med{{color:var(--med)}}
  .conf-low{{color:var(--low)}}
  .btn-expand{{background:var(--navy);color:white;border:none;border-radius:4px;
               padding:3px 10px;font-size:11px;cursor:pointer}}
  .btn-expand:hover{{background:#1e5a9e}}
  .modal-overlay{{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);
                  z-index:1000;align-items:center;justify-content:center}}
  .modal-overlay.open{{display:flex}}
  .modal{{background:white;border-radius:10px;width:90%;max-width:900px;
          max-height:85vh;display:flex;flex-direction:column;overflow:hidden}}
  .modal-header{{padding:14px 18px;background:var(--navy);color:white;
                 display:flex;justify-content:space-between;align-items:center}}
  .modal-header h3{{font-size:15px}}
  .modal-close{{background:none;border:none;color:white;font-size:20px;
                cursor:pointer;line-height:1;padding:0 4px}}
  .modal-body{{overflow-y:auto;padding:16px}}
  .subnet-table{{width:100%;border-collapse:collapse;font-size:12px}}
  .subnet-table th{{background:#334155;color:white;padding:6px 10px;text-align:left;font-weight:500}}
  .subnet-table td{{padding:5px 10px;border-bottom:1px solid var(--border);font-family:monospace}}
  .subnet-table tr:hover td{{background:#f8fafc}}
  .method-tag{{display:inline-block;background:#e2e8f0;border-radius:4px;
               padding:1px 6px;font-size:10px;color:var(--mid);font-family:monospace}}
  .conf-badge{{display:inline-block;padding:1px 7px;border-radius:10px;
               font-size:11px;color:white;font-weight:600}}
  .expand-arrow{{display:inline-block;width:14px;font-size:11px;
                 color:var(--mid);transition:transform .15s;margin-right:4px}}
  .fw-row:hover td{{background:#dbeafe}}
  .loc-row:hover td{{background:#e0e7ff}}
  .sub-detail-row td{{border-bottom:1px solid #f1f5f9}}
</style>
</head>
<body>
<header>
  <div>
    <h1>IP Network Egress Firewall Topology</h1>
    <div style="font-size:12px;opacity:.7;margin-top:3px;">CVS Health Information Security — CCD Platform</div>
  </div>
  <div class="meta">
    Generated: {today_str}<br>
    Sources: {sources_desc}<br>
    Script: {SCRIPT_NAME}
  </div>
</header>

<div class="summary-bar">
  <div class="stat-card">
    <div class="val">{total_subnets:,}</div>
    <div class="lbl">Total Subnet Rows</div>
  </div>
  <div class="stat-card">
    <div class="val" style="color:var(--high)">{total_confirmed:,}</div>
    <div class="lbl">Traffic Confirmed</div>
  </div>
  <div class="stat-card">
    <div class="val" style="color:var(--med)">{total_asserted:,}</div>
    <div class="lbl">Inferred</div>
  </div>
  <div class="stat-card">
    <div class="val">{total_conns:,}</div>
    <div class="lbl">Total Connections</div>
  </div>
  <div class="stat-card">
    <div class="val">{len(fws_ordered)}</div>
    <div class="lbl">Egress Firewalls</div>
  </div>
  <div class="stat-card" style="border-color:#7C3AED">
    <div class="val" style="color:#7C3AED">{cnt_both:,}</div>
    <div class="lbl">Zscaler + CS</div>
  </div>
  <div class="stat-card" style="border-color:#2563EB">
    <div class="val" style="color:#2563EB">{cnt_zsc:,}</div>
    <div class="lbl">Zscaler Only</div>
  </div>
  <div class="stat-card" style="border-color:#D97706">
    <div class="val" style="color:#D97706">{cnt_cs:,}</div>
    <div class="lbl">CS Only</div>
  </div>
</div>

<div class="tabs" id="fw-tabs"></div>
<div id="fw-panes"></div>

<div class="modal-overlay" id="modal">
  <div class="modal">
    <div class="modal-header">
      <h3 id="modal-title">Subnets</h3>
      <button class="modal-close" onclick="closeModal()">×</button>
    </div>
    <div class="modal-body" id="modal-body"></div>
  </div>
</div>

<script>
const FW_DATA={fw_data_js};
const FWS={fws_js};
const RD_COLOURS={rd_colours_js};
const FW_SRC={fw_src_js};
const CONF_COLOURS={{'HIGH':'#16a34a','MEDIUM':'#d97706','LOW':'#94a3b8','NONE':'#cbd5e1'}};
const SRC_COLOURS={{'BOTH':'#7C3AED','ZSCALER':'#2563EB','CS':'#D97706','NONE':'#94a3b8'}};

function rdBadge(rd){{
  const c=RD_COLOURS[rd]||'#6B7280';
  return `<span class="rd-badge" style="background:${{c}}">${{rd}}</span>`;
}}
function confBadge(c){{
  const col=CONF_COLOURS[c]||'#94a3b8';
  return `<span class="conf-badge" style="background:${{col}}">${{c}}</span>`;
}}
function srcBadge(s){{
  const col=SRC_COLOURS[s]||'#94a3b8';
  return `<span class="conf-badge" style="background:${{col}}">${{s}}</span>`;
}}
function fmtNum(n){{return n.toLocaleString()}}

function renderOverview(){{
  // Build a lookup: fw -> locations -> subnets (from FW_DATA, enriched with source)
  // We need per-location source counts for the location expansion rows
  const fwLocSrc={{}};
  FWS.forEach(fw=>{{
    fwLocSrc[fw]={{}};
    (FW_DATA[fw]?.locations||[]).forEach(loc=>{{
      const key=loc.site_code||loc.loc;
      const cnt={{BOTH:0,ZSCALER:0,CS:0,NONE:0}};
      loc.subnets.forEach(s=>{{
        const src=s.confirmed==='Y'?(s.source||'NONE'):'NONE';
        cnt[src]=(cnt[src]||0)+1;
      }});
      fwLocSrc[fw][key]={{loc,cnt}};
    }});
  }});

  const fwRows=FWS.map((fw,fi)=>{{
    const d=FW_SRC[fw]||{{}};
    const tot=d.total||0;
    const both=d.BOTH||0;
    const zsc=d.ZSCALER||0;
    const cs=d.CS||0;
    const none=d.NONE||0;
    const locs=FW_DATA[fw]?.locations||[];

    // Location sub-rows (hidden initially)
    const locRows=locs.map((loc,li)=>{{
      const lkey=loc.site_code||loc.loc;
      const lsrc=fwLocSrc[fw][lkey]?.cnt||{{BOTH:0,ZSCALER:0,CS:0,NONE:0}};

      // Subnet detail rows (hidden initially, two levels deep)
      const confirmed_subs=loc.subnets.filter(s=>s.confirmed==='Y');
      const inferred_subs =loc.subnets.filter(s=>s.confirmed!=='Y');
      const subRows=[...confirmed_subs,...inferred_subs].map(s=>{{
        const src=s.confirmed==='Y'?srcBadge(s.source||'NONE'):'<span style="color:#94a3b8">—</span>';
        return `<tr class="sub-detail-row" data-lkey="ov-${{fi}}-${{li}}" style="display:none;background:#f8fafc">
          <td style="padding:4px 10px 4px 56px;font-family:monospace;font-size:11px">${{s.cidr}}</td>
          <td style="padding:4px 8px;font-size:11px;color:#475569">${{s.net_type}}</td>
          <td style="padding:4px 8px">${{src}}</td>
          <td style="padding:4px 8px">${{confBadge(s.confidence)}}</td>
          <td style="padding:4px 8px;text-align:right;font-size:11px">${{parseInt(s.connections||0).toLocaleString()}}</td>
        </tr>`;
      }}).join('');

      return `<tr class="loc-row" data-fw-idx="${{fi}}" data-loc-idx="${{li}}"
                  style="display:none;background:#f1f5f9;cursor:pointer"
                  onclick="toggleSubnets(${{fi}},${{li}})">
        <td style="padding:6px 10px 6px 28px;font-size:12px">
          <span class="expand-arrow" id="sarr-${{fi}}-${{li}}">▶</span>
          ${{loc.loc}}
        </td>
        <td style="padding:6px 8px;font-family:monospace;font-size:11px">${{loc.site_code}}</td>
        <td style="padding:6px 8px;text-align:right;font-size:12px">${{loc.subnet_count}}</td>
        <td style="padding:6px 8px;text-align:right;color:#7C3AED;font-weight:600;font-size:12px">${{lsrc.BOTH||0}}</td>
        <td style="padding:6px 8px;text-align:right;color:#2563EB;font-weight:600;font-size:12px">${{lsrc.ZSCALER||0}}</td>
        <td style="padding:6px 8px;text-align:right;color:#D97706;font-weight:600;font-size:12px">${{lsrc.CS||0}}</td>
        <td style="padding:6px 8px;text-align:right;color:#94a3b8;font-size:12px">${{lsrc.NONE||0}}</td>
      </tr>
      ${{subRows}}`;
    }}).join('');

    return `<tr class="fw-row" style="cursor:pointer" onclick="toggleFW(${{fi}})">
      <td style="padding:8px 10px;font-weight:600">
        <span class="expand-arrow" id="farr-${{fi}}">▶</span>
        ${{fw}}
      </td>
      <td style="text-align:right">${{fmtNum(tot)}}</td>
      <td style="text-align:right;color:#7C3AED;font-weight:600">${{fmtNum(both)}}</td>
      <td style="text-align:right;color:#2563EB;font-weight:600">${{fmtNum(zsc)}}</td>
      <td style="text-align:right;color:#D97706;font-weight:600">${{fmtNum(cs)}}</td>
      <td style="text-align:right;color:#94a3b8">${{fmtNum(none)}}</td>
    </tr>
    ${{locRows}}`;
  }}).join('');

  return `
    <div class="fw-header" style="margin-bottom:20px">
      <div>
        <div class="fw-title">Source Overlap Analysis</div>
        <div class="fw-meta">Click a firewall to expand locations · click a location to expand subnets</div>
      </div>
    </div>
    <table id="ov-table" style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:24px">
      <thead><tr>
        <th style="background:var(--navy);color:white;padding:8px 10px;text-align:left;font-weight:500;font-size:12px">Firewall / Location</th>
        <th style="background:var(--navy);color:white;padding:8px 10px;text-align:right;font-weight:500;font-size:12px">Total</th>
        <th style="background:#7C3AED;color:white;padding:8px 10px;text-align:right;font-weight:500;font-size:12px">Zscaler+CS</th>
        <th style="background:#2563EB;color:white;padding:8px 10px;text-align:right;font-weight:500;font-size:12px">Zscaler Only</th>
        <th style="background:#D97706;color:white;padding:8px 10px;text-align:right;font-weight:500;font-size:12px">CS Only</th>
        <th style="background:#64748b;color:white;padding:8px 10px;text-align:right;font-weight:500;font-size:12px">Not Confirmed</th>
      </tr></thead>
      <tbody>${{fwRows}}</tbody>
    </table>
    <div id="sub-header" style="display:none;background:#e2e8f0;border-radius:6px;padding:6px 12px;
         font-size:11px;color:#475569;margin-bottom:8px">
      Subnet detail: <span id="sub-header-loc"></span>
    </div>`;
}}

let ovFWOpen=null;
let ovLocOpen=null;

function toggleFW(fi){{
  const rows=document.querySelectorAll('.loc-row[data-fw-idx="'+fi+'"]');
  const arr=document.getElementById('farr-'+fi);
  if(ovFWOpen===fi){{
    // collapse fw and any open loc
    rows.forEach(r=>r.style.display='none');
    if(ovLocOpen!==null){{
      document.querySelectorAll('.sub-detail-row[data-lkey="ov-'+fi+'-'+ovLocOpen+'"]')
        .forEach(r=>r.style.display='none');
      const sarr=document.getElementById('sarr-'+fi+'-'+ovLocOpen);
      if(sarr) sarr.textContent='▶';
      ovLocOpen=null;
    }}
    arr.textContent='▶';
    ovFWOpen=null;
  }} else {{
    // collapse previous fw
    if(ovFWOpen!==null){{
      document.querySelectorAll('.loc-row[data-fw-idx="'+ovFWOpen+'"]')
        .forEach(r=>r.style.display='none');
      if(ovLocOpen!==null){{
        document.querySelectorAll('.sub-detail-row[data-lkey="ov-'+ovFWOpen+'-'+ovLocOpen+'"]')
          .forEach(r=>r.style.display='none');
        const sarr=document.getElementById('sarr-'+ovFWOpen+'-'+ovLocOpen);
        if(sarr) sarr.textContent='▶';
        ovLocOpen=null;
      }}
      const prevArr=document.getElementById('farr-'+ovFWOpen);
      if(prevArr) prevArr.textContent='▶';
    }}
    rows.forEach(r=>r.style.display='');
    arr.textContent='▼';
    ovFWOpen=fi;
  }}
}}

function toggleSubnets(fi,li){{
  if(ovFWOpen!==fi) return;
  const key='ov-'+fi+'-'+li;
  const rows=document.querySelectorAll('.sub-detail-row[data-lkey="'+key+'"]');
  const arr=document.getElementById('sarr-'+fi+'-'+li);
  if(ovLocOpen===li){{
    rows.forEach(r=>r.style.display='none');
    arr.textContent='▶';
    ovLocOpen=null;
  }} else {{
    if(ovLocOpen!==null){{
      document.querySelectorAll('.sub-detail-row[data-lkey="ov-'+fi+'-'+ovLocOpen+'"]')
        .forEach(r=>r.style.display='none');
      const prevArr=document.getElementById('sarr-'+fi+'-'+ovLocOpen);
      if(prevArr) prevArr.textContent='▶';
    }}
    rows.forEach(r=>r.style.display='');
    arr.textContent='▼';
    ovLocOpen=li;
  }}
}}

function renderTabs(){{
  const tabsEl=document.getElementById('fw-tabs');
  const panesEl=document.getElementById('fw-panes');

  // Overview tab
  const ovTab=document.createElement('div');
  ovTab.className='tab active';
  ovTab.innerHTML='Overview';
  ovTab.dataset.fw='__overview__';
  ovTab.onclick=()=>activateTab('__overview__');
  tabsEl.appendChild(ovTab);
  const ovPane=document.createElement('div');
  ovPane.className='pane active';
  ovPane.id='pane-__overview__';
  ovPane.innerHTML=renderOverview();
  panesEl.appendChild(ovPane);

  FWS.forEach((fw,i)=>{{
    const d=FW_DATA[fw];
    const tab=document.createElement('div');
    tab.className='tab';
    tab.innerHTML=`${{fw}}<span class="badge">${{fmtNum(d.total)}}</span>`;
    tab.onclick=()=>activateTab(fw);
    tab.dataset.fw=fw;
    tabsEl.appendChild(tab);
    const pane=document.createElement('div');
    pane.className='pane';
    pane.id='pane-'+fw;
    pane.innerHTML=renderPane(fw,d);
    panesEl.appendChild(pane);
  }});
}}

function activateTab(fw){{
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.pane').forEach(p=>p.classList.remove('active'));
  document.querySelector(`[data-fw="${{fw}}"]`).classList.add('active');
  document.getElementById('pane-'+fw).classList.add('active');
}}

function renderPane(fw,d){{
  const confirmed=d.locations.reduce((s,l)=>s+l.confirmed,0);
  const asserted=d.locations.reduce((s,l)=>s+l.asserted,0);
  const conns=d.locations.reduce((s,l)=>s+l.connections,0);
  return `
    <div class="fw-header">
      <div>
        <div class="fw-title">${{fw}}</div>
        <div class="fw-meta">Cluster: ${{d.cluster}} &nbsp;|&nbsp; PA Device Group: ${{d.dg}}</div>
      </div>
      <div class="fw-stats">
        <div class="fw-stat"><b>${{fmtNum(d.total)}}</b>Subnets</div>
        <div class="fw-stat"><b style="color:var(--high)">${{fmtNum(confirmed)}}</b>Traffic Confirmed</div>
        <div class="fw-stat"><b style="color:var(--med)">${{fmtNum(asserted)}}</b>Inferred</div>
        <div class="fw-stat"><b>${{fmtNum(conns)}}</b>Connections</div>
        <div class="fw-stat"><b>${{fmtNum(d.locations.length)}}</b>Locations</div>
      </div>
    </div>
    <div class="search-bar">
      <input type="text" placeholder="Search locations, site codes, routing domains..."
             oninput="filterTable(this,'${{fw}}')" />
    </div>
    <table id="tbl-${{fw}}">
      <thead><tr>
        <th onclick="sortTable('${{fw}}',0)">Location</th>
        <th onclick="sortTable('${{fw}}',1)">Site Code</th>
        <th onclick="sortTable('${{fw}}',2)">Routing Domain</th>
        <th onclick="sortTable('${{fw}}',3)">Heritage</th>
        <th onclick="sortTable('${{fw}}',4)">Type</th>
        <th onclick="sortTable('${{fw}}',5)" style="text-align:right">Subnets</th>
        <th onclick="sortTable('${{fw}}',6)" style="text-align:right">Confirmed</th>
        <th onclick="sortTable('${{fw}}',7)" style="text-align:right">Inferred</th>
        <th onclick="sortTable('${{fw}}',8)" style="text-align:right">Connections</th>
        <th></th>
      </tr></thead>
      <tbody>
        ${{d.locations.map((l,idx)=>`
          <tr>
            <td>${{l.loc}}</td>
            <td style="font-family:monospace;font-size:12px">${{l.site_code}}</td>
            <td>${{rdBadge(l.rd)}}</td>
            <td>${{l.heritage}}</td>
            <td>${{l.loc_type}}</td>
            <td style="text-align:right;font-weight:600">${{fmtNum(l.subnet_count)}}</td>
            <td style="text-align:right" class="conf-high">${{fmtNum(l.confirmed)}}</td>
            <td style="text-align:right" class="conf-med">${{fmtNum(l.asserted)}}</td>
            <td style="text-align:right">${{fmtNum(l.connections)}}</td>
            <td><button class="btn-expand" onclick="showSubnets('${{fw}}',${{idx}})">Subnets</button></td>
          </tr>`).join('')}}
      </tbody>
    </table>`;
}}

function filterTable(input,fw){{
  const val=input.value.toLowerCase();
  document.getElementById('tbl-'+fw).querySelectorAll('tbody tr').forEach(r=>{{
    r.style.display=r.textContent.toLowerCase().includes(val)?'':'none';
  }});
}}

let sortState={{}};
function sortTable(fw,col){{
  const tbl=document.getElementById('tbl-'+fw);
  const tbody=tbl.querySelector('tbody');
  const rows=Array.from(tbody.querySelectorAll('tr'));
  const key=fw+'-'+col;
  const asc=!sortState[key];
  sortState[key]=asc;
  rows.sort((a,b)=>{{
    const av=a.cells[col]?.textContent.trim()||'';
    const bv=b.cells[col]?.textContent.trim()||'';
    const an=parseFloat(av.replace(/,/g,''));
    const bn=parseFloat(bv.replace(/,/g,''));
    if(!isNaN(an)&&!isNaN(bn)) return asc?an-bn:bn-an;
    return asc?av.localeCompare(bv):bv.localeCompare(av);
  }});
  rows.forEach(r=>tbody.appendChild(r));
}}

function showSubnets(fw,idx){{
  const loc=FW_DATA[fw].locations[idx];
  const subs=loc.subnets;
  document.getElementById('modal-title').textContent=
    `${{loc.loc}} → ${{fw}}  (${{subs.length.toLocaleString()}} subnets)`;
  let h=`<table class="subnet-table"><thead><tr>
    <th>CIDR</th><th>NET_TYPE</th><th>Confidence</th><th>Source</th><th>Connections</th><th>Method</th>
  </tr></thead><tbody>`;
  subs.forEach(s=>{{
    h+=`<tr>
      <td>${{s.cidr}}</td><td>${{s.net_type}}</td>
      <td>${{confBadge(s.confidence)}}</td>
      <td>${{s.confirmed==='Y'?srcBadge(s.source):'<span style="color:#94a3b8">—</span>'}}</td>
      <td style="text-align:right">${{parseInt(s.connections||0).toLocaleString()}}</td>
      <td><span class="method-tag">${{s.method}}</span></td>
    </tr>`;
  }});
  h+='</tbody></table>';
  document.getElementById('modal-body').innerHTML=h;
  document.getElementById('modal').classList.add('open');
}}

function closeModal(){{document.getElementById('modal').classList.remove('open')}}
document.getElementById('modal').addEventListener('click',e=>{{
  if(e.target===document.getElementById('modal')) closeModal();
}});
document.addEventListener('keydown',e=>{{if(e.key==='Escape') closeModal()}});
renderTabs();
</script>
</body>
</html>"""

    if dry_run:
        print(f'  [DRY-RUN] Would write HTML → {os.path.basename(out_path)}')
    else:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(html)
        size_kb = Path(out_path).stat().st_size // 1024
        print(f'  Wrote: {os.path.basename(out_path)}  ({size_kb:,} KB)')


def _quick_row_count(path):
    """v1.17.1: display-only row count for the Stage 7 import-confirmation
    prompt -- NOT a substitute for ipam-db.py's own Row-Count Collapse
    Check, which independently re-verifies before writing anything. Uses
    the same csv.field_size_limit(10_000_000) already set at module load
    (see top of file) so a large field (e.g. a LOCATIONS/SUBNET_CIDRS
    column) doesn't raise here either -- deliberately mirrors the fix
    applied to ipam-db.py's own count_rows() (v3.27.1) for the same
    class of problem, rather than reintroducing it at this call site.
    """
    try:
        with open(path, encoding='utf-8', errors='replace', newline='') as f:
            lines = [l for l in f if not l.startswith('#')]
        return max(0, sum(1 for _ in csv.reader(lines)) - 1)
    except Exception as e:
        print(f'  [WARN] could not pre-count rows in {path} ({type(e).__name__}: {e}) '
              f'-- proceeding without a row-count preview.')
        return 0


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description=SCRIPT_NAME,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument('--base', default='.',
                    help='Base IP_Lookup directory (default: .)')
    ap.add_argument('--zscaler-dir', default=None,
                    help='Directory containing Zscaler .zip files '
                         '(default: <base>/IP_Datasets_Raw/zscaler_logs)')
    ap.add_argument('--cs-dir', default=None,
                    help='Directory containing CrowdStrike CSV files '
                         '(default: <base>/IP_Datasets_Raw/CS_Data)')
    ap.add_argument('--ipam', default=None,
                    help='Explicit IPAM path (default: auto-discover from <base>/ipam-db/)')
    ap.add_argument('--retail', default=None,
                    help='Explicit retail_networks path (default: auto-discover from '
                         '<base>/ipam-db/). v1.16.0: retail is now a real input to this '
                         'script -- pass --retail "" (empty string) to explicitly skip it.')
    ap.add_argument('--ipdatasets-dir', default=None,
                    help='ipdatasets/ directory for ip_dataset.py registry cross-reference '
                         '(default: <base>/ipdatasets/). Used to distinguish known-enterprise '
                         'public assets from genuine internet noise on unregistered subnets '
                         '(v1.7.3+).')
    ap.add_argument('--out-ipam-dir', default=None,
                    help='Output dir for topology + unknown CSVs (default: <base>/)')
    ap.add_argument('--out-report-dir', default=None,
                    help='Output dir for HTML, breakdown CSV, conflicts (default: <base>/)')
    ap.add_argument('--no-cs', action='store_true',
                    help='Skip CrowdStrike data ingestion')
    ap.add_argument('--fw-routes-dir', default=None,
                    help='Directory containing FW routing table CSV files '
                         '(default: <base>/IP_Datasets_Raw/FW_Routes)')
    ap.add_argument('--no-routes', action='store_true',
                    help='Skip FW routing table validation pass')
    ap.add_argument('--route-db', default=None,
                    help='Path to fw_route_db.sqlite for unknown-subnet egress validation '
                         '(default: read the registered path from <base>/ipam-db/ipam-db.json, '
                         'falling back to auto-discovering <base>/ipam-db/fw_route_db*.sqlite '
                         'if the registry is unavailable). '
                         'NOTE: this database is built incrementally as devices are collected -- '
                         '"no match" means "no evidence yet," never "confirmed unrouted."')
    ap.add_argument('--no-route-db', action='store_true',
                    help='Skip fw_route_db.sqlite egress validation for unknown subnets')
    ap.add_argument('--no-report', action='store_true',
                    help='Skip HTML report and breakdown CSV generation')
    ap.add_argument('--skip-custom-objects', action='store_true',
                    help='Skip the entire downstream chain: build_custom_objects.py, '
                         'ipam-db.py --import, and build_object_pipeline.py. '
                         'Non-fatal either way -- this is opt-out, not a dependency gate.')
    ap.add_argument('--skip-ipam-import', action='store_true',
                    help='Build custom objects but skip the ipam-db.py --import step '
                         'and the object pipeline run that follows it.')
    ap.add_argument('--skip-object-pipeline', action='store_true',
                    help='Build custom objects and import to ipam-db, but skip running '
                         'build_object_pipeline.py (the full NG/SO/UA/custom objects + '
                         'EDL catalog rebuild) at the end.')
    ap.add_argument('--yes', '-y', action='store_true',
                    help='v1.17.1: skip the interactive "Import into ipam-db now? [y/N]" '
                         'confirmation before Stage 7 runs ipam-db.py --import. Without '
                         'this flag, a non-interactive stdin (e.g. cron, CI) is treated '
                         'as "no" -- stages 7-8 are skipped, not silently forced through. '
                         'Has no effect if --skip-custom-objects or --skip-ipam-import '
                         'is also passed (those already skip the prompt entirely).')
    ap.add_argument('--dry-run', action='store_true',
                    help='Parse and analyse; print stats; write no files')
    ap.add_argument('--version', action='version', version=SCRIPT_NAME)
    args = ap.parse_args()

    base        = Path(args.base).resolve()
    zsc_dir     = Path(args.zscaler_dir) if args.zscaler_dir else base / 'IP_Datasets_Raw' / 'zscaler_logs'
    cs_dir      = Path(args.cs_dir)      if args.cs_dir      else base / 'IP_Datasets_Raw' / 'CS_Data'
    ipam_dir    = base / 'ipam-db'
    ipdatasets_dir = Path(args.ipdatasets_dir) if args.ipdatasets_dir else base / 'ipdatasets'
    out_ipam    = Path(args.out_ipam_dir)    if args.out_ipam_dir    else base / 'FW-Egress_Out'
    out_report  = Path(args.out_report_dir)  if args.out_report_dir  else base / 'FW-Egress_Out'

    # Resolve the same-day revision BEFORE any row is built or any file is
    # written — build_topology_rows() stamps DATASET_VERSION into every row
    # from this global, so it must be correct first. See _next_dataset_version()
    # docstring / v1.6.0 changelog for why this exists.
    global VERSION
    VERSION = _next_dataset_version([out_ipam, out_report], TODAY)

    print('=' * 70)
    print(f'{SCRIPT_NAME}')
    print(f'  Base dir    : {base}')
    print(f'  Zscaler dir : {zsc_dir}')
    print(f'  CS dir      : {cs_dir}')
    print(f'  Output dir  : {out_ipam}')
    print(f'  Dataset ver : {VERSION}')
    if args.dry_run:
        print('  DRY RUN — no files will be written')
    print('=' * 70)

    # ── [1/5] Load IPAM ───────────────────────────────────────────────────
    print('\n[1/5] Loading IPAM...')
    ipam_path = args.ipam or find_latest(str(ipam_dir / 'all_IP_networks_v*.csv'))
    if not ipam_path:
        print('  [ERROR] all_IP_networks not found. Use --ipam.', file=sys.stderr)
        sys.exit(1)
    print(f'  {os.path.basename(ipam_path)}')
    ipam_nets = load_ipam(ipam_path)
    ipam_rows = []
    with open(ipam_path, encoding='utf-8-sig', errors='replace') as f:
        for line in f:
            if line.startswith('#'):
                continue
            reader = csv.DictReader(itertools.chain([line], f))
            for r in reader:
                ipam_rows.append(r)
            break
    print(f'  {len(ipam_nets):,} LPM prefixes  |  {len(ipam_rows):,} IPAM rows')

    # v1.16.0: real, confirmed gap fixed -- retail_networks.csv was never
    # loaded as an input to this script at all (see load_retail()'s own
    # docstring for the full real finding). Merged into the SAME
    # ipam_rows list processed below, using the SAME already-validated
    # inference pipeline -- no separate retail-specific logic needed,
    # since real evidence (traffic confirmation, location+heritage,
    # /16-sibling, route data) works identically once retail's OWNER
    # field is normalized to HERITAGE.
    retail_path = args.retail or find_latest(str(ipam_dir / 'retail_networks_v*.csv'))
    retail_row_count = 0
    if retail_path:
        print(f'  {os.path.basename(retail_path)}')
        retail_nets = load_retail(retail_path)
        with open(retail_path, encoding='utf-8-sig', errors='replace') as f:
            for line in f:
                if line.startswith('#'):
                    continue
                reader = csv.DictReader(itertools.chain([line], f))
                for r in reader:
                    if not r.get('HERITAGE'):
                        r['HERITAGE'] = r.get('OWNER', '')
                    ipam_rows.append(r)
                    retail_row_count += 1
                break
        ipam_nets = ipam_nets + retail_nets
        print(f'  {len(retail_nets):,} retail LPM prefixes  |  {retail_row_count:,} retail rows merged')
    else:
        print('  [WARN] retail_networks not found -- retail subnets will NOT be')
        print('         included in this run. Use --retail to specify explicitly.')

    # ── [2/5] Ingest Zscaler ──────────────────────────────────────────────
    print('\n[2/5] Ingesting Zscaler FW log zips...')
    zip_files = find_zscaler_zips(str(zsc_dir))
    if not zip_files:
        print(f'  [WARN] No .zip files found in {zsc_dir} — Zscaler data skipped')
    else:
        print(f'  Found {len(zip_files)} zip(s):')

    confirmed     = {}   # /24 → confirmed traffic data
    unmatched_raw = {}   # /24 → unmatched traffic data (no IPAM)
    subnet24_cache = {}  # /24 → ipam_row (LPM cache)

    total_conns = matched = unmatched_count = 0
    if zip_files:
        total_conns, matched, unmatched_count = ingest_zscaler_zips(
            zip_files, ipam_nets, subnet24_cache, confirmed, unmatched_raw
        )
        pct_m = matched / total_conns * 100 if total_conns else 0
        print(f'\n  Total connections : {total_conns:,}')
        print(f'  IPAM-matched      : {matched:,} ({pct_m:.1f}%)')
        print(f'  Unmatched (blind) : {unmatched_count:,}')
        print(f'  Confirmed CIDRs   : {len(confirmed):,}')

    # ── [3/5] Ingest CrowdStrike ──────────────────────────────────────────
    cs_files = []
    if not args.no_cs:
        print('\n[3/5] Ingesting CrowdStrike PA exports...')
        cs_files = find_cs_files(str(cs_dir))
        if not cs_files:
            print(f'  [WARN] No CSV files found in {cs_dir} — CS data skipped')
        else:
            print(f'  Found {len(cs_files)} file(s):')
            ingest_cs_files(cs_files, ipam_nets, subnet24_cache, confirmed, unmatched_raw)
            print(f'  Confirmed CIDRs after CS : {len(confirmed):,}')
    else:
        print('\n[3/5] CrowdStrike ingestion skipped (--no-cs)')

    # ── [4/5] Build topology rows ─────────────────────────────────────────
    print('\n[4/5] Building topology mapping...')

    # Load FW routing tables for validation (optional)
    fw_routes_dir = Path(args.fw_routes_dir) if args.fw_routes_dir else base / 'IP_Datasets_Raw' / 'FW_Routes'
    fw_route_index = {}
    if not args.no_routes:
        if fw_routes_dir.is_dir():
            print(f'\n  Loading FW routing tables from {fw_routes_dir.name}/')
            fw_route_index, routes_loaded = load_fw_routes(str(fw_routes_dir))
            fws_with_routes = len(fw_route_index)
            unique_nets = sum(len(v) for v in fw_route_index.values())
            print(f'  Route entries loaded : {routes_loaded:,}')
            print(f'  Logical FWs indexed  : {fws_with_routes}  ({unique_nets:,} unique networks)')
            for lfw in sorted(fw_route_index.keys()):
                print(f'    {len(fw_route_index[lfw]):>6,}  routes  {lfw}')
        else:
            print(f'\n  [INFO] FW_Routes dir not found at {fw_routes_dir} — route validation skipped')
    else:
        print('\n  Route validation skipped (--no-routes)')

    # v1.7.0: fw_route_db.sqlite egress validation for unknown subnets --
    # separate from the FW_Routes-CSV route validation above (that
    # validates ALREADY-ASSIGNED confirmed CIDRs' logical-firewall
    # consistency; this checks whether any real, collected device has
    # ANY routing knowledge of a subnet that isn't even in IPAM yet).
    route_db_cache, route_db_note = None, ''
    if not args.no_route_db:
        # v1.11.0: real bug fixed, confirmed against a live ipam-db.py
        # --list showing fw_route_db_v20260727.sqlite correctly REGISTERED
        # (13,501 rows) while this script still reported "not found" the
        # same day. Root cause: fw_route_db.sqlite is registered
        # "(in-place)" -- ipam-db.py's own convention for large binary
        # databases it tracks by reference rather than copying into
        # ipam-db/ the way small CSVs are (same reasoning
        # collect_external_ip_bundle.sh already documents for fw_rule_db).
        # The v1.7.1 fix below (glob both bare and versioned names under
        # <base>/ipam-db/) was solving the wrong problem -- it assumed the
        # file always lives in ipam-db/, which "in-place" registration
        # doesn't guarantee. Now reads the actual registered path from
        # ipam-db.json first (single source of truth, can't drift from
        # wherever ipam-db.py itself thinks the file is), falling back to
        # the v1.7.1 glob only if the registry read fails or the key isn't
        # present -- e.g. an ipam-db.json-less standalone environment.
        route_db_path = args.route_db or resolve_route_db_path(base)
        route_db_cache, route_db_note = load_route_db(route_db_path)
        print(f'\n  [Route DB] {route_db_note}')
    else:
        route_db_note = 'egress validation skipped (--no-route-db)'
        print(f'\n  [Route DB] {route_db_note}')

    # v1.7.0: cross-run history -- scans out_ipam for every prior
    # unknown_ip_subnets_v*.csv still on disk (see load_unknown_subnet_
    # history() docstring for what this depends on).
    subnet_dates, all_run_dates = load_unknown_subnet_history(str(out_ipam))
    if all_run_dates:
        print(f'  [History] {len(all_run_dates)} prior run-date(s) found on disk '
              f'({", ".join(sorted(all_run_dates))})')
    else:
        print('  [History] No prior unknown_ip_subnets_v*.csv found — starting fresh '
              '(every subnet in this run will show FIRST_SEEN=today, RUNS_SEEN=1)')

    if route_db_cache is not None:
        n_ifaces_total = len(route_db_cache['iface_broad']) + sum(
            len(v) for v in route_db_cache['iface_buckets'].values())
        n_routes_total = len(route_db_cache['route_broad']) + sum(
            len(v) for v in route_db_cache['route_buckets'].values())
        print(f'  [Route DB] Validating egress routing for {len(unmatched_raw):,} unmatched '
              f'subnets against {n_ifaces_total:,} interfaces + '
              f'{n_routes_total:,} routes (v1.12.0: /16-bucketed in-memory lookup -- '
              f'no longer a flat per-call scan)...')

    # v1.7.3: ip_dataset.py registry cross-reference for unregistered
    # public subnets (see classify_ip_dataset_match() docstring).
    # Optional -- degrades gracefully if unavailable.
    ip_dataset_index = load_ip_dataset_index(str(ipdatasets_dir))
    if ip_dataset_index:
        _total_cidrs = sum(len(d['los']) for d in ip_dataset_index.values())
        print(f'  [ip_dataset] {len(ip_dataset_index)} datasets, {_total_cidrs:,} CIDRs '
              f'loaded from {ipdatasets_dir}')
    else:
        print(f'  [ip_dataset] not available at {ipdatasets_dir} — PUBLIC-IP-NOT-OWNED '
              f'classification using RFC1918/CGNAT check only, no enterprise-asset or '
              f'provider cross-reference')

    out_rows, unmatched_rows, stats, ambiguous_rows = build_topology_rows(
        ipam_rows, confirmed, unmatched_raw, fw_route_index,
        ipam_nets=ipam_nets, route_db_cache=route_db_cache, route_db_note=route_db_note,
        subnet_dates=subnet_dates, all_run_dates=all_run_dates,
        ip_dataset_index=ip_dataset_index,
    )
    unique_cidrs = len(set(r['CIDR'] for r in out_rows))
    print(f'  Output rows (CIDR × FW)  : {len(out_rows):,}')
    print(f'  Unique CIDRs covered     : {unique_cidrs:,}')
    print(f'  Unknown subnets          : {len(unmatched_rows):,}')
    print(f'  Traffic confirmed        : {stats["confirmed"]:,}')
    print(f'  Location+Heritage conf.  : {stats["location_heritage_confirmed"]:,}')
    print(f'  Location+Heritage+Route  : {stats["location_heritage_route_confirmed"]:,}')
    print(f'  Location+Heritage+/16 sib: {stats["location_heritage_sibling16_confirmed"]:,}')
    print(f'  Location confirmed (broad): {stats["location_confirmed"]:,}')
    print(f'  Location+Route (broad)   : {stats["location_route_confirmed"]:,}')
    print(f'  Location+Heritage AMBIGUOUS: {stats["location_heritage_ambiguous"]:,}  '
          f'← real tie, no confident single answer -- see known_ambiguous_egress')
    print(f'  Asserted (inferred)      : {stats["asserted"]:,}')
    print(f'  No FW mapping            : {stats["no_location"]:,}')

    # Route validation summary
    # v1.10.0: gating condition fixed to match the actual per-CIDR
    # validation logic above -- was `if fw_route_index:` only, which
    # silently skipped this entire summary whenever FW_Routes/ wasn't
    # found even if fw_route_db.sqlite was loaded and validation still
    # ran. Also added a source breakdown so fw_route_db.sqlite's
    # contribution (vs. FW_Routes/, vs. both agreeing) is visible here,
    # not just buried in the CSV's new ROUTE_SOURCE column.
    if fw_route_index or route_db_cache is not None:
        validated   = sum(1 for r in out_rows if r.get('ROUTE_VALIDATED') == 'Y')
        mismatched  = sum(1 for r in out_rows if r.get('ROUTE_MISMATCH')  == 'Y')
        no_route    = sum(1 for r in out_rows if r.get('ROUTE_VALIDATED') == 'NO_ROUTE')
        print(f'  Route validated          : {validated:,}')
        print(f'  Route mismatch           : {mismatched:,}  ← FW assignment not in routing table')
        no_route_exp = sum(1 for r in out_rows if r.get('ROUTE_VALIDATED') == 'NO_ROUTE_EXPECTED')
        print(f'  No route found           : {no_route:,}  ← subnet not in any FW routing table')
        print(f'  No route (BGP expected)  : {no_route_exp:,}  ← BGP-learned, not in static tables')
        if fw_route_index and route_db_cache is not None:
            src_fw_routes = sum(1 for r in out_rows if r.get('ROUTE_SOURCE') == 'FW_ROUTES')
            src_route_db  = sum(1 for r in out_rows if r.get('ROUTE_SOURCE') == 'ROUTE_DB')
            src_both      = sum(1 for r in out_rows if r.get('ROUTE_SOURCE') == 'BOTH')
            print(f'  Confirmed by FW_Routes/ only : {src_fw_routes:,}')
            print(f'  Confirmed by route DB only   : {src_route_db:,}')
            print(f'  Confirmed by both sources    : {src_both:,}')

    # ── [5/5] Write outputs ───────────────────────────────────────────────
    print('\n[5/5] Writing outputs...')

    sources_desc = f'{len(zip_files)} Zscaler zip(s), {len(cs_files)} CS file(s)'

    topo_path      = out_ipam    / f'ent-ipdataset-EGRESS-FW-TOPOLOGY-{VERSION}.csv'
    unknown_path   = out_ipam    / f'unknown_ip_subnets_{VERSION}.csv'
    ambiguous_path = out_ipam    / f'known_ambiguous_egress_{VERSION}.csv'
    bdn_csv_path   = out_report  / f'fw_egress_breakdown_{VERSION}.csv'
    bdn_html_path  = out_report  / f'fw_egress_breakdown_{VERSION}.html'
    conflict_path  = out_report  / f'fw_topology_conflicts_{VERSION}.csv'

    if args.dry_run:
        print(f'  [DRY-RUN] Would write → {topo_path.name}  ({len(out_rows):,} rows)')
        print(f'  [DRY-RUN] Would write → {unknown_path.name}  ({len(unmatched_rows):,} rows)')
        if fw_route_index:
            write_conflicts_csv(out_rows, conflict_path, dry_run=True)
        if not args.no_report:
            mapped = [r for r in out_rows if r.get('EGRESS_FIREWALL_LOGICAL')]
            print(f'  [DRY-RUN] Would write → {bdn_csv_path.name}')
            print(f'  [DRY-RUN] Would write → {bdn_html_path.name}')
    else:
        out_ipam.mkdir(parents=True, exist_ok=True)
        write_topology_csv(out_rows, topo_path, ipam_path, len(zip_files), len(cs_files))
        write_unknown_csv(unmatched_rows, unknown_path)
        write_known_ambiguous_egress(ambiguous_rows, ambiguous_path)

        if fw_route_index:
            out_report.mkdir(parents=True, exist_ok=True)
            write_conflicts_csv(out_rows, conflict_path, dry_run=False)

        if not args.no_report:
            out_report.mkdir(parents=True, exist_ok=True)
            mapped = [r for r in out_rows if r.get('EGRESS_FIREWALL_LOGICAL')]
            build_breakdown_csv(mapped, bdn_csv_path, dry_run=False)
            build_html_report(mapped, {}, sources_desc, bdn_html_path, dry_run=False)

    # ── Summary ───────────────────────────────────────────────────────────
    print()
    print('=' * 70)
    print(f'IP Network Egress FW Topology — {VERSION}')
    print()
    fw_dist = collections.Counter(
        r['EGRESS_FIREWALL_LOGICAL'] for r in out_rows if r.get('EGRESS_FIREWALL_LOGICAL')
    )
    print('  FW DISTRIBUTION:')
    for fw in FW_ORDER:
        if fw in fw_dist:
            cluster = FW_CLUSTER_MAP.get(fw, '')
            pct = fw_dist[fw] / max(len(out_rows), 1) * 100
            print(f'    {fw_dist[fw]:>7,}  {pct:>4.0f}%  {fw:<25}  {cluster}')
    others = {k: v for k, v in fw_dist.items() if k not in FW_ORDER}
    for fw, cnt in sorted(others.items(), key=lambda x: -x[1]):
        print(f'    {cnt:>7,}        {fw}')
    print()
    conf_dist = collections.Counter(r.get('CONFIDENCE', '') for r in out_rows)
    print('  CONFIDENCE TIERS:')
    for tier in ('HIGH', 'MEDIUM', 'LOW', 'LOW-AMBIGUOUS', 'NONE'):
        cnt = conf_dist.get(tier, 0)
        pct = cnt / max(len(out_rows), 1) * 100
        print(f'    {cnt:>7,}  {pct:>4.0f}%  {tier}')

    if fw_route_index:
        mismatched_rows = [r for r in out_rows if r.get('ROUTE_MISMATCH') == 'Y']
        if mismatched_rows:
            print()
            print(f'  ROUTE MISMATCHES: {len(mismatched_rows):,} rows where assigned FW has no route to CIDR')
            # Group by assigned FW
            by_fw = collections.defaultdict(list)
            for r in mismatched_rows:
                by_fw[r.get('EGRESS_FIREWALL_LOGICAL', '')].append(r)
            for fw, rows in sorted(by_fw.items(), key=lambda x: -len(x[1])):
                sample = rows[0]
                route_fws = sample.get('ROUTE_MATCH_FWS', '')
                print(f'    {len(rows):>5,}  {fw:<25}  route found in: {route_fws or "none"}')
        else:
            print()
            print('  ROUTE VALIDATION: all assigned FWs confirmed in routing tables ✓')
    print()
    if not args.dry_run:
        print('  Next steps:')
        print(f'    python3 ipam-db.py --import {topo_path} --type EGRESS-FW-TOPOLOGY')
        print(f'    python3 ipam-db.py --import {unknown_path} --type EGRESS-FW-UNMATCHED')
        if ambiguous_rows:
            print(f'    python3 ipam-db.py --import {ambiguous_path} --type known_ambiguous_egress')
            print(f'      # {len(ambiguous_rows):,} genuinely ambiguous CIDR(s) -- real ties, '
                  f'not guesses. Re-running this script against future traffic snapshots may '
                  f'resolve some of these to TRAFFIC-CONFIRMED without manual action.')
    print('=' * 70)

    # ── [6/8] Rebuild custom objects (EGRESS_TRAFFIC) ───────────────────────
    # build_custom_objects.py's EGRESS_TRAFFIC class reads the topology CSV
    # this script just wrote as a required input (--egress-dir). Without this
    # auto-chain, EGRESS_TRAFFIC objects only refresh whenever someone
    # remembers to run build_custom_objects.py by hand -- a real, repeated
    # failure mode (confirmed live: a stale build_custom_objects.py version,
    # then a dry-run mistaken for a real run, then a UI file swap that
    # silently reverted the object count because the catalog was never
    # rebuilt after it). Stages 6-8 below close that gap completely: one
    # command takes topology -> custom objects -> ipam import -> full
    # object pipeline (which rebuilds the EDL catalog at the end).
    # Each stage is non-fatal on its own -- a failure here does not affect
    # this script's exit code or the topology outputs already written above.
    custom_objects_csv = None
    if not args.skip_custom_objects:
        print()
        print('[6/8] Rebuilding custom objects (EGRESS_TRAFFIC)...')
        custom_objects_script = base / 'build_custom_objects.py'
        if not custom_objects_script.is_file():
            print(f'  [WARN] build_custom_objects.py not found '
                  f'at {custom_objects_script} — skipping stages 6-8')
        else:
            proc_dir = base / 'processed_outputs'
            cmd = [
                sys.executable, str(custom_objects_script),
                '--ipam-dir', str(ipam_dir),
                '--egress-dir', str(out_ipam),
                '--out-dir', str(proc_dir),
                '--net-object-dir', str(base / 'Net_Object'),
            ]
            if args.dry_run:
                cmd.append('--dry-run')
            print(f'  Running: {" ".join(cmd)}')
            result = subprocess.run(cmd)
            if result.returncode != 0:
                print(f'  [WARN] build_custom_objects.py exited {result.returncode} '
                      f'— EGRESS_TRAFFIC objects may be stale. Skipping stages 7-8. '
                      f'Topology outputs above are unaffected.')
            else:
                print('  ✓ Custom objects (EGRESS_TRAFFIC) rebuilt')
                if not args.dry_run:
                    matches = sorted(
                        proc_dir.glob('canonical_custom_objects_v*.csv'),
                        key=lambda p: p.stat().st_mtime, reverse=True
                    )
                    custom_objects_csv = matches[0] if matches else None

    # ── [7/8] Import custom objects into ipam-db ─────────────────────────────
    if not args.dry_run and not args.skip_custom_objects and not args.skip_ipam_import:
        if custom_objects_csv is None:
            print()
            print('[7/8] Import to ipam-db — skipped (no canonical_custom_objects '
                  'CSV was produced in stage 6)')
        else:
            print()
            print('[7/8] Importing custom objects into ipam-db...')
            ipam_db_script = base / 'ipam-db.py'
            if not ipam_db_script.is_file():
                print(f'  [WARN] ipam-db.py not found at {ipam_db_script} — skipping '
                      f'import and stage 8')
            else:
                cmd = [
                    sys.executable, str(ipam_db_script),
                    '--import', str(custom_objects_csv),
                    '--type', 'CANONICAL-CUSTOM-OBJECTS',
                ]
                # v1.17.1: real safety gap fixed -- this used to run
                # unconditionally, with no confirmation, no matter how it
                # was invoked. Print what's about to happen and require
                # explicit confirmation (or --yes) before actually
                # touching ipam-db's registered CANONICAL-CUSTOM-OBJECTS
                # stem. A non-interactive stdin (cron, CI, piped input)
                # is treated as "no" -- fails safe, doesn't silently
                # force the import through.
                _preview_rows = _quick_row_count(custom_objects_csv)
                print(f'  About to run: {" ".join(cmd)}')
                print(f'  File:  {custom_objects_csv}')
                print(f'  Rows:  {_preview_rows:,} (this script\'s own count -- '
                      f'ipam-db.py will independently verify against its Row-Count '
                      f'Collapse Check before actually writing anything)')
                if args.yes:
                    proceed = True
                    print('  --yes passed, proceeding without prompt.')
                elif not sys.stdin.isatty():
                    proceed = False
                    print('  [SKIP] Non-interactive stdin and --yes not passed -- '
                          'treating as "no". Pass --yes to import unattended '
                          '(e.g. from a scheduled run).')
                else:
                    answer = input('  Import into ipam-db now? [y/N] ').strip().lower()
                    proceed = answer in ('y', 'yes')
                if not proceed:
                    print('  Skipped -- topology outputs from stages 1-6 are unaffected. '
                          'Run manually later with:')
                    print(f'    {" ".join(cmd)}')
                else:
                    print(f'  Running: {" ".join(cmd)}')
                    result = subprocess.run(cmd)
                    if result.returncode != 0:
                        print(f'  [WARN] ipam-db.py --import exited {result.returncode} '
                              f'— skipping stage 8 (object pipeline)')
                    else:
                        print('  ✓ Custom objects imported to ipam-db')


                    # ── [8/8] Run the full object pipeline ────────────────────
                    if not args.skip_object_pipeline:
                        print()
                        print('[8/8] Running the full object pipeline...')
                        pipeline_script = base / 'build_object_pipeline.py'
                        if not pipeline_script.is_file():
                            print(f'  [WARN] build_object_pipeline.py not found '
                                  f'at {pipeline_script} — skipping')
                        else:
                            cmd = [sys.executable, str(pipeline_script), '--base', str(base)]
                            print(f'  Running: {" ".join(cmd)}')
                            result = subprocess.run(cmd)
                            if result.returncode != 0:
                                print(f'  [WARN] build_object_pipeline.py exited '
                                      f'{result.returncode} — EDL catalog may be stale.')
                            else:
                                print('  ✓ Object pipeline complete — EDL catalog rebuilt')
                                print()
                                print('  Next: ./object-viewer-web-service.sh, then hard-refresh')
                                print('  (Cmd+Option+R / Cmd+Shift+R) or open in an incognito window.')


if __name__ == '__main__':
    # v1.17.0: real, confirmed gap -- no Ctrl-C handling anywhere. An
    # interrupt (like the real one that produced this exact fix -- 8
    # minutes of silence mid-run, assumed hung, Ctrl-C'd) produced a raw
    # Python traceback instead of a clean, informative exit.
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  Interrupted by user (Ctrl-C). No output was written for this run")
        print("  unless a 'Wrote:' line already printed above.")
        sys.exit(130)
