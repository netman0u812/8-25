#!/usr/bin/env python3
"""
build_partner_ng.py  v2.0.0  —  CCD Platform
Generates the Partner-NG source Network-Object hierarchy from the VPN/P2P
partner registries, independent of build_network_groups.py. Two parallel
hierarchies per link type (VPN, P2P):

  DC-<TAG>-PARTNERS       Site-aggregated view (was NG-<TAG>-PARTNERS through
                          v1.0.2) — "what partner traffic passes through
                          this datacenter/gateway."
                          Tier-1  DC-VPN-PARTNERS / DC-P2P-PARTNERS
                          Tier-2  Per gateway site   DC-VPN-<SITE> / DC-P2P-<SITE>
                          Tier-3  Per (site, partner) AO-VPN-<SITE>-<PARTNER> /
                                                       AO-P2P-<SITE>-<PARTNER>-PARTNER

  Partner-<TAG>           NEW in v2.0.0. Partner-centric view — "what address
                          space belongs to this partner, regardless of which
                          gateway reaches it." A partner's destination address
                          space doesn't change based on which CVS gateway
                          serves the connection, so this hierarchy merges a
                          partner's CIDRs across every site/gateway that
                          reaches them, rather than fragmenting the same
                          partner into one object per site the way the DC-*
                          hierarchy intentionally does.
                          Tier-1  Partner-VPN / Partner-P2P  (umbrella)
                          Tier-2  Per partner   PARTNER-VPN-<PARTNER> /
                                                 PARTNER-P2P-<PARTNER>
                          (no Tier-3 — a partner's CIDRs are already fully
                          merged at Tier-2; the per-gateway distinction lives
                          in each CIDR's own EDL comment instead, see below)

Both hierarchies are built from the SAME filtered, validated record set
(load_subnet_registry()), so they can never disagree about which rows
qualify as partner data.

Why this exists:
  build_network_groups.py already derives NG-VPN-PARTNERS and NG-P2P-PARTNERS
  Tier-1 classes from ent-ipdataset-VPN-PROTECTED-SUBNETS and
  ent-ipdataset-P2P-PROTECTED-SUBNETS, but writes them into the same
  Net_Group/NG-YYYYMMDD_vN/ output as Internal-NG. This script builds that
  same slot directly and independently from the source registries.

  v1.0.2 — output now nests inside build_network_groups.py's own
  Net_Group/NG-YYYYMMDD_vN/ directory (Net_Group/NG-.../Partner_NG/), not
  a separate top-level Partner_NG/ tree — a full platform export only
  needs Net_Group/ and Net_Object/, not N additional directories.

EDL comment format (new in v2.0.0, applies to every EDL this script writes):
  # <Partner Name>
  # <Connection Device(s), comma-separated if more than one>
  <CIDR>
  #
  Every non-CIDR line starts with '#' so any EDL parser treats it as a
  comment regardless of PAN-OS version, and the CIDR line itself carries no
  trailing text -- the safer of two formats considered (a same-line trailing
  comment risks a stricter parser choking on or misreading the address).
  Device field: gateway_hostname for VPN, GATEWAY_DEVICE for P2P (both are
  the CVS-side firewall/gateway hostname, not the raw source config
  filename). Where a CIDR is reachable via more than one gateway, every
  device that reaches it is listed on one comma-joined comment line.

Input:
  ent-ipdataset-VPN-PROTECTED-SUBNETS-v*.csv  (required)
    Columns used: IP_NETWORK, PARTNER_NAME, direction, gateway_site,
    gateway_hostname. Rows with direction=LOCAL are excluded (CVS-side,
    already in IPAM hierarchy).

  ent-ipdataset-P2P-PROTECTED-SUBNETS-v*.csv  (optional, subnet-level)
    Columns used: IP_NETWORK, PARTNER_NAME, DIRECTION, GATEWAY_SITE,
    GATEWAY_DEVICE. Rows with DIRECTION=CVS are excluded. IF NOT FOUND,
    this script checks for ent-ipdataset-P2P-LINK-REGISTRY-v*.csv and — if
    that's all that's available — SKIPS the P2P hierarchies with an
    explicit warning rather than fabricating CIDRs. P2P-LINK-REGISTRY is a
    tunnel/link-level summary (cvs_subnet_count / partner_subnet_count
    columns only, no actual CIDR column) and cannot be used to build real
    address objects.

Outputs (written to --out, default ./Partner_NG/NG-YYYYMMDD_v1):
  network_object_catalog_v<stamp>.csv   TIER,OBJECT_NAME,PARENT,CLASS,
                                         MEMBER_TYPE,VALUE,CIDR_COUNT,SOURCE
  ng_manifest.csv                       Tier1_Class,Tier2_Location,Tier3_Object,CIDR_count
  EDL/*.txt                             one EDL per Tier-1/Tier-2/Tier-3 object (unless --no-edl)

Usage:
  python3 build_partner_ng.py \\
      --vpn-subs ipam-db/ent-ipdataset-VPN-PROTECTED-SUBNETS-v20260724.csv \\
      --p2p-subs ipam-db/ent-ipdataset-P2P-PROTECTED-SUBNETS-v20260724.csv \\
      --out Partner_NG/NG-20260728_v1

  # Auto-discover from {base}/ipam-db/:
  python3 build_partner_ng.py --base . [--dry-run]

Changelog:
  v2.0.0 — 2026-07-28  Three changes, all requested together:
           (1) BUGFIX, verified against real data, not just theorized:
               P2P direction-exclusion was hardcoded to 'LOCAL' for both
               VPN and P2P (a v1.0.1 "fix" that assumed P2P used the same
               LOCAL/REMOTE convention as VPN). Checked against the real
               ent-ipdataset-P2P-PROTECTED-SUBNETS-v20260724.csv: it uses
               CVS/PARTNER, not LOCAL/REMOTE, at all -- 10,708 CVS-direction
               rows were passing the old filter unfiltered, meaning every
               P2P object ever built by this script included CVS's own
               internal address space mislabeled as partner data. Now
               kind-specific again (LOCAL for vpn, CVS for p2p), restoring
               v1.0.0's original (and correct) design before v1.0.1
               regressed it.
           (2) NG-VPN-PARTNERS / NG-P2P-PARTNERS renamed to
               DC-VPN-PARTNERS / DC-P2P-PARTNERS (and their Tier-2/3
               children correspondingly) -- same site-aggregated structure,
               new prefix reflecting that this view is organized by
               datacenter/gateway, not by partner.
           (3) NEW Partner-VPN / Partner-P2P hierarchy: one object per
               partner, CIDRs merged across every gateway site that reaches
               them (a partner's destination address space doesn't change
               based on which CVS gateway serves it -- confirmed this is
               the intended semantics, not an oversight). New EDL comment
               format applied to every file this script writes (both DC-*
               and Partner-*): partner name + connection device(s) per
               CIDR, all-comment-line format (see above).
  v1.0.2 — 2026-07-08  Partner-NG output nested inside build_network_groups.py's
           own Net_Group/NG-YYYYMMDD_vN/ directory structure.
  v1.0.1 — 2026-07-09  P2P direction-exclusion value changed to 'LOCAL'
           (SUPERSEDED by v2.0.0 above -- this was a regression, not a fix,
           confirmed against real v20260724 data).
  v1.0.0 — 2026-07-08  Initial build. Standalone Partner-NG generator,
           independent of build_network_groups.py per architecture decision.
"""
from __future__ import annotations
import argparse, csv, glob, ipaddress, json, os, re, sys
from collections import defaultdict
from datetime import date

__version__ = "2.0.0"

# ---------------------------------------------------------------------------
# FILE DISCOVERY
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    def _ver_key(path):
        name = os.path.basename(path)
        m = re.search(r'v(\d{8})(?:r(\d+))?', name)
        if m:
            return (int(m.group(1)), int(m.group(2) or 0))
        return (0, 0)
    matches = glob.glob(os.path.join(directory, pattern))
    return max(matches, key=_ver_key) if matches else None


def discover_inputs(base="."):
    ipam_dir = os.path.join(base, "ipam-db")
    return {
        "vpn_subs": _latest(ipam_dir, "ent-ipdataset-VPN-PROTECTED-SUBNETS*.csv"),
        "p2p_subs": _latest(ipam_dir, "ent-ipdataset-P2P-PROTECTED-SUBNETS*.csv"),
        "p2p_link_registry": _latest(ipam_dir, "ent-ipdataset-P2P-LINK-REGISTRY*.csv"),
    }


def resolve_input(cli_value, discovered_value, name, required=True):
    path = cli_value or discovered_value
    if path and os.path.exists(path):
        print(f"  {name:<22s} {path}  [{'arg' if cli_value else 'auto'}]")
        return path
    if required:
        label = path or "(no match in default locations)"
        print(f"  {name:<22s} NOT FOUND: {label}", file=sys.stderr)
        sys.exit(1)
    if path:
        print(f"  {name:<22s} skipped (not found)")
    return None


def next_version_dir(base_out_dir: str) -> str:
    stamp = date.today().strftime('%Y%m%d')
    n = 1
    while True:
        candidate = os.path.join(base_out_dir, f"NG-{stamp}_v{n}")
        if not os.path.exists(candidate):
            return candidate
        n += 1


def latest_net_group_dir(base_dir: str) -> str:
    """Find the most recent Net_Group/NG-YYYYMMDD_vN/ directory.

    v1.0.2 — Partner-NG now nests inside build_network_groups.py's own
    Net_Group/ version directory (in its own Partner_NG/ subfolder)
    instead of maintaining a separate top-level Partner_NG/ tree — a full
    platform export only needs Net_Group/ and Net_Object/, not N
    additional directories. Falls back to creating a fresh dated
    directory using the same NG-YYYYMMDD_vN convention if none exists yet
    (e.g. this script run standalone before Stage 1 has ever run).
    """
    ng_dir = os.path.join(base_dir, 'Net_Group')
    candidates = []
    if os.path.isdir(ng_dir):
        for d in os.listdir(ng_dir):
            m = re.match(r'NG-(\d{8})_v(\d+)$', d)
            if m:
                candidates.append((int(m.group(1)), int(m.group(2)), d))
    if not candidates:
        return next_version_dir(ng_dir)
    candidates.sort()
    return os.path.join(ng_dir, candidates[-1][2])


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def valid_cidr(c: str) -> bool:
    if not c or "/" not in str(c):
        return False
    try:
        ipaddress.ip_network(c, strict=False)
        return True
    except ValueError:
        return False


def write_edl(group_name, entries, edl_dir):
    """entries: list of (cidr, partner_name, device_set) tuples, one per
    unique CIDR in this file. Format:
      # <Partner Name>
      # <Connection Device(s), comma-separated>
      <CIDR>
      #
    Every non-CIDR line starts with '#' so any EDL parser treats it as a
    comment regardless of PAN-OS version; the CIDR line itself carries no
    trailing text. Devices are comma-joined, sorted, on one comment line --
    a CIDR reachable via more than one gateway lists all of them.
    """
    fname = group_name.replace('/', '_') + '.txt'
    path = os.path.join(edl_dir, fname)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# {group_name}\n')
        f.write(f'# Export Date: {date.today().isoformat()}\n')
        f.write(f'# Source: CCD Platform build_partner_ng.py v{__version__}\n')
        f.write(f'# Subnets: {len(entries)}\n')
        f.write('#\n')
        for cidr, partner, devices in sorted(
                entries, key=lambda e: (ipaddress.ip_network(e[0], strict=False), e[1])):
            dev_str = ', '.join(sorted(devices)) if devices else '(device unknown)'
            f.write(f'# {partner}\n')
            f.write(f'# {dev_str}\n')
            f.write(f'{cidr}\n')
            f.write('#\n')


def load_subnet_registry(path, kind):
    """Parse a VPN- or P2P-PROTECTED-SUBNETS style CSV into a flat, already-
    filtered, already-validated list of (cidr, partner, site, device)
    records. Both the DC-* (site-based) and Partner-* (partner-based)
    hierarchies are built from this same record list, so they can never
    disagree about which rows qualify as partner data.

    kind: 'vpn' excludes direction=LOCAL (VPN-PROTECTED-SUBNETS uses
    LOCAL/REMOTE); 'p2p' excludes DIRECTION=CVS (P2P-PROTECTED-SUBNETS uses
    CVS/PARTNER -- a DIFFERENT value set than VPN's, confirmed against the
    real v20260724 file, not assumed to match). Device field:
    gateway_hostname for vpn, GATEWAY_DEVICE for p2p -- both the CVS-side
    firewall/gateway hostname.
    """
    exclude_dir = 'LOCAL' if kind == 'vpn' else 'CVS'
    device_field = 'gateway_hostname' if kind == 'vpn' else 'GATEWAY_DEVICE'

    records = []
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(l for l in f if not l.startswith('#'))
        for row in reader:
            cidr = (row.get('IP_NETWORK') or row.get('CIDR') or '').strip()
            partner = (row.get('PARTNER_NAME') or '').strip().replace('/', '_').replace(' ', '-')
            site = (row.get('gateway_site') or row.get('GATEWAY_SITE') or '').strip().upper()
            direction = (row.get('direction') or row.get('DIRECTION') or '').strip().upper()
            device = (row.get(device_field) or '').strip()
            if not valid_cidr(cidr) or not partner or not site:
                continue
            if direction == exclude_dir:
                continue
            records.append((cidr, partner, site, device))

    return records


def _merge_by_cidr(records):
    """records: iterable of (cidr, partner, site, device) -- site is
    ignored here (used only by build_site_hierarchy's own grouping key,
    not by this merge). Returns (entries, conflicts):
      entries:   list of (cidr, partner, devices_set), one per unique cidr,
                 devices merged across every record for that cidr.
      conflicts: list of (cidr, [partner names]) where the same cidr showed
                 up under more than one partner name -- shouldn't happen (a
                 CIDR belongs to exactly one partner circuit), so this is
                 surfaced as a data-quality warning rather than silently
                 resolved. The alphabetically-first partner name is used
                 for the entry itself so the run still completes.
    """
    partners_by_cidr = defaultdict(set)
    devices_by_cidr = defaultdict(set)
    for cidr, partner, _site, device in records:
        partners_by_cidr[cidr].add(partner)
        if device:
            devices_by_cidr[cidr].add(device)

    entries, conflicts = [], []
    for cidr, partners in partners_by_cidr.items():
        if len(partners) > 1:
            conflicts.append((cidr, sorted(partners)))
        partner = sorted(partners)[0]
        entries.append((cidr, partner, devices_by_cidr[cidr]))
    return entries, conflicts


def build_site_hierarchy(records, tag):
    """DC-<TAG>-PARTNERS: Tier-2 per gateway site, Tier-3 per (site, partner).
    Same structure as the pre-v2.0.0 NG-<TAG>-PARTNERS hierarchy, just
    renamed. Returns (t2_children, t3_entries) where t3_entries maps each
    AO object name to its merged (cidr, partner, devices) entry list."""
    by_t2 = defaultdict(list)
    by_ao = defaultdict(list)
    t2_children = defaultdict(set)

    for cidr, partner, site, device in records:
        t2 = f'DC-{tag}-{site}'
        suffix = '-PARTNER' if tag == 'P2P' else ''
        ao = f'AO-{tag}-{site}-{partner}{suffix}'
        by_ao[ao].append((cidr, partner, site, device))
        t2_children[t2].add(ao)

    t3_entries = {}
    for ao, ao_records in by_ao.items():
        entries, conflicts = _merge_by_cidr(ao_records)
        t3_entries[ao] = entries
        for cidr, names in conflicts:
            print(f'  [WARN] {ao}: {cidr} attributed to multiple partners {names} -- '
                  f'using {sorted(names)[0]}')

    return t2_children, t3_entries


def build_partner_hierarchy(records, tag):
    """Partner-<TAG>: one object per partner, CIDRs merged across every
    gateway site/device that reaches them -- a partner's destination
    address space doesn't change based on which CVS gateway serves the
    connection, so (unlike the DC-* hierarchy, which intentionally keeps
    partners split per site) this view rolls every site together. Returns
    dict of {partner_name: entries} where entries is the merged
    (cidr, partner, devices) list for that partner."""
    by_partner = defaultdict(list)
    for record in records:
        _cidr, partner, _site, _device = record
        by_partner[partner].append(record)

    partner_entries = {}
    for partner, partner_records in by_partner.items():
        entries, conflicts = _merge_by_cidr(partner_records)
        partner_entries[partner] = entries
        # conflicts can't happen here (every record in by_partner[partner]
        # already has partner==partner by construction) -- no warning needed.

    return partner_entries


# ---------------------------------------------------------------------------
# BUILD
# ---------------------------------------------------------------------------

def build(args):
    print(f'build_partner_ng.py v{__version__}')
    print()

    catalog = []
    manifest_rows = []
    t1_present = []

    # ── VPN partner subnets ────────────────────────────────────────────────
    vpn_records = load_subnet_registry(args.vpn_subs, 'vpn')
    vpn_sites = {r[2] for r in vpn_records}
    print(f'Processing VPN partner subnets: {os.path.basename(args.vpn_subs)}')
    print(f'  {len(vpn_records):,} VPN partner CIDR rows across {len(vpn_sites)} gateway sites')

    # ── P2P partner subnets ────────────────────────────────────────────────
    p2p_records = []
    if args.p2p_subs and os.path.exists(args.p2p_subs):
        p2p_records = load_subnet_registry(args.p2p_subs, 'p2p')
        p2p_sites = {r[2] for r in p2p_records}
        print(f'Processing P2P/MPLS partner subnets: {os.path.basename(args.p2p_subs)}')
        print(f'  {len(p2p_records):,} P2P partner CIDR rows across {len(p2p_sites)} gateway sites')
    elif args.p2p_link_registry:
        print(f'  NOTE: {os.path.basename(args.p2p_link_registry)} found but is a link/tunnel-level')
        print(f'        summary (no per-subnet CIDR column) — cannot build P2P partner objects from it.')
        print(f'        Skipping. A subnet-level P2P-PROTECTED-SUBNETS export is needed.')
    else:
        print('  No P2P subnet-level dataset found — skipping P2P partner objects')
    print()

    if args.dry_run:
        vpn_partners = len({r[1] for r in vpn_records})
        p2p_partners = len({r[1] for r in p2p_records})
        print(json.dumps({
            "dry_run": True,
            "vpn_partner_sites": len({r[2] for r in vpn_records}),
            "vpn_unique_partners": vpn_partners,
            "vpn_partner_cidr_rows": len(vpn_records),
            "p2p_partner_sites": len({r[2] for r in p2p_records}),
            "p2p_unique_partners": p2p_partners,
            "p2p_partner_cidr_rows": len(p2p_records),
            "p2p_skipped_reason": None if p2p_records else (
                "link-level registry only, no subnet CIDRs" if args.p2p_link_registry else "no source file"),
        }, indent=2))
        return

    os.makedirs(args.out, exist_ok=True)

    # ── Catalog rows: DC-* (site-based) hierarchy ───────────────────────────
    def _add_dc_tier(tag, records, source_label):
        if not records:
            return None, None
        t2_children, t3_entries = build_site_hierarchy(records, tag)
        tier1 = f'DC-{tag}-PARTNERS'
        total = sum(len(v) for v in t3_entries.values())
        t1_present.append(tier1)
        catalog.append(dict(TIER=1, OBJECT_NAME=tier1, PARENT='', CLASS=f'{tag}-PARTNERS',
                             MEMBER_TYPE='group', VALUE=';'.join(sorted(t2_children)),
                             CIDR_COUNT=total, SOURCE=source_label))
        for t2, aos in sorted(t2_children.items()):
            t2_total = sum(len(t3_entries.get(ao, [])) for ao in aos)
            catalog.append(dict(TIER=2, OBJECT_NAME=t2, PARENT=tier1, CLASS=f'{tag}-PARTNERS',
                                 MEMBER_TYPE='group', VALUE=';'.join(sorted(aos)),
                                 CIDR_COUNT=t2_total, SOURCE=source_label))
            for ao in sorted(aos):
                entries = t3_entries.get(ao, [])
                catalog.append(dict(TIER=3, OBJECT_NAME=ao, PARENT=t2, CLASS='',
                                     MEMBER_TYPE='cidr-list',
                                     VALUE=';'.join(sorted(e[0] for e in entries)),
                                     CIDR_COUNT=len(entries), SOURCE=source_label))
                manifest_rows.append([tier1, t2, ao, len(entries)])
        return t2_children, t3_entries

    vpn_dc_t2, vpn_dc_t3 = _add_dc_tier('VPN', vpn_records, 'vpn-registry')
    p2p_dc_t2, p2p_dc_t3 = _add_dc_tier('P2P', p2p_records, 'p2p-registry')

    # ── Catalog rows: Partner-* (partner-based) hierarchy ───────────────────
    def _add_partner_tier(tag, records, source_label):
        if not records:
            return None
        partner_entries = build_partner_hierarchy(records, tag)
        tier1 = f'Partner-{tag}'
        total = sum(len(v) for v in partner_entries.values())
        t1_present.append(tier1)
        obj_names = [f'PARTNER-{tag}-{p}' for p in sorted(partner_entries)]
        catalog.append(dict(TIER=1, OBJECT_NAME=tier1, PARENT='', CLASS=f'PARTNER-{tag}',
                             MEMBER_TYPE='group', VALUE=';'.join(obj_names),
                             CIDR_COUNT=total, SOURCE=source_label))
        for partner, entries in sorted(partner_entries.items()):
            obj_name = f'PARTNER-{tag}-{partner}'
            all_devices = sorted({d for e in entries for d in e[2]})
            catalog.append(dict(TIER=2, OBJECT_NAME=obj_name, PARENT=tier1, CLASS=f'PARTNER-{tag}',
                                 MEMBER_TYPE='cidr-list',
                                 VALUE=';'.join(sorted(e[0] for e in entries)),
                                 CIDR_COUNT=len(entries),
                                 SOURCE=f'{source_label} (devices: {", ".join(all_devices) or "unknown"})'))
            manifest_rows.append([tier1, '', obj_name, len(entries)])
        return partner_entries

    vpn_partner_entries = _add_partner_tier('VPN', vpn_records, 'vpn-registry')
    p2p_partner_entries = _add_partner_tier('P2P', p2p_records, 'p2p-registry')

    stamp = date.today().strftime('%Y%m%d')
    cat_csv = os.path.join(args.out, f'network_object_catalog_v{stamp}.csv')
    cols = ['TIER', 'OBJECT_NAME', 'PARENT', 'CLASS', 'MEMBER_TYPE', 'VALUE', 'CIDR_COUNT', 'SOURCE']
    with open(cat_csv, 'w', newline='') as f:
        f.write(f'#STEM=partner_ng_catalog\n#VERSION={stamp}\n#ROWS={len(catalog)}\n')
        f.write(f'#TOOL=build_partner_ng.py v{__version__}\n'
                f'#SOURCE_INPUT_VPN={os.path.basename(args.vpn_subs)}\n'
                f'#SOURCE_INPUT_P2P={os.path.basename(args.p2p_subs) if args.p2p_subs else "none (skipped, see script docstring)"}\n'
                f'#END_HEADER\n')
        wr = csv.DictWriter(f, fieldnames=cols)
        wr.writeheader()
        for row in catalog:
            wr.writerow(row)

    with open(os.path.join(args.out, 'ng_manifest.csv'), 'w', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['Tier1_Class', 'Tier2_Location', 'Tier3_Object', 'CIDR_count'])
        wr.writerows(manifest_rows)

    edl_count = 0
    if not args.no_edl:
        edl_dir = os.path.join(args.out, 'EDL')
        os.makedirs(edl_dir, exist_ok=True)

        # DC-* hierarchy EDLs
        for tag, t2_children, t3_entries in (('VPN', vpn_dc_t2, vpn_dc_t3), ('P2P', p2p_dc_t2, p2p_dc_t3)):
            if not t2_children:
                continue
            tier1 = f'DC-{tag}-PARTNERS'
            all_entries, _conflicts = _merge_by_cidr(
                (e[0], e[1], '', d) for ao_entries in t3_entries.values()
                for e in ao_entries for d in (e[2] or {''}))
            write_edl(tier1, all_entries, edl_dir)
            edl_count += 1
            for t2, aos in sorted(t2_children.items()):
                t2_records = [(e[0], e[1], '', d) for ao in aos for e in t3_entries.get(ao, [])
                              for d in (e[2] or {''})]
                if t2_records:
                    t2_entries, _c = _merge_by_cidr(t2_records)
                    write_edl(t2, t2_entries, edl_dir)
                    edl_count += 1
            for ao, entries in sorted(t3_entries.items()):
                if entries:
                    write_edl(ao, entries, edl_dir)
                    edl_count += 1

        # Partner-* hierarchy EDLs
        for tag, partner_entries in (('VPN', vpn_partner_entries), ('P2P', p2p_partner_entries)):
            if not partner_entries:
                continue
            tier1 = f'Partner-{tag}'
            all_records = [(e[0], e[1], '', d) for entries in partner_entries.values()
                            for e in entries for d in (e[2] or {''})]
            all_entries, _conflicts = _merge_by_cidr(all_records)
            write_edl(tier1, all_entries, edl_dir)
            edl_count += 1
            for partner, entries in sorted(partner_entries.items()):
                obj_name = f'PARTNER-{tag}-{partner}'
                write_edl(obj_name, entries, edl_dir)
                edl_count += 1

        print(f'EDL export: {edl_count} files written to {edl_dir}/')

    print(json.dumps({
        "version": __version__,
        "tier1_classes_present": t1_present,
        "vpn_partner_sites": len({r[2] for r in vpn_records}),
        "vpn_partner_cidr_rows": len(vpn_records),
        "vpn_unique_partners": len({r[1] for r in vpn_records}),
        "p2p_partner_sites": len({r[2] for r in p2p_records}),
        "p2p_partner_cidr_rows": len(p2p_records),
        "p2p_unique_partners": len({r[1] for r in p2p_records}),
        "edls_written": edl_count,
        "catalog_csv": cat_csv,
        "out_dir": args.out,
    }, indent=2))


def main():
    ap = argparse.ArgumentParser(description='CCD Platform — Partner-NG (VPN/P2P partner subnets) builder')
    ap.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    ap.add_argument('--vpn-subs', default=None, help='ent-ipdataset-VPN-PROTECTED-SUBNETS CSV (auto-discovered if omitted)')
    ap.add_argument('--p2p-subs', default=None, help='ent-ipdataset-P2P-PROTECTED-SUBNETS CSV, subnet-level (optional)')
    ap.add_argument('--out', default=None, help='output directory (default: ./Partner_NG/NG-YYYYMMDD_v<N>)')
    ap.add_argument('--base', default='.', help='CCD Platform root directory for auto-discovery (default: .)')
    ap.add_argument('--no-edl', action='store_true', help='skip EDL/*.txt export (EDL is written by default)')
    ap.add_argument('--dry-run', action='store_true', help='report counts without writing files')
    args = ap.parse_args()

    print('Resolving inputs:')
    disc = discover_inputs(args.base)
    args.vpn_subs = resolve_input(args.vpn_subs, disc.get('vpn_subs'), 'vpn_subs', required=True)
    args.p2p_subs = resolve_input(args.p2p_subs, disc.get('p2p_subs'), 'p2p_subs', required=False)
    args.p2p_link_registry = disc.get('p2p_link_registry')
    print()

    if args.out is None:
        args.out = os.path.join(latest_net_group_dir(args.base), 'Partner_NG')

    build(args)


if __name__ == '__main__':
    main()
