#!/usr/bin/env python3
"""
build_network_groups.py  v1.8.8  —  CCD Platform
Generates the 3-tier PAN-OS source Network-Object hierarchy from IPAM datasets.

  Tier-1  Site-Type / BU class      (e.g. NG-DATACENTER, NG-DR, NG-CLOUD, NG-CORPORATE)
  Tier-2  Location breakout         (SITE_CODE for named facilities; provider for cloud;
                                      state + East/West region for Corporate;
                                      function+state for Retail/MinuteClinic/Optical)
  Tier-3  Concatenated CIDR object  (the ONLY tier where IP literals exist)

Tier-1 classification is taken from location_master (authoritative LOCATION_TYPE owner),
joined onto all_IP_networks by SITE_CODE — NOT from the denormalized LOCATION_TYPE copy
carried in all_IP_networks. Retail tiers are emitted as native /26 address groups
(host rows collapsed to their containing /26) — NO EDLs, to preserve the platform's
finite EDL slots for SOC threat feeds and Zscaler AI lists.

Outputs:
  <out>/ccd_network_groups.set      PAN-OS set-format CLI (all address objects + Tier-3/2/1 groups + retail /26 groups)
  <out>/ng_manifest.csv             Tier1/Tier2/Tier3/CIDR-count manifest
  <out>/ng_reconciliation.csv       rows where all_IP_networks LOCATION_TYPE != location_master
  <out>/retail_oversized_blocks.csv retail blocks broader than /26 (kept intact, for review)

Versioning: SCRIPT __version__ = MAJOR.MINOR.PATCH ; emits a #VERSION header in the .set file.
  v1.1.0 — retail converted from EDL feeds to native /26 address groups (EDL-slot conservation).

Usage:
  python build_network_groups.py \
      --ipam all_IP_networks_v20260525r5.csv \
      --lm   location_master_v5_11.csv \
      --retail retail_networks_v2_9.csv \
      --out  ./Net_Group/NG-YYYYMMDD_v1  \
      [--tier1-source lm|ipam] [--dry-run]
"""
from __future__ import annotations
import argparse, csv, ipaddress, json, os, re, sys
from collections import OrderedDict, defaultdict

# ---------------------------------------------------------------------------
# IP OVERLAP VERIFICATION
# ---------------------------------------------------------------------------

def resolve_address_objects(
        ipam_rows: list[dict],
        out_dir: str,
) -> tuple[dict, int]:
    """
    Three-pass routing-aware address object resolver.

    Replaces the old post-build overlap checker. Operates on raw IPAM rows
    (SITE_CODE + CIDR) before the network group hierarchy is assembled, and
    returns the clean per-SITE_CODE address object set that the builder should
    use instead of iterating raw IPAM rows directly.

    Pass 1 — SITE_CODE uniqueness
        A CIDR must belong to exactly one SITE_CODE.
        Same CIDR under two different SITE_CODEs → HIGH EXACT_DUP_CROSS_SITE.
        Retail /26 in 172.16/12 space appearing in both retail and DC SITE_CODEs
        is by-design dual-use → INFO RETAIL_DC_172_DUP.

    Pass 2 — Intra-site supernet suppression
        Within a SITE_CODE, if CIDR A is a supernet of CIDR B (both same site),
        only B (the more-specific) is emitted as an address object — LPM wins.
        Suppressed supernets reported as INFO INTRASITE_SUPERNET_SUPPRESSED.
        P2P links (/30, /31) and host routes (/32) are never emitted as address
        objects regardless — reported as INFO P2P_LINK_EXCLUDED.

    Pass 3 — Inter-site LPM conflict detection
        For each emitted CIDR, find the longest-prefix match from any other
        SITE_CODE. Applying routing rules:
          - Exact match (same prefix, different SITE_CODE) → HIGH EXACT_DUP_CROSS_SITE
          - More-specific from other site at /30 or /31 → INFO P2P_SPLIT
            (expected: point-to-point links split address space between two sites)
          - More-specific from other site at /29 or larger → HIGH SITE_CARVEOUT
            (one site has carved allocations from within another site's block)
          - Less-specific from other site → no violation (LPM resolves correctly,
            the more-specific CIDR wins at enforcement time)
        Cloud _IS SITE_CODEs containing on-prem allocations → INFO CLOUD_ALLOC_BOUNDARY
        (cloud /16 summary objects are allocation markers, not routing boundaries).

    Returns:
        clean_cidrs : dict  SITE_CODE -> sorted list of CIDR strings to emit
        high_count  : int   number of HIGH violations (should be 0 before deployment)

    Side effect: writes ng_overlap_violations.csv to out_dir.
    """

    # ── Parse IPAM rows into (net, site_code) pairs ──────────────────────────
    entries = []   # list of (ipaddress.IPv4Network, site_code)
    for r in ipam_rows:
        sc = (r.get('SITE_CODE') or '').strip()
        if not sc:
            continue
        try:
            net = ipaddress.ip_network((r.get('CIDR') or '').strip(), strict=False)
        except ValueError:
            continue
        entries.append((net, sc))

    total = len(entries)
    print(f'\nAddress Object Resolution:')
    print(f'  IPAM rows      : {total:,}')

    # ── Build lookup structures ───────────────────────────────────────────────
    # cidr_to_sites: str(net) -> list of SITE_CODEs
    cidr_to_sites: dict[str, list[str]] = {}
    for net, sc in entries:
        key = str(net)
        cidr_to_sites.setdefault(key, [])
        if sc not in cidr_to_sites[key]:
            cidr_to_sites[key].append(sc)

    # site_nets: SITE_CODE -> sorted list of IPv4Network (most-specific first)
    # Use a parallel set of strings for dedup — avoids Python 3.14 IPv4Network
    # __eq__ hang when checking membership in a list of network objects.
    site_nets: dict[str, list] = {}
    site_nets_seen: dict[str, set] = {}
    for net, sc in entries:
        site_nets.setdefault(sc, [])
        site_nets_seen.setdefault(sc, set())
        key = str(net)
        if key not in site_nets_seen[sc]:
            site_nets_seen[sc].add(key)
            site_nets[sc].append(net)
    for sc in site_nets:
        site_nets[sc].sort(key=lambda n: n.prefixlen, reverse=True)

    violations = []

    # ── PASS 1: SITE_CODE uniqueness ─────────────────────────────────────────
    print(f'  Pass 1: SITE_CODE uniqueness...', end=' ', flush=True)
    p1_dups = 0
    for cidr_str, sites in cidr_to_sites.items():
        if len(sites) < 2:
            continue
        net = ipaddress.ip_network(cidr_str, strict=False)
        retail_sites  = [s for s in sites if s.startswith('US_') and '_RT' in s or '_MC' in s or '_OPT' in s]
        cloud_sites   = [s for s in sites if s.endswith('_IS')]
        onprem_sites  = [s for s in sites if s not in retail_sites and s not in cloud_sites]
        # Retail /26 in 172.16/12 coexisting with DC → by-design INFO
        if net.prefixlen == 26 and retail_sites and onprem_sites:
            for rs in retail_sites:
                for os_ in onprem_sites:
                    violations.append(('INFO', 'RETAIL_DC_172_DUP',
                                       cidr_str, rs, cidr_str, os_))
            continue
        # Cloud summary containing on-prem → INFO (allocation boundary, not routing)
        if cloud_sites and onprem_sites:
            for cs in cloud_sites:
                for os_ in onprem_sites:
                    violations.append(('INFO', 'CLOUD_ALLOC_BOUNDARY',
                                       cidr_str, cs, cidr_str, os_))
            continue
        # Everything else → HIGH exact duplicate
        for i in range(len(sites)):
            for j in range(i + 1, len(sites)):
                violations.append(('HIGH', 'EXACT_DUP_CROSS_SITE',
                                   cidr_str, sites[i], cidr_str, sites[j]))
                p1_dups += 1
    print(f'{p1_dups} HIGH exact duplicates')

    # ── PASS 2: Intra-site supernet suppression ───────────────────────────────
    print(f'  Pass 2: Intra-site supernet suppression...', end=' ', flush=True)
    # For each SITE_CODE, determine which CIDRs to emit:
    #   - Never emit /32, /31, /30 (host routes and P2P links)
    #   - If a less-specific CIDR from the same site contains this CIDR, suppress
    #     the less-specific (more-specific wins via LPM)
    clean_cidrs: dict[str, list[str]] = {}
    p2p_excluded = 0
    supernet_suppressed = 0

    for sc, nets in site_nets.items():
        # Exclude P2P/host
        p2p = [n for n in nets if n.prefixlen >= 30]
        policy = [n for n in nets if n.prefixlen < 30]
        p2p_excluded += len(p2p)
        for n in p2p:
            violations.append(('INFO', 'P2P_LINK_EXCLUDED', str(n), sc, '', ''))

        # Suppress intra-site supernets — if a more-specific from same site exists
        # within a less-specific, drop the less-specific
        # nets are already sorted most-specific first
        emit = []
        suppressed_set = set()
        for n in policy:
            if str(n) in suppressed_set:
                continue
            emit.append(n)
            # Mark all same-site supernets of n as suppressed
            for other in policy:
                if other.prefixlen < n.prefixlen and n.subnet_of(other):
                    if str(other) not in suppressed_set:
                        suppressed_set.add(str(other))
                        violations.append(('INFO', 'INTRASITE_SUPERNET_SUPPRESSED',
                                           str(other), sc, str(n), sc))
                        supernet_suppressed += 1

        clean_cidrs[sc] = sorted([str(n) for n in emit],
                                 key=lambda x: ipaddress.ip_network(x, strict=False))

    print(f'{p2p_excluded} P2P excluded, {supernet_suppressed} intra-site supernets suppressed')

    # ── PASS 3: Inter-site LPM conflict detection ─────────────────────────────
    print(f'  Pass 3: Inter-site LPM conflict detection...', end=' ', flush=True)

    # Build global prefix-length buckets for fast LPM lookup
    # bucket[prefixlen][network_address_int] -> list of SITE_CODEs
    buckets: dict[int, dict[int, list[str]]] = {}
    for sc, cidrs in clean_cidrs.items():
        for cidr_str in cidrs:
            net = ipaddress.ip_network(cidr_str, strict=False)
            pl = net.prefixlen
            addr = int(net.network_address)
            buckets.setdefault(pl, {})
            buckets[pl].setdefault(addr, [])
            if sc not in buckets[pl][addr]:
                buckets[pl][addr].append(sc)

    sorted_pls = sorted(buckets.keys())
    p3_high = 0
    checked = 0
    last_pct = -1
    total_check = sum(len(cidrs) for cidrs in clean_cidrs.values())

    for sc, cidrs in clean_cidrs.items():
        for cidr_str in cidrs:
            checked += 1
            pct = (checked * 100) // total_check if total_check else 100
            if pct != last_pct and pct % 10 == 0:
                print(f'\r  Pass 3: Inter-site LPM conflict detection... {pct}%   ', end='', flush=True)
                last_pct = pct

            net = ipaddress.ip_network(cidr_str, strict=False)
            pl  = net.prefixlen
            addr_int = int(net.network_address)

            # Only flag exact duplicates — same prefix length, same CIDR, different SITE_CODE.
            # Containment across sites is fine — LPM resolves it at enforcement time.
            other_sites = [s for s in buckets.get(pl, {}).get(addr_int, []) if s != sc]
            for other_sc in other_sites:
                other_is_cloud = other_sc.endswith('_IS')
                this_is_cloud  = sc.endswith('_IS')
                if other_is_cloud or this_is_cloud:
                    violations.append(('INFO', 'CLOUD_ALLOC_BOUNDARY',
                                       cidr_str, sc, cidr_str, other_sc))
                else:
                    violations.append(('HIGH', 'EXACT_DUP_CROSS_SITE',
                                       cidr_str, sc, cidr_str, other_sc))
                    p3_high += 1

    print(f'\r  Pass 3: Inter-site LPM conflict detection... 100%   ')
    print(f'          {p3_high} HIGH conflicts')

    # ── Deduplicate violations ────────────────────────────────────────────────
    seen_v: set = set()
    deduped = []
    for v in violations:
        # Normalise key — (type, sorted pair of (cidr,site))
        pair = tuple(sorted([(v[1], v[2]), (v[1], v[4])]))
        key  = (v[0], v[1], pair)
        if key not in seen_v:
            seen_v.add(key)
            deduped.append(v)
    violations = deduped

    # ── Write violations CSV ──────────────────────────────────────────────────
    viol_path = os.path.join(out_dir, 'ng_overlap_violations.csv')
    os.makedirs(out_dir, exist_ok=True)
    with open(viol_path, 'w', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['SEVERITY', 'VIOLATION_TYPE',
                     'CIDR_A', 'SITE_A', 'CIDR_B', 'SITE_B'])
        sev_order = ['HIGH', 'MEDIUM', 'LOW', 'INFO']
        for v in sorted(violations, key=lambda x: sev_order.index(x[0])):
            wr.writerow(v)

    high   = sum(1 for v in violations if v[0] == 'HIGH')
    info   = sum(1 for v in violations if v[0] == 'INFO')
    total_v = len(violations)
    emit_count = sum(len(c) for c in clean_cidrs.values())

    print(f'\n  Address objects to emit : {emit_count:,}')
    print(f'  Violations              : {total_v}  (HIGH={high}  INFO={info})')
    if total_v:
        print(f'  Report                  : {viol_path}')
    if high:
        print(f'  ✗ {high} HIGH violation(s) — must resolve before deployment')
    else:
        print(f'  ✓ No HIGH violations')

    return clean_cidrs, high

# ---------------------------------------------------------------------------
# FILE DISCOVERY HELPERS
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    """
    Return the latest versioned file matching glob pattern in directory.
    Sorts by (date, revision) numerically so r18 > r9 > bare.
    Pattern: vYYYYMMDD or vYYYYMMDDrN
    """
    import glob, re as _re
    def _ver_key(path):
        name = os.path.basename(path)
        m = _re.search(r'v(\d{8})(?:r(\d+))?', name)
        if m:
            return (int(m.group(1)), int(m.group(2) or 0))
        return (0, 0)
    matches = glob.glob(os.path.join(directory, pattern))
    return max(matches, key=_ver_key) if matches else None


def discover_inputs(base="."):
    """
    Auto-discover the latest version of every CCD Platform input dataset
    from the standard directory layout under base:
        {base}/ipam-db/            IPAM, LM, SNAT, CPC, EIF datasets
        {base}/network-groups/     network_object_catalog, internet_segments
        {base}/processed_outputs/  canonical_app_objects, EIR
    Returns a dict keyed by input name; values are paths or None.
    """
    ipam_dir = os.path.join(base, "ipam-db")
    ng_dir   = os.path.join(base, "network-groups")
    proc_dir = os.path.join(base, "processed_outputs")
    lm_canonical = os.path.join(ipam_dir, "location_master_table.csv")
    lm = lm_canonical if os.path.exists(lm_canonical) \
         else _latest(ipam_dir, "location_master_v*.csv")
    return {
        "ipam":          _latest(ipam_dir,  "all_IP_networks_v*.csv"),
        "lm":            lm,
        "retail":        _latest(ipam_dir,  "retail_networks_v*.csv"),
        "inet_segments": _latest(ng_dir,    "internet_segments_v*.csv"),
        "catalog":       _latest(ng_dir,    "network_object_catalog_v*.csv"),
        "snat":          _latest(ipam_dir,  "ent-ipdataset-FW-SNAT-POOLS-v*.csv"),
        "eif":           _latest(ipam_dir,  "ent-ipdataset-INTERNET-FACING-v*.csv"),
        "eir":           _latest(proc_dir,  "external_ip_registry_v*.csv"),
        "vpn_subs":      _latest(ipam_dir,  "ent-ipdataset-VPN-PROTECTED-SUBNETS*.csv"),
        "p2p_subs":      _latest(ipam_dir,  "ent-ipdataset-P2P-PROTECTED-SUBNETS*.csv"),
    }


def resolve_input(cli_value, discovered_value, name, required=True):
    """
    Resolve an input path: prefer explicit CLI value, fall back to auto-discovery.
    Prints the resolved path so every run is auditable. Exits on required-missing.
    """
    path = cli_value or discovered_value
    if path and os.path.exists(path):
        print(f"  {name:<22s} {path}  [{'arg' if cli_value else 'auto'}]")
        return path
    if required:
        label = path or "(no match in default locations)"
        print(f"  {name:<22s} NOT FOUND: {label}", file=sys.stderr)
        sys.exit(1)
    if path:
        print(f"  {name:<22s} skipped (not found)")
    return None

from collections import defaultdict, OrderedDict

__version__ = "1.8.8"
# v1.8.8 — 2026-07-09  BUG FIX: write_edl()'s CIDR sort crashed the entire
#           pipeline on a single malformed value anywhere in the input —
#           confirmed live, an upstream FMC object literally named
#           'OBJ-10.218.116.691' (a real typo in CVS's own source data,
#           not a parsing bug) propagated through and aborted Stage 1
#           outright. Now filters out anything malformed first (with a
#           warning) instead of crashing — defense in depth on top of the
#           actual fix at the data source
#           (extract_partner_subnets_from_rule_db.py v1.0.4).
# v1.8.7 — 2026-07-09  BUG FIX: NG-P2P-PARTNERS direction filter never
#           fired. Two compounding bugs: (1) read _row.get('DIRECTION')
#           (uppercase) but the real column is lowercase 'direction' — the
#           VPN partner block two sections above already reads it lowercase
#           correctly; (2) even with the case fixed, compared against
#           'CVS' — never a real value in this dataset, which uses
#           LOCAL/REMOTE (same convention as VPN-PROTECTED-SUBNETS). Net
#           effect: ALL rows passed the filter unfiltered, so
#           NG-P2P-PARTNERS carried all 9,642 P2P-PROTECTED-SUBNETS rows
#           (7,799 LOCAL/CVS-owned + 1,843 REMOTE/partner) instead of just
#           the 1,843 real partner CIDRs — confirmed via a live pipeline
#           run 2026-07-09. Fixed to match the VPN block's exact pattern:
#           lowercase 'direction' with uppercase fallback, exclude LOCAL.
#           Also fixed a stale docstring-header version mismatch found in
#           the same file (header said v1.8.5, __version__ was already at
#           1.8.6) while in here.
# v1.8.6 — 2026-07-07  REMOTE-ACCESS group generation: per-CIDR NET_TYPE
#           lookup via cidr_nt. Mixed SITE_CODEs split at classification.
#           NG-REMOTE-ACCESS-RA_POOL_CSA/RA_SNAT_HCB/RA_CONN_ZPA Tier-2.
# v1.8.5 — 2026-07-07  TIER1_TAXONOMY: added REMOTE-ACCESS tier for
#           RA-POOL-CSA, RA-SNAT-HCB, RA-CONN-ZPA, and legacy
#           User-Access-VPN / ZPA-Connector NET_TYPEs.
# v1.8.4 — Fix VPN-PARTNERS/P2P-PARTNERS catalog CIDR_COUNT: Tier-1 and Tier-2
#           rows were written with CIDR_COUNT='' causing the report and EDL
#           catalog to show 0 CIDRs for all VPN/P2P partner groups. Fixed by
#           computing the sum of Tier-3 CIDR sets at each level before writing.
#           Fix NG-INTERNET-FACING Tier-1 CIDR_COUNT (same blank value bug).
#           Fix duplicate NG-VPN-PARTNERS/NG-P2P-PARTNERS/NG-INTERNET-FACING
#           Tier-1 catalog rows: excluded from the general t1_children loop
#           since they are emitted with correct counts in their own blocks.
# v1.8.3 — TIER1_TAXONOMY: added "NAAS-Hub" (LM v5.20+ normalized form) and
#           "Cloud-Peering" entries. Sites with these LOCATION_TYPEs were
#           falling into unclassified; now route to NAAS-HUB and CLOUD
#           respectively. Zero reconciliation_rows expected after LM v5.22 sync.
# v1.7.5 — Added --edl flag: exports PA-compatible EDL .txt files (one per
#           Tier-1 group and one per Tier-2 site group) into edl/ subdirectory.
#           EDL format: comment header block (#) + one CIDR per line.
#           NG-APP/INFRA/DELIVERY/SERVICE confirmed absent — owned by
#           build_service_objects.py (removed in v1.7.0).
# v1.7.4 — Added missing retail_addr/retail_state_addr_groups/
#           retail_region_addr_groups build block (dropped during v1.5→v1.7
#           rebuild). Caused NameError on live run.
# v1.7.3 — dry_run JSON now includes VPN/P2P partner group counts and
#           NG-VPN-PARTNERS/NG-P2P-PARTNERS in tier1_classes output.
#           VPN/P2P wired into t1_children before dry_run gate.
# v1.7.2 — vpn_subs/p2p_subs added to discover_inputs() dict.
# v1.7.1 — --version flag added to argparse.
# v1.7.0 — Removed Tier-4 APP/SERVICE/INFRA/DELIVERY/CPC object groups.
#           These are now owned exclusively by build_service_objects.py.
#           build_network_groups.py is the SOURCE side only (location groups).
#           Removed --app-objects and --cpc-services CLI args.
#           Tier-4 INET segments retained (location-scoped, source-side).
# v1.6.0 — VPN/P2P partner groups: reads VPN-PROTECTED-SUBNETS and
#           P2P-PROTECTED-SUBNETS to produce NG-VPN-PARTNERS and
#           NG-P2P-PARTNERS Tier-1 groups with per-site Tier-2.
#           Partner subnets excluded from IPAM loop (no double-counting).
# v1.5.0 — File discovery: inputs auto-discovered from standard layout; all input flags optional.
# v1.4.0 — Structural fix: INET segments wired to Tier-2 parent location groups.
#           APP/SERVICE/INFRA/DELIVERY objects emitted as first-class Tier-1 classes
#           (NG-APP, NG-SERVICE, NG-INFRA, NG-DELIVERY) with objects as direct children.
#           CPC SVC_* objects dual-parented: under Tier-2 location AND NG-SERVICE Tier-1.
# v1.3.0 — Added Tier-4 internet segment objects (INET_SEG_*), CPC service objects,
#           and canonical app objects to the network group hierarchy.
#           New CLI args: --inet-segments, --cpc-services, --app-objects.
#           Catalog schema: TIER column now supports 4-inet, 4-cpc, 4-app values.
# v1.2.1 — CORPORATE region handler: non-US state codes (e.g. IE=Ireland) now
#           route to NG-CORP-INTL instead of NG-CORP-UNK / NG-CORP-<COUNTRY>.
#           NG-CORPORATE Tier-1 rollup now includes INTL alongside EAST/WEST.

# ----------------------------------------------------------------------
# Canonical Site-Type / BU taxonomy.
# Maps BOTH the long LOCATION_TYPE values AND the raw short codes that
# appear un-normalized in location_master (CI/CO/IS/TP/MO/RT/SP/HP/CP/NH)
# to a single canonical Tier-1 class. Edit here to extend the taxonomy.
# ----------------------------------------------------------------------
TIER1_TAXONOMY = {
    # long forms
    "Datacenter": "DATACENTER", "DataCenter": "DATACENTER",
    "COLO": "COLO",
    "Cloud": "CLOUD", "Cloud-Azure": "CLOUD", "Cloud-GCP": "CLOUD", "Cloud-AWS": "CLOUD",
    "Corporate": "CORPORATE", "Field-Office": "CORPORATE",
    "Distribution": "DISTRIBUTION",
    "Call-Center": "CALL-CENTER", "CVS-CC": "CALL-CENTER",
    "Specialty": "SPECIALTY",
    "CarePlus": "CAREPLUS", "Field-Clinic": "CAREPLUS",
    "Omnicare": "OMNICARE",
    "Mail-Order": "MAIL-ORDER",
    "Coram": "CORAM",
    "DMZ": "DMZ",
    "Partner": "PARTNER",
    "Internet-Facing": "INTERNET-FACING",
    "P2P-WAN": "P2P-WAN", "SNAT": "SNAT",
    "DR": "DR",
    "Retail": "RETAIL", "MinuteClinic": "MINUTECLINIC", "Optical": "OPTICAL",
    "VoIP-Hub": "NAAS-HUB", "NH": "NAAS-HUB",
    "NAAS-Hub": "NAAS-HUB",      # LM v5.20+ normalized form
    "Cloud-Peering": "CLOUD",    # cloud peering exchange points fall under CLOUD tier
    # Remote Access infrastructure (v1.8.5)
    "RA-POOL-CSA":  "REMOTE-ACCESS",  # AnyConnect/CSA client pool subnets
    "RA-SNAT-HCB":  "REMOTE-ACCESS",  # Aetna PDC SNAT translation pools
    "RA-CONN-ZPA":  "REMOTE-ACCESS",  # ZPA App Connector hosting subnets
    "User-Access-VPN": "REMOTE-ACCESS",  # legacy — superseded by RA-POOL-CSA
    "ZPA-Connector":   "REMOTE-ACCESS",  # legacy — superseded by RA-CONN-ZPA
    # raw short codes (un-normalized LOCATION_TYPE values — see remediation prompt)
    "CI": "COLO", "CO": "CORPORATE", "IS": "CLOUD", "TP": "PARTNER",
    "MO": "MAIL-ORDER", "RT": "RETAIL", "SP": "SPECIALTY",
    "HP": "CAREPLUS", "CP": "CAREPLUS",
}

CLOUD_PROVIDER_TOKEN = {"AZR": "AZURE", "GCP": "GCP", "AWS": "AWS"}

# ----------------------------------------------------------------------
# RETAIL geographic segmentation (Network-Grouping construct, not an LM/IPAM
# attribute). Two distinct, co-existing levels: REGION (East/West of the
# Mississippi) and STATE. Both are emitted as first-class, rule-addressable
# address-groups. The region map is externalized here so any state's
# assignment can be changed in one place; the build report lists every
# assignment for review. Border states (river straddles MN WI IA IL MO KY TN
# AR MS LA) are assigned wholesale to the side their footprint predominates:
#   East bank (sit east of river): WI IL KY TN MS LA
#   West bank (sit west of river): MN IA MO AR
# ----------------------------------------------------------------------
EAST_OF_MISSISSIPPI = set(
    "AL CT DE FL GA IL IN KY ME MD MA MI MS NH NJ NY NC OH PA RI SC TN VT VA WV WI DC "
    "PR VI".split()   # Puerto Rico / USVI grouped East (Atlantic)
)
WEST_OF_MISSISSIPPI = set(
    "AK AZ AR CA CO HI ID IA KS LA MN MO MT NE NV NM ND OK OR SD TX UT WA WY "
    "GU".split()       # Guam grouped West (Pacific)
)

def region_for_state(st: str) -> str:
    """Return 'EAST' or 'WEST' for a 2-letter state, or 'UNK' if unmapped."""
    st = (st or "").upper()
    if st in EAST_OF_MISSISSIPPI:
        return "EAST"
    if st in WEST_OF_MISSISSIPPI:
        return "WEST"
    return "UNK"

# SITE_CODE suffix -> retail function (authoritative). FACILITY_TYPE is
# cross-checked against this; disagreements are reported, not silently resolved.
RETAIL_SUFFIX_FUNCTION = {"RT": "PHARMA", "MC": "MINUTECLINIC", "OPT": "OPTICAL"}
# FACILITY_TYPE -> function (fallback / cross-check only)
RETAIL_FACILITY_MAP = {"Retail-Store": "PHARMA", "MinuteClinic": "MINUTECLINIC", "Optical": "OPTICAL"}
# All retail functions roll up under the single Tier-1 business-function class NG-RETAIL.
RETAIL_TIER1 = "NG-RETAIL"


def clean(s: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", str(s).upper()).strip("-")


def state_from_sitecode(sc: str) -> str:
    parts = str(sc).split("_")
    return parts[2] if len(parts) >= 3 else "UNK"


def suffix_from_sitecode(sc: str) -> str:
    """
    Return the trailing TYPE suffix of a SITE_CODE (e.g. US_TX_06752_RT -> 'RT').
    Strips a numeric disambiguator if present (CO1 -> CO). Returns '' if none.
    """
    parts = str(sc).split("_")
    if len(parts) < 4:
        return ""
    suf = parts[-1].upper()
    m = re.match(r"^([A-Z\-]+?)\d*$", suf)   # CO1 -> CO ; RT -> RT ; F9-NH -> F9-NH
    return m.group(1) if m else suf


def read_stamped_csv(path: str):
    """Read a CCD CSV that has #-prefixed header stamps before the real header row."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        lines = f.readlines()
    hdr_idx = next(i for i, ln in enumerate(lines)
                   if not ln.startswith("#") and "," in ln)
    reader = csv.DictReader(lines[hdr_idx:])
    return list(reader)


def valid_cidr(c: str) -> bool:
    if not c or "/" not in str(c):
        return False
    try:
        ipaddress.ip_network(c.strip(), strict=False)
        return True
    except ValueError:
        return False


def collapse_to_26(cidr: str):
    """
    Collapse a retail CIDR to the /26 supernet that contains it.

    WHY: retail_networks is overwhelmingly /32 host rows (one row per device).
    Emitting those raw burns EDL slots and bloats objects. The CCD retail model
    allocates /26 per function per store, so the /26 is the natural object
    boundary. This returns the canonical /26 string for any host/longer prefix.

    Behavior by input prefix:
      * /32, /27..  -> the containing /26  (e.g. 10.237.1.130/32 -> 10.237.1.128/26)
      * /26          -> itself (already canonical)
      * /25, /24, .. -> returned unchanged; cannot shrink to /26 without inventing
                        a split, so the broader block is kept as a single object
                        and reported separately.
    Returns (canonical_cidr_str, was_aggregated_bool) or (None, False) if invalid.
    """
    try:
        net = ipaddress.ip_network(str(cidr).strip(), strict=False)
    except ValueError:
        return None, False
    if net.prefixlen > 26:
        # host or sub-/26 -> snap up to the enclosing /26
        return str(net.supernet(new_prefix=26)), True
    # /26 exactly, or broader (/25,/24...) which we keep intact
    return str(net), False


def obj_name_for_cidr(cidr: str) -> str:
    """Stable PAN-OS address-object name for a CIDR (e.g. addr-10-237-1-128_26)."""
    return "addr-" + cidr.replace("/", "_").replace(".", "-")


def build(args):
    ipam = read_stamped_csv(args.ipam)
    lm = read_stamped_csv(args.lm)

    # authoritative LOCATION_TYPE + canonical name keyed by SITE_CODE
    lm_loctype = {r["SITE_CODE"]: r.get("LOCATION_TYPE", "") for r in lm}
    lm_canon = {r["SITE_CODE"]: r.get("CANONICAL_NAME", "") for r in lm}

    # ── Phase 0: resolve clean address objects from IPAM ─────────────────────
    # resolve_address_objects() runs three passes:
    #   1. SITE_CODE uniqueness — flag exact duplicate CIDRs across sites
    #   2. Intra-site supernet suppression — emit only most-specific per site;
    #      exclude /30, /31, /32 (P2P links / host routes)
    #   3. Inter-site LPM conflict — flag only true ambiguities (same prefix,
    #      different site); containment is fine (LPM resolves at enforcement time)
    # Returns clean_cidrs: {SITE_CODE -> [cidr, ...]} used below instead of raw rows.
    import tempfile as _tf
    _viol_dir = args.out if not args.dry_run else _tf.mkdtemp()
    os.makedirs(_viol_dir, exist_ok=True)
    clean_cidrs, _high_count = resolve_address_objects(ipam, _viol_dir)

    # Build a single-row lookup per SITE_CODE for LOCATION_TYPE reconciliation
    # (still needed for reconciliation reporting)
    # Also build per-CIDR NET_TYPE lookup for RA subnet override (v1.8.6)
    _RA_NET_TYPES = {'RA-POOL-CSA', 'RA-SNAT-HCB', 'RA-CONN-ZPA',
                     'User-Access-VPN', 'ZPA-Connector'}
    cidr_nt = {}  # cidr -> NET_TYPE for RA override
    ipam_lt_by_sc = {}
    for r in ipam:
        sc  = (r.get("SITE_CODE") or "").strip()
        nt  = (r.get("NET_TYPE") or "").strip()
        cid = (r.get("CIDR") or "").strip()
        if cid and nt in _RA_NET_TYPES:
            cidr_nt[cid] = nt
        if sc and sc not in ipam_lt_by_sc:
            ipam_lt_by_sc[sc] = r.get("LOCATION_TYPE") or ""

    t3 = OrderedDict()                  # AO-name -> set(cidr)
    t2_children = defaultdict(set)      # NG-T2 -> set(AO-name)
    t1_children = defaultdict(set)      # NG-T1 -> set(NG-T2)
    reconciliation = []                 # rows where ipam loctype != lm loctype
    unclassified = []

    # ── Iterate clean address objects by SITE_CODE ────────────────────────────
    for sc, cidrs in clean_cidrs.items():
        if not cidrs:
            continue

        # ---- Tier-1 classification (identical logic, now per SITE_CODE) ----
        ipam_lt = ipam_lt_by_sc.get(sc, "")
        lm_lt   = lm_loctype.get(sc, "")
        if ipam_lt and lm_lt and ipam_lt != lm_lt:
            for cidr in cidrs:
                reconciliation.append([sc, cidr, ipam_lt, lm_lt])

        chosen_lt = lm_lt if (args.tier1_source == "lm" and lm_lt) else (ipam_lt or lm_lt)
        if sc.endswith("_DR"):
            t1 = "DR"
        else:
            t1 = TIER1_TAXONOMY.get(chosen_lt)
        if not t1:
            # Rescue any RA CIDRs before marking unclassified (v1.8.6)
            ra_c = [c for c in cidrs if cidr_nt.get(c) in _RA_NET_TYPES]
            for c in ra_c:
                nt = cidr_nt[c]
                t2k = nt.replace('-', '_')
                _ao = f'AO-RA-{t2k}-{clean(lm_canon.get(sc) or sc)}'
                _t2 = f'NG-REMOTE-ACCESS-{t2k}'
                t3.setdefault(_ao, set()).add(c)
                t2_children[_t2].add(_ao)
                t1_children['NG-REMOTE-ACCESS'].add(_t2)
            for cidr in [c for c in cidrs if c not in ra_c]:
                unclassified.append([sc, cidr, chosen_lt])
            continue

        # Split mixed SC: RA CIDRs routed to REMOTE-ACCESS tier (v1.8.6)
        if t1 != 'REMOTE-ACCESS':
            ra_c = [c for c in cidrs if cidr_nt.get(c) in _RA_NET_TYPES]
            if ra_c:
                for c in ra_c:
                    nt = cidr_nt[c]
                    t2k = nt.replace('-', '_')
                    _ao = f'AO-RA-{t2k}-{clean(lm_canon.get(sc) or sc)}'
                    _t2 = f'NG-REMOTE-ACCESS-{t2k}'
                    t3.setdefault(_ao, set()).add(c)
                    t2_children[_t2].add(_ao)
                    t1_children['NG-REMOTE-ACCESS'].add(_t2)
                cidrs = [c for c in cidrs if c not in ra_c]
                if not cidrs:
                    continue

        # ---- CLOUD: Tier-2 = provider ----
        if t1 == "CLOUD":
            tok  = sc.split("_")[1] if len(sc.split("_")) > 1 else ""
            prov = CLOUD_PROVIDER_TOKEN.get(tok)
            if not prov:
                rd   = ipam_lt_by_sc.get(sc, "")
                prov = ("AZURE" if "Azure" in rd else "GCP" if "GCP" in rd
                        else "AWS" if "AWS" in rd else "AZURE")
            ao = f"AO-{prov}"
            t2 = f"NG-{prov}"
            for cidr in cidrs:
                t3.setdefault(ao, set()).add(cidr)
            t2_children[t2].add(ao)
            t1_children["NG-CLOUD"].add(t2)
            continue

        # ---- CORPORATE: Tier-2 = state, nested under East/West/Intl region ----
        if t1 == "CORPORATE":
            st = state_from_sitecode(sc)
            if st in args.east:
                region = "EAST"
            elif st in (WEST_OF_MISSISSIPPI - args.east):
                region = "WEST"
            else:
                region = "INTL"
            label    = clean(lm_canon.get(sc) or sc)
            t2_state = f"NG-CORP-{st}"
            ao       = f"AO-CORP-{label}"
            for cidr in cidrs:
                t3.setdefault(ao, set()).add(cidr)
            t2_children[t2_state].add(ao)
            t1_children[f"NG-CORP-{region}"].add(t2_state)
            t1_children["NG-CORPORATE"].add(f"NG-CORP-{region}")
            continue

        # ---- REMOTE-ACCESS: per-CIDR NET_TYPE → Tier-2 subclass (v1.8.6) ----
        if t1 == 'REMOTE-ACCESS':
            for c in list(cidrs):
                nt = cidr_nt.get(c, 'RA-OTHER')
                t2_key = nt.replace('-', '_')
                ao = f'AO-RA-{t2_key}-{clean(lm_canon.get(sc) or sc)}'
                t2 = f'NG-REMOTE-ACCESS-{t2_key}'
                t3.setdefault(ao, set()).add(c)
                t2_children[t2].add(ao)
                t1_children['NG-REMOTE-ACCESS'].add(t2)
            continue

        # ---- named-facility classes: Tier-2 = SITE_CODE ----
        label = clean(lm_canon.get(sc) or sc)
        ao    = f"AO-{t1}-{label}"
        t2    = f"NG-{t1}-{label}"
        for cidr in cidrs:
            t3.setdefault(ao, set()).add(cidr)
        t2_children[t2].add(ao)
        t1_children[f"NG-{t1}"].add(t2)

    # ---- Retail -> /26 NATIVE ADDRESS GROUPS, function x region x state ----
    # v1.2.0: function is read from the SITE_CODE suffix (authoritative:
    #   _RT->PHARMA, _MC->MINUTECLINIC, _OPT->OPTICAL), cross-checked against
    #   retail_networks FACILITY_TYPE (disagreements reported, not resolved).
    # Geography is segmented at TWO co-existing, rule-addressable levels:
    #   region-level  NG-RETAIL-<FUNCTION>-<REGION>   (EAST/WEST of Mississippi)
    #   state-level   NG-RETAIL-<FUNCTION>-<STATE>     (members = /26 objects)
    # The region group's members are the function-matched state groups.
    # All native address-groups; ZERO EDLs. /32 rows collapse to /26.
    retail_state_groups = defaultdict(set)   # NG-RETAIL-<FN>-<ST> -> set of /26 cidrs
    retail_region_members = defaultdict(set)  # NG-RETAIL-<FN>-<REGION> -> set of state-group names
    retail_oversized = []                     # rows broader than /26 (kept, reported)
    retail_dropped_ft = set()                 # FACILITY_TYPE seen but unmapped (e.g. Partner)
    retail_func_disagreements = []            # SITE_CODE suffix vs FACILITY_TYPE mismatches
    retail_unk_region = set()                 # states with no East/West assignment
    if args.retail:
        for r in read_stamped_csv(args.retail):
            sc = r.get("SITE_CODE", "") or ""
            suffix = suffix_from_sitecode(sc)
            fn = RETAIL_SUFFIX_FUNCTION.get(suffix)          # authoritative: SITE_CODE suffix
            ft = r.get("FACILITY_TYPE", "")
            fn_ft = RETAIL_FACILITY_MAP.get(ft)              # cross-check source
            if not fn:
                # SITE_CODE suffix unusable -> fall back to FACILITY_TYPE
                fn = fn_ft
                if not fn:
                    if ft:
                        retail_dropped_ft.add(ft)
                    continue
            elif fn_ft and fn_ft != fn:
                retail_func_disagreements.append((sc, suffix, fn, ft, fn_ft))

            # Retail SITE_CODE layout is US_<STATE>_<STORENUM>_<TYPE>, so the
            # state is the 2nd field (index 1), NOT index 2 (that's the store
            # number). This differs from non-retail SITE_CODEs.
            parts = sc.split("_")
            st = parts[1].upper() if len(parts) >= 2 else ""
            if not st or len(st) != 2:
                st = (r.get("STATES") or "").strip().upper()[:2]
            if not st:
                continue
            region = region_for_state(st)
            if region == "UNK":
                retail_unk_region.add(st)

            canon, aggregated = collapse_to_26(r.get("CIDR", ""))
            if canon is None:
                continue

            state_grp = f"NG-RETAIL-{fn}-{st}"
            retail_state_groups[state_grp].add(canon)
            if region != "UNK":
                region_grp = f"NG-RETAIL-{fn}-{region}"
                retail_region_members[region_grp].add(state_grp)
            if not aggregated and ipaddress.ip_network(canon, strict=False).prefixlen < 26:
                retail_oversized.append((state_grp, canon, sc))

        # Wire the hierarchy: Tier-1 NG-RETAIL -> region groups -> state groups
        for region_grp in retail_region_members:
            t1_children[RETAIL_TIER1].add(region_grp)
        # state groups with no region (UNK) attach directly under Tier-1 so they
        # are not orphaned
        for state_grp in retail_state_groups:
            in_region = any(state_grp in members for members in retail_region_members.values())
            if not in_region:
                t1_children[RETAIL_TIER1].add(state_grp)


    # ── NG-VPN-PARTNERS: VPN partner protected subnets ───────────────────────
    vpn_partner_cidrs = set()
    vpn_t2_children   = {}   # NG-VPN-{SITE} → set of AO names
    vpn_t3            = {}   # AO name → set of CIDRs

    if getattr(args, 'vpn_subs', None) and os.path.exists(args.vpn_subs):
        import csv as _csv
        print(f'Processing VPN partner subnets: {os.path.basename(args.vpn_subs)}')
        with open(args.vpn_subs, newline='', encoding='utf-8-sig') as _f:
            for _row in _csv.DictReader(l for l in _f if not l.startswith('#')):
                _cidr    = (_row.get('IP_NETWORK') or _row.get('CIDR') or '').strip()
                _partner = (_row.get('PARTNER_NAME') or '').strip().replace('/', '_').replace(' ', '-')
                _site    = (_row.get('gateway_site') or '').strip().upper()
                _dir     = (_row.get('direction') or '').strip().upper()
                if not _cidr or not _partner or not _site: continue
                if _dir == 'LOCAL': continue  # CVS-side already in IPAM hierarchy
                _t2 = f'NG-VPN-{_site}'
                _ao = f'AO-VPN-{_site}-{_partner}'
                vpn_t3.setdefault(_ao, set()).add(_cidr)
                vpn_t2_children.setdefault(_t2, set()).add(_ao)
                vpn_partner_cidrs.add(_cidr)
        print(f'  {sum(len(v) for v in vpn_t3.values()):,} VPN partner CIDRs across '
              f'{len(vpn_t2_children)} gateway sites')
    else:
        print('  VPN-PROTECTED-SUBNETS not found — skipping NG-VPN-PARTNERS')

    # ── NG-P2P-PARTNERS: P2P/MPLS partner protected subnets ──────────────────
    p2p_partner_cidrs = set()
    p2p_t2_children   = {}
    p2p_t3            = {}

    if getattr(args, 'p2p_subs', None) and os.path.exists(args.p2p_subs):
        print(f'Processing P2P/MPLS partner subnets: {os.path.basename(args.p2p_subs)}')
        with open(args.p2p_subs, newline='', encoding='utf-8-sig') as _f:
            for _row in _csv.DictReader(l for l in _f if not l.startswith('#')):
                _cidr    = (_row.get('IP_NETWORK') or _row.get('CIDR') or '').strip()
                _partner = (_row.get('PARTNER_NAME') or '').strip().replace('/', '_').replace(' ', '-')
                _site    = (_row.get('gateway_site') or _row.get('GATEWAY_SITE') or '').strip().upper()
                _dir     = (_row.get('direction') or _row.get('DIRECTION') or '').strip().upper()
                _ltype   = (_row.get('link_type') or _row.get('LINK_TYPE') or 'Dedicated').strip()
                if not _cidr or not _partner or not _site: continue
                if _dir == 'LOCAL': continue  # CVS-side already in IPAM hierarchy
                _t2 = f'NG-P2P-{_site}'
                _dir_suffix = 'PARTNER'
                _ao = f'AO-P2P-{_site}-{_partner}-{_dir_suffix}'
                p2p_t3.setdefault(_ao, set()).add(_cidr)
                p2p_t2_children.setdefault(_t2, set()).add(_ao)
                p2p_partner_cidrs.add(_cidr)
        print(f'  {sum(len(v) for v in p2p_t3.values()):,} P2P/MPLS partner CIDRs across '
              f'{len(p2p_t2_children)} gateway sites')
    else:
        print('  P2P-PROTECTED-SUBNETS not found — skipping NG-P2P-PARTNERS')
    print()

    # Wire VPN/P2P into t1_children so dry_run and report see them
    if vpn_t2_children:
        t1_children['NG-VPN-PARTNERS'] = set(vpn_t2_children.keys())
    if p2p_t2_children:
        t1_children['NG-P2P-PARTNERS'] = set(p2p_t2_children.keys())

    if args.dry_run:
        print(json.dumps({
            "dry_run": True,
            "tier1_classes": sorted(t1_children),
            "tier2_groups": len(t2_children),
            "tier3_objects": len(t3),
            "vpn_partner_sites": len(vpn_t2_children),
            "vpn_partner_cidrs": sum(len(v) for v in vpn_t3.values()),
            "p2p_partner_sites": len(p2p_t2_children),
            "p2p_partner_cidrs": sum(len(v) for v in p2p_t3.values()),
            "retail_region_groups": len(retail_region_members),
            "retail_state_groups": len(retail_state_groups),
            "retail_26_objects": len(set().union(*retail_state_groups.values())) if retail_state_groups else 0,
            "retail_oversized_blocks": len(retail_oversized),
            "retail_func_disagreements": len(retail_func_disagreements),
            "retail_unmapped_facility_types": sorted(retail_dropped_ft),
            "retail_states_no_region": sorted(retail_unk_region),
            "reconciliation_rows": len(reconciliation),
            "unclassified_rows": len(unclassified),
            "overlap_high_violations": _high_count,
            "edls_used": 0,
            "tier4_inet_segments": 0,
        }, indent=2))
        return

    os.makedirs(args.out, exist_ok=True)

    # ── Tier-4: load optional internet segments, CPC services, app objects ──
    # These hang off their parent Tier-2 location group in the hierarchy.
    # INET_SEG_* → keyed by SITE_CODE (from internet_segments CSV)
    # CPC SVC_*  → keyed by SITE_CODE derived from IP LPM into all_IP_networks
    # APP_*      → keyed by SITE_CODE from CANONICAL_LOCATION in app objects

    # Build SITE_CODE → Tier-2 group name reverse map for Tier-4 parent lookup
    _sc_to_t2 = {}
    for _t2, _members in t2_children.items():
        # Extract SITE_CODE from Tier-2 name: NG-DC-US-SCO-AZ-DC → US_SCO_AZ_DC
        _parts = _t2.split('-')
        if len(_parts) >= 4:
            # Tier-2 format: NG-<CLASS>-<US>-<CITY>-<STATE>-<TYPE>
            # Site code = US_<CITY>_<STATE>_<TYPE>
            _sc_candidate = '_'.join(_parts[2:])
            _sc_to_t2[_sc_candidate] = _t2

    # Also map canonical location name → Tier-2 for INET segs
    _loc_to_t2 = {}
    for _row in read_stamped_csv(args.ipam):
        _loc = _row.get('CANONICAL_LOCATION', '')
        _sc  = _row.get('SITE_CODE', '')
        if _sc in _sc_to_t2:
            _loc_to_t2[_loc] = _sc_to_t2[_sc]

    tier4_inet  = {}  # seg_name  -> {'parent': t2, 'cidrs': [...],'site_code':sc}
    # ── Tier-4 INET segments ────────────────────────────────────────────────
    if args.inet_segments and os.path.exists(args.inet_segments):
        _inet_rows = read_stamped_csv(args.inet_segments)
        _seg_cidrs = {}
        _seg_meta  = {}
        for _r in _inet_rows:
            _sn  = _r.get('SEGMENT_NAME', '').strip()
            _sc  = _r.get('SITE_CODE', '').strip()
            _loc = _r.get('CANONICAL_LOCATION', '').strip()
            _c   = _r.get('CIDR', '').strip()
            if not _sn or not _c:
                continue
            if _sn not in _seg_cidrs:
                _seg_cidrs[_sn] = []
                _seg_meta[_sn]  = {'site_code': _sc, 'loc': _loc}
            _seg_cidrs[_sn].append(_c)
        for _sn, _cidrs in _seg_cidrs.items():
            _sc  = _seg_meta[_sn]['site_code']
            _loc = _seg_meta[_sn]['loc']
            _t2  = _sc_to_t2.get(_sc) or _loc_to_t2.get(_loc, '')
            tier4_inet[_sn] = {'parent': _t2, 'cidrs': _cidrs, 'site_code': _sc}
        print(f'  Tier-4 INET segments loaded: {len(tier4_inet)} objects, '
              f'{sum(len(v["cidrs"]) for v in tier4_inet.values())} CIDRs')
    else:
        if args.inet_segments:
            print(f'  WARNING: --inet-segments file not found: {args.inet_segments}')

    # Build retail_addr: obj name -> /26 cidr (for .set file emission)
    retail_addr = OrderedDict()
    retail_state_addr_groups = OrderedDict()
    for grp in sorted(retail_state_groups):
        members = []
        for c in sorted(retail_state_groups[grp],
                        key=lambda x: ipaddress.ip_network(x).network_address):
            name = obj_name_for_cidr(c)
            retail_addr[name] = c
            members.append(name)
        retail_state_addr_groups[grp] = members
    retail_region_addr_groups = OrderedDict()
    for grp in sorted(retail_region_members):
        retail_region_addr_groups[grp] = sorted(retail_region_members[grp])

    # flatten Tier-3 into individual address objects
    addr, t3_groups = OrderedDict(), OrderedDict()
    for ao in sorted(t3):
        members = []
        for c in sorted(t3[ao]):
            name = "addr-" + c.replace("/", "_").replace(".", "-")
            addr[name] = c
            members.append(name)
        t3_groups[ao] = members

    out_set = os.path.join(args.out, "ccd_network_groups.set")
    with open(out_set, "w") as f:
        w = f.write
        w(f"# CCD Source Network Groups — 3-tier hierarchical model\n")
        w(f"#VERSION={__version__}\n")
        w(f"#TIER1_SOURCE={args.tier1_source}\n")
        w(f"#IPAM={os.path.basename(args.ipam)}  LM={os.path.basename(args.lm)}"
          f"  RETAIL={os.path.basename(args.retail) if args.retail else 'none'}\n")
        w("# Tier-1=Site-Type/BU  Tier-2=Location  Tier-3=concatenated CIDR object."
          "  CIDRs live ONLY at Tier-3.\n\n")
        w("# ===== TIER-3: address objects =====\n")
        for name, c in addr.items():
            w(f"set address {name} ip-netmask {c}\n")
        w("\n# ===== RETAIL: /26 address objects (collapsed from host rows; NO EDLs) =====\n")
        for name, c in retail_addr.items():
            w(f"set address {name} ip-netmask {c}\n")
        w("\n# ===== TIER-3: location CIDR groups =====\n")
        for ao, m in t3_groups.items():
            w(f"set address-group {ao} static [ " + " ".join(m) + " ]\n")
        w("\n# ===== TIER-2: location breakout =====\n")
        for t2 in sorted(t2_children):
            w(f"set address-group {t2} static [ " + " ".join(sorted(t2_children[t2])) + " ]\n")
        w("\n# ===== RETAIL state-level groups: NG-RETAIL-<FUNCTION>-<STATE> (members = /26 objects) =====\n")
        for g in sorted(retail_state_addr_groups):
            w(f"set address-group {g} static [ " + " ".join(retail_state_addr_groups[g]) + " ]\n")
        w("\n# ===== RETAIL region-level groups: NG-RETAIL-<FUNCTION>-<REGION> (members = state groups) =====\n")
        for g in sorted(retail_region_addr_groups):
            w(f"set address-group {g} static [ " + " ".join(retail_region_addr_groups[g]) + " ]\n")
        w("\n# ===== TIER-1: Site-Type/BU classes =====\n")
        for t1 in sorted(t1_children):
            w(f"set address-group {t1} static [ " + " ".join(sorted(t1_children[t1])) + " ]\n")

        # ── VPN partner groups ─────────────────────────────────────────────
        if vpn_t2_children:
            w("\n# ===== NG-VPN-PARTNERS: VPN IPSec partner subnets =====\n")
            for ao, cidrs in sorted(vpn_t3.items()):
                for c in sorted(cidrs):
                    w(f"set address addr-{c.replace('/','_').replace('.','_')} ip-netmask {c}\n")
            for t2, aos in sorted(vpn_t2_children.items()):
                w(f"set address-group {t2} static [ " + " ".join(sorted(aos)) + " ]\n")
            w("set address-group NG-VPN-PARTNERS static [ " +
              " ".join(sorted(vpn_t2_children.keys())) + " ]\n")

        # ── P2P partner groups ─────────────────────────────────────────────
        if p2p_t2_children:
            w("\n# ===== NG-P2P-PARTNERS: P2P/MPLS dedicated circuit partner subnets =====\n")
            for ao, cidrs in sorted(p2p_t3.items()):
                for c in sorted(cidrs):
                    w(f"set address addr-{c.replace('/','_').replace('.','_')} ip-netmask {c}\n")
            for t2, aos in sorted(p2p_t2_children.items()):
                w(f"set address-group {t2} static [ " + " ".join(sorted(aos)) + " ]\n")
            w("set address-group NG-P2P-PARTNERS static [ " +
              " ".join(sorted(p2p_t2_children.keys())) + " ]\n")

        # ── TIER-4: Internet segments (wired to Tier-2 parent) ────────────
        if tier4_inet:
            w("\n# ===== TIER-4 INET: Internet segment objects (SNAT+EIF) =====\n")
            for seg_name, meta in sorted(tier4_inet.items()):
                for c in meta['cidrs']:
                    aname = "addr-" + c.replace("/","_").replace(".","_")
                    w(f"set address {aname} ip-netmask {c}\n")
            for seg_name, meta in sorted(tier4_inet.items()):
                if not meta['cidrs']:
                    continue
                members = ["addr-" + c.replace("/","_").replace(".","_") for c in meta['cidrs']]
                w(f"set address-group {seg_name} static [ " + " ".join(sorted(members)) + " ]\n")
            inet_segs = [s for s in sorted(tier4_inet) if tier4_inet[s]['cidrs']]
            if inet_segs:
                w(f"set address-group NG-INTERNET-FACING static [ " + " ".join(inet_segs) + " ]\n")


    with open(os.path.join(args.out, "ng_manifest.csv"), "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["Tier1_Class", "Tier2_Location", "Tier3_Object", "CIDR_count"])
        for t1 in sorted(t1_children):
            for t2 in sorted(t1_children[t1]):
                if t2 in t2_children:
                    for ao in sorted(t2_children[t2]):
                        wr.writerow([t1, t2, ao, len(t3.get(ao, []))])
                elif t2 in retail_region_addr_groups:
                    for sgrp in retail_region_addr_groups[t2]:
                        for ao in retail_state_addr_groups.get(sgrp, []):
                            wr.writerow([t1, f"{t2} > {sgrp}", ao, 1])
                elif t2 in retail_state_addr_groups:
                    for ao in retail_state_addr_groups[t2]:
                        wr.writerow([t1, t2, ao, 1])
                else:
                    wr.writerow([t1, t2, "(empty)", "—"])

    with open(os.path.join(args.out, "ng_reconciliation.csv"), "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["SITE_CODE", "CIDR", "all_IP_networks_LOCATION_TYPE", "location_master_LOCATION_TYPE"])
        wr.writerows(reconciliation)

    if unclassified:
        with open(os.path.join(args.out, "ng_unclassified.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["SITE_CODE", "CIDR", "LOCATION_TYPE"])
            wr.writerows(unclassified)


    # ---- INDEPENDENT NETWORK-OBJECT CATALOG (generic, tool-agnostic) ----
    # Schema: TIER, OBJECT_NAME, PARENT, CLASS, MEMBER_TYPE, VALUE, CIDR_COUNT, SOURCE
    catalog = []
    # Tier-1
    # VPN-PARTNERS, P2P-PARTNERS, and INTERNET-FACING are skipped here —
    # they are emitted in their own blocks below with correct CIDR_COUNT values.
    _t1_skip = {'NG-VPN-PARTNERS', 'NG-P2P-PARTNERS', 'NG-INTERNET-FACING'}
    for t1 in sorted(t1_children):
        if t1 in _t1_skip:
            continue
        cls = t1.replace('NG-','')
        catalog.append(dict(TIER=1, OBJECT_NAME=t1, PARENT='', CLASS=cls,
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(t1_children[t1])),
                            CIDR_COUNT='', SOURCE='derived'))
    # Tier-2 (static groups)
    for t2 in sorted(t2_children):
        parent = next((t1 for t1 in t1_children if t2 in t1_children[t1]), '')
        cls = parent.replace('NG-','') if parent else ''
        catalog.append(dict(TIER=2, OBJECT_NAME=t2, PARENT=parent, CLASS=cls,
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(t2_children[t2])),
                            CIDR_COUNT='', SOURCE='static'))
    # Retail region-level groups (members = state groups)
    for g in sorted(retail_region_addr_groups):
        catalog.append(dict(TIER='2-region', OBJECT_NAME=g, PARENT=RETAIL_TIER1,
                            CLASS='RETAIL', MEMBER_TYPE='group',
                            VALUE=';'.join(retail_region_addr_groups[g]),
                            CIDR_COUNT=len(retail_region_addr_groups[g]), SOURCE='static-26'))
    # Retail state-level groups (members = /26 objects)
    for g in sorted(retail_state_addr_groups):
        parent = next((rg for rg in retail_region_addr_groups if g in retail_region_addr_groups[rg]), RETAIL_TIER1)
        catalog.append(dict(TIER='2-state', OBJECT_NAME=g, PARENT=parent, CLASS='RETAIL',
                            MEMBER_TYPE='group', VALUE=';'.join(retail_state_addr_groups[g]),
                            CIDR_COUNT=len(retail_state_addr_groups[g]), SOURCE='static-26'))
    # Tier-3 retail /26 address objects
    for name, c in retail_addr.items():
        parent = next((g for g in retail_state_addr_groups if name in retail_state_addr_groups[g]), '')
        catalog.append(dict(TIER=3, OBJECT_NAME=name, PARENT=parent, CLASS='',
                            MEMBER_TYPE='cidr', VALUE=c, CIDR_COUNT=1, SOURCE='static-26'))
    # Tier-3 (concatenated CIDR objects)
    for ao in sorted(t3):
        parent = next((t2 for t2 in t2_children if ao in t2_children[t2]), '')
        catalog.append(dict(TIER=3, OBJECT_NAME=ao, PARENT=parent, CLASS='',
                            MEMBER_TYPE='cidr-list', VALUE=';'.join(sorted(t3[ao])),
                            CIDR_COUNT=len(t3[ao]), SOURCE='static'))

    # ── VPN partner catalog rows ─────────────────────────────────────────────
    if vpn_t2_children:
        _vpn_total = sum(len(v) for v in vpn_t3.values())
        catalog.append(dict(TIER=1, OBJECT_NAME='NG-VPN-PARTNERS', PARENT='', CLASS='VPN-PARTNERS',
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(vpn_t2_children.keys())),
                            CIDR_COUNT=_vpn_total, SOURCE='vpn-registry'))
        for _t2, _aos in sorted(vpn_t2_children.items()):
            _t2_total = sum(len(vpn_t3.get(_ao, set())) for _ao in _aos)
            catalog.append(dict(TIER=2, OBJECT_NAME=_t2, PARENT='NG-VPN-PARTNERS', CLASS='VPN-PARTNERS',
                                MEMBER_TYPE='group', VALUE=';'.join(sorted(_aos)),
                                CIDR_COUNT=_t2_total, SOURCE='vpn-registry'))
            for _ao in sorted(_aos):
                _cidrs = vpn_t3.get(_ao, set())
                catalog.append(dict(TIER=3, OBJECT_NAME=_ao, PARENT=_t2, CLASS='',
                                    MEMBER_TYPE='cidr-list', VALUE=';'.join(sorted(_cidrs)),
                                    CIDR_COUNT=len(_cidrs), SOURCE='vpn-registry'))

    # ── P2P partner catalog rows ──────────────────────────────────────────────
    if p2p_t2_children:
        _p2p_total = sum(len(v) for v in p2p_t3.values())
        catalog.append(dict(TIER=1, OBJECT_NAME='NG-P2P-PARTNERS', PARENT='', CLASS='P2P-PARTNERS',
                            MEMBER_TYPE='group', VALUE=';'.join(sorted(p2p_t2_children.keys())),
                            CIDR_COUNT=_p2p_total, SOURCE='p2p-registry'))
        for _t2, _aos in sorted(p2p_t2_children.items()):
            _t2_total = sum(len(p2p_t3.get(_ao, set())) for _ao in _aos)
            catalog.append(dict(TIER=2, OBJECT_NAME=_t2, PARENT='NG-P2P-PARTNERS', CLASS='P2P-PARTNERS',
                                MEMBER_TYPE='group', VALUE=';'.join(sorted(_aos)),
                                CIDR_COUNT=_t2_total, SOURCE='p2p-registry'))
            for _ao in sorted(_aos):
                _cidrs = p2p_t3.get(_ao, set())
                catalog.append(dict(TIER=3, OBJECT_NAME=_ao, PARENT=_t2, CLASS='',
                                    MEMBER_TYPE='cidr-list', VALUE=';'.join(sorted(_cidrs)),
                                    CIDR_COUNT=len(_cidrs), SOURCE='p2p-registry'))

    # ── Tier-4: Internet segments — wired to Tier-2 parent location ──────────
    # Each INET_SEG_* is a child of its corresponding Tier-2 location group.
    # Also add the Tier-2 parent as a member of NG-INTERNET-FACING Tier-1.
    inet_t1 = 'NG-INTERNET-FACING'
    if tier4_inet:
        _inet_total = sum(len(meta['cidrs']) for meta in tier4_inet.values())
        catalog.append(dict(TIER=1, OBJECT_NAME=inet_t1, PARENT='', CLASS='INTERNET-FACING',
                            MEMBER_TYPE='group',
                            VALUE=';'.join(sorted(s for s in tier4_inet)),
                            CIDR_COUNT=_inet_total, SOURCE='derived'))
    for seg_name, meta in sorted(tier4_inet.items()):
        # Parent is the Tier-2 location group (already set in loader)
        parent = meta['parent'] or inet_t1
        catalog.append(dict(TIER='4-inet', OBJECT_NAME=seg_name,
                            PARENT=parent, CLASS='INET',
                            MEMBER_TYPE='cidr-list',
                            VALUE=';'.join(sorted(meta['cidrs'])),
                            CIDR_COUNT=len(meta['cidrs']), SOURCE='snat+eif'))

    # ── Tier-4: CPC service objects — NG-SERVICE Tier-1 ────────────────────
    # SVC_* objects hang under NG-SERVICE as a new Tier-1 class.
    # They are also recorded as children of their Tier-2 location if matched.
    import datetime
    stamp = datetime.date.today().strftime('%Y%m%d')
    cat_csv = os.path.join(args.out, f'network_object_catalog_v{stamp}.csv')
    cols = ['TIER','OBJECT_NAME','PARENT','CLASS','MEMBER_TYPE','VALUE','CIDR_COUNT','SOURCE']
    with open(cat_csv,'w',newline='') as f:
        f.write(f'#STEM=network_object_catalog\n#VERSION={stamp}\n#ROWS={len(catalog)}\n')
        f.write(f'#TOOL=build_network_groups.py v{__version__}\n#END_HEADER\n')
        wr=csv.DictWriter(f, fieldnames=cols); wr.writeheader()
        for row in catalog: wr.writerow(row)

    # YAML: hierarchical nesting for human/HTML consumption
    cat_yaml = os.path.join(args.out, f'network_object_catalog_v{stamp}.yaml')
    with open(cat_yaml,'w') as f:
        f.write(f'# network_object_catalog v{stamp}  (generated by build_network_groups.py v{__version__})\n')
        f.write('# 3-tier source network-object hierarchy. CIDRs live only at tier 3.\n')
        f.write(f'version: "{stamp}"\n')
        f.write(f'tool: "build_network_groups.py v{__version__}"\n')
        f.write('tier1_classes:\n')
        for t1 in sorted(t1_children):
            f.write(f'  - name: {t1}\n    class: {t1.replace("NG-","")}\n    tier2:\n')
            for t2 in sorted(t1_children[t1]):
                if t2 in t2_children:
                    f.write(f'      - name: {t2}\n        type: group\n        tier3:\n')
                    for ao in sorted(t2_children[t2]):
                        f.write(f'          - name: {ao}\n            cidr_count: {len(t3.get(ao,[]))}\n')
                        f.write(f'            cidrs: [{", ".join(sorted(t3.get(ao,[])))}]\n')
                elif t2 in retail_region_addr_groups:
                    f.write(f'      - name: {t2}\n        type: region-group\n        states:\n')
                    for sgrp in retail_region_addr_groups[t2]:
                        objs = retail_state_addr_groups.get(sgrp, [])
                        cidrs = [retail_addr[n] for n in objs]
                        f.write(f'          - name: {sgrp}\n            cidr_count: {len(objs)}\n')
                        f.write(f'            cidrs: [{", ".join(cidrs)}]\n')
                elif t2 in retail_state_addr_groups:
                    objs = retail_state_addr_groups[t2]
                    cidrs = [retail_addr[n] for n in objs]
                    f.write(f'      - name: {t2}\n        type: state-group-26\n        cidr_count: {len(objs)}\n')
                    f.write(f'        cidrs: [{", ".join(cidrs)}]\n')


    # Report retail blocks broader than /26 (kept intact) and unmapped facility types
    if retail_oversized:
        with open(os.path.join(args.out, "retail_oversized_blocks.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["GROUP", "CIDR", "SITE_CODE", "NOTE"])
            for grp, c, sc in retail_oversized:
                wr.writerow([grp, c, sc, "broader than /26 - kept as single object, review"])

    # Report SITE_CODE-suffix vs FACILITY_TYPE function disagreements
    if retail_func_disagreements:
        with open(os.path.join(args.out, "retail_function_disagreements.csv"), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(["SITE_CODE", "SUFFIX", "FUNCTION_FROM_SUFFIX", "FACILITY_TYPE", "FUNCTION_FROM_FT", "NOTE"])
            for sc, suf, fn, ft, fn_ft in retail_func_disagreements:
                wr.writerow([sc, suf, fn, ft, fn_ft, "suffix used (authoritative); FACILITY_TYPE disagrees"])

    # Emit the East/West region assignment table actually used, for review
    with open(os.path.join(args.out, "retail_region_assignment.csv"), "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["STATE", "REGION"])
        for st in sorted(EAST_OF_MISSISSIPPI):
            wr.writerow([st, "EAST"])
        for st in sorted(WEST_OF_MISSISSIPPI):
            wr.writerow([st, "WEST"])

    # ── EDL export ──────────────────────────────────────────────────────────
    edl_count = 0
    edl_dir   = None
    if getattr(args, 'edl', False):
        edl_dir = os.path.join(args.out, 'EDL')
        os.makedirs(edl_dir, exist_ok=True)

        # Build Tier-1 and Tier-2 CIDR maps from catalog
        # t1_cidrs[t1_name] = set of all CIDRs under that Tier-1 group
        # t2_cidrs[t2_name] = set of all CIDRs under that Tier-2 group
        t1_cidrs = defaultdict(set)
        t2_cidrs = defaultdict(set)

        for t1, t2_set in t1_children.items():
            for t2 in t2_set:
                # Tier-2 CIDRs from t3_groups
                if t2 in t2_children:
                    for ao in t2_children[t2]:
                        for cidr in t3.get(ao, []):
                            t2_cidrs[t2].add(cidr)
                            t1_cidrs[t1].add(cidr)
                # Retail: state groups -> /26 objects
                elif t2 in retail_region_addr_groups:
                    for sgrp in retail_region_addr_groups[t2]:
                        for obj in retail_state_addr_groups.get(sgrp, []):
                            cidr = retail_addr.get(obj, '')
                            if cidr:
                                t2_cidrs[t2].add(cidr)
                                t1_cidrs[t1].add(cidr)
                elif t2 in retail_state_addr_groups:
                    for obj in retail_state_addr_groups[t2]:
                        cidr = retail_addr.get(obj, '')
                        if cidr:
                            t2_cidrs[t2].add(cidr)
                            t1_cidrs[t1].add(cidr)

        # VPN/P2P partner groups
        for t2, ao_set in vpn_t2_children.items():
            for ao in ao_set:
                for cidr in vpn_t3.get(ao, []):
                    t2_cidrs[t2].add(cidr)
                    t1_cidrs['NG-VPN-PARTNERS'].add(cidr)
        for t2, ao_set in p2p_t2_children.items():
            for ao in ao_set:
                for cidr in p2p_t3.get(ao, []):
                    t2_cidrs[t2].add(cidr)
                    t1_cidrs['NG-P2P-PARTNERS'].add(cidr)

        # INET segments — Tier-2 scoped
        for seg_name, meta in tier4_inet.items():
            parent = meta.get('parent', '')
            for cidr in meta.get('cidrs', []):
                if parent:
                    t2_cidrs[parent].add(cidr)
                    # Find Tier-1 parent of this Tier-2
                    for t1, t2s in t1_children.items():
                        if parent in t2s:
                            t1_cidrs[t1].add(cidr)
                            break

        # Write Tier-1 EDLs
        for t1_name, cidrs in sorted(t1_cidrs.items()):
            if not cidrs:
                continue
            write_edl(t1_name, cidrs, edl_dir,
                      metadata={'Tier': '1', 'Class': t1_name.replace('NG-', '')})
            edl_count += 1

        # Write Tier-2 EDLs (site-level groups — skip retail state groups, too many)
        SKIP_TIER2_PREFIXES = ('NG-RETAIL-', 'NG-MINUTECLINIC-', 'NG-OPTICAL-')
        for t2_name, cidrs in sorted(t2_cidrs.items()):
            if not cidrs:
                continue
            if any(t2_name.startswith(p) for p in SKIP_TIER2_PREFIXES):
                continue  # retail /26 groups — too granular for EDL
            write_edl(t2_name, cidrs, edl_dir, metadata={'Tier': '2'})
            edl_count += 1

        # Write Tier-3 EDLs (address objects — one per site)
        # t3_groups values are addr-* object names; resolve to CIDRs via addr dict
        for t3_name, members in sorted(t3_groups.items()):
            if not members:
                continue
            cidrs = [addr[m] for m in members if m in addr]
            if not cidrs:
                continue
            write_edl(t3_name, cidrs, edl_dir, metadata={'Tier': '3'})
            edl_count += 1

        print(f'\nEDL export: {edl_count} files written to {edl_dir}/')

    print(json.dumps({
        "version": __version__,
        "tier1_classes": len(t1_children),
        "tier2_groups": len(t2_children),
        "tier3_objects": len(t3_groups),
        "address_objects": len(addr),
        "retail_region_groups": len(retail_region_addr_groups),
        "retail_state_groups": len(retail_state_addr_groups),
        "retail_26_objects": len(retail_addr),
        "retail_oversized_blocks": len(retail_oversized),
        "retail_func_disagreements": len(retail_func_disagreements),
        "retail_unmapped_facility_types": sorted(retail_dropped_ft),
        "retail_states_no_region": sorted(retail_unk_region),
        "edls_used": edl_count,
        "reconciliation_rows": len(reconciliation),
        "unclassified_rows": len(unclassified),
        "overlap_high_violations": _high_count,
        "tier4_inet_segments": len(tier4_inet),
        "output_set": out_set,
        "catalog_csv": cat_csv,
        "catalog_yaml": cat_yaml,
        "edl_dir": edl_dir,
    }, indent=2))


def write_edl(group_name, cidrs, edl_dir, metadata=None):
    """Write a single PA EDL .txt file for group_name with the given CIDRs.

    Format:
        # <GROUP_NAME>
        # Export Date: YYYY-MM-DD
        # Source: CCD Platform build_network_groups.py vX.Y.Z
        # Subnets: N
        # <key>: <value>   (optional metadata lines)
        #
        <cidr>
        <cidr>
        ...
    """
    import datetime
    fname = group_name.replace('/', '_') + '.txt'
    path  = os.path.join(edl_dir, fname)

    # v1.8.8 — BUG FIX: sorted(cidrs, key=lambda c: ipaddress.ip_network(...))
    # crashed the entire pipeline on a single malformed CIDR anywhere in the
    # input — confirmed live: an upstream FMC object literally named
    # 'OBJ-10.218.116.691' (a real one-digit typo in CVS's own source data)
    # propagated through to here and aborted Stage 1 outright. Filter out
    # anything malformed first (with a warning) instead of letting one bad
    # value take down the whole run — defense in depth on top of the fix at
    # the actual data source (extract_partner_subnets_from_rule_db.py
    # v1.0.4), since this writer has no way to know whether some other
    # future input source is equally clean.
    valid_cidrs = []
    skipped = []
    for c in cidrs:
        try:
            ipaddress.ip_network(c, strict=False)
            valid_cidrs.append(c)
        except ValueError:
            skipped.append(c)
    if skipped:
        print(f'  WARNING: {group_name} — skipping {len(skipped)} malformed '
              f'CIDR(s): {skipped[:5]}{"..." if len(skipped) > 5 else ""}')

    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# {group_name}\n')
        f.write(f'# Export Date: {datetime.date.today().isoformat()}\n')
        f.write(f'# Source: CCD Platform build_network_groups.py v{__version__}\n')
        f.write(f'# Subnets: {len(valid_cidrs)}\n')
        if metadata:
            for k, v in metadata.items():
                f.write(f'# {k}: {v}\n')
        f.write('#\n')
        for cidr in sorted(valid_cidrs, key=lambda c: ipaddress.ip_network(c, strict=False)):
            f.write(f'{cidr}\n')
    return path


def main():
    ap = argparse.ArgumentParser(description="Generate 3-tier PAN-OS source network-group hierarchy from CCD IPAM datasets.")
    ap.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    ap.add_argument("--ipam", default=None, help="all_IP_networks CSV (auto-discovered if omitted)")
    ap.add_argument("--lm", default=None, help="location_master CSV (auto-discovered if omitted)")
    ap.add_argument("--retail", help="retail_networks CSV (emits native /26 address groups, no EDLs)")
    ap.add_argument("--out", default=None, help="output directory (default: ./Net_Group/NG-YYYYMMDD_v<N>)")
    ap.add_argument("--edl-host", default="https://<edl-host>/ccd", help="(reserved; retail no longer uses EDLs as of v1.1.0)")
    ap.add_argument("--edl", action="store_true",
                    help="Export PA EDL .txt files (one per Tier-1 and Tier-2 group) into <out>/edl/")
    ap.add_argument("--tier1-source", choices=["lm", "ipam"], default="lm",
                    help="authoritative source for Tier-1 LOCATION_TYPE (default: lm)")
    ap.add_argument("--east", help="comma-separated state list for East region (overrides default Mississippi split)")
    ap.add_argument("--base", default=".", help="CCD Platform root directory for auto-discovery (default: .)")
    ap.add_argument("--dry-run", action="store_true", help="report counts without writing files")
    ap.add_argument("--inet-segments", default=None,
                    help="internet_segments CSV from build_internet_segments.py")
    args = ap.parse_args()
    args.east = set(args.east.split(",")) if args.east else EAST_OF_MISSISSIPPI

    # ── Output directory: versioned Net_Group/NG-YYYYMMDD_vN ────────────────
    if args.out is None:
        import datetime
        _base_dir = './Net_Group'
        _date_str = datetime.date.today().strftime('%Y%m%d')
        _base_name = f'NG-{_date_str}'
        # Find next available revision suffix
        _rev = 1
        if os.path.isdir(_base_dir):
            import re as _re
            _existing = [d for d in os.listdir(_base_dir)
                         if _re.match(rf'^{_base_name}_v\d+$', d)]
            if _existing:
                _nums = [int(_re.search(r'_v(\d+)$', d).group(1)) for d in _existing]
                _rev = max(_nums) + 1
        args.out = os.path.join(_base_dir, f'{_base_name}_v{_rev}')

    # ── File discovery ──────────────────────────────────────────────────────
    print("Input files:")
    disc = discover_inputs(args.base)
    args.ipam          = resolve_input(args.ipam,          disc["ipam"],          "all_IP_networks",  required=True)
    args.lm            = resolve_input(args.lm,            disc["lm"],            "location_master",  required=True)
    args.retail        = resolve_input(args.retail,        disc["retail"],        "retail_networks",  required=False)
    args.inet_segments = resolve_input(args.inet_segments, disc["inet_segments"], "inet_segments",    required=False)
    # VPN/P2P: auto-discover from ipam-db
    args.vpn_subs = resolve_input(None, disc.get("vpn_subs"), "vpn_protected_subnets", required=False)
    args.p2p_subs = resolve_input(None, disc.get("p2p_subs"), "p2p_protected_subnets", required=False)
    print()

    build(args)


if __name__ == "__main__":
    main()
