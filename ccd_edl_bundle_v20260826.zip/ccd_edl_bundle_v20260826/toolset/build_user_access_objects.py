#!/usr/bin/env python3
"""
build_user_access_objects.py  v1.8.1
CCD Platform — User Access Object Library Builder
CVS Health Information Security

Builds USER_ACCESS_Objects from:
  1. all_IP_networks WHERE NET_TYPE IN (User-Access-VDI, User-Access-VPN,
     User-Access-Wired, User-Access-WLAN, RA-POOL-CSA, RA-SNAT-HCB)
     → Subnet objects grouped by NET_TYPE × heritage × site
  2. ent_host_master WHERE hostname matches CITRIX-VDI patterns
     → Host objects grouped by Citrix site
  3. ent-ipdataset-ZPA-CONNECTOR-REGISTRY (host-based, real /32 addresses)
     → USER-ACCESS-ZPA-* objects. NOTE: ZPA-CONNECTOR / RA-CONN-ZPA are
     deliberately NOT processed via the subnet-tag path above — moved to
     this registry-based path in v1.5.0 after subnet tagging was found to
     miss 41 of 107 real connector devices. See USER_ACCESS_SUPERSEDED_NET_TYPES.

Per-site/heritage objects from sources 1-3 are intermediate, not the final
deliverable — the point of this builder is FW-rule-usable SRC objects, so
v1.8.0 added a consolidation pass: every VDI-* object (plus Citrix) merges
into one USER-ACCESS-VDI-ALL, and every VPN-* object merges into one
USER-ACCESS-VPN-ALL. WLAN/WIRED consolidation exists in the reference
build but isn't implemented here yet — see v1.8.0 changelog note.

These are SOURCE objects in firewall rules:
  src=USER-ACCESS-VDI-PBM-SHEA   dst=APP-RXCONNECT     port=443
  src=USER-ACCESS-CITRIX-HCB-MDC dst=APP-HEALTHRULES   port=443
  src=USER-ACCESS-VPN-HCB-WDC    dst=APP-CLAIMSCENTRAL port=443

Output:
  processed_outputs/canonical_user_access_objects_vDATE.csv

Usage:
  python3 build_user_access_objects.py --dry-run
  python3 build_user_access_objects.py
  python3 ipam-db.py --import processed_outputs/canonical_user_access_objects_vDATE.csv \
      --type CANONICAL-USER-ACCESS-OBJECTS

Changelog:
  v1.7.0  2026-07-08  PBM-Northeast (633) and PBM-Southeast (739) — the two
                      LAN regions still over the ~500 threshold after v1.6.0
                      — now bin-packed by state into 2 balanced sub-objects
                      each (NE-1/NE-2, SE-1/SE-2), greedy-assigned to
                      balance collapsed CIDR count. Written as a general
                      post-process (any (heritage, region) group over
                      threshold gets split, not hardcoded to these two
                      specifically) so a future data change that pushes
                      another region over doesn't need a repeat fix.
                      Result: NE-1 349, NE-2 337, SE-1 389, SE-2 382 — all
                      comfortably under 500. All 18 LAN objects now clear
                      the threshold.
  v1.6.0  2026-07-08  USER_ACCESS_LAN split from 2 heritage-only objects
                      (PBM 2,513 CIDRs, HCB 690 — unusable as FW SRC
                      objects) into heritage+REGION objects. Not a
                      compression bug — LAN genuinely covers 230+ distinct
                      physical locations nationwide, so no CIDR-math trick
                      meaningfully shrinks one giant object; the fix is
                      splitting into multiple smaller ones. 14 of 16
                      resulting objects land under ~500 entries.
                      PBM-Northeast (677) and PBM-Southeast (746) are still
                      over — logged honestly, not silently claimed fixed;
                      would need a further per-state split to close.
                      REGION sourced from location_master (new optional
                      input, --ipam-dir) — genuinely load-bearing this
                      time, unlike the LOCATION_TYPE join removed earlier
                      this session, since REGION isn't in all_IP_networks
                      at all.
  v1.5.0  2026-07-08  Two structural fixes, both confirmed by the platform
                      owner as real modeling errors, not just data gaps:
                        1. ZPA moved from subnet-based (NET_TYPE=RA-CONN-ZPA
                           IPAM tags) to host-based /32 addresses read
                           directly from ent-ipdataset-ZPA-CONNECTOR-REGISTRY.
                           Root cause of the earlier 41/107-device gap:
                           subnet-based tracking depends on IPAM subnet
                           tagging keeping pace with actual device
                           deployment, and it hadn't. The registry is the
                           authoritative host-level source — same reasoning
                           Citrix already used (EHM host data, not a subnet
                           tag). NETSCALER-LV cluster excluded — confirmed
                           to be Citrix NetScaler Gateway devices bundled
                           into the same registry file, not ZPA.
                        2. Citrix consolidated from 15 per-site objects
                           (4,687 raw /32 hosts total — unusable as a
                           firewall SRC object) into ONE object,
                           USER-ACCESS-CITRIX-OPTIMIZED, summarized to a
                           /24 ceiling (every /24 with >=1 real host becomes
                           one CIDR entry, never collapsed coarser than /24).
                           Real host list preserved in MEMBER_IPS for
                           audit/traceability; SUBNET_CIDRS (the /24-ceiling
                           list) is what the EDL export uses.
                      Also fixed while implementing the above: MEMBER_IPS
                      and EDL file output were both sorting IPs/CIDRs as
                      raw strings (lexicographic — 10.40.x before 10.6.x),
                      not numeric IP order. Fixed everywhere.
  v1.4.0  2026-07-08  Split RA-SNAT-HCB into its own USER_ACCESS_SNAT class,
                      out of USER_ACCESS_VPN. These were conflated since
                      v1.1.0 — both "Cisco RA VPN"-adjacent, but RA-POOL-CSA
                      is a client-assigned address pool while RA-SNAT-HCB is
                      a SNAT translation pool, functionally different in a
                      firewall rule (client source range vs. NAT'd source
                      range). Previously distinguished only by a heritage
                      tag in the object name (USER-ACCESS-VPN-HCB-* vs
                      USER-ACCESS-VPN-PBM-*); now genuinely separate object
                      classes. Flagged as an open item 2026-07-07, resolved
                      here. USER_ACCESS_VPN now covers User-Access-VPN
                      (legacy) + RA-POOL-CSA only.
  v1.3.0  2026-07-08  Real EDL export added. Previously canonical_user_access_objects
                      only lived as a flat CSV in processed_outputs/, so the
                      EDL catalog web UI could list objects but never had an
                      actual .txt file to serve for preview/download — "0 EDL
                      files" was correct but meant the objects weren't truly
                      usable yet, not just unlisted. Now also writes a versioned
                      Net_Object/UA-YYYYMMDD_vN/ directory (same pattern as
                      build_service_objects.py's SO-YYYYMMDD_vN/) containing
                      the catalog CSV plus one real EDL/*.txt per object
                      (subnet-based objects get SUBNET_CIDRS; Citrix gets
                      MEMBER_IPS as /32s). processed_outputs/ write is
                      unchanged for ipam-db.py --import compatibility — this
                      is additive, not a replacement.
  v1.2.0  2026-07-07  Added USER_ACCESS_LAN — "User Networks" SOURCE objects
                      (src=USER-ACCESS-LAN-PBM-RIONE dst=APP-X port=443).
                      Selection: NET_TYPE in {Corporate, Omnicare, Distribution,
                      Specialty, CVS-CallCenter, AETNA-CallCenter, Call-Center,
                      Partner-CallCenter, CarePlus, Mail-Order, Partner,
                      Guest-Wireless}, LOCATION_TYPE not in {DataCenter, COLO,
                      Cloud, DR} — both read directly off the all_IP_networks
                      row, no location_master join. Citrix VDI unaffected
                      (separate EHM-sourced object family, not in this filter).
  v1.1.0  2026-07-07  Two bugs fixed, found while building prefix-optimized
                      network objects for Cisco RA VPN / ZPA / VDI users:
                        1. USER_ACCESS_NET_TYPES was stale. IPAM reclassified
                           User-Access-VPN -> RA-POOL-CSA / RA-SNAT-HCB and
                           ZPA-Connector -> RA-CONN-ZPA some time ago; this
                           script was never updated to match. Result: all 24
                           Cisco RA VPN pool subnets (15 RA-POOL-CSA + 9
                           RA-SNAT-HCB) and all 4 RA-CONN-ZPA connector
                           subnets were being silently dropped -- the exact
                           same failure pattern independently found and
                           fixed in build_service_objects.py v1.1.0/v1.2.0.
                           Added RA-POOL-CSA, RA-SNAT-HCB, RA-CONN-ZPA to
                           USER_ACCESS_NET_TYPES; legacy User-Access-VPN and
                           ZPA-CONNECTOR left in place (User-Access-VPN
                           still has 23 legitimate unreclassified rows).
                        2. SUBNET_CIDRS was never collapsed -- raw CIDRs
                           were joined as-is, including cases where IPAM
                           legitimately registers both a summary block and
                           a contained child subnet as separate Authoritative
                           rows (e.g. 10.176.0.0/21 and 10.176.0.0/24 at the
                           same site -- confirmed not a data error, both
                           rows fully consistent, likely route-level vs
                           VLAN-level NMS discovery of the same address
                           space). CanonicalObject now collapses
                           subnet_cidrs via ipaddress.collapse_addresses()
                           at serialization time. Observed reduction on
                           real data: 33-86% fewer CIDRs per object
                           depending on how sequential the original
                           allocation was.
                      Also added: unmapped-NET_TYPE audit, printed in the
                      run summary -- any all_IP_networks row whose NET_TYPE
                      looks access-related (contains RA-/ZPA/VPN/VDI/ACCESS)
                      but isn't in USER_ACCESS_NET_TYPES gets counted and
                      named, so the next taxonomy rename is visible on the
                      first run instead of requiring a multi-session debug.
                      No output schema change.
  v1.0.1  2026-06-15  Fixed output filename: canonical_user_access_objects_20260615.csv
                      → canonical_user_access_objects_v20260615.csv (missing v prefix).
                      Also fixed #VERSION= header to include v prefix. Consistent with
                      CCD Platform versioning convention (vYYYYMMDD).
  v1.0.0  2026-06-15  Extracted from build_canonical_app_objects.py v1.7.2.
                      Standalone script — separate refresh cycle from app objects.
"""

import argparse
import csv
import glob
import ipaddress
import os
import re
import sys
from datetime import datetime
from collections import defaultdict

VERSION    = "v1.8.1"
# v1.8.1 2026-07-09  Resolved the bare 'VPN' NET_TYPE gap flagged in v1.8.0
#          (64 rows, previously just an unmapped-type audit warning every
#          run). Confirmed via direct data check: ROUTING_DOMAIN=Partner,
#          HERITAGE=CVS, CANONICAL_LOCATION='Offshore - Contractor' — this
#          is offshore contractor/partner circuit connectivity, NOT a
#          synonym for User-Access-VPN. Added to
#          USER_ACCESS_SUPERSEDED_NET_TYPES (silences the false-alarm
#          audit) rather than USER_ACCESS_NET_TYPES — folding it into
#          USER-ACCESS-VPN-ALL would have silently blended a partner
#          population into the CVS/Aetna employee-access object, and
#          _her_tag() would have misclassified it as PBM in the process
#          (checks 'PBM' in rd first — false — then falls through to 'CVS'
#          in her — true). Belongs in the Partner-NG/B2B-VPN pipeline
#          instead, not USER_ACCESS_Objects at any level.
# v1.8.0 2026-07-09  Added VDI-ALL and VPN-ALL consolidation passes — the
#          per-site objects were always meant to be intermediate, not the
#          FW-usable deliverable. USER-ACCESS-VDI-ALL merges all VDI-* +
#          CITRIX-OPTIMIZED (7 sources, matches confirmed reference build).
#          USER-ACCESS-VPN-ALL merges all VPN-* (14 sources, matches
#          confirmed reference build exactly — does NOT include the still-
#          unmapped bare 'VPN' NET_TYPE, a separate open gap). WLAN/WIRED
#          consolidation (WLAN-HCB, WLAN-PBM-SHEA per the 2026-07-08
#          reference build) intentionally NOT yet implemented here — that
#          pattern folds in a specific site (RIONE stays separate, RI2100
#          merges into SHEA) that wasn't confirmed as a general rule vs. a
#          one-off judgment call; needs confirmation before hard-coding.
# v1.7.1 2026-07-09  Fixed real bug: add_member() accepted any non-empty
#          string with zero validation, then to_dict()'s unguarded
#          ipaddress.ip_address() call crashed the ENTIRE build (not just
#          skipped the bad row) on the first malformed IP encountered —
#          inconsistent with _collapse_cidrs()'s existing graceful-skip
#          pattern elsewhere in this file. add_member() now validates and
#          silently skips invalid entries the same way. Also corrected the
#          top-of-file and build_user_access_objects() docstrings, which
#          still described ZPA-CONNECTOR as processed via the subnet-tag
#          path — that moved to the host-based connector registry in
#          v1.5.0, but the docstrings were never updated to match.
# v1.2.0 2026-07-07  Added USER_ACCESS_LAN builder — see docstring changelog.
BUILD_DATE = datetime.now().strftime("%Y%m%d")

# ANSI
BLD = "\033[1m"; GRN = "\033[0;32m"; YEL = "\033[0;33m"
RED = "\033[0;31m"; RST = "\033[0m"

OUTPUT_STEM = "canonical_user_access_objects"
FIELDNAMES  = [
    "OBJECT_NAME", "OBJECT_TYPE", "OBJECT_CLASS", "APP_ACRONYM",
    "SERVICE_ROLE", "HERITAGE", "ROUTING_DOMAIN",
    "MEMBER_IPS", "VIP_IPS", "SUBNET_CIDRS", "LOCATIONS",
    "MEMBER_COUNT", "VIP_COUNT", "SOURCE_DATASETS", "DATASET_VERSION",
    "APP_ARCHITECTURE", "ROLE_MAP", "SNAT_IPS", "SNAT_COUNT",
    "PORT_DEPS", "SERVER_PORTS", "CLIENT_PORTS", "SERVICE_DEPS",
    "PCI_SCOPE", "CRITICALITY", "NON_PROD",
]

LOC_CODE_MAP = {
    # Primary DCs
    "Scottsdale AZ - Shea DC":              "SHEA",
    "Woonsocket RI - RI One":               "RIONE",
    "Woonsocket RI - Corporate":            "RIONE",      # same campus
    "Cumberland RI - 2100 Highland":        "RI2100",
    "Cumberland RI - Corporate":            "RI2100",
    "Middletown CT - Aetna MDC":            "MDC",
    "Windsor CT - Aetna WDC":              "WDC",
    "Phoenix AZ - Aetna DC":               "PHX",
    "Las Vegas NV - Switch Colo":           "LV",
    "Las Vegas NV - Switch DC":             "LV",
    "Atlanta GA - Switch Colo":             "ATL",
    "Atlanta GA - Switch COLO":             "ATL",        # casing variant
    "Atlanta GA - Aetna DC":               "ATL_AETNA",
    "Sparks NV - Switch TRE":              "TRE",
    # Corporate / Call-Center
    "Linthicum MD - Corporate":             "LINTHICUM",
    "Hartford CT - Corporate":             "HARTFORD",
    "Hartford CT - Aetna HQ":             "HARTFORD",
    "Richardson TX - Call Center":          "RIC",
    "Columbia MD - Corporate":              "COLUMBIA",
    "Charlotte NC - Corporate":             "CLT",
    "Buffalo Grove IL - Corporate":         "BUFFGRV",
    "Mount Prospect IL - Corporate":        "MTPROSPECT",
    "Denver CO - Corporate":               "DENVER",
    "Philadelphia PA - Corporate":          "PHL",
    "Watertown MA - Retail DR":             "WATERTOWN",
    # Distribution / Specialty / Other
    "Lumberton NJ - Distribution Center":  "LUMBERTON",
    "Flower Mound TX - Spinks Rd":         "FLOWERMND",
    "Tolleson AZ - Distribution Center":   "TOLLESON",
    "Kapolei HI - Distribution Center":    "KAPOLEI",
    "Indianapolis IN - Omnicare":           "INDY",
    "Orlando FL - Specialty":              "ORLANDO",
    "Wilkes Barre PA - Mail Order":        "WILKESBARRE",
    "San Antonio TX - Corporate":          "SANANTONIO",
    "Knoxville TN - Corporate":            "KNOXVILLE",
    "Pittsburgh PA - Corporate":           "PITTSBURGH",
    # Additional on-prem sites
    "San Antonio TX - Mail Order":         "SANANTONIO_MO",
    "Knoxville TN - Distribution Center":  "KNOXVILLE_DC",
    "Atlanta GA - Specialty":             "ATL_SPEC",
    "Carlstadt NJ - SunGard DR":          "CARLSTADT",
    "Orlando FL - Corporate":             "ORLANDO_CORP",
    "Cloud - AWS US-East1":               "AWS_USE1",
    # Cloud
    "Cloud - GCP US-East4":                "GCP_USE4",
    "Cloud - GCP US-West2":                "GCP_USW2",
    "Cloud - GCP CVS West US 2":           "GCP_USW2",
    "Cloud - Azure East US 2":             "AZ_USE2",
    "Cloud - Azure Central US":            "AZ_USC",
    "Cloud - Azure CVS East US 2":         "AZ_CVS_USE2",
    "Cloud - Azure CVS Central US":        "AZ_CVS_USC",
    "Cloud - Azure CVS":                   "AZ_CVS",
    "Cloud - Azure CVS West US":           "AZ_CVS_USW",
    "Cloud - Azure Aetna East US 2":       "AZ_HCB_USE2",
    "Cloud - Azure UE2 - SecureHub":       "AZ_SECHUB",
    "Cloud - AWS US-East1":                "AWS_USE1",
    "Cloud - GCP US-East4 - CVS":          "GCP_USE4",
    "Cloud - GCP US-East4 - Aetna":        "GCP_USE4_HCB",
}

def find_file(directory, glob_pattern):
    """Find first matching file in directory."""
    matches = sorted(glob.glob(os.path.join(directory, glob_pattern)), reverse=True)
    if not matches:
        return None
    return matches[0]


def nan_to_none(val):
    """Treat empty/nan strings as None."""
    if val is None:
        return None
    v = str(val).strip()
    if v.lower() in ('', 'nan', 'none', 'null'):
        return None
    return v

# ---------------------------------------------------------------------------
# IPAM LPM lookup (for SUBNET_CIDRS enrichment)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Shared Server Detection — absorbed from build_shared_server_registry.py v1.1.1
# Detects IPs hosting multiple applications and classifies them into
# DELIVERY_* groups for the shared server registry.
# ---------------------------------------------------------------------------

_SHARED_PLATFORM_TYPES = {'SHARED-SERVER', 'SHARED-PLATFORM', 'CONTAINER-BRIDGE'}

_DB_ACRONYMS = {'DB2DBE','ORADBE','SQLDBE','MSSQLDBE','MYSQLDBE','PGDBE',
                'POSTGREDBE','SYBDBE','CASSDBE','MONGODBE','ELASTICDBE'}
_MW_ACRONYMS = {'MQUE','IBMMQ','MQSERIES','ACE','ACEINTEGRATION',
                'INFRASTRUCTUREMIDDLEWARET','WEBSPHR','JBOSS','TOMCAT',
                'CVSESL','ESL','MULE','TIBCO','KAFKA'}

_DELIVERY_HOSTNAME_RULES = [
    (r'^XML(EDH|DB|IO|DT|HR)',      'DELIVERY_EDH',            'DELIVERY_EDH_'),
    (r'^XIIB',                       'DELIVERY_IIB',            'DELIVERY_IIB_'),
    (r'^XACE',                       'DELIVERY_ACE',            'DELIVERY_ACE_'),
    (r'^PAC4DB2',                    'DELIVERY_DB_COLO',        'DELIVERY_DB_COLO_'),
    (r'^X\w+DB2',                   'DELIVERY_DB',             'DELIVERY_DB_'),
    (r'^X\w+ORACL',                 'DELIVERY_DB',             'DELIVERY_DB_'),
    (r'^XMQCLS',                     'DELIVERY_MQ',             'DELIVERY_MQ_'),
    (r'^XWAS[MW]',                   'DELIVERY_WAS',            'DELIVERY_WAS_'),
    (r'^XIFSAP',                     'DELIVERY_SAP',            'DELIVERY_SAP_'),
    (r'^XIWEB',                      'DELIVERY_WEB',            'DELIVERY_WEB_'),
]

_DELIVERY_PLATFORM_TYPE_RULES = {
    'CONTAINER-BRIDGE': ('DELIVERY_CONTAINER_HOST', 'DELIVERY_CONTAINER_HOST_'),
    'SHARED-PLATFORM':  ('DELIVERY_SHARED_PLATFORM', 'DELIVERY_SHARED_PLATFORM_'),
}



def read_ccd_csv(path):
    """Read CCD-format CSV, skipping # comment header lines."""
    rows = []
    headers = None
    with open(path, newline='', encoding='utf-8-sig') as f:
        for line in f:
            if line.startswith('#'):
                continue
            if headers is None:
                reader = csv.DictReader([line] + list(f))
                return list(reader)
            break
    return rows


def loc_code(canonical_location):
    """Return short location code for object naming."""
    if not isinstance(canonical_location, str):
        return "UNKNOWN"
    return LOC_CODE_MAP.get(canonical_location,
           re.sub(r'[^A-Z0-9]', '_', canonical_location.upper())[:12])

# ---------------------------------------------------------------------------
# INFRA classification — delivery_infrastructure
# ---------------------------------------------------------------------------
# Key: (SERVER_CLASS, APP_ACRONYMS_first_token) → infra_platform string
# Used to assign INFRA vs SERVICE/DELIVERY vs skip

# SERVER_CLASS → INFRA platform type
INFRA_SERVER_CLASS_MAP = {
    "ESX Server":          "ESXI",
    "IBM HMC Server":      "IBM_HMC",
    "Ibm Hmc Server":      "IBM_HMC",
    "IBM iSeries LPAR":    "IBM_ISERIES",
    "IBM Mainframe":       "IBM_MF",
    "IBM Mainframe LPAR":  "IBM_MF",
    "Ibm Mainframe Lpar":  "IBM_MF",
    "IBM zOS server":      "IBM_ZOS",
    "Linux Server":        None,   # needs APP_ACRONYMS to disambiguate
    "Windows Server":      None,
    "AIX Server":          None,
    "Hyper-V Server":      "HYPERV",
    "Network Appliance Hardware": "NAS",
}

# APP_ACRONYMS that indicate this row IS the infrastructure (INFRA_Object)
INFRA_ACRONYM_SET = {
    "ESXSystems", "ESXSystemsHCB", "ESXPCI", "ESXSystemsHCBPCI",
    "HMCSystemsCVS", "HMCSystemsPCICVS", "HMCSystemsRXConnect",
    "ESXVMW",    # ESXi VMware mgmt hosts — Windows SERVER_CLASS, AETNA/HCB
    "FMF",       # File Master for Mainframes — mainframe utility, not an app workload
    # ── Database engine acronyms — infra, not app workloads ──────────────────
    "DB2DBE",    # IBM DB2 database engine
    "ORADBE",    # Oracle database engine
    "SQLDBE",    # SQL Server database engine
    "MSSQLDBE",  # MS SQL Server database engine
    "MYSQLDBE",  # MySQL database engine
    "PGDBE",     # PostgreSQL database engine
    "POSTGREDBE",# PostgreSQL variant
    "SYBDBE",    # Sybase database engine
    "CASSDBE",   # Cassandra
    "MONGODBE",  # MongoDB
    "ELASTICDBE",# Elasticsearch
    # ── Middleware / messaging / ESB acronyms ─────────────────────────────────
    "MQue",      # IBM MQ
    "IBMMQ",     # IBM MQ variant
    "MQSERIES",  # IBM MQ Series
    "ACE",       # IBM App Connect Enterprise
    "CVSESL",    # CVS ESL integration bus
    "ACEINTEGRATION",  # ACE integration
}

# APP_ACRONYMS → canonical SERVICE_Object name
SERVICE_ACRONYM_MAP = {
    "VCENTER":          "SVC_VCENTER_CVS",
    "VCenterHCB":       "SVC_VCENTER_HCB",
    "VmwareVra":        "SVC_VMWARE_VRA",
    "Vmware":           "SVC_VMWARE_HCX",   # HCX appliances
    "NetBackup":        "SVC_NETBACKUP",
    "MFInfraSoftware":  "SVC_MF_INFRA",
    "MFSTORAGE":        "SVC_MF_STORAGE",
    "FileServersIsilon":"SVC_ISILON",
    "FMF":              "SVC_MF_INFRA",     # File Master for Mainframes → mainframe infra
    # ── Database engine acronyms → granular INFRA_DB service objects ─────────
    "DB2DBE":           "SVC_INFRA_DB2_ENGINE",
    "ORADBE":           "SVC_INFRA_ORACLE_ENGINE",
    "SQLDBE":           "SVC_INFRA_MSSQL_ENGINE",
    "MSSQLDBE":         "SVC_INFRA_MSSQL_ENGINE",
    "MYSQLDBE":         "SVC_INFRA_MYSQL_ENGINE",
    "PGDBE":            "SVC_INFRA_POSTGRES_ENGINE",
    "POSTGREDBE":       "SVC_INFRA_POSTGRES_ENGINE",
    "SYBDBE":           "SVC_INFRA_SYBASE_ENGINE",
    "CASSDBE":          "SVC_INFRA_CASSANDRA_ENGINE",
    "MONGODBE":         "SVC_INFRA_MONGO_ENGINE",
    "ELASTICDBE":       "SVC_INFRA_ELASTIC_ENGINE",
    # ── Middleware / messaging acronyms → granular INFRA_MW service objects ──
    "MQue":             "SVC_INFRA_IBMMQ_ENGINE",
    "IBMMQ":            "SVC_INFRA_IBMMQ_ENGINE",
    "MQSERIES":         "SVC_INFRA_IBMMQ_ENGINE",
    "ACE":              "SVC_INFRA_ACE_ENGINE",
    "CVSESL":           "SVC_INFRA_ESL_ENGINE",
}

# SERVER_CLASS that maps to a DELIVERY object (not INFRA, not SERVICE)
DELIVERY_SERVER_CLASS_MAP = {
    "Data Power Hosting Server": "DATAPOWER",
}

# APP_ACRONYMS that map to a known EHM SERVICE (for EHM-sourced service objects)
EHM_SERVICE_ACRONYM_MAP = {
    "Guardium":     "SVC_GUARDIUM",      # heritage suffix applied by build function
    "GUARDIANCVS":  "SVC_GUARDIUM",      # heritage=CVS → becomes SVC_GUARDIUM_CVS
    "GuardiumHCB":  "SVC_GUARDIUM",      # heritage=AETNA → becomes SVC_GUARDIUM_HCB
    "GUARDIUMCVS":  "SVC_GUARDIUM",      # heritage=CVS → becomes SVC_GUARDIUM_CVS
    "GuardiumHCBR": "SVC_GUARDIUM",
    "CyberArk":     "SVC_CYBERARK",
    "CyberArkHCB":  "SVC_CYBERARK_HCB",
    "Infoblox":     "SVC_INFOBLOX",
    "InfraQualys":  "SVC_QUALYS",
    "QualysCVS":    "SVC_QUALYS_CVS",
    "QualysHCB":    "SVC_QUALYS_HCB",
    "Splunk":       "SVC_SPLUNK",
    "SplunkHCB":    "SVC_SPLUNK_HCB",
    "ThousandEyes": "SVC_THOUSANDEYES",
    # ── Confirmed in EHM 2026-05-22 (from LGS foundational services review) ──
    "SCCManager":   "SVC_SCCM",          # 125 EHM rows: PBM(59) HCB(54) AZ(9) COLO(2)
    "SCCM":         "SVC_SCCM",          # alternate acronym variant
    "VENAFI":       "SVC_VENAFI",        # 3 EHM rows with PRIMARY_ACRONYM=VENAFI (52 raw — contaminated via APP_ACRONYMS)
    "Tidal":        "SVC_TIDAL",         # 165 EHM rows: PBM(88) HCB(75) AZ(2)
    "SCOM":         "SVC_SCOM",          # 269 EHM rows: PBM(149) HCB(81) AZ(25) COLO(14)
    "BigID":        "SVC_BIGID",         # 2 EHM rows: PBM(2) — minimal, below APP min_members anyway
    "Infra":        None,  # too generic, skip
}

# ---------------------------------------------------------------------------
# ENV normalization
# ---------------------------------------------------------------------------

def normalize_heritage(heritage_str):
    if not isinstance(heritage_str, str):
        return "UNKNOWN"
    h = heritage_str.strip()
    hu = h.upper()
    if hu in ("CVS", "CAREMARK", "PBM", "SWITCH", "COLO"):
        # Switch COLO is CVS-owned infrastructure
        return "CVS"
    if hu in ("AETNA", "HCB"):
        return "AETNA"
    if hu == "OMNICARE":
        return "OMNICARE"
    # Multi-word / hyphenated variants seen in EHM
    if hu in ("CAREMARK/CVS", "CVSHCD"):
        # CAREMARK/CVS = legacy Caremark under CVS
        # CVSHCD = CVS+HCB shared hosting — treat as MIXED
        return "MIXED" if hu == "CVSHCD" else "CVS"
    if hu == "MIXED":
        return "MIXED"
    return hu

# ---------------------------------------------------------------------------
# File loader
# ---------------------------------------------------------------------------

def rd_short(routing_domain):
    return RD_SHORT.get(routing_domain, re.sub(r'[^A-Z0-9]', '', routing_domain.upper())[:8])

# ---------------------------------------------------------------------------
# HERITAGE normalization
# ---------------------------------------------------------------------------

def normalize_env(env_str):
    """Return PROD / NONPROD / DEV from APP_ENVIRONMENTS or PRIMARY_ENV."""
    if not isinstance(env_str, str):
        return "UNKNOWN"
    env_str = env_str.upper()
    if "PROD" in env_str and "NONPROD" not in env_str and "PDEV" not in env_str:
        return "PROD"
    if any(x in env_str for x in ["DEV", "QA", "TEST", "UAT", "PDEV", "PT", "STP", "CTE",
                                    "SANDBOX", "NONPROD"]):
        return "NONPROD"
    if "DR" in env_str:
        return "DR"
    return "UNKNOWN"

# ---------------------------------------------------------------------------
# ROUTING_DOMAIN → RD_SHORT
# ---------------------------------------------------------------------------
RD_SHORT = {
    "Internal-PBM":     "PBM",
    "Internal-HCB":     "HCB",
    "Internal-Retail":  "RETAIL",
    "Cloud-Azure":      "AZ",
    "Cloud-GCP":        "GCP",
    "Cloud-AWS":        "AWS",
    "COLO":             "COLO",
}




# ---------------------------------------------------------------------------
# CIDR collapsing — v1.1.0
#
# IPAM can legitimately carry both a summary block and a contained child
# subnet as separate Authoritative rows (e.g. NMS discovering a /21 route
# and a /24 VLAN within it as distinct entries — confirmed not a data
# error, see changelog). For firewall object purposes only the minimal
# covering set matters, so subnet_cidrs is collapsed at serialization time
# rather than upstream IPAM data being "fixed" to remove the redundancy.
# ---------------------------------------------------------------------------

def _collapse_cidrs(cidr_strs):
    """Return the minimal non-overlapping covering CIDR set, sorted.
    Invalid/unparseable entries are dropped rather than raising, since this
    runs at output time and one bad row shouldn't block the whole object."""
    nets = []
    for c in cidr_strs:
        try:
            nets.append(ipaddress.ip_network(c.strip(), strict=False))
        except (ValueError, AttributeError):
            continue
    return sorted(ipaddress.collapse_addresses(nets), key=lambda n: (n.version, n))


def _collapse_to_24_ceiling(ips):
    """Group host IPs into their containing /24s. Every /24 with at least
    one real host becomes a single CIDR — capped at /24, never collapsed
    coarser even if adjacent /24s could merge into a /23 or larger. This is
    deliberately different from _collapse_cidrs() (minimal covering set):
    a true minimal-cover collapse on thousands of scattered hosts could
    legitimately produce very coarse blocks (/16s) that sweep in far more
    address space than the object should actually match. Confirmed
    2026-07-08 for USER-ACCESS-CITRIX-OPTIMIZED: 4,687 hosts -> 111 /24s."""
    seen_24s = set()
    for ip in ips:
        try:
            seen_24s.add(ipaddress.ip_network(f'{ip}/24', strict=False))
        except ValueError:
            continue
    return sorted(seen_24s, key=lambda n: (n.version, n))


class CanonicalObject:
    def __init__(self, name, obj_type, app_acronym=None, service_role=None,
                 heritage=None, routing_domain=None):
        self.name = name
        self.obj_type = obj_type          # APP / INFRA / SERVICE / DELIVERY
        self.app_acronym = app_acronym
        self.service_role = service_role
        self.heritage = heritage
        self.routing_domain = routing_domain
        self.member_ips = set()
        self.vip_ips = set()
        self.subnet_cidrs = set()
        self.locations = set()
        self.source_datasets = set()
        self.no_further_collapse = False   # v1.5.0 — if True, subnet_cidrs is
                                            # already at its final ceiling
                                            # (e.g. /24-ceiling for Citrix) and
                                            # must NOT be run through the
                                            # minimal-covering-set collapse in
                                            # to_dict(), which would merge
                                            # adjacent blocks coarser than the
                                            # deliberate ceiling.
        # Schema v2 fields — populated post-build from supplementary sources
        self.app_architecture = 'unknown'   # single-instance|2-tier|3-tier|n-tier|container|microservice|serverless
        self.role_map         = {}          # {ip: role}  UI|MW|DB|API|CACHE|MQ|PROXY|MGMT|BATCH
        self.snat_ips         = set()       # outbound SNAT source IPs
        self.port_deps        = []          # [{from_role, to_role, app_id, port, proto}]
        self.server_ports     = []          # [{app_id, port, proto}]  — listens on
        self.client_ports     = []          # [{app_id, port, proto}]  — connects to
        self.service_deps     = []          # [{name, dep_type}]       — upstream deps
        self.pci_scope        = 'UNKNOWN'   # YES|NO|UNKNOWN
        self.criticality      = 'UNKNOWN'   # HIGH|MED|LOW|UNKNOWN
        self.non_prod         = False        # v1.3.0: True if all members are NON_PROD

    def add_member(self, ip, canonical_location=None, source=None):
        # v1.7.1 — validate before adding. Previously any non-empty string
        # (including comma-separated multi-IP fields, stray hostnames, or
        # other garbage from messy EHM/registry rows) was accepted here with
        # zero validation, then crashed the ENTIRE build — not just skipped
        # the bad row — at to_dict() time via an unguarded
        # ipaddress.ip_address() call, potentially minutes into a run.
        # _collapse_cidrs() elsewhere in this file already validates and
        # skips bad entries gracefully; this brings add_member() in line
        # with that same pattern instead of being the one unguarded path.
        if ip:
            ip_clean = ip.strip()
            try:
                ipaddress.ip_address(ip_clean)
                self.member_ips.add(ip_clean)
            except ValueError:
                pass  # invalid IP — skip silently, same as _collapse_cidrs()
        if canonical_location:
            self.locations.add(canonical_location)
        if source:
            self.source_datasets.add(source)

    def to_dict(self, dataset_version):
        member_list = [str(ip) for ip in sorted(
            (ipaddress.ip_address(x) for x in self.member_ips),
            key=lambda a: (a.version, a)
        )]
        heritage = self.heritage
        if len(set(
            ('CVS' if h in ('CVS','CAREMARK') else
             'AETNA' if h in ('AETNA','HCB') else h)
            for h in [heritage or '']
        )) > 1:
            heritage = 'MIXED'

        # Serialise PORT_DEPS: FROM>TO:APP_ID:PORT/PROTO pipe-separated
        def _fmt_pd(d):
            return f"{d['fr']}>{d['to']}:{d['ai']}:{d['pt']}/{d['pr']}"
        def _fmt_port(p):
            prefix = f"{p['ai']}:" if p.get('ai') else ''
            return f"{prefix}{p['pt']}/{p['pr']}"
        def _fmt_sd(s):
            return f"{s['nm']}:{s['dt']}" if s.get('dt') else s['nm']

        # Normalize OBJECT_TYPE to base class for downstream consumers
        # (APP/INFRA/SERVICE/DELIVERY) — granular subtype preserved in OBJECT_CLASS
        # e.g. obj_type='DELIVERY_EDH' → OBJECT_TYPE='DELIVERY', OBJECT_CLASS='DELIVERY_EDH'
        base_type = self.obj_type or ''
        for _base in ('APP', 'INFRA', 'SERVICE', 'DELIVERY', 'USER_ACCESS', 'UNALLOC'):
            if base_type.upper().startswith(_base):
                base_type = _base
                break

        return {
            'OBJECT_NAME':      self.name,
            'OBJECT_TYPE':      base_type,
            'OBJECT_CLASS':     self.obj_type,   # granular subtype
            'APP_ACRONYM':      self.app_acronym or '',
            'SERVICE_ROLE':     self.service_role or '',
            'HERITAGE':         heritage or '',
            'ROUTING_DOMAIN':   self.routing_domain or '',
            'MEMBER_IPS':       '|'.join(member_list),
            'VIP_IPS':          '|'.join(sorted(self.vip_ips)),
            'SUBNET_CIDRS':     '|'.join(
                                    str(c) for c in (
                                        sorted((ipaddress.ip_network(x) for x in self.subnet_cidrs),
                                               key=lambda n: (n.version, n))
                                        if self.no_further_collapse
                                        else _collapse_cidrs(self.subnet_cidrs)
                                    )
                                ),
            'LOCATIONS':        '|'.join(sorted(self.locations)),
            'MEMBER_COUNT':     len(member_list),
            'VIP_COUNT':        len(self.vip_ips),
            'SOURCE_DATASETS':  '|'.join(sorted(self.source_datasets)),
            'DATASET_VERSION':  dataset_version,
            # Schema v2
            'APP_ARCHITECTURE': self.app_architecture or 'unknown',
            'ROLE_MAP':         '|'.join(f"{ip}:{role}" for ip, role in sorted(self.role_map.items())),
            'SNAT_IPS':         '|'.join(sorted(self.snat_ips)),
            'SNAT_COUNT':       len(self.snat_ips),
            'PORT_DEPS':        '|'.join(_fmt_pd(d) for d in self.port_deps),
            'SERVER_PORTS':     '|'.join(_fmt_port(p) for p in self.server_ports),
            'CLIENT_PORTS':     '|'.join(_fmt_port(p) for p in self.client_ports),
            'SERVICE_DEPS':     '|'.join(_fmt_sd(s) for s in self.service_deps),
            'PCI_SCOPE':        self.pci_scope or 'UNKNOWN',
            'CRITICALITY':      self.criticality or 'UNKNOWN',
            'NON_PROD':         'Y' if self.non_prod else 'N',    # v1.3.0
        }

# ---------------------------------------------------------------------------
# Build functions
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Site / heritage tagging — shared by all USER_ACCESS_* builders (v1.2.0)
# Promoted to module level so the NET_TYPE-driven builder and the new
# LOCATION_TYPE-driven "User Networks" builder can't drift out of sync with
# each other the way the RA-role duplication did in build_service_objects.py.
# ---------------------------------------------------------------------------

_SITE_SLUG = {
    'scottsdale az - shea dc':          'SHEA',
    'woonsocket ri - ri one':           'RIONE',
    'woonsocket ri':                    'RIONE',
    'cumberland ri - 2100':             'RI2100',
    'cumberland ri':                    'RI2100',
    'middletown ct - aetna mdc':        'MDC',
    'middletown ct':                    'MDC',
    'windsor ct - aetna wdc':           'WDC',
    'windsor ct':                       'WDC',
    'hartford ct - aetna hq':           'HARTFORD',
    'hartford ct':                      'HARTFORD',
    'phoenix az - aetna dc':            'PHOENIX',
    'phoenix az - corporate':           'PHOENIX',
    'phoenix az':                       'PHOENIX',
    'las vegas nv - switch colo':       'LV-COLO',
    'las vegas nv':                     'LV-COLO',
    'atlanta ga - switch colo':         'ATL-COLO',
    'atlanta ga':                       'ATL-COLO',
    'sparks nv - switch tre':           'SPK-COLO',
    'cloud - azure east us 2':          'AZURE-EUS2',
    'cloud - azure':                    'AZURE',
    'cloud - gcp':                      'GCP',
    'cloud - aws':                      'AWS',
}


def _site_slug(location):
    if not location:
        return 'UNKNOWN'
    loc_lower = location.lower().strip()
    for k, v in _SITE_SLUG.items():
        if k in loc_lower:
            return v
    # Cloud locations
    if 'azure' in loc_lower:
        return 'AZURE'
    if 'gcp' in loc_lower or 'google' in loc_lower:
        return 'GCP'
    if 'aws' in loc_lower:
        return 'AWS'
    # Generic: take first two meaningful tokens
    parts = re.sub(r'[^a-z0-9 ]', ' ', loc_lower).split()
    return ('-'.join(p.upper() for p in parts[:2]) if parts else 'UNKNOWN')


def _her_tag(routing_domain, heritage):
    rd = (routing_domain or '').upper()
    her = (heritage or '').upper()
    if 'HCB' in rd or 'AETNA' in her:
        return 'HCB'
    if 'RETAIL' in rd:
        return 'RETAIL'
    if 'PBM' in rd or 'CVS' in her or 'CAREMARK' in her:
        return 'PBM'
    if 'AZURE' in rd or 'GCP' in rd or 'AWS' in rd:
        return 'CLOUD'
    return 'UNKNOWN'


# NET_TYPEs already claimed by another USER_ACCESS_* object class — must be
# excluded from USER_ACCESS_LAN to avoid double-counting the same subnet
# into two different FW SRC objects.
USER_ACCESS_NET_TYPES = {
    'User-Access-VDI',
    'User-Access-VPN',
    'User-Access-Wired',
    'User-Access-WLAN',
    'User-Access-Unknown',
    'RA-POOL-CSA',         # v1.1.0 — CVS/PBM Cisco Secure Access client pools
    'RA-SNAT-HCB',         # v1.1.0 — Aetna/HCB SNAT translation pools
    # ZPA-CONNECTOR / RA-CONN-ZPA intentionally removed v1.5.0 — ZPA is now
    # host-based from the connector registry, not this subnet-tag path.
    # See USER_ACCESS_SUPERSEDED_NET_TYPES below.
}

# NET_TYPEs that legitimately still exist in IPAM but are deliberately NOT
# processed by the subnet-based path above — excluded from the unmapped-type
# audit too, since flagging them would be a false alarm, not a real gap.
USER_ACCESS_SUPERSEDED_NET_TYPES = {
    'ZPA-CONNECTOR', 'RA-CONN-ZPA',
    # v1.8.1 — 'VPN' (bare, distinct from 'User-Access-VPN') confirmed
    # 2026-07-09: all 64 rows are ROUTING_DOMAIN=Partner, HERITAGE=CVS,
    # CANONICAL_LOCATION='Offshore - Contractor', SITE_CODE=US_OFF_EX_TP —
    # offshore contractor/partner circuit connectivity, NOT CVS/Aetna
    # employee remote access. This is NOT a synonym for User-Access-VPN and
    # must not be folded into USER-ACCESS-VPN-ALL — doing so would silently
    # blend a partner population into the employee-access object.
    # IMPORTANT: _her_tag() would have misclassified this as PBM if it had
    # been added to USER_ACCESS_NET_TYPES instead — it checks 'PBM' in rd
    # first (false, rd='Partner'), then falls through to 'CVS' in her
    # (true) and tags PBM. Confirmed belongs in the Partner-NG/B2B-VPN
    # pipeline (build_partner_ng.py / P2P-PROTECTED-SUBNETS), not here.
    'VPN',
}


def build_user_access_objects(ipam_rows, ehm_rows, zpa_registry_rows=None, verbose=False):
    """
    Build USER_ACCESS_Objects from:
      1. all_IP_networks WHERE NET_TYPE IN (User-Access-VDI, User-Access-VPN,
         User-Access-Wired, User-Access-WLAN, RA-POOL-CSA, RA-SNAT-HCB)
         → Subnet-based objects grouped by NET_TYPE × heritage × site
      2. ent_host_master WHERE platform matches CITRIX-VDI patterns
         → Host-based objects grouped by Citrix site
      3. ent-ipdataset-ZPA-CONNECTOR-REGISTRY — host-based /32 addresses.
         ZPA-CONNECTOR / RA-CONN-ZPA are NOT processed via the subnet-tag
         path above (see USER_ACCESS_SUPERSEDED_NET_TYPES) — moved here in
         v1.5.0; subnet tagging was missing 41 of 107 real connectors.

    Object naming:
      USER-ACCESS-CITRIX-PBM-SHEA     Citrix worker pool at Shea DC (CVS/PBM)
      USER-ACCESS-CITRIX-HCB-MDC      Citrix farm at Middletown (Aetna/HCB)
      USER-ACCESS-VDI-PBM-AZURE       Azure VDI pools (CVS PBM)
      USER-ACCESS-VPN-HCB-WDC         VPN pool at Windsor (HCB)
      USER-ACCESS-VPN-RETAIL          Retail VPN pool
      USER-ACCESS-WIRED-HCB           HCB wired user subnets
      USER-ACCESS-ZPA-WDC             ZPA connectors at Windsor

    These are SOURCE objects in firewall rules:
      src=USER-ACCESS-VDI-PBM-SHEA dst=APP-RXCONNECT port=443
    """
    # re is imported at module level
    # USER_ACCESS_NET_TYPES now module-level — see above

    # _site_slug / _her_tag / _SITE_SLUG now module-level — see above build_user_access_objects()

    objects = {}
    unmapped_types = defaultdict(int)   # v1.1.0 — unmapped-type audit
    _AUDIT_HINTS = ('RA-', 'ZPA', 'VPN', 'VDI', 'ACCESS')

    # ── Source 1: IPAM subnet-based USER-ACCESS objects ───────────────────────
    for row in ipam_rows:
        net_type  = (row.get('NET_TYPE') or '').strip()
        if net_type not in USER_ACCESS_NET_TYPES:
            if (net_type and net_type not in USER_ACCESS_SUPERSEDED_NET_TYPES
                    and any(h in net_type.upper() for h in _AUDIT_HINTS)):
                unmapped_types[net_type] += 1
            continue

        cidr     = (row.get('CIDR') or '').strip()
        loc      = (row.get('CANONICAL_LOCATION') or '').strip()
        rd       = (row.get('ROUTING_DOMAIN') or '').strip()
        her      = (row.get('HERITAGE') or '').strip()
        site_code= (row.get('SITE_CODE') or '').strip()

        if not cidr:
            continue

        her_tag  = _her_tag(rd, her)
        site_tag = _site_slug(loc)

        # Derive object class and name from NET_TYPE
        # NOTE: ZPA-CONNECTOR / RA-CONN-ZPA intentionally NOT handled here.
        # v1.5.0 — ZPA moved to host-based /32 addresses from the actual
        # connector registry (ent-ipdataset-ZPA-CONNECTOR-REGISTRY), not
        # subnet-level IPAM tags. Confirmed 2026-07-08: subnet-based tracking
        # was missing 41 of 107 real connector devices because IPAM's
        # RA-CONN-ZPA subnet tagging hadn't kept pace with actual deployment.
        # The registry is the authoritative host-level source; see Source 3
        # below. Same reasoning as Citrix using EHM host data instead of a
        # subnet tag.
        if net_type == 'User-Access-VDI':
            # Distinguish Azure VDI from on-prem Citrix
            if 'Cloud-Azure' in rd or 'Azure' in loc:
                obj_class = 'USER_ACCESS_VDI_AZURE'
                obj_name  = f'USER-ACCESS-VDI-{her_tag}-AZURE'
            elif 'Cloud-GCP' in rd:
                obj_class = 'USER_ACCESS_VDI_GCP'
                obj_name  = f'USER-ACCESS-VDI-{her_tag}-GCP'
            else:
                obj_class = 'USER_ACCESS_VDI'
                obj_name  = f'USER-ACCESS-VDI-{her_tag}-{site_tag}'
        elif net_type in ('User-Access-VPN', 'RA-POOL-CSA'):
            # Client-assigned VPN address pools — what a connecting device
            # itself gets an IP from. RA-SNAT-HCB is NOT the same concept
            # (see below) — a translation pool, not a client pool — and
            # must not share this class even though both are "Cisco RA VPN"
            # in casual conversation. Split confirmed 2026-07-08.
            obj_class = 'USER_ACCESS_VPN'
            obj_name  = f'USER-ACCESS-VPN-{her_tag}-{site_tag}'
        elif net_type == 'RA-SNAT-HCB':
            # SNAT translation pool — the address a connection is translated
            # TO on egress, not a client-assigned address. Functionally
            # different in a firewall rule than a client VPN pool (matches
            # as a NAT'd source range, not an end-user device range), so it
            # gets its own object class rather than folding into
            # USER_ACCESS_VPN just because both are "Cisco RA VPN"-adjacent.
            obj_class = 'USER_ACCESS_SNAT'
            obj_name  = f'USER-ACCESS-SNAT-{her_tag}-{site_tag}'
        elif net_type == 'User-Access-Wired':
            obj_class = 'USER_ACCESS_WIRED'
            obj_name  = f'USER-ACCESS-WIRED-{her_tag}-{site_tag}'
        elif net_type == 'User-Access-WLAN':
            obj_class = 'USER_ACCESS_WLAN'
            obj_name  = f'USER-ACCESS-WLAN-{her_tag}-{site_tag}'
        else:
            obj_class = 'USER_ACCESS_UNKNOWN'
            obj_name  = f'USER-ACCESS-UNKNOWN-{her_tag}-{site_tag}'

        if obj_name not in objects:
            objects[obj_name] = CanonicalObject(
                name=obj_name,
                obj_type='USER_ACCESS',
                heritage=her_tag,
                routing_domain=rd,
            )
            objects[obj_name].obj_type = obj_class  # preserve granular class

        objects[obj_name].subnet_cidrs.add(cidr)
        objects[obj_name].locations.add(loc)
        objects[obj_name].source_datasets.add('all_IP_networks')

    # ── Source 2: EHM CITRIX-VDI host-based objects ────────────────────────────
    _CITRIX_PATS = [
        r'pvmp?-pvs', r'pvs22', r'pvs16',
        r'(paz1|eri[12]|rri[12]|eaz1|maz[pqr])(crt|prx|mth|ehy|ce2|cst|cit)',
        r'(mazp|mazr|mazq|rac2|eri1|rri1|paz1|eaz1)-?mcs',
        r'mcs22', r'mcs16', r'mcsm',
        r'ctxddc', r'ctxpvs', r'ctxvda',
    ]
    _citrix_re = re.compile('|'.join(_CITRIX_PATS), re.I)

    for row in ehm_rows:
        hn  = (row.get('SERVER_NAME') or '').strip()
        pt  = (row.get('PLATFORM_TYPE') or '').strip()
        ip  = (row.get('IP_ADDRESS') or row.get('IP') or '').strip()
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        rd  = (row.get('ROUTING_DOMAIN') or '').strip()
        her = (row.get('HERITAGE') or '').strip()

        # Match Citrix infrastructure hosts
        is_citrix = (_citrix_re.search(hn) or
                     pt in ('CITRIX-VDI', 'CITRIX-INFRA') or
                     (row.get('ASSET_FAMILY') or '').upper() == 'CITRIX')

        if not is_citrix or not ip:
            continue

        her_tag  = _her_tag(rd, her)
        site_tag = _site_slug(loc)
        obj_name = f'USER-ACCESS-CITRIX-{her_tag}-{site_tag}'

        if obj_name not in objects:
            objects[obj_name] = CanonicalObject(
                name=obj_name,
                obj_type='USER_ACCESS_CITRIX',
                heritage=her_tag,
                routing_domain=rd,
            )

        objects[obj_name].add_member(ip, canonical_location=loc, source='EHM')

    # ── Source 3: ZPA Connector Registry — host-based, real /32 addresses ─────
    # Confirmed 2026-07-08: subnet-based tracking (old Source 1 branch) missed
    # 41 of 107 real connector devices because IPAM's RA-CONN-ZPA subnet
    # tagging hadn't kept pace with actual deployment. This registry is the
    # authoritative host-level source — one row per physical/virtual
    # Connector appliance. NETSCALER-LV cluster excluded: confirmed by the
    # platform owner to be Citrix NetScaler Gateway devices, not ZPA App
    # Connectors, despite being bundled into this registry file.
    zpa_registry_rows = zpa_registry_rows or []
    for row in zpa_registry_rows:
        cluster = (row.get('CLUSTER_NAME') or '').strip()
        if cluster == 'NETSCALER-LV':
            continue  # confirmed not ZPA — Citrix NetScaler Gateway
        ip  = (row.get('CONNECTOR_IP') or '').strip().split('/')[0]
        loc = (row.get('LOCATION') or '').strip()
        rd  = (row.get('ROUTING_DOMAIN') or '').strip()
        her = (row.get('HERITAGE') or '').strip()
        if not ip:
            continue

        her_tag  = _her_tag(rd, her)
        site_tag = _site_slug(loc)
        obj_name = f'USER-ACCESS-ZPA-{her_tag}-{site_tag}'

        if obj_name not in objects:
            objects[obj_name] = CanonicalObject(
                name=obj_name,
                obj_type='USER_ACCESS_ZPA',
                heritage=her_tag,
                routing_domain=rd,
            )

        objects[obj_name].add_member(ip, canonical_location=loc, source='ZPA-CONNECTOR-REGISTRY')

    # ── Source 4: Citrix consolidated /24-ceiling object ───────────────────────
    # Confirmed 2026-07-08: 15 separate per-site objects each listing raw /32
    # hosts (4,687 total) is unusable as a firewall SRC object. Consolidate
    # into ONE object, summarized to /24 blocks — every /24 containing at
    # least one real Citrix host becomes a single CIDR entry, capped at /24
    # (never collapsed coarser, to avoid sweeping in unrelated address space).
    # Real host list is preserved in MEMBER_IPS for audit/traceability;
    # SUBNET_CIDRS (the /24-ceiling list) is what the EDL export actually
    # uses, since CanonicalObject prefers subnet_cidrs over member_ips when
    # both are present.
    citrix_names = [n for n in objects if n.startswith('USER-ACCESS-CITRIX-')]
    if citrix_names:
        all_citrix_ips = set()
        all_citrix_locs = set()
        for n in citrix_names:
            all_citrix_ips |= objects[n].member_ips
            all_citrix_locs |= objects[n].locations
            del objects[n]

        consolidated = CanonicalObject(
            name='USER-ACCESS-CITRIX-OPTIMIZED',
            obj_type='USER_ACCESS_CITRIX',
            heritage='MIXED',
            routing_domain='',
        )
        for ip in all_citrix_ips:
            consolidated.add_member(ip, source='EHM')
        consolidated.locations |= all_citrix_locs
        for net24 in _collapse_to_24_ceiling(all_citrix_ips):
            consolidated.subnet_cidrs.add(str(net24))
        consolidated.no_further_collapse = True
        objects['USER-ACCESS-CITRIX-OPTIMIZED'] = consolidated

    # ── Source 5: VDI-ALL consolidation — the actual FW-usable deliverable ────
    # v1.8.0 — confirmed 2026-07-09: per-site VDI objects are intermediate,
    # not the deliverable; a real FW SRC object needs one rule-optimized VDI
    # object, not 7 near-duplicates split by heritage/site. Merges every
    # USER-ACCESS-VDI-* object plus CITRIX-OPTIMIZED (VDI sessions and
    # Citrix sessions get identical FW treatment) into USER-ACCESS-VDI-ALL.
    # Unlike the Citrix-alone object, this is NOT capped at a /24 ceiling —
    # that ceiling existed only to keep Citrix's own object from sweeping in
    # unrelated address space; once merged into the VDI-wide object, a full
    # minimal-covering-set collapse (the normal _collapse_cidrs() path at
    # to_dict() time) is appropriate and matches the reference build's
    # observed 176-deduplicated -> 91-final result.
    vdi_names = [n for n in objects
                 if n.startswith('USER-ACCESS-VDI-') or n == 'USER-ACCESS-CITRIX-OPTIMIZED']
    if vdi_names:
        vdi_all = CanonicalObject(
            name='USER-ACCESS-VDI-ALL',
            obj_type='USER_ACCESS_VDI',
            heritage='MIXED',
            routing_domain='',
        )
        for n in vdi_names:
            vdi_all.subnet_cidrs |= objects[n].subnet_cidrs
            vdi_all.locations |= objects[n].locations
            vdi_all.source_datasets |= objects[n].source_datasets
            del objects[n]
        objects['USER-ACCESS-VDI-ALL'] = vdi_all

    # ── Source 6: VPN-ALL consolidation — same reasoning as VDI-ALL ───────────
    # v1.8.0 — merges every USER-ACCESS-VPN-* object (User-Access-VPN and
    # RA-POOL-CSA net types both land here — see the classification branch
    # above) regardless of heritage/site into one USER-ACCESS-VPN-ALL.
    # NOTE: this does NOT include the still-unmapped bare 'VPN' NET_TYPE
    # (64 rows, flagged separately in the unmapped-type audit below) — the
    # reference build's own "14 VPN objects" source count matches exactly
    # today's per-site VPN object count with nothing else folded in, so that
    # bare NET_TYPE is a distinct, still-open gap, not part of this merge.
    vpn_names = [n for n in objects if n.startswith('USER-ACCESS-VPN-')]
    if vpn_names:
        vpn_all = CanonicalObject(
            name='USER-ACCESS-VPN-ALL',
            obj_type='USER_ACCESS_VPN',
            heritage='MIXED',
            routing_domain='',
        )
        for n in vpn_names:
            vpn_all.subnet_cidrs |= objects[n].subnet_cidrs
            vpn_all.locations |= objects[n].locations
            vpn_all.source_datasets |= objects[n].source_datasets
            del objects[n]
        objects['USER-ACCESS-VPN-ALL'] = vpn_all

    if verbose:
        print(f'  USER_ACCESS_Objects: {len(objects)}')
        for name, obj in sorted(objects.items()):
            n_cidrs = len(obj.subnet_cidrs)
            n_ips   = len(obj.member_ips)
            print(f'    {name:<55} {n_cidrs:>3} subnets  {n_ips:>4} hosts')
        if unmapped_types:
            print()
            print(f'  {YEL}\u26a0 UNMAPPED NET_TYPE — access-related but not in USER_ACCESS_NET_TYPES:{RST}')
            for nt, cnt in sorted(unmapped_types.items(), key=lambda kv: -kv[1]):
                print(f'      {nt:<24} {cnt:>5} rows')
            print(f'      -> If this is a real taxonomy change, add it to USER_ACCESS_NET_TYPES and re-run.')

    return objects




def build_user_network_lan_objects(ipam_rows, lm_rows=None, verbose=False):
    """
    Build USER_ACCESS_LAN objects — SOURCE objects for FW rules, same as
    every other builder in this script.
      src=USER-ACCESS-LAN-PBM-NORTHEAST   dst=APP-RXCONNECT   port=443

    Selection: user traffic subnets only — not server subnets, not remote
    access subnets. Two exclusions, both real:
      1. LOCATION_TYPE in (DataCenter, COLO, Cloud) — infra locations.
      2. NET_TYPE is infra (DMZ, P2P-WAN, VPN, SD-WAN, DR, Data-Center/
         DataCenter) or already claimed by another USER_ACCESS_* object
         class (User-Access-VPN, User-Access-VDI, RA-POOL-CSA, RA-SNAT-HCB,
         RA-CONN-ZPA, etc. — see USER_ACCESS_NET_TYPES) — those subnets
         already have their own FW SRC object and must not double-count
         into this one too.
    Citrix VDI is unaffected either way — separate EHM-sourced object
    family (USER_ACCESS_CITRIX above), never subject to this filter.

    Grouped by heritage + REGION — confirmed 2026-07-08: heritage-only
    grouping produced two unusable objects (USER-ACCESS-LAN-PBM at 2,513
    CIDRs, USER-ACCESS-LAN-HCB at 690) — not a compression failure, LAN
    genuinely covers subnets scattered across 230+ distinct physical
    locations nationwide, so no further CIDR-math trick meaningfully
    shrinks a single object. Regional split brings 14 of 16 resulting
    objects under the practical ~500-entry FW address-group ceiling.
    PBM-Northeast (677) and PBM-Southeast (746) are still over — flagged,
    not silently left as a false "fixed" claim; a further per-state split
    would be needed to close those two specifically.

    REGION comes from location_master, not all_IP_networks — unlike the
    LOCATION_TYPE join removed earlier this session (that was genuinely
    redundant, already present on the IPAM row), REGION isn't available
    anywhere except location_master, so this join is load-bearing, not
    redundant.
    """
    EXCLUDE_LOC_TYPES  = {'DataCenter', 'COLO', 'Cloud'}
    EXCLUDE_INFRA_NET_TYPES = {
        'DMZ', 'P2P-WAN', 'VPN', 'SD-WAN', 'DR', 'Data-Center', 'DataCenter',
        'Network-Infrastructure',
    }

    region_map = {r['CANONICAL_NAME']: (r.get('REGION') or '').strip()
                  for r in (lm_rows or [])}
    state_map  = {r['CANONICAL_NAME']: (r.get('STATE') or '').strip()
                  for r in (lm_rows or [])}
    _REGION_ABBR = {
        'NORTHEAST': 'NE', 'SOUTHEAST': 'SE', 'MIDWEST': 'MW',
        'SOUTHCENTRAL': 'SC', 'WEST': 'WE',
    }
    OVERSIZE_THRESHOLD = 500

    # Pass 1: collect CIDRs by (heritage, region, state) — deferred object
    # creation, since whether a region needs sub-splitting can't be known
    # until all its data is in.
    raw = defaultdict(lambda: defaultdict(list))  # raw[(her_tag, region_tag)][state] = [cidrs]
    loc_by_group = defaultdict(set)
    rd_by_group = {}

    for row in ipam_rows:
        if (row.get('LOCATION_TYPE') or '').strip() in EXCLUDE_LOC_TYPES:
            continue
        net_type = (row.get('NET_TYPE') or '').strip()
        if net_type in EXCLUDE_INFRA_NET_TYPES or net_type in USER_ACCESS_NET_TYPES:
            continue

        cidr = (row.get('CIDR') or '').strip()
        if not cidr:
            continue
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        rd  = (row.get('ROUTING_DOMAIN') or '').strip()
        her = (row.get('HERITAGE') or '').strip()

        her_tag = _her_tag(rd, her)
        region  = region_map.get(loc) or 'NOREGION'
        region_tag = region.upper().replace(' ', '').replace('-', '') or 'NOREGION'
        state = state_map.get(loc) or 'UNK'

        key = (her_tag, region_tag)
        raw[key][state].append(cidr)
        loc_by_group[key].add(loc)
        rd_by_group[key] = rd

    # Pass 2: for each group, either emit as one object, or bin-pack by
    # state into 2 sub-objects if the collapsed size is over threshold.
    # Confirmed 2026-07-08: PBM-Northeast/Southeast were the only two over
    # threshold; this is written generally so any future oversized region
    # gets the same treatment automatically rather than needing another
    # hand-built fix.
    objects = {}
    for (her_tag, region_tag), by_state in raw.items():
        all_cidrs = [c for cidrs in by_state.values() for c in cidrs]
        collapsed_n = len(_collapse_cidrs(all_cidrs))

        if collapsed_n <= OVERSIZE_THRESHOLD or len(by_state) < 2:
            obj_name = f'USER-ACCESS-LAN-{her_tag}-{region_tag}'
            obj = CanonicalObject(name=obj_name, obj_type='USER_ACCESS_LAN',
                                   heritage=her_tag, routing_domain=rd_by_group[(her_tag, region_tag)])
            obj.subnet_cidrs.update(all_cidrs)
            obj.locations.update(loc_by_group[(her_tag, region_tag)])
            obj.source_datasets.add('all_IP_networks')
            objects[obj_name] = obj
            continue

        # Oversized — bin-pack states into 2 balanced sub-groups by collapsed size
        state_sizes = {s: len(_collapse_cidrs(cidrs)) for s, cidrs in by_state.items()}
        bins = [[], []]
        bin_totals = [0, 0]
        for s in sorted(by_state, key=lambda s: -state_sizes[s]):
            idx = bin_totals.index(min(bin_totals))
            bins[idx].append(s)
            bin_totals[idx] += state_sizes[s]

        abbr = _REGION_ABBR.get(region_tag, region_tag[:2])
        for i, states in enumerate(bins, 1):
            if not states:
                continue
            obj_name = f'USER-ACCESS-LAN-{her_tag}-{abbr}-{i}'
            obj = CanonicalObject(name=obj_name, obj_type='USER_ACCESS_LAN',
                                   heritage=her_tag, routing_domain=rd_by_group[(her_tag, region_tag)])
            for s in states:
                obj.subnet_cidrs.update(by_state[s])
            # only the locations actually in this bin's states
            state_set = set(states)
            obj.locations.update(
                loc for loc in loc_by_group[(her_tag, region_tag)]
                if state_map.get(loc) in state_set
            )
            obj.source_datasets.add('all_IP_networks')
            objects[obj_name] = obj

    if verbose:
        print(f'  USER_ACCESS_LAN objects: {len(objects)}')
        for name, obj in sorted(objects.items()):
            collapsed_n = len(_collapse_cidrs(obj.subnet_cidrs))
            flag = '  \u26a0 still over 500' if collapsed_n > 500 else ''
            print(f'    {name:<40} {len(obj.subnet_cidrs):>4} raw -> {collapsed_n:>4} collapsed  '
                  f'{len(obj.locations)} locations{flag}')

    return objects


def _write_edl_files(objects, edl_dir):
    """
    Write one PAN-OS-style EDL .txt file per object into edl_dir.
    Subnet-based objects (LAN/VPN/ZPA/VDI/WLAN/Wired): SUBNET_CIDRS, one per line.
    Host-based objects (Citrix): MEMBER_IPS as /32 entries, one per line.
    Returns the set of object names that got a file written (non-empty only —
    an object with zero members doesn't get a file, matching has_edl semantics
    used elsewhere in this pipeline).
    """
    os.makedirs(edl_dir, exist_ok=True)
    written = set()
    for obj in objects:
        if obj.subnet_cidrs:
            cidrs = [str(c) for c in sorted(
                (ipaddress.ip_network(x, strict=False) for x in obj.subnet_cidrs),
                key=lambda n: (n.version, n)
            )]
        else:
            cidrs = [str(ip) + '/32' for ip in sorted(
                (ipaddress.ip_address(x) for x in obj.member_ips),
                key=lambda a: (a.version, a)
            )]
        if not cidrs:
            continue
        path = os.path.join(edl_dir, f'{obj.name}.txt')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(f'# {obj.name}\n')
            f.write(f'# CCD Platform — build_user_access_objects.py {VERSION}\n')
            f.write(f'# Generated: {BUILD_DATE}\n')
            for c in cidrs:
                f.write(f'{c}\n')
        written.add(obj.name)
    return written


def main():
    p = argparse.ArgumentParser(
        description=f"CCD Platform — build_user_access_objects.py {VERSION}"
    )
    p.add_argument("--ipam-dir",  dest="ipam_dir",  default="./ipam-db",
                   help="ipam-db/ directory (default: ./ipam-db)")
    p.add_argument("--out-dir",   dest="out_dir",   default="./processed_outputs",
                   help="Output directory (default: ./processed_outputs)")
    p.add_argument("--net-object-dir", dest="net_object_dir", default="./Net_Object",
                   help="Net_Object/ root for versioned UA-YYYYMMDD_vN/ output "
                        "with EDL files (default: ./Net_Object)")
    p.add_argument("--dry-run",   dest="dry_run",   action="store_true")
    p.add_argument("-V", "--version", action="version", version=f"%(prog)s {VERSION}")
    args = p.parse_args()

    print(f"\nbuild_user_access_objects.py {VERSION}")
    print(f"  ipam-dir : {args.ipam_dir}")
    print(f"  out-dir  : {args.out_dir}")
    if args.dry_run:
        print(f"  DRY RUN  : no files written")
    print()

    # ── Load datasets ─────────────────────────────────────────────────────────
    print("[1/3] Loading datasets...")
    ipam_path = find_file(args.ipam_dir, "all_IP_networks_v*.csv")
    ehm_path  = find_file(args.ipam_dir, "ent_host_master_v*.csv")

    if not ipam_path or not ehm_path:
        missing = []
        if not ipam_path: missing.append("all_IP_networks")
        if not ehm_path:  missing.append("ent_host_master")
        print(f"{RED}Error: missing required files: {missing}{RST}", file=sys.stderr)
        sys.exit(1)

    ipam_rows = read_ccd_csv(ipam_path)
    ehm_rows  = read_ccd_csv(ehm_path)
    print(f"  all_IP_networks : {len(ipam_rows):,} rows  ({os.path.basename(ipam_path)})")
    print(f"  ent_host_master : {len(ehm_rows):,} rows  ({os.path.basename(ehm_path)})")

    zpa_registry_path = find_file(args.ipam_dir, "ent-ipdataset-ZPA-CONNECTOR-REGISTRY-v*.csv")
    zpa_registry_rows = read_ccd_csv(zpa_registry_path) if zpa_registry_path else []
    if zpa_registry_path:
        print(f"  ZPA-CONNECTOR-REGISTRY : {len(zpa_registry_rows):,} rows  ({os.path.basename(zpa_registry_path)})")
    else:
        print(f"  {YEL}⚠ ZPA-CONNECTOR-REGISTRY not found — USER_ACCESS_ZPA will be empty this run{RST}")

    # ── Build objects ─────────────────────────────────────────────────────────
    print("\n[2/3] Building USER_ACCESS_Objects...")
    objects = build_user_access_objects(ipam_rows, ehm_rows, zpa_registry_rows, verbose=True)

    lm_path = find_file(args.ipam_dir, "location_master_v*.csv")
    lm_rows = read_ccd_csv(lm_path) if lm_path else []
    if lm_path:
        print(f"  location_master : {len(lm_rows):,} rows  ({os.path.basename(lm_path)})")
    else:
        print(f"  {YEL}⚠ location_master not found — USER_ACCESS_LAN will use NOREGION for all rows{RST}")

    lan_objects = build_user_network_lan_objects(ipam_rows, lm_rows, verbose=True)
    objects.update(lan_objects)

    total_subnets = sum(len(o.subnet_cidrs) for o in objects.values())
    total_hosts   = sum(len(o.member_ips)   for o in objects.values())
    print(f"\n  Total: {len(objects)} objects  "
          f"({total_subnets} subnets  {total_hosts:,} hosts)")

    # ── Write ─────────────────────────────────────────────────────────────────
    print(f"\n[3/3] Writing output...")
    out_fname = f"{OUTPUT_STEM}_v{BUILD_DATE}.csv"
    out_path  = os.path.join(args.out_dir, out_fname)

    if args.dry_run:
        print(f"  {YEL}[DRY RUN] Would write: {out_path}  "
              f"({len(objects)} objects){RST}")
        return

    os.makedirs(args.out_dir, exist_ok=True)
    all_objs = sorted(objects.values(), key=lambda o: o.name)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        f.write(f"#STEM={OUTPUT_STEM}\n")
        f.write(f"#VERSION=v{BUILD_DATE}\n")
        f.write(f"#ROWS={len(all_objs)}\n")
        f.write(f"#BUILT_BY=build_user_access_objects.py {VERSION}\n")
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        for obj in all_objs:
            writer.writerow(obj.to_dict(BUILD_DATE))

    print(f"{GRN}✓ Written: {out_path}  ({len(all_objs)} objects){RST}")

    # ── Versioned Net_Object/UA-YYYYMMDD_vN/ output with real EDL files ────────
    # Matches the Net_Object/SO-YYYYMMDD_vN/ pattern build_service_objects.py
    # uses, so build_edl_catalog.py can discover this the same way as every
    # other object family instead of needing a flat-file special case.
    _ua_base   = args.net_object_dir
    _prefix    = f'UA-{BUILD_DATE}_v'
    _existing  = sorted(
        [d for d in (os.listdir(_ua_base) if os.path.isdir(_ua_base) else [])
         if re.match(rf'^UA-{BUILD_DATE}_v(\d+)$', d)],
        key=lambda d: int(re.search(r'_v(\d+)$', d).group(1))
    )
    _next_n    = (int(re.search(r'_v(\d+)$', _existing[-1]).group(1)) + 1) if _existing else 1
    _ua_dir    = os.path.join(_ua_base, f'{_prefix}{_next_n}')
    _edl_dir   = os.path.join(_ua_dir, 'EDL')

    os.makedirs(_ua_dir, exist_ok=True)
    _ver_cat_path = os.path.join(_ua_dir, out_fname)
    with open(_ver_cat_path, "w", newline="", encoding="utf-8") as f:
        f.write(f"#STEM={OUTPUT_STEM}\n")
        f.write(f"#VERSION=v{BUILD_DATE}\n")
        f.write(f"#ROWS={len(all_objs)}\n")
        f.write(f"#BUILT_BY=build_user_access_objects.py {VERSION}\n")
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        for obj in all_objs:
            writer.writerow(obj.to_dict(BUILD_DATE))

    edl_written = _write_edl_files(all_objs, _edl_dir)
    print(f"{GRN}✓ Versioned dir: {_ua_dir}  "
          f"({len(edl_written)}/{len(all_objs)} objects got an EDL file){RST}")
    if len(edl_written) < len(all_objs):
        skipped = [o.name for o in all_objs if o.name not in edl_written]
        print(f"  {YEL}⚠ {len(skipped)} object(s) with zero members, no EDL written: "
              f"{', '.join(skipped[:5])}{'...' if len(skipped) > 5 else ''}{RST}")

    print(f"\n  Next steps:")
    print(f"    python3 ipam-db.py --import {out_path} --type CANONICAL-USER-ACCESS-OBJECTS")


if __name__ == "__main__":
    main()
