#!/usr/bin/env python3
"""
build_custom_objects.py  v1.7.1
CCD Platform — Custom Object Library Builder
CVS Health Information Security

Builds CUSTOM_Objects — curated network abstractions that don't fit any
existing object family:
  - NOT a Network Group (build_network_groups.py) — those are mechanical
    IPAM derivatives (NET_TYPE/LOCATION/ROUTING_DOMAIN straight off the
    row). CUSTOM objects are a curation decision layered on top of IPAM,
    same relationship APP/SERVICE/DELIVERY objects have to IPAM.
  - NOT USER_ACCESS (build_user_access_objects.py) — "User Networks"
    (USER_ACCESS_LAN) is explicitly non-DataCenter/COLO/Cloud/DR space
    (see that script's v1.2.0 changelog). CUSTOM is the general-purpose
    escape hatch for anything that doesn't fit APP/INFRA/SERVICE/DELIVERY/
    USER_ACCESS — AETNA_HCB_172 (general Aetna DC/campus subnets) is its
    first registered class, not its only intended use.

Adds a sixth OBJECT_TYPE to the canonical model: CUSTOM, alongside
APP / INFRA / SERVICE / DELIVERY / USER_ACCESS / UNALLOC used elsewhere
in this platform's build_*.py scripts.

Object classes (see _CUSTOM_CLASSES registry):
  1. AETNA_HCB_172          — Aetna-heritage subnets in 172.16.0.0/12,
     one object per DC location. Filters all_IP_networks directly
     (HERITAGE=AETNA, CIDR within 172.16.0.0/12, CANONICAL_LOCATION in
     a known DC-location set) — no IPAM NET_TYPE tagging required or
     expected, deliberately avoiding an IPAM REMOVE+ADD patch cycle on
     existing rows for what is a curation decision, not an IPAM
     correction.
  2. AETNA_HCB_172_COMBINED — the same AETNA_HCB_172 source rows as
     class 1, merged into a single cross-location object. Additive:
     sits alongside the 5 per-location objects, does not replace them.
     Use case: a single EDL for "all Aetna-HCB-172 space" where the
     consumer doesn't care about location.
  3. EGRESS_TRAFFIC         — per-firewall egress traffic objects
     sourced from ent-ipdataset-EGRESS-FW-TOPOLOGY (the live-traffic
     breadcrumbed dataset from build_IP_Network_Egress_FW_topology.py),
     NOT from all_IP_networks. Three confidence tiers per firewall,
     all heritages, all 10 EGRESS_FIREWALL_LOGICAL values:
       - VERIFIED  TRAFFIC_SOURCE=BOTH  — confirmed USER traffic.
         Requires both Zscaler (proxy) AND CS (managed-system agent)
         breadcrumbs; this dual-source requirement is the qualifier
         for real user traffic, not just infrastructure noise.
       - MANAGED   TRAFFIC_SOURCE=CS    — confirmed traffic, but from
         managed systems (CS agent only, no Zscaler proxy hit) — NOT
         user traffic. Same disqualification logic as the CS-only
         rule in build_user_traffic_confirmed_prefixes.py.
       - INFERRED  everything else with an assigned firewall but no
         direct traffic confirmation: ZSCALER-only (small population,
         uncorroborated by CS — folded in here rather than given its
         own bucket), LOCATION-CONFIRMED, and ASSERTED-* rows.
     ROUTE_VALIDATED=Y required in all three tiers (routing-table
     confirmed FW assignment; independent of traffic-source confidence).
     Objects split at 500 raw-CIDR-equivalent members per firewall/tier
     into PART1/PART2/... suffixed objects (mirrors the manual 500-cap
     split used in the MID/WIN test case).

Written as a registry pattern (_CUSTOM_CLASSES) so additional custom
object classes — DC-related or otherwise — can be added the same way
without restructuring the builder.

Output:
  processed_outputs/canonical_custom_objects_vDATE.csv
  Net_Object/CUS-YYYYMMDD_vN/  (versioned dir + EDL/*.txt, same pattern as
  build_user_access_objects.py's UA-YYYYMMDD_vN/ and build_service_objects.py's
  SO-YYYYMMDD_vN/)

Usage:
  python3 build_custom_objects.py --dry-run
  python3 build_custom_objects.py
  python3 ipam-db.py --import processed_outputs/canonical_custom_objects_vDATE.csv \
      --type CANONICAL-CUSTOM-OBJECTS

Changelog:
  v1.8.0  2026-08-20  Real bug fix: LOCATIONS field had no size discipline,
                      unlike SUBNET_CIDRS (capped/split at
                      _EGRESS_SPLIT_CAP). build_egress_traffic_objects()
                      applies the full, unsplit location set to every
                      part -- fine when locations meant DC/campus names
                      (a handful of values), but today's retail_networks
                      merge (294,343 individually-named store subnets,
                      e.g. "ACTON MA - Store 00654") feeds thousands of
                      distinct location strings into firewalls like
                      RI-ONE-SEC-DMZ. EGRESS-INFERRED-PRIVATE-RETAIL-
                      RI-ONE-SEC-DMZ's LOCATIONS field hit 305,490 chars
                      (10,870 pipe-joined store names) -- past Python's
                      csv module default field_size_limit (131,072),
                      which caused ipam-db.py's count_rows() to raise
                      _csv.Error, silently caught by a bare except and
                      reported as 0 rows, tripping the Row-Count Collapse
                      Check on a genuinely valid 136-row file.
                      Fix: new _LOCATIONS_DISPLAY_CAP (100) applied in
                      to_dict(), the single serialization point every
                      object class already goes through -- same
                      choke-point discipline as ipam-db.py's row-collapse
                      gate. Location sets above the cap are summarized as
                      "<count> locations (list omitted -- N distinct
                      locations exceeds display cap; see
                      SOURCE_DATASETS for the full breakdown)" instead of
                      being pipe-joined in full. Sets at or under the cap
                      are unaffected -- byte-for-byte identical output to
                      v1.7.1 for every non-retail-heavy object (verified
                      against all 136 v20260820 objects: only the one
                      RI-ONE-SEC-DMZ retail-inferred object exceeds the
                      cap). MINOR bump: behavior change for a field's
                      content in the over-cap case, no schema/column
                      change. Downstream impact: any consumer reading
                      LOCATIONS for a retail-heavy CUSTOM_EGRESS object
                      now gets a summary string, not a full store list --
                      none of today's 3 downstream consumers (EDL
                      catalog UI, ipam-db.py import, Net_Object export)
                      parse LOCATIONS programmatically, all display it
                      as-is, so this is a pure display-format change, no
                      breakage.
  v1.7.1  2026-07-23  Dropped the APM registry dependency from the
                      'explicit' draft type entirely -- no _APM_ID_RE,
                      no required app_id, no format validation on it.
                      app_id/app_name are now purely optional freeform
                      notes (shown in the catalog UI, not validated or
                      looked up anywhere). Reflects a scope change: the
                      wizard's CIDR-list flow doesn't need or use an
                      external application registry -- just a label, a
                      CIDR list (typed or file-uploaded), and the same
                      known-address-space + overlap checks every other
                      object gets.
  v1.7.0  2026-07-23  New draft type: 'explicit' (alongside the original
                      'filter' type, still the default for backward
                      compatibility). An explicit draft is a hand-entered
                      CIDR list tied to an APM Application Id, no IPAM
                      filtering -- the CIDRs in the spec ARE the object.
                      New build_explicit_object() builder. New _APM_ID_RE
                      validates a hand-entered apm_id against the two
                      formats actually seen in the real APM-*.xlsx export
                      (APM+7digit legacy, 16-char hex current) -- confirmed
                      100% coverage, zero stragglers, across a 9,355-row
                      sample. This is the backend for the wizard's planned
                      "Internal object" flow: pick or define an APM ID,
                      paste a CIDR list, validate against known address
                      space and other apps' claimed CIDRs (that validation
                      lives in ccd_local_server.py's /api/validate-cidrs,
                      not here -- this script trusts whatever CIDR list a
                      draft file already contains, same as it trusts every
                      other draft type). SUPERSEDED by v1.7.1 above -- the
                      APM registry dependency described here was dropped.
  v1.6.0  2026-07-23  New: data-driven "draft" custom object classes.
                      build_from_spec() is a generic interpreter for the
                      same filter/group/name/split pattern add_custom_
                      object_class.py generates as Python source -- but
                      driven by a JSON spec at runtime instead. New
                      --draft-dir flag (default ./draft_obj) scans
                      draft_obj/*.json, validates each spec (fails closed:
                      a bad spec is skipped with a warning, never partially
                      applied, never crashes the run), and appends valid
                      ones to the registry as DRAFT_<label> entries. This
                      is the backend for a planned web-based class builder
                      in the EDL catalog: the browser only ever needs to
                      write a validated JSON spec file, never touch this
                      script's own source -- a much smaller trust boundary
                      than the codegen-and-patch approach
                      add_custom_object_class.py uses for permanent,
                      hand-editable classes. Both mechanisms coexist:
                      _CUSTOM_CLASSES for classes worth hand-tuning in
                      Python, draft_obj/ for anything built through a UI
                      or that doesn't need EGRESS_TRAFFIC-style nested
                      classification.
  v1.5.0  2026-07-23  Bugfix: --egress-dir default corrected from
                      "./processed_outputs" to "./FW-Egress_Out" —
                      build_IP_Network_Egress_FW_topology.py's own default
                      --out-ipam-dir is <base>/FW-Egress_Out, not
                      processed_outputs. The v1.2.0 default was never
                      verified against that script's actual behavior, only
                      against a manually-placed test copy of the topology
                      CSV. Corresponding fix in build_object_pipeline.py
                      v1.8.2 (Stage 0's explicit --egress-dir arg, added in
                      v1.8.1, pointed at the same wrong directory).
  v1.4.0  2026-07-23  PRIVATE-scope EGRESS_TRAFFIC objects further split by
                      ROUTING_DOMAIN — one object per distinct domain seen
                      in the data (Internal-HCB, Internal-PBM, Cloud-Azure,
                      Cloud-AWS, Cloud-GCP, COLO, Partner, Internet-Facing,
                      P2P-WAN), not collapsed into an HCB/PBM/OTHER
                      3-bucket scheme. Naming changed from EGRESS-<TIER>-
                      PRIVATE-<FW> to EGRESS-<TIER>-PRIVATE-<DOMAIN>-<FW>
                      (breaking rename of the PRIVATE objects introduced
                      in v1.3.0, one day old, not yet consumed downstream
                      — MINOR not MAJOR). DOMAIN is the ROUTING_DOMAIN
                      value with its Internal-/Cloud- prefix stripped and
                      uppercased (Internal-HCB -> HCB, Cloud-Azure ->
                      AZURE, etc.); a domain with no prefix (COLO, Partner)
                      keeps its own name. PUBLIC scope remains un-split —
                      CVS/Aetna's public IP space doesn't carry the same
                      per-domain distinction private RFC1918/CGNAT space
                      does. Each object's ROUTING_DOMAIN field is set to
                      the raw domain value (or MIXED if a FW/tier/domain
                      group somehow spans more than one raw string).
  v1.3.0  2026-07-23  EGRESS_TRAFFIC objects restructured: added a PUBLIC/
                      PRIVATE scope dimension, applied uniformly to all
                      three tiers. Object naming changed from
                      EGRESS-<TIER>-<FW> to EGRESS-<TIER>-<SCOPE>-<FW>
                      (breaking rename of every EGRESS_TRAFFIC object
                      introduced in v1.2.0 — those object names are one
                      day old and not yet consumed downstream, so treated
                      as MINOR rather than MAJOR). Reason: CVS/Aetna owns
                      real public IP space (e.g. 157.121.x.0/24 at Shea
                      DC) that legitimately shows up in managed-system
                      (CS-only) and inferred egress traffic — 16.3% of
                      MANAGED, 8.2% of INFERRED, 0.4% of VERIFIED are
                      public. Mixing that into RFC1918/CGNAT-space
                      objects would misrepresent the traffic's actual
                      scope for FW policy purposes, so public and private
                      now always get separate objects, never merged.
                      SCOPE=PUBLIC is not heritage-filtered — 34 of 2,046
                      public CIDRs (all INFERRED) belong to OMNICARE/
                      PARTNER/SWITCH heritage rather than CVS/Aetna; the
                      object's own HERITAGE field reflects this (MIXED
                      where applicable) rather than silently dropping
                      that space from the object.
  v1.2.0  2026-07-23  Added AETNA_HCB_172_COMBINED (6th object, additive
                      to the 5 per-location AETNA_HCB_172 objects — same
                      source rows, single cross-location EDL). Added
                      EGRESS_TRAFFIC class: new required input source
                      ent-ipdataset-EGRESS-FW-TOPOLOGY (--egress-dir),
                      independent of all_IP_networks. Builds VERIFIED/
                      MANAGED/INFERRED objects per EGRESS_FIREWALL_LOGICAL
                      (10 firewalls, all heritages) from TRAFFIC_SOURCE +
                      ROUTE_VALIDATED classification; see class docstring
                      above for the CS/ZS confidence-tier rules. Objects
                      >500 members split into PART1/PART2/... siblings.
                      Builder signature changed from builder_fn(ipam_rows,
                      dataset_version, verbose) to builder_fn(sources,
                      dataset_version, verbose) where sources is a dict
                      {'ipam_rows': [...], 'topology_rows': [...]} — every
                      registered builder updated to the new signature.
                      MINOR bump: new input source, new object classes,
                      internal signature change; output CSV schema
                      unchanged (same FIELDNAMES, same OBJECT_TYPE=CUSTOM
                      base).
  v1.1.0  2026-07-22  Generalized from CUSTOM_DC to CUSTOM. Renamed
                      build_custom_dc_objects.py -> build_custom_objects.py.
                      OBJECT_TYPE base value changed CUSTOM_DC -> CUSTOM;
                      AETNA_HCB_172's obj_type prefix changed to match
                      (CUSTOM_DC_AETNA_HCB_172 -> CUSTOM_AETNA_HCB_172).
                      Output filename stem canonical_custom_dc_objects ->
                      canonical_custom_objects; versioned Net_Object dir
                      prefix CDC- -> CUS-. This was originally scoped as
                      DC-specific from a misread of the request (the ask
                      was for general custom-object capability, using
                      USER_ACCESS only as a worked example of the
                      group-vs-object distinction, not as the target of
                      reclassification). AETNA_HCB_172 remains the first
                      registered class in _CUSTOM_CLASSES, not the only
                      intended use of the CUSTOM type. MINOR bump — schema
                      value change (OBJECT_TYPE), not just a rename.
  v1.0.0  2026-07-22  Initial build. AETNA_HCB_172 class — 5 objects
                      (one per DC location: Middletown/Windsor/Phoenix/
                      Hartford/Scottsdale), 853 subnets total, sourced
                      from all_IP_networks_v20260716r2.csv. Establishes
                      CUSTOM as a new base OBJECT_TYPE, distinct from
                      USER_ACCESS (which this data was originally, and
                      incorrectly, proposed to live under — DC subnets
                      are not "User Networks" traffic).
"""

import argparse
import csv
import glob
import ipaddress
import json
import os
import re
import sys
from datetime import datetime
from collections import defaultdict

VERSION    = "v1.8.0"
BUILD_DATE = datetime.now().strftime("%Y%m%d")

# v1.8.0: LOCATIONS has no per-part cap the way SUBNET_CIDRS does (see
# _EGRESS_SPLIT_CAP). Retail-heavy egress objects can carry thousands of
# individually-named store locations -- past this cap, summarize instead
# of pipe-joining the full set, to keep the serialized field well under
# Python csv's default field_size_limit (131,072 bytes) that
# ipam-db.py's count_rows() parses against.
_LOCATIONS_DISPLAY_CAP = 100


def _format_locations(locations):
    """Serialize a CanonicalObject's locations set for the LOCATIONS
    column. Pipe-joins as normal at or under _LOCATIONS_DISPLAY_CAP
    distinct values; above it, summarizes to a count rather than
    emitting a field large enough to hit downstream CSV field-size
    limits (real incident: RI-ONE-SEC-DMZ retail-inferred object hit
    10,870 locations / 305,490 chars after the retail_networks merge).
    """
    locs = sorted(locations)
    if len(locs) <= _LOCATIONS_DISPLAY_CAP:
        return '|'.join(locs)
    return (f'{len(locs)} locations (list omitted -- {len(locs)} distinct '
            f'locations exceeds the {_LOCATIONS_DISPLAY_CAP}-value display '
            f'cap; see SOURCE_DATASETS for the full breakdown)')

# ANSI
BLD = "\033[1m"; GRN = "\033[0;32m"; YEL = "\033[0;33m"
RED = "\033[0;31m"; RST = "\033[0m"

OUTPUT_STEM = "canonical_custom_objects"
FIELDNAMES  = [
    "OBJECT_NAME", "OBJECT_TYPE", "OBJECT_CLASS", "APP_ACRONYM",
    "SERVICE_ROLE", "HERITAGE", "ROUTING_DOMAIN",
    "MEMBER_IPS", "VIP_IPS", "SUBNET_CIDRS", "LOCATIONS",
    "MEMBER_COUNT", "VIP_COUNT", "SOURCE_DATASETS", "DATASET_VERSION",
    "APP_ARCHITECTURE", "ROLE_MAP", "SNAT_IPS", "SNAT_COUNT",
    "PORT_DEPS", "SERVER_PORTS", "CLIENT_PORTS", "SERVICE_DEPS",
    "PCI_SCOPE", "CRITICALITY", "NON_PROD",
]


def find_file(directory, glob_pattern):
    """Find most recent matching file in directory (reverse-sorted filename)."""
    matches = sorted(glob.glob(os.path.join(directory, glob_pattern)), reverse=True)
    return matches[0] if matches else None


def read_ccd_csv(path):
    """Read CCD-format CSV, skipping '#' comment lines throughout the file."""
    with open(path, newline='', encoding='utf-8-sig') as f:
        lines = [line for line in f if not line.startswith('#')]
    reader = csv.DictReader(lines)
    return list(reader)


def _collapse_cidrs(cidr_strs):
    """Return the minimal non-overlapping covering CIDR set, sorted.
    Invalid/unparseable entries are dropped rather than raising."""
    nets = []
    for c in cidr_strs:
        try:
            nets.append(ipaddress.ip_network(c.strip(), strict=False))
        except (ValueError, AttributeError):
            continue
    return sorted(ipaddress.collapse_addresses(nets), key=lambda n: (n.version, n))


# ---------------------------------------------------------------------------
# CanonicalObject — same shape as build_canonical_app_objects.py /
# build_user_access_objects.py's own copies. Each builder script in this
# platform owns its own copy rather than importing a shared module — this
# follows that existing convention.
# ---------------------------------------------------------------------------
class CanonicalObject:
    def __init__(self, name, obj_type, app_acronym=None, service_role=None,
                 heritage=None, routing_domain=None):
        self.name = name
        self.obj_type = obj_type          # granular OBJECT_CLASS
        self.app_acronym = app_acronym
        self.service_role = service_role
        self.heritage = heritage
        self.routing_domain = routing_domain
        self.member_ips = set()
        self.vip_ips = set()
        self.subnet_cidrs = set()
        self.locations = set()
        self.source_datasets = set()
        self.no_further_collapse = False
        # Schema v2 fields
        self.app_architecture = 'unknown'
        self.role_map         = {}
        self.snat_ips         = set()
        self.port_deps        = []
        self.server_ports     = []
        self.client_ports     = []
        self.service_deps     = []
        self.pci_scope        = 'UNKNOWN'
        self.criticality      = 'UNKNOWN'
        self.non_prod         = False

    def add_member(self, ip, canonical_location=None, source=None):
        if ip:
            ip_clean = ip.strip()
            try:
                ipaddress.ip_address(ip_clean)
                self.member_ips.add(ip_clean)
            except ValueError:
                pass
        if canonical_location:
            self.locations.add(canonical_location)
        if source:
            self.source_datasets.add(source)

    def to_dict(self, dataset_version):
        member_list = [str(ip) for ip in sorted(
            (ipaddress.ip_address(x) for x in self.member_ips),
            key=lambda a: (a.version, a)
        )]
        heritage = self.heritage
        if len(set(
            ('CVS' if h in ('CVS', 'CAREMARK') else
             'AETNA' if h in ('AETNA', 'HCB') else h)
            for h in [heritage or '']
        )) > 1:
            heritage = 'MIXED'

        def _fmt_pd(d):
            return f"{d['fr']}>{d['to']}:{d['ai']}:{d['pt']}/{d['pr']}"

        def _fmt_port(p):
            prefix = f"{p['ai']}:" if p.get('ai') else ''
            return f"{prefix}{p['pt']}/{p['pr']}"

        def _fmt_sd(s):
            return f"{s['nm']}:{s['dt']}" if s.get('dt') else s['nm']

        # Normalize OBJECT_TYPE to base class for downstream consumers.
        # CUSTOM added here as a new base type, alongside the bases
        # used by build_canonical_app_objects.py / build_user_access_objects.py.
        base_type = self.obj_type or ''
        for _base in ('APP', 'INFRA', 'SERVICE', 'DELIVERY', 'USER_ACCESS',
                      'UNALLOC', 'CUSTOM'):
            if base_type.upper().startswith(_base):
                base_type = _base
                break

        return {
            'OBJECT_NAME':      self.name,
            'OBJECT_TYPE':      base_type,
            'OBJECT_CLASS':     self.obj_type,
            'APP_ACRONYM':      self.app_acronym or '',
            'SERVICE_ROLE':     self.service_role or '',
            'HERITAGE':         heritage or '',
            'ROUTING_DOMAIN':   self.routing_domain or '',
            'MEMBER_IPS':       '|'.join(member_list),
            'VIP_IPS':          '|'.join(sorted(self.vip_ips)),
            'SUBNET_CIDRS':     '|'.join(
                                    str(c) for c in (
                                        sorted((ipaddress.ip_network(x, strict=False)
                                                for x in self.subnet_cidrs),
                                               key=lambda n: (n.version, n))
                                        if self.no_further_collapse
                                        else _collapse_cidrs(self.subnet_cidrs)
                                    )
                                ),
            'LOCATIONS':        _format_locations(self.locations),
            'MEMBER_COUNT':     len(member_list),
            'VIP_COUNT':        len(self.vip_ips),
            'SOURCE_DATASETS':  '|'.join(sorted(self.source_datasets)),
            'DATASET_VERSION':  dataset_version,
            'APP_ARCHITECTURE': self.app_architecture or 'unknown',
            'ROLE_MAP':         '|'.join(f"{ip}:{role}" for ip, role in sorted(self.role_map.items())),
            'SNAT_IPS':         '|'.join(sorted(self.snat_ips)),
            'SNAT_COUNT':       len(self.snat_ips),
            'PORT_DEPS':        '|'.join(_fmt_pd(d) for d in self.port_deps),
            'SERVER_PORTS':     '|'.join(_fmt_port(p) for p in self.server_ports),
            'CLIENT_PORTS':     '|'.join(_fmt_port(p) for p in self.client_ports),
            'SERVICE_DEPS':     '|'.join(_fmt_sd(s) for s in self.service_deps),
            'PCI_SCOPE':        self.pci_scope or 'UNKNOWN',
            'CRITICALITY':      self.criticality or 'UNKNOWN',
            'NON_PROD':         'Y' if self.non_prod else 'N',
        }


# ---------------------------------------------------------------------------
# AETNA_HCB_172 — first CUSTOM class
# ---------------------------------------------------------------------------

_AETNA_HCB_172_LOCATIONS = {
    'Middletown CT - Aetna MDC',
    'Windsor CT - Aetna WDC',
    'Phoenix AZ - Aetna DC',
    'Hartford CT - Aetna HQ',
    'Scottsdale AZ - Shea DC',
}

_AETNA_HCB_172_SLUG = {
    'Middletown CT - Aetna MDC': 'MIDDLETOWN-CT',
    'Windsor CT - Aetna WDC':    'WINDSOR-CT',
    'Phoenix AZ - Aetna DC':     'PHOENIX-AZ',
    'Hartford CT - Aetna HQ':    'HARTFORD-CT',
    'Scottsdale AZ - Shea DC':   'SCOTTSDALE-AZ',
}


def build_aetna_hcb_172_objects(ipam_rows, dataset_version, verbose=False):
    """
    AETNA-HCB-172-<LOCATION> — Aetna-heritage subnets in 172.16.0.0/12,
    one object per DC location. Filters all_IP_networks directly; no
    NET_TYPE tagging on source rows required.
    """
    full16 = ipaddress.ip_network('172.16.0.0/12')

    def _in_172(cidr):
        try:
            return ipaddress.ip_network(cidr, strict=False).subnet_of(full16)
        except Exception:
            return False

    grouped = defaultdict(list)  # location -> list of CIDR strings
    for row in ipam_rows:
        if (row.get('HERITAGE') or '').strip() != 'AETNA':
            continue
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        if loc not in _AETNA_HCB_172_LOCATIONS:
            continue
        cidr = (row.get('CIDR') or '').strip()
        if not cidr or not _in_172(cidr):
            continue
        grouped[loc].append(cidr)

    objects = {}
    for loc, cidrs in grouped.items():
        slug = _AETNA_HCB_172_SLUG[loc]
        obj_name = f'AETNA-HCB-172-{slug}'
        obj = CanonicalObject(
            name=obj_name,
            obj_type='CUSTOM_AETNA_HCB_172',
            heritage='AETNA',
            routing_domain='Internal-HCB',
        )
        obj.locations.add(loc)
        obj.subnet_cidrs.update(cidrs)
        obj.source_datasets.add('all_IP_networks')
        objects[obj_name] = obj
        if verbose:
            print(f'  {obj_name:<35} {len(cidrs):>4} CIDRs  ({loc})')

    return objects


def build_aetna_hcb_172_combined_objects(ipam_rows, dataset_version, verbose=False):
    """
    AETNA-HCB-172-COMBINED — the same source rows as build_aetna_hcb_172_objects
    (HERITAGE=AETNA, CIDR in 172.16.0.0/12, CANONICAL_LOCATION in the known
    DC-location set), merged into ONE cross-location object instead of one
    object per location. Additive: this sits alongside the 5 per-location
    objects, it does not replace them — a consumer that wants "all Aetna-172
    space, don't care which DC" gets a single EDL instead of having to union
    5 files themselves.
    """
    full16 = ipaddress.ip_network('172.16.0.0/12')

    def _in_172(cidr):
        try:
            return ipaddress.ip_network(cidr, strict=False).subnet_of(full16)
        except Exception:
            return False

    all_cidrs = []
    locs_seen = set()
    for row in ipam_rows:
        if (row.get('HERITAGE') or '').strip() != 'AETNA':
            continue
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        if loc not in _AETNA_HCB_172_LOCATIONS:
            continue
        cidr = (row.get('CIDR') or '').strip()
        if not cidr or not _in_172(cidr):
            continue
        all_cidrs.append(cidr)
        locs_seen.add(loc)

    if not all_cidrs:
        return {}

    obj_name = 'AETNA-HCB-172-COMBINED'
    obj = CanonicalObject(
        name=obj_name,
        obj_type='CUSTOM_AETNA_HCB_172_COMBINED',
        heritage='AETNA',
        routing_domain='Internal-HCB',
    )
    obj.locations.update(locs_seen)
    obj.subnet_cidrs.update(all_cidrs)
    obj.source_datasets.add('all_IP_networks')
    if verbose:
        print(f'  {obj_name:<35} {len(all_cidrs):>4} raw CIDRs  '
              f'({len(locs_seen)} locations merged)')

    return {obj_name: obj}


# ---------------------------------------------------------------------------
# EGRESS_TRAFFIC — per-firewall egress traffic objects, sourced from
# ent-ipdataset-EGRESS-FW-TOPOLOGY (build_IP_Network_Egress_FW_topology.py),
# NOT from all_IP_networks. See module docstring for the VERIFIED/MANAGED/
# INFERRED classification rules.
# ---------------------------------------------------------------------------

_EGRESS_SPLIT_CAP = 500  # max members per object before PART1/PART2/... split

_EGRESS_TIERS = ('VERIFIED', 'MANAGED', 'INFERRED')

_PRIVATE_SPACE = (
    ipaddress.ip_network('10.0.0.0/8'),
    ipaddress.ip_network('172.16.0.0/12'),
    ipaddress.ip_network('192.168.0.0/16'),
    ipaddress.ip_network('100.64.0.0/10'),   # CGNAT
)


def _is_public_cidr(cidr_str):
    """True if cidr_str is NOT RFC1918/CGNAT space (i.e. a publicly routable
    block). CVS/Aetna owns real public IP space that shows up in managed-
    system telemetry (e.g. 157.121.x.0/24 at Shea DC) — this is a legitimate,
    distinct traffic-scope, not an anomaly, and every FW-specific tier gets
    a PUBLIC and a PRIVATE object rather than mixing the two."""
    try:
        net = ipaddress.ip_network(cidr_str)
    except Exception:
        return False
    return not any(net.overlaps(p) for p in _PRIVATE_SPACE)


def _egress_tier(traffic_source, confidence):
    """Classify a topology row into VERIFIED / MANAGED / INFERRED / None.
    None = no firewall assignment at all (CONFIDENCE=NONE), excluded entirely.
    """
    if confidence == 'NONE':
        return None
    if traffic_source == 'BOTH':
        return 'VERIFIED'
    if traffic_source == 'CS':
        return 'MANAGED'
    # ZSCALER-only + LOCATION-CONFIRMED + ASSERTED-* all fall here
    return 'INFERRED'


def _fw_slug(fw_logical):
    return re.sub(r'[^A-Z0-9]+', '-', fw_logical.upper()).strip('-')


def _private_domain_bucket(routing_domain):
    """Slug a ROUTING_DOMAIN value into an object-name-safe bucket, one
    bucket per distinct domain actually present in the data (Internal-HCB,
    Internal-PBM, Cloud-Azure, Cloud-AWS, Cloud-GCP, COLO, Partner,
    Internet-Facing, P2P-WAN, ...) rather than merging everything outside
    HCB/PBM into a single OTHER catch-all — each domain gets its own
    FW-specific object."""
    d = (routing_domain or '').strip()
    if not d:
        return 'UNKNOWN'
    for prefix in ('Internal-', 'Cloud-'):
        if d.startswith(prefix):
            d = d[len(prefix):]
            break
    return re.sub(r'[^A-Za-z0-9]+', '-', d).upper().strip('-') or 'UNKNOWN'


def build_egress_traffic_objects(topology_rows, dataset_version, verbose=False):
    """
    EGRESS-<TIER>-<SCOPE>-<FIREWALL>[-PARTn] for PUBLIC scope; PRIVATE scope
    is further split by routing domain into EGRESS-<TIER>-PRIVATE-<HCB|PBM|
    OTHER>-<FIREWALL>[-PARTn]. All EGRESS_FIREWALL_LOGICAL values, all
    heritages. PUBLIC isn't domain-split — CVS/Aetna's public space doesn't
    carry the same HCB/PBM heritage distinction that private RFC1918/CGNAT
    space does.
    """
    # (fw, tier, scope, domain_bucket) -> set of CIDR strings; domain_bucket
    # is None for PUBLIC (no split)
    grouped = defaultdict(set)
    heritages = defaultdict(set)
    locations = defaultdict(set)
    raw_domains = defaultdict(set)  # (fw,tier,scope,bucket) -> set of raw ROUTING_DOMAIN strings seen

    for row in topology_rows:
        if (row.get('ROUTE_VALIDATED') or '').strip() != 'Y':
            continue
        fw = (row.get('EGRESS_FIREWALL_LOGICAL') or '').strip()
        if not fw:
            continue
        tier = _egress_tier(
            (row.get('TRAFFIC_SOURCE') or '').strip(),
            (row.get('CONFIDENCE') or '').strip(),
        )
        if tier is None:
            continue
        cidr = (row.get('CIDR') or '').strip()
        if not cidr:
            continue
        scope = 'PUBLIC' if _is_public_cidr(cidr) else 'PRIVATE'
        raw_rd = (row.get('ROUTING_DOMAIN') or '').strip()
        domain_bucket = _private_domain_bucket(raw_rd) if scope == 'PRIVATE' else None
        key = (fw, tier, scope, domain_bucket)
        grouped[key].add(cidr)
        her = (row.get('HERITAGE') or '').strip()
        if her:
            heritages[key].add(her)
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        if loc:
            locations[key].add(loc)
        if raw_rd:
            raw_domains[key].add(raw_rd)

    objects = {}
    for (fw, tier, scope, domain_bucket), cidr_strs in sorted(grouped.items(), key=lambda kv: tuple(x or '' for x in kv[0])):
        collapsed = _collapse_cidrs(cidr_strs)
        n_parts = max(1, -(-len(collapsed) // _EGRESS_SPLIT_CAP))  # ceil div
        her_set = heritages[(fw, tier, scope, domain_bucket)]
        heritage = 'MIXED' if len(her_set) > 1 else (next(iter(her_set)) if her_set else None)
        rd_set = raw_domains[(fw, tier, scope, domain_bucket)]
        routing_domain = 'MIXED' if len(rd_set) > 1 else (next(iter(rd_set)) if rd_set else None)
        slug = _fw_slug(fw)
        scope_label = f'{scope}-{domain_bucket}' if domain_bucket else scope
        obj_type_suffix = f'{tier}_{scope}_{domain_bucket}' if domain_bucket else f'{tier}_{scope}'

        for part in range(1, n_parts + 1):
            chunk = collapsed[(part - 1) * _EGRESS_SPLIT_CAP: part * _EGRESS_SPLIT_CAP]
            suffix = f'-PART{part}' if n_parts > 1 else ''
            obj_name = f'EGRESS-{tier}-{scope_label}-{slug}{suffix}'
            obj = CanonicalObject(
                name=obj_name,
                obj_type=f'CUSTOM_EGRESS_{obj_type_suffix}',
                heritage=heritage,
                routing_domain=routing_domain,
            )
            obj.no_further_collapse = True  # already collapsed above; keep chunk boundaries intact
            obj.locations.update(locations[(fw, tier, scope, domain_bucket)])
            obj.subnet_cidrs.update(str(c) for c in chunk)
            obj.source_datasets.add('ent-ipdataset-EGRESS-FW-TOPOLOGY')
            objects[obj_name] = obj

        if verbose:
            part_note = f' -> {n_parts} parts' if n_parts > 1 else ''
            print(f'  EGRESS-{tier:<9} {scope_label:<12} {fw:<20} {len(collapsed):>5} CIDRs{part_note}')

    return objects


# ---------------------------------------------------------------------------
# Draft classes — data-driven custom object classes defined as JSON specs in
# a draft directory (default ./draft_obj/), rather than hand-written Python
# functions. This is how the web wizard (and add_custom_object_class.py's
# --write-draft mode) add new classes without ever touching this file's own
# source: a spec is just data, validated and interpreted at runtime by
# build_from_spec() below. Contrast with add_custom_object_class.py's
# original design, which generated and inserted real Python source — that
# still exists for people who want a class permanently hand-editable in this
# file, but drafts are the safer default for anything built through a UI.
# ---------------------------------------------------------------------------

def build_from_spec(spec, source_rows, dataset_version, verbose=False):
    """Generic interpreter for a draft custom object class spec. Implements
    the same filter -> [group] -> name -> [split] pattern as the hand-written
    classes above (AETNA_HCB_172 etc.), driven entirely by spec data.

    Expected spec shape (see draft_obj/*.json or add_custom_object_class.py's
    collect_spec()):
      label, source ('ipam'|'topology'), cidr_field, heritage_field,
      location_field, routing_domain_field, filters (list of
      {type, field, value|values|supernet}), group (bool), group_field,
      name_template, obj_type, split_cap (int or None).
    """
    label = spec['label']
    cidr_field = spec.get('cidr_field') or 'CIDR'
    heritage_field = spec.get('heritage_field') or None
    location_field = spec.get('location_field') or None
    routing_domain_field = spec.get('routing_domain_field') or None
    filters = spec.get('filters') or []
    group = bool(spec.get('group'))
    group_field = spec.get('group_field') or None
    name_template = spec.get('name_template') or label.replace('_', '-')
    obj_type = spec.get('obj_type') or f'CUSTOM_{label}'
    split_cap = spec.get('split_cap') or None
    source_dataset_label = spec.get('source_dataset_label', 'draft')

    def row_matches(row):
        for f in filters:
            field = f.get('field', '')
            val = (row.get(field) or '').strip()
            ftype = f.get('type')
            if ftype == 'equals':
                if val != f.get('value'):
                    return False
            elif ftype == 'not_equals':
                if val == f.get('value'):
                    return False
            elif ftype == 'in':
                if val not in (f.get('values') or []):
                    return False
            elif ftype == 'cidr_within':
                try:
                    if not ipaddress.ip_network(val, strict=False).subnet_of(
                            ipaddress.ip_network(f.get('supernet'))):
                        return False
                except (ValueError, AttributeError, TypeError):
                    return False
            else:
                return False  # unknown filter type -- fail closed, match nothing
        return True

    grouped = defaultdict(set)
    heritages = defaultdict(set)
    locations = defaultdict(set)
    routing_domains = defaultdict(set)

    for row in source_rows:
        if not row_matches(row):
            continue
        cidr = (row.get(cidr_field) or '').strip()
        if not cidr:
            continue
        key = (row.get(group_field) or '').strip() if group else '__ALL__'
        grouped[key].add(cidr)
        if heritage_field:
            her = (row.get(heritage_field) or '').strip()
            if her:
                heritages[key].add(her)
        if location_field:
            loc = (row.get(location_field) or '').strip()
            if loc:
                locations[key].add(loc)
        if routing_domain_field:
            rd = (row.get(routing_domain_field) or '').strip()
            if rd:
                routing_domains[key].add(rd)

    if not grouped:
        return {}

    objects = {}
    for key, cidr_strs in sorted(grouped.items()):
        collapsed = _collapse_cidrs(cidr_strs)
        if not collapsed:
            continue
        base_name = name_template.format(group=key) if group else name_template

        her_set = heritages[key]
        heritage = 'MIXED' if len(her_set) > 1 else (next(iter(her_set)) if her_set else None)
        rd_set = routing_domains[key]
        routing_domain = 'MIXED' if len(rd_set) > 1 else (next(iter(rd_set)) if rd_set else None)

        n_parts = max(1, -(-len(collapsed) // split_cap)) if split_cap else 1
        for part in range(1, n_parts + 1):
            chunk = collapsed[(part - 1) * split_cap: part * split_cap] if split_cap else collapsed
            suffix = f'-PART{part}' if n_parts > 1 else ''
            obj_name = f'{base_name}{suffix}'
            obj = CanonicalObject(
                name=obj_name,
                obj_type=obj_type,
                heritage=heritage,
                routing_domain=routing_domain,
            )
            obj.no_further_collapse = True
            obj.locations.update(locations[key])
            obj.subnet_cidrs.update(str(c) for c in chunk)
            obj.source_datasets.add(source_dataset_label)
            objects[obj_name] = obj

        if verbose:
            note = f' -> {n_parts} parts' if n_parts > 1 else ''
            print(f'  {base_name:<40} {len(collapsed):>5} CIDRs{note}')

    return objects


_DRAFT_REQUIRED_FIELDS = {'label', 'source'}
_DRAFT_VALID_SOURCES = ('ipam', 'topology')
_DRAFT_VALID_FILTER_TYPES = ('equals', 'not_equals', 'in', 'cidr_within')


def _validate_draft_spec(spec):
    """Returns (ok, error_message). Fails closed -- any structural problem
    means this draft is skipped entirely rather than partially applied.
    Dispatches on spec.get('type', 'filter'):
      'filter'   (default, backward compatible) -- the original filter/
                 group/name/split spec, see build_from_spec().
      'explicit' -- a literal, hand-entered (or file-uploaded) CIDR list,
                 see build_explicit_object(). No IPAM filtering happens for
                 this type -- the CIDRs ARE the object, as typed/uploaded
                 and validated at save time by ccd_local_server.py's
                 /api/validate-cidrs. app_id, if given, is a freeform note
                 (no registry, no format requirement) -- purely descriptive.
    """
    if not isinstance(spec, dict):
        return False, 'spec is not a JSON object'
    spec_type = spec.get('type', 'filter')
    if spec_type not in ('filter', 'explicit'):
        return False, f"type must be 'filter' or 'explicit', got {spec_type!r}"

    label = spec.get('label')
    if not isinstance(label, str) or not re.match(r'^[A-Za-z][A-Za-z0-9_]*$', label):
        return False, f'label {label!r} is not a valid identifier'

    if spec_type == 'explicit':
        cidrs = spec.get('cidrs')
        if not isinstance(cidrs, list) or not cidrs:
            return False, 'cidrs must be a non-empty list'
        for c in cidrs:
            try:
                ipaddress.ip_network(c, strict=False)
            except (ValueError, TypeError):
                return False, f'invalid CIDR in cidrs: {c!r}'
        return True, ''

    # spec_type == 'filter' -- original validation, unchanged
    missing = _DRAFT_REQUIRED_FIELDS - set(spec.keys())
    if missing:
        return False, f'missing required field(s): {sorted(missing)}'
    if spec.get('source') not in _DRAFT_VALID_SOURCES:
        return False, f'source must be one of {_DRAFT_VALID_SOURCES}'
    for f in spec.get('filters') or []:
        if not isinstance(f, dict) or f.get('type') not in _DRAFT_VALID_FILTER_TYPES:
            return False, f'invalid filter entry: {f!r}'
        if not isinstance(f.get('field'), str) or not f.get('field'):
            return False, f'filter missing field name: {f!r}'
    if spec.get('group') and not spec.get('group_field'):
        return False, 'group=true requires group_field'
    split_cap = spec.get('split_cap')
    if split_cap is not None and (not isinstance(split_cap, int) or split_cap <= 0):
        return False, f'split_cap must be a positive integer, got {split_cap!r}'
    return True, ''


def build_explicit_object(spec, dataset_version, verbose=False):
    """Builds a single CanonicalObject from a hand-entered or file-uploaded
    CIDR list -- no IPAM filtering, the CIDRs in the spec ARE the object.
    Intended for internal application objects created through the wizard:
    paste or upload a CIDR list, validate against known address space and
    other objects' claimed CIDRs (that validation happens at save time,
    server-side -- this function trusts the spec it's given, same as every
    other draft type). app_id/app_name are optional freeform notes only,
    no registry lookup or format requirement.
    """
    label = spec['label']
    app_id = spec.get('app_id') or ''
    app_name = spec.get('app_name') or ''
    cidrs = spec['cidrs']

    collapsed = _collapse_cidrs(cidrs)
    if not collapsed:
        return {}

    obj_name = spec.get('name_template') or label.replace('_', '-')
    obj = CanonicalObject(
        name=obj_name,
        obj_type=f'CUSTOM_APP_{label}',
        heritage=spec.get('heritage') or None,
    )
    obj.no_further_collapse = True
    obj.subnet_cidrs.update(str(c) for c in collapsed)
    obj.source_datasets.add(f'manual-entry:{app_id}' if app_id else 'manual-entry')
    if app_name:
        obj.locations.add(app_name)  # repurposed field, shows in catalog UI as context

    if verbose:
        tag = f' (app_id {app_id})' if app_id else ''
        print(f'  {obj_name:<40} {len(collapsed):>5} CIDRs  explicit{tag}')

    return {obj_name: obj}


def _load_draft_classes(draft_dir):
    """Scan draft_dir/*.json, validate each spec, return a list of
    (label, builder_fn) registry entries -- same shape as _CUSTOM_CLASSES,
    appended to it at runtime. A draft that fails validation is skipped with
    a printed warning, never partially applied, never allowed to crash the
    run. Draft labels are prefixed DRAFT_ in the registry so they're visually
    distinct from hand-written classes until promoted (see README note in
    draft_obj/ tooling)."""
    entries = []
    if not draft_dir or not os.path.isdir(draft_dir):
        return entries
    for path in sorted(glob.glob(os.path.join(draft_dir, '*.json'))):
        fname = os.path.basename(path)
        try:
            with open(path, encoding='utf-8') as f:
                spec = json.load(f)
        except (OSError, ValueError) as e:
            print(f'  [WARN] draft {fname}: unreadable JSON ({e}) -- skipping')
            continue
        ok, err = _validate_draft_spec(spec)
        if not ok:
            print(f'  [WARN] draft {fname}: {err} -- skipping')
            continue
        spec = dict(spec)  # own copy -- avoid late-binding surprises in the closure below
        label = spec['label']

        if spec.get('type', 'filter') == 'explicit':
            def _make_explicit_builder(spec=spec):
                return lambda sources, dv, verbose: build_explicit_object(spec, dv, verbose)
            entries.append((f'DRAFT_{label}', _make_explicit_builder()))
            continue

        spec.setdefault(
            'source_dataset_label',
            'ent-ipdataset-EGRESS-FW-TOPOLOGY' if spec['source'] == 'topology'
            else 'all_IP_networks')
        source_key = 'topology_rows' if spec['source'] == 'topology' else 'ipam_rows'

        def _make_builder(spec=spec, source_key=source_key):
            return lambda sources, dv, verbose: build_from_spec(spec, sources[source_key], dv, verbose)

        entries.append((f'DRAFT_{label}', _make_builder()))
    return entries


# ---------------------------------------------------------------------------
# Registry of CUSTOM object classes — add future classes here, each as
# (label, builder_fn) where builder_fn(sources, dataset_version, verbose)
# -> dict of {object_name: CanonicalObject}. `sources` is a dict with keys
# 'ipam_rows' and 'topology_rows' — a builder pulls whichever it needs.
# ---------------------------------------------------------------------------
_CUSTOM_CLASSES = [
    ('AETNA_HCB_172',          lambda sources, dv, verbose: build_aetna_hcb_172_objects(sources['ipam_rows'], dv, verbose)),
    ('AETNA_HCB_172_COMBINED', lambda sources, dv, verbose: build_aetna_hcb_172_combined_objects(sources['ipam_rows'], dv, verbose)),
    ('EGRESS_TRAFFIC',         lambda sources, dv, verbose: build_egress_traffic_objects(sources['topology_rows'], dv, verbose)),
]


def build_custom_objects_from_registry(sources, dataset_version, verbose=False, draft_dir=None):
    """Run every registered CUSTOM class builder and merge results. If
    draft_dir is given, also scans it for draft_obj/*.json specs (see
    _load_draft_classes) and runs those too -- draft classes are data-driven
    and never touch this file's own source code."""
    all_objects = {}
    classes = list(_CUSTOM_CLASSES)
    draft_entries = _load_draft_classes(draft_dir)
    if draft_entries:
        classes.extend(draft_entries)
        if verbose:
            print(f'\n  Loaded {len(draft_entries)} draft class(es) from {draft_dir}')
    for label, builder_fn in classes:
        if verbose:
            print(f'\n  [{label}]')
        objs = builder_fn(sources, dataset_version, verbose=verbose)
        all_objects.update(objs)
        if verbose:
            print(f'  {label} objects: {len(objs)}')
    return all_objects


# ---------------------------------------------------------------------------
# EDL export — Net_Object/CUS-YYYYMMDD_vN/EDL/*.txt
# Mirrors build_user_access_objects.py's _write_edl_files() pattern so
# build_edl_catalog.py can discover this the same way as every other object
# family.
# ---------------------------------------------------------------------------
def _write_edl_files(objects, edl_dir):
    os.makedirs(edl_dir, exist_ok=True)
    written = set()
    for obj in objects:
        if obj.subnet_cidrs:
            cidrs = [str(c) for c in sorted(
                (ipaddress.ip_network(x, strict=False) for x in obj.subnet_cidrs),
                key=lambda n: (n.version, n)
            )]
        else:
            cidrs = [str(ip) + '/32' for ip in sorted(
                (ipaddress.ip_address(x) for x in obj.member_ips),
                key=lambda a: (a.version, a)
            )]
        if not cidrs:
            continue
        path = os.path.join(edl_dir, f'{obj.name}.txt')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(f'# {obj.name}\n')
            f.write(f'# CCD Platform — build_custom_objects.py {VERSION}\n')
            f.write(f'# Generated: {BUILD_DATE}\n')
            for c in cidrs:
                f.write(f'{c}\n')
        written.add(obj.name)
    return written


def main():
    p = argparse.ArgumentParser(
        description=f"CCD Platform — build_custom_objects.py {VERSION}"
    )
    p.add_argument("--ipam-dir", dest="ipam_dir", default="./ipam-db",
                    help="ipam-db/ directory (default: ./ipam-db)")
    p.add_argument("--egress-dir", dest="egress_dir", default="./FW-Egress_Out",
                    help="Directory containing ent-ipdataset-EGRESS-FW-TOPOLOGY-v*.csv "
                         "(default: ./FW-Egress_Out — matches "
                         "build_IP_Network_Egress_FW_topology.py's own default "
                         "--out-ipam-dir; override if that script was run with a "
                         "non-default --out-ipam-dir)")
    p.add_argument("--out-dir", dest="out_dir", default="./processed_outputs",
                    help="Output directory (default: ./processed_outputs)")
    p.add_argument("--net-object-dir", dest="net_object_dir", default="./Net_Object",
                    help="Net_Object/ root for versioned CUS-YYYYMMDD_vN/ output "
                         "with EDL files (default: ./Net_Object)")
    p.add_argument("--draft-dir", dest="draft_dir", default="./draft_obj",
                    help="Directory of draft_obj/*.json custom object class "
                         "specs, applied alongside the hand-written classes "
                         "in _CUSTOM_CLASSES (default: ./draft_obj — pass "
                         "'' or a nonexistent path to disable)")
    p.add_argument("--dry-run", dest="dry_run", action="store_true")
    p.add_argument("-V", "--version", action="version", version=f"%(prog)s {VERSION}")
    args = p.parse_args()

    print(f"\nbuild_custom_objects.py {VERSION}")
    print(f"  ipam-dir : {args.ipam_dir}")
    print(f"  out-dir  : {args.out_dir}")
    if args.dry_run:
        print(f"  DRY RUN  : no files written")
    print()

    print("[1/3] Loading datasets...")
    ipam_path = find_file(args.ipam_dir, "all_IP_networks_v*.csv")
    if not ipam_path:
        print(f"{RED}Error: all_IP_networks not found in {args.ipam_dir}{RST}", file=sys.stderr)
        sys.exit(1)
    ipam_rows = read_ccd_csv(ipam_path)
    print(f"  all_IP_networks : {len(ipam_rows):,} rows  ({os.path.basename(ipam_path)})")

    m = re.search(r'_v(\d{8}(?:r\d+)?)', os.path.basename(ipam_path))
    dataset_version = m.group(1) if m else BUILD_DATE

    topology_path = find_file(args.egress_dir, "ent-ipdataset-EGRESS-FW-TOPOLOGY-v*.csv")
    if not topology_path:
        print(f"{YEL}Warning: ent-ipdataset-EGRESS-FW-TOPOLOGY not found in "
              f"{args.egress_dir} — EGRESS_TRAFFIC class will be skipped{RST}")
        topology_rows = []
    else:
        topology_rows = read_ccd_csv(topology_path)
        print(f"  EGRESS-FW-TOPOLOGY : {len(topology_rows):,} rows  "
              f"({os.path.basename(topology_path)})")

    sources = {'ipam_rows': ipam_rows, 'topology_rows': topology_rows}

    print("\n[2/3] Building CUSTOM_Objects...")
    objects = build_custom_objects_from_registry(
        sources, dataset_version, verbose=True, draft_dir=args.draft_dir)

    total_subnets = sum(len(o.subnet_cidrs) for o in objects.values())
    total_hosts   = sum(len(o.member_ips)   for o in objects.values())
    print(f"\n  Total: {len(objects)} objects  "
          f"({total_subnets} subnets  {total_hosts:,} hosts)")

    print(f"\n[3/3] Writing output...")
    out_fname = f"{OUTPUT_STEM}_v{BUILD_DATE}.csv"
    out_path  = os.path.join(args.out_dir, out_fname)

    if args.dry_run:
        print(f"  {YEL}[DRY RUN] Would write: {out_path}  ({len(objects)} objects){RST}")
        for obj in sorted(objects.values(), key=lambda o: o.name):
            d = obj.to_dict(dataset_version)
            print(f"    {d['OBJECT_NAME']:<35} {d['OBJECT_TYPE']:<12} "
                  f"{len(obj.subnet_cidrs):>4} raw CIDRs  {d['LOCATIONS']}")
        return

    os.makedirs(args.out_dir, exist_ok=True)
    all_objs = sorted(objects.values(), key=lambda o: o.name)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        f.write(f"#STEM={OUTPUT_STEM}\n")
        f.write(f"#VERSION=v{BUILD_DATE}\n")
        f.write(f"#ROWS={len(all_objs)}\n")
        f.write(f"#BUILT_BY=build_custom_objects.py {VERSION}\n")
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        for obj in all_objs:
            writer.writerow(obj.to_dict(dataset_version))

    print(f"{GRN}✓ Written: {out_path}  ({len(all_objs)} objects){RST}")

    # Versioned Net_Object/CUS-YYYYMMDD_vN/ output with real EDL files
    _cdc_base  = args.net_object_dir
    _prefix    = f'CUS-{BUILD_DATE}_v'
    _existing  = sorted(
        [d for d in (os.listdir(_cdc_base) if os.path.isdir(_cdc_base) else [])
         if re.match(rf'^CUS-{BUILD_DATE}_v(\d+)$', d)],
        key=lambda d: int(re.search(r'_v(\d+)$', d).group(1))
    )
    _next_n  = (int(re.search(r'_v(\d+)$', _existing[-1]).group(1)) + 1) if _existing else 1
    _cdc_dir = os.path.join(_cdc_base, f'{_prefix}{_next_n}')
    _edl_dir = os.path.join(_cdc_dir, 'EDL')

    os.makedirs(_cdc_dir, exist_ok=True)
    _ver_cat_path = os.path.join(_cdc_dir, out_fname)
    with open(_ver_cat_path, "w", newline="", encoding="utf-8") as f:
        f.write(f"#STEM={OUTPUT_STEM}\n")
        f.write(f"#VERSION=v{BUILD_DATE}\n")
        f.write(f"#ROWS={len(all_objs)}\n")
        f.write(f"#BUILT_BY=build_custom_objects.py {VERSION}\n")
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        for obj in all_objs:
            writer.writerow(obj.to_dict(dataset_version))

    edl_written = _write_edl_files(all_objs, _edl_dir)
    print(f"{GRN}✓ Versioned dir: {_cdc_dir}  "
          f"({len(edl_written)}/{len(all_objs)} objects got an EDL file){RST}")

    print(f"\n  Next steps:")
    print(f"    python3 ipam-db.py --import {out_path} --type CANONICAL-CUSTOM-OBJECTS")


if __name__ == "__main__":
    main()
