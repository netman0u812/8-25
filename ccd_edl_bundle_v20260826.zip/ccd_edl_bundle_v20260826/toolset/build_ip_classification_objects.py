#!/usr/bin/env python3
"""
build_ip_classification_objects.py  v1.3.0  —  CCD Platform

CCD Platform — IP Classification EDL Object Builder

Generates EDL address objects from registered ipdatasets that represent
infrastructure, partner, and public/private IP space. Fills the two empty
catalog families (external_no, partner_no) in the EDL model and adds
fw_infra and fw_mgmt families.

Output families:
  external_no  — CVS/Aetna public IP classification objects
                 CVS_INTERNET_FACING_{HERITAGE}_{ZONE}
                 CVS_INTERNAL_PUBLIC_{HERITAGE}_{ZONE}

  partner_no   — Third-party partner connectivity objects
                 VPN_PARTNER_{PEER_KEY}   (partner-side protected subnets)
                 CVS_VPN_PROTECTED_{PEER_KEY} (CVS-side subnets per tunnel)
                 P2P_PARTNER_{PARTNER}    (P2P/MPLS partner-side subnets)
                 CVS_P2P_PROTECTED_{PARTNER} (CVS-side P2P subnets)
                 PARTNER_PROVIDER_{NAME}  (external provider IP space)

  fw_infra     — Firewall infrastructure interface objects
                 FW_INTF_OUTSIDE_{ZONE}   (outside/egress interface CIDRs)
                 FW_INTF_INSIDE_{ZONE}    (inside interface CIDRs)
                 F5_VIP_{HERITAGE}_{ZONE}
                 ZPA_CONNECTOR_{SITE}

  fw_mgmt      — Egress FW management IP objects (one per EGR_CODE cluster)
                 FW_MGMT_{EGR_CODE}       e.g. FW_MGMT_EGR_MDC
                 FW_MGMT_ALL_EGRESS       all 38 egress FW management IPs
                 Source: egress_fw_mgmt_ips_v*.csv (MGMT_IP field, /32)
                 Use: Panorama/FMC management access rules, policy scoping

Source datasets (auto-discovered from ipam-db/):
  public_ipv4_ipam           — Internet-facing CVS/Aetna IANA subnets
  private_ipv4_ipam          — Internally-routed CVS/Aetna IANA subnets
  partner_provider_ipv4_ipam — External partner/provider IP space
  ent-ipdataset-FW-INTERFACE-INVENTORY (NAMEIF: Inside/Outside/mgmt)
  ent-ipdataset-VPN-PROTECTED-SUBNETS  (CIDR, PEER_IP, CVS_LOCATION)
  ent-ipdataset-P2P-PROTECTED-SUBNETS  (CIDR, DIRECTION, PARTNER_NAME)
  ent-ipdataset-P2P-FTD-PROTECTED-SUBNETS
  ent-ipdataset-F5-VIP-REGISTRY
  ent-ipdataset-ZPA-CONNECTOR-REGISTRY
  egress_fw_mgmt_ips_v*.csv (EGR_CODE, HOSTNAME, MGMT_IP)

Confirmed schemas (2026-08-23 Yggdrasil):
  VPN-PROTECTED-SUBNETS: IP_NETWORK, PARTNER_NAME, GATEWAY, PEER_IP,
    IKE_VERSION, CIDR, CVS_LOCATION, CVS_RD, GEO_COUNTRY, ...
    No DIRECTION column — CVS_LOCATION populated = CVS side, empty = partner
  P2P-PROTECTED-SUBNETS: IP_NETWORK, PARTNER_NAME, CONTEXT_HOSTNAME,
    GATEWAY_DEVICE, DIRECTION (uppercase), CIDR, CVS_LOCATION, ...
  FW-INTERFACE-INVENTORY: FW_NAME, FW_TYPE, INTERFACE, NAMEIF (Inside/
    Outside/mgmt), IP_ADDRESS, MASK_LENGTH, CIDR, ZONE, ROUTING_DOMAIN,
    CANONICAL_LOCATION — no EGRESS_CLUSTER field; derive zone from NAMEIF
  egress_fw_mgmt_ips: EGRESS_FIREWALL_LOGICAL, HOSTNAME, MGMT_IP, EGR_CODE

Usage:
  python3 build_ip_classification_objects.py
  python3 build_ip_classification_objects.py --base /path/to/IP_Lookup
  python3 build_ip_classification_objects.py --family fw_mgmt
  python3 build_ip_classification_objects.py --dry-run
"""

__version__ = '1.3.0'
# v1.3.0  2026-08-23  Added fw_mgmt family — one EDL object per EGR_CODE
#          cluster (FW_MGMT_EGR_MDC, FW_MGMT_EGR_WDC, etc.) plus
#          FW_MGMT_ALL_EGRESS aggregate covering all 38 egress FW
#          management IPs as /32 host routes. Source: egress_fw_mgmt_ips
#          auto-discovered from ipam-db/. Use: Panorama/FMC management
#          access rules, policy scope targeting by cluster.
# v1.2.0  2026-08-23  Fixed output path: all families now write to
#          Net_Object/IPDATASET-vDATE/edl/ (flat, lowercase).
# v1.1.0  2026-08-23  Fixed field names against real Yggdrasil schemas.
#          VPN-PROTECTED-SUBNETS: no DIRECTION column — use CVS_LOCATION
#          to distinguish CVS vs partner subnets (populated = CVS side,
#          empty = partner). Group by PEER_IP since PARTNER_NAME is often
#          blank. CIDR field confirmed as 'CIDR'.
#          P2P-PROTECTED-SUBNETS: DIRECTION is uppercase. PARTNER_NAME
#          is populated. CIDR confirmed.
#          FW-INTERFACE-INVENTORY: NAMEIF field (Inside/Outside/mgmt)
#          determines zone. CIDR field confirmed. No EGRESS_CLUSTER —
#          zone derived from NAMEIF + ROUTING_DOMAIN.
# v1.0.0  2026-08-23  Initial build — three families: external_no,
#          partner_no, fw_infra. Name corrected from build_ipdataset_objects
#          (name collision with existing Stage 2.5 Cloud Services script).

import argparse
import csv
import glob
import os
import re
import sys
from collections import defaultdict
from datetime import date

SEP = '─' * 62
TODAY = date.today().strftime('%Y%m%d')
SCRIPT_NAME = os.path.basename(__file__)
FAMILIES = ['external_no', 'partner_no', 'fw_infra', 'fw_mgmt']


# ── Helpers ───────────────────────────────────────────────────────────────────

def edl_header(name, cls, source, cidr_count):
    return (
        f'# {name}\n'
        f'# Class: {cls}\n'
        f'# Generated by {SCRIPT_NAME} v{__version__}\n'
        f'# Source: {source}\n'
        f'# CIDRs: {cidr_count}\n'
    )


def find_latest(pattern):
    matches = sorted(glob.glob(pattern), key=os.path.getmtime, reverse=True)
    return matches[0] if matches else None


def discover_datasets(base, ipam_dir):
    patterns = {
        'public_ipv4_ipam':          os.path.join(ipam_dir, 'public_ipv4_ipam_v*.csv'),
        'private_ipv4_ipam':         os.path.join(ipam_dir, 'private_ipv4_ipam_v*.csv'),
        'partner_provider_ipv4_ipam':os.path.join(ipam_dir, 'partner_provider_ipv4_ipam_v*.csv'),
        'fw_interface_inventory':    os.path.join(ipam_dir, 'ent-ipdataset-FW-INTERFACE-INVENTORY-v*.csv'),
        'vpn_protected_subnets':     os.path.join(ipam_dir, 'ent-ipdataset-VPN-PROTECTED-SUBNETS-v*.csv'),
        'p2p_protected_subnets':     os.path.join(ipam_dir, 'ent-ipdataset-P2P-PROTECTED-SUBNETS-v*.csv'),
        'p2p_ftd_protected_subnets': os.path.join(ipam_dir, 'ent-ipdataset-P2P-FTD-PROTECTED-SUBNETS-v*.csv'),
        'f5_vip_registry':           os.path.join(ipam_dir, 'ent-ipdataset-F5-VIP-REGISTRY-v*.csv'),
        'zpa_connector_registry':    os.path.join(ipam_dir, 'ent-ipdataset-ZPA-CONNECTOR-REGISTRY-v*.csv'),
        'egress_fw_mgmt':            os.path.join(ipam_dir, 'egress_fw_mgmt_ips_v*.csv'),
    }
    return {k: find_latest(p) for k, p in patterns.items()}


def read_csv(path):
    if not path or not os.path.exists(path):
        return []
    with open(path, encoding='utf-8-sig', errors='replace') as f:
        lines = [l for l in f if not l.startswith('#')]
    return list(csv.DictReader(lines))


def clean(s, maxlen=40):
    """Sanitise string for EDL object name component."""
    s = re.sub(r'[^A-Za-z0-9_\-]', '_', str(s).strip())
    s = re.sub(r'_+', '_', s).strip('_').upper()
    return s[:maxlen]


def zone_from_rd(rd):
    rd = str(rd).strip()
    return {
        'Internal-PBM':    'PBM',
        'Internal-HCB':    'HCB',
        'Internal-Retail': 'RETAIL',
        'Internet-Facing': 'INTERNET',
        'EGR_RI1-TC':      'RI1',
        'EGR_RI1-TI':      'RI1_TI',
        'EGR_MDC-TC':      'MDC',
        'EGR_MDC-TI':      'MDC_TI',
        'EGR_SHEAW-TC':    'SHEA',
        'EGR_SHEAW-TI':    'SHEA_TI',
        'COLO':            'COLO',
        'Cloud-AWS':       'AWS',
        'Cloud-Azure':     'AZ',
        'Cloud-GCP':       'GCP',
        'Partner':         'PARTNER',
    }.get(rd, clean(rd, 20) or 'UNKNOWN')


def setup_out_dir(base, dry_run=False):
    """Single shared IPDATASET-vDATE/edl/ directory for all families.
    Matches the collect_edl_bundle.sh expectation of Net_Object/IPDATASET-vDATE/edl/*.txt
    """
    version = f'IPDATASET-v{TODAY}'
    out_dir = os.path.join(base, 'Net_Object', version, 'edl')
    if not dry_run:
        os.makedirs(out_dir, exist_ok=True)
    return out_dir, version


def write_edl(out_dir, name, cls, source, cidrs, dry_run=False):
    cidrs = sorted(set(c.strip() for c in cidrs if c.strip()))
    if not cidrs:
        return None
    content = edl_header(name, cls, source, len(cidrs)) + '\n'.join(cidrs) + '\n'
    if not dry_run:
        with open(os.path.join(out_dir, f'{name}.txt'), 'w') as f:
            f.write(content)
    return (name, len(cidrs))


# ── EXTERNAL_NO ───────────────────────────────────────────────────────────────

def build_external_no(datasets, base, dry_run=False):
    """
    CVS_INTERNET_FACING_{HERITAGE}_{ZONE} from public_ipv4_ipam
    CVS_INTERNAL_PUBLIC_{HERITAGE}_{ZONE} from private_ipv4_ipam

    Both datasets share the same schema (confirmed 2026-08-23):
      CIDR, SITE_CODE, CANONICAL_LOCATION, ROUTING_DOMAIN, HERITAGE,
      NET_TYPE, LOCATION_TYPE, STATUS
    """
    out_dir, version = setup_out_dir(base, dry_run)
    results = []

    for ds_key, prefix in [
        ('public_ipv4_ipam',  'CVS_INTERNET_FACING'),
        ('private_ipv4_ipam', 'CVS_INTERNAL_PUBLIC'),
    ]:
        rows = read_csv(datasets.get(ds_key))
        by_key = defaultdict(list)
        for row in rows:
            heritage = clean(row.get('HERITAGE', 'UNKNOWN'), 10)
            rd       = row.get('ROUTING_DOMAIN', '')
            zone     = zone_from_rd(rd) if rd else clean(
                row.get('SITE_CODE', 'UNKNOWN'), 20
            )
            cidr = row.get('CIDR', row.get('IP_NETWORK', '')).strip()
            if cidr:
                by_key[(heritage, zone)].append(cidr)

        for (heritage, zone), cidrs in sorted(by_key.items()):
            name = f'{prefix}_{heritage}_{zone}'
            r = write_edl(out_dir, name, 'EXTERNAL_NO', ds_key, cidrs, dry_run)
            if r:
                results.append(r)

    return results, out_dir, version


# ── PARTNER_NO ────────────────────────────────────────────────────────────────

def _peer_key(peer_ip, partner_name):
    """
    Build a stable EDL name key from peer IP and partner name.
    PARTNER_NAME is often blank in VPN-PROTECTED-SUBNETS — fall back to peer IP.
    """
    if partner_name and partner_name.strip():
        return clean(partner_name, 30)
    # Convert peer IP to safe name: 203.99.209.250 → 203_99_209_250
    return 'PEER_' + re.sub(r'[^0-9]', '_', peer_ip.strip())


def build_partner_no(datasets, base, dry_run=False):
    """
    VPN partner objects from VPN-PROTECTED-SUBNETS:
      Schema: IP_NETWORK, PARTNER_NAME, GATEWAY, PEER_IP, CIDR,
              CVS_LOCATION (populated = CVS side, empty = partner side)

      VPN_PARTNER_{KEY}       — partner-side subnets (CVS_LOCATION empty)
      CVS_VPN_PROTECTED_{KEY} — CVS-side subnets (CVS_LOCATION populated)

    P2P objects from P2P-PROTECTED-SUBNETS:
      Schema: IP_NETWORK, PARTNER_NAME, DIRECTION (uppercase), CIDR,
              GATEWAY_DEVICE, CONTEXT_HOSTNAME

      P2P_PARTNER_{PARTNER}       — DIRECTION = PARTNER
      CVS_P2P_PROTECTED_{PARTNER} — DIRECTION = CVS (or empty)

    Provider objects from partner_provider_ipv4_ipam.
    """
    out_dir, version = setup_out_dir(base, dry_run)
    results = []

    # ── VPN protected subnets ─────────────────────────────────────────────────
    vpn_rows = read_csv(datasets.get('vpn_protected_subnets'))
    vpn_partner = defaultdict(list)  # partner-side
    vpn_cvs     = defaultdict(list)  # CVS-side

    for row in vpn_rows:
        cidr         = row.get('CIDR', row.get('IP_NETWORK', '')).strip()
        peer_ip      = row.get('PEER_IP', '').strip()
        partner_name = row.get('PARTNER_NAME', '').strip()
        cvs_location = row.get('CVS_LOCATION', '').strip()

        if not cidr or not peer_ip:
            continue
        if '/' not in cidr:
            cidr = f'{cidr}/32'

        key = _peer_key(peer_ip, partner_name)

        # CVS_LOCATION populated = this subnet is in CVS IPAM = CVS side
        if cvs_location:
            vpn_cvs[key].append(cidr)
        else:
            vpn_partner[key].append(cidr)

    for key, cidrs in sorted(vpn_partner.items()):
        r = write_edl(out_dir, f'VPN_PARTNER_{key}', 'PARTNER_NO',
                      'VPN-PROTECTED-SUBNETS', cidrs, dry_run)
        if r:
            results.append(r)

    for key, cidrs in sorted(vpn_cvs.items()):
        r = write_edl(out_dir, f'CVS_VPN_PROTECTED_{key}', 'PARTNER_NO',
                      'VPN-PROTECTED-SUBNETS', cidrs, dry_run)
        if r:
            results.append(r)

    # ── P2P protected subnets (MPLS Dedicated + FTD) ─────────────────────────
    for ds_key, pfx_partner, pfx_cvs in [
        ('p2p_protected_subnets',     'P2P_PARTNER',     'CVS_P2P_PROTECTED'),
        ('p2p_ftd_protected_subnets', 'P2P_FTD_PARTNER', 'CVS_P2P_FTD_PROTECTED'),
    ]:
        p2p_rows = read_csv(datasets.get(ds_key))
        p2p_partner = defaultdict(list)
        p2p_cvs     = defaultdict(list)

        for row in p2p_rows:
            cidr      = row.get('CIDR', row.get('IP_NETWORK', '')).strip()
            partner   = clean(
                row.get('PARTNER_NAME') or row.get('CONTEXT_HOSTNAME', 'UNKNOWN'), 30
            )
            direction = str(row.get('DIRECTION', '')).upper().strip()

            if not cidr:
                continue
            if '/' not in cidr:
                cidr = f'{cidr}/32'

            if direction in ('PARTNER', 'REMOTE', 'DST', 'DESTINATION'):
                p2p_partner[partner].append(cidr)
            elif direction in ('CVS', 'LOCAL', 'SRC', 'SOURCE', 'INTERNAL'):
                p2p_cvs[partner].append(cidr)
            else:
                # Ambiguous or blank — use CVS_LOCATION same as VPN
                cvs_loc = row.get('CVS_LOCATION', '').strip()
                if cvs_loc:
                    p2p_cvs[partner].append(cidr)
                else:
                    p2p_partner[partner].append(cidr)

        for partner, cidrs in sorted(p2p_partner.items()):
            r = write_edl(out_dir, f'{pfx_partner}_{partner}', 'PARTNER_NO',
                          ds_key.upper(), cidrs, dry_run)
            if r:
                results.append(r)

        for partner, cidrs in sorted(p2p_cvs.items()):
            r = write_edl(out_dir, f'{pfx_cvs}_{partner}', 'PARTNER_NO',
                          ds_key.upper(), cidrs, dry_run)
            if r:
                results.append(r)

    # ── External provider IP space ────────────────────────────────────────────
    provider_rows = read_csv(datasets.get('partner_provider_ipv4_ipam'))
    by_provider = defaultdict(list)
    for row in provider_rows:
        name = clean(
            row.get('PROVIDER', '') or row.get('PARTNER', '') or
            row.get('ORG', '') or row.get('CANONICAL_LOCATION', 'UNKNOWN'), 30
        )
        cidr = row.get('CIDR', row.get('IP_NETWORK', '')).strip()
        if cidr:
            by_provider[name].append(cidr)

    for name, cidrs in sorted(by_provider.items()):
        r = write_edl(out_dir, f'PARTNER_PROVIDER_{name}', 'PARTNER_NO',
                      'partner_provider_ipv4_ipam', cidrs, dry_run)
        if r:
            results.append(r)

    return results, out_dir, version


# ── FW_INFRA ──────────────────────────────────────────────────────────────────

def build_fw_infra(datasets, base, dry_run=False):
    """
    FW interface objects from FW-INTERFACE-INVENTORY.

    Confirmed schema (2026-08-23):
      FW_NAME, FW_TYPE, INTERFACE, NAMEIF (Inside/Outside/mgmt),
      IP_ADDRESS, MASK_LENGTH, CIDR, ZONE, ROUTING_DOMAIN, CANONICAL_LOCATION

    No EGRESS_CLUSTER field — zone derived from NAMEIF:
      Outside/mgmt = egress/external side → FW_INTF_OUTSIDE_{ZONE}
      Inside        = internal side       → FW_INTF_INSIDE_{ZONE}

    ZONE derived from ROUTING_DOMAIN first, then CANONICAL_LOCATION.
    """
    out_dir, version = setup_out_dir(base, dry_run)
    results = []

    # ── FW interface inventory ────────────────────────────────────────────────
    fw_rows = read_csv(datasets.get('fw_interface_inventory'))
    outside_by_zone = defaultdict(list)
    inside_by_zone  = defaultdict(list)

    for row in fw_rows:
        nameif = str(row.get('NAMEIF', row.get('ZONE', ''))).strip()
        cidr   = row.get('CIDR', '').strip()
        rd     = row.get('ROUTING_DOMAIN', '').strip()
        loc    = row.get('CANONICAL_LOCATION', '').strip()

        if not cidr or cidr in ('0.0.0.0/0',):
            continue

        # Zone key: prefer ROUTING_DOMAIN, fall back to CANONICAL_LOCATION abbrev
        if rd:
            zone = zone_from_rd(rd)
        elif loc:
            zone = clean(loc, 25)
        else:
            zone = 'UNKNOWN'

        if nameif.lower() in ('outside', 'mgmt', 'management'):
            outside_by_zone[zone].append(cidr)
        else:
            inside_by_zone[zone].append(cidr)

    for zone, cidrs in sorted(outside_by_zone.items()):
        r = write_edl(out_dir, f'FW_INTF_OUTSIDE_{zone}', 'FW_INFRA',
                      'FW-INTERFACE-INVENTORY', cidrs, dry_run)
        if r:
            results.append(r)

    for zone, cidrs in sorted(inside_by_zone.items()):
        r = write_edl(out_dir, f'FW_INTF_INSIDE_{zone}', 'FW_INFRA',
                      'FW-INTERFACE-INVENTORY', cidrs, dry_run)
        if r:
            results.append(r)

    # ── F5 VIP registry ───────────────────────────────────────────────────────
    f5_rows = read_csv(datasets.get('f5_vip_registry'))
    f5_by_key = defaultdict(list)
    for row in f5_rows:
        heritage = clean(row.get('HERITAGE', 'UNKNOWN'), 10)
        rd       = row.get('ROUTING_DOMAIN', '')
        zone     = zone_from_rd(rd) if rd else clean(
            row.get('SITE_CODE', row.get('CANONICAL_LOCATION', 'UNKNOWN')), 20
        )
        # VIP address — may be VS_DESTINATION or IP_ADDRESS
        vip = (row.get('VS_DESTINATION', '') or
               row.get('VIP_ADDRESS', '') or
               row.get('IP_ADDRESS', '')).strip().split(':')[0]
        if not vip or vip in ('0.0.0.0',):
            continue
        if '/' not in vip:
            vip = f'{vip}/32'
        f5_by_key[(heritage, zone)].append(vip)

    for (heritage, zone), vips in sorted(f5_by_key.items()):
        r = write_edl(out_dir, f'F5_VIP_{heritage}_{zone}', 'FW_INFRA',
                      'F5-VIP-REGISTRY', vips, dry_run)
        if r:
            results.append(r)

    # ── ZPA connector registry ────────────────────────────────────────────────
    zpa_rows = read_csv(datasets.get('zpa_connector_registry'))
    zpa_by_site = defaultdict(list)
    for row in zpa_rows:
        site = clean(
            row.get('SITE_CODE', '') or
            row.get('CANONICAL_LOCATION', 'UNKNOWN'), 25
        )
        ip = (row.get('IP_ADDRESS', '') or row.get('PRIVATE_IP', '')).strip()
        if not ip:
            continue
        if '/' not in ip:
            ip = f'{ip}/32'
        zpa_by_site[site].append(ip)

    for site, ips in sorted(zpa_by_site.items()):
        r = write_edl(out_dir, f'ZPA_CONNECTOR_{site}', 'FW_INFRA',
                      'ZPA-CONNECTOR-REGISTRY', ips, dry_run)
        if r:
            results.append(r)

    return results, out_dir, version


# ── fw_mgmt — Egress FW management IP objects ────────────────────────────────

def build_fw_mgmt(datasets, base, dry_run=False):
    """
    One EDL object per EGR_CODE cluster containing the /32 management IPs
    of all FWs in that cluster. Plus FW_MGMT_ALL_EGRESS covering all 38.

    Source: egress_fw_mgmt_ips_v*.csv
      EGRESS_FIREWALL_LOGICAL, HOSTNAME, MGMT_IP, EGR_CODE

    Objects:
      FW_MGMT_{EGR_CODE}      e.g. FW_MGMT_EGR_MDC  (2 IPs)
                                    FW_MGMT_EGR_CMEP (4 IPs)
      FW_MGMT_ALL_EGRESS      all 38 egress FW management IPs combined
    """
    out_dir, version = setup_out_dir(base, dry_run)
    results = []

    rows = read_csv(datasets.get('egress_fw_mgmt'))
    if not rows:
        return results, out_dir, version

    # Group by EGR_CODE
    by_egr = defaultdict(list)
    all_ips = []
    for row in rows:
        egr_code = row.get('EGR_CODE', '').strip()
        mgmt_ip  = row.get('MGMT_IP', '').strip()
        if not egr_code or not mgmt_ip:
            continue
        cidr = mgmt_ip if '/' in mgmt_ip else f'{mgmt_ip}/32'
        by_egr[egr_code].append(cidr)
        all_ips.append(cidr)

    # Per-cluster objects
    for egr_code in sorted(by_egr.keys()):
        name = f'FW_MGMT_{egr_code}'
        r = write_edl(out_dir, name, 'FW_MGMT', 'egress_fw_mgmt_ips',
                      by_egr[egr_code], dry_run)
        if r:
            results.append(r)

    # Aggregate — all egress FW management IPs
    r = write_edl(out_dir, 'FW_MGMT_ALL_EGRESS', 'FW_MGMT',
                  'egress_fw_mgmt_ips', all_ips, dry_run)
    if r:
        results.append(r)

    return results, out_dir, version


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='CCD Platform — IP classification EDL object builder'
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    parser.add_argument('--base', default='.',
                        help='CCD Platform root directory (default: .)')
    parser.add_argument('--family', choices=FAMILIES,
                        help='Build only this object family (default: all)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Discover sources and count objects; do not write files')
    args = parser.parse_args()

    base     = os.path.abspath(args.base)
    ipam_dir = os.path.join(base, 'ipam-db')

    print(f'\n{SCRIPT_NAME} v{__version__}')
    print(f'Base: {base}')
    if args.dry_run:
        print('DRY RUN — no files will be written')
    print()

    print('Auto-discovering source datasets...')
    datasets = discover_datasets(base, ipam_dir)
    for key, path in datasets.items():
        print(f'  {key:35s} : {os.path.basename(path) if path else "(not found)"}')
    print()

    families_to_build = [args.family] if args.family else FAMILIES
    total = 0
    summary = {}

    for family in families_to_build:
        print(f'Building {family}...')
        if family == 'external_no':
            results, out_dir, ver = build_external_no(datasets, base, args.dry_run)
        elif family == 'partner_no':
            results, out_dir, ver = build_partner_no(datasets, base, args.dry_run)
        elif family == 'fw_infra':
            results, out_dir, ver = build_fw_infra(datasets, base, args.dry_run)
        elif family == 'fw_mgmt':
            results, out_dir, ver = build_fw_mgmt(datasets, base, args.dry_run)

        count     = len(results)
        cidr_total = sum(c for _, c in results)
        total    += count
        summary[family] = (count, cidr_total, out_dir)
        print(f'  {count} objects  ({cidr_total:,} CIDRs)')
        if not args.dry_run and count:
            print(f'  → {out_dir}')
        print()

    # ── Output ────────────────────────────────────────────────────────────────
    after_parts = [f'{f}: {summary[f][0]} objects' for f in families_to_build if f in summary]

    print(SEP)
    print(f'  Before  :  external_no: 0  partner_no: 0  fw_infra: 0  fw_mgmt: 0')
    print(f'  After   :  {"  ".join(after_parts)}')
    print(SEP)

    if not args.dry_run and total > 0:
        print(f'\n  Next step: python3 build_object_pipeline.py --skip-obj --collect')
    elif args.dry_run:
        print(f'\n  Dry run complete — {total} objects would be generated.')
    print()


if __name__ == '__main__':
    main()
