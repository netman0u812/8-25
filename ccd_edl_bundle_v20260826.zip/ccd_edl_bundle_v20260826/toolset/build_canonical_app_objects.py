#!/usr/bin/env python3
"""
build_canonical_app_objects.py  v1.9.1
CCD Platform — Canonical App Object Library Builder
CVS Health Information Security

Builds APP_Objects, INFRA_Objects, SERVICE_Objects, and DELIVERY_Objects
from authoritative CCD Platform datasets. Does NOT derive objects from
firewall rules.

Usage:
    python3 build_canonical_app_objects.py \
        --ipam-dir ./ipam-db \
        --fw-dir   ./processed_outputs \
        --out-dir  ./processed_outputs \
        --min-members 2 \
        --dry-run

Changelog:
  v1.9.1 2026-07-07  Fix NameError in build_ra_service_objects() —
            CcdObject → CanonicalObject (correct class name).
  v1.9.0 2026-07-07  Remote Access service objects integrated into pipeline.
            build_ra_service_objects() added: reads ZPA-CONNECTOR-REGISTRY,
            RAVPN-GATEWAY-REGISTRY, and all_IP_networks (RA-POOL-CSA,
            RA-SNAT-HCB NET_TYPEs) to generate RA_CONNECTOR_ZPA,
            RA_GATEWAY_CSA, RA_GATEWAY_NTX, RA_POOL_CSA, RA_SNAT_HCB
            objects. Merged into service_objects before final assembly.
            --ra-registry-dir flag added (default: ./ipam-db).
  v1.8.3 2026-06-15  EHM_ROLLUP_AGGREGATES source lists corrected to match
                     actual object names from EHM service acronym routing:
                     SVC_IIB_ACE_ALL now sources SVC_MIDDLEWARE_IIB_*;
                     SVC_SCOM_ALL now sources SVC_SCOM_EHM_* variants;
                     SVC_SCCM_ALL now includes SVC_SCCM_MECM_* variants;
                     SVC_VENAFI_ALL now includes SVC_VENAFI_PKI_* variants.
                     Three new rollups added: SVC_BIGFIX_ALL (SVC_BIGFIX_EHM_*),
                     SVC_ANSIBLE_ALL (SVC_ANSIBLE_EHM_CVS + SVC_ANSIBLE_HCB),
                     SVC_SMTP_ALL (SVC_SMTP_MAIL_CVS — HCB gap still open).
  v1.8.2 2026-06-15  Bug fixes for v1.8.1 rollup objects:
                     - rollup.server_ports was set as a raw comma-separated
                       string; to_dict() expects list of {'ai','pt','pr'} dicts.
                       Fixed: now built as list comprehension per schema.
                     - rollup.service_deps was set as '|'.join(found_srcs) string;
                       to_dict() expects list of {'nm','dt'} dicts.
                       Fixed: now [{'nm': s, 'dt': 'source'} for s in found_srcs].
                     - rollup.client_ports was set as empty string '';
                       Fixed: now set as [].
                     - Step [8c/9] print used .split('|') on service_deps which
                       is now a list; fixed to len(robj.service_deps).
                     - Defensive guards added to _fmt_port, _fmt_sd, _fmt_pd
                       and validate_objects loop to coerce any residual string
                       fields to [] before iteration.
  v1.8.1 2026-06-15  EHM service rollup aggregates (step [8c/9]): 14
                     SVC_*_ALL objects built by unioning per-heritage
                     SVC_* variants. SVC_IBM_MQ_ALL, SVC_IIB_ACE_ALL,
                     SVC_GUARDIUM_ALL, SVC_SCOM_ALL, SVC_SPLUNK_ALL,
                     SVC_SCCM_ALL, SVC_QUALYS_ALL, SVC_ZIA_PROXY_ALL,
                     SVC_TIDAL_ALL, SVC_APPDYNAMICS_ALL, SVC_KAFKA_ALL,
                     SVC_VENAFI_ALL, SVC_DATAPOWER_ALL, SVC_VCENTER_ALL.
                     CPC-sourced rollups (AD, Kerberos, NTP, Jump) remain
                     in build_cpc_service_catalog.py.
  v1.4.3 2026-05-28  CPC_SERVICE_NAME_MAP: 46 per-domain AD entries added.
                     Domain FQDN is the SERVICE key; each maps to SVC_AD_*
                     object. Apps declare CONSUMES_SERVICES on specific domain.
  v1.4.2 2026-05-28  CPC_SERVICE_NAME_MAP: 9 name variants added for
                     tivoli itm, obm, rear / linux jump, red hat satellite 6,
                     cloudbees ci, beyondtrust, apache nifi, dell ppdm,
                     nexus repository — all map to existing SVC_* objects.
  v1.4.1 2026-05-28  Bug fix: DELIVERY_Objects from delivery_platform used UNKNOWN
                     env suffix when APP_ENVIRONMENTS/PRIMARY_ENV blank (77% of rows).
                     NON_PROD fallback added at platform env derivation call site:
                     NON_PROD=Y -> NONPROD, NON_PROD=N -> PROD. INFRA section unchanged
                     (has its own UNKNOWN -> SHARED fallback).

Findings from pre-build inspection (2026-05-21):
  - delivery_infrastructure has NO ROLE/INFRA_ROLE column; use SERVER_CLASS + APP_ACRONYMS
  - delivery_platform has NO CLUSTER_ID column; PLATFORM_TYPE='KUBERNETES' for GKE,
    NaN+OpenshiftOCP APP_ACRONYMS for OpenShift nodes
  - EHM column is APP_ACRONYMS (plural, pipe-delimited); single-value key is PRIMARY_ACRONYM
  - EHM, delivery_infrastructure, delivery_platform are fully disjoint IP sets
  - F5-POOL-MEMBERS join key: MEMBER_IP -> VIP_IP
"""

import argparse
import csv
import glob
import ipaddress
import os
import re
import sys
from collections import defaultdict
from datetime import datetime

VERSION = "v1.9.2"
# v1.9.2 — 2026-07-09  read_ccd_csv() rewritten to avoid a double-list-copy
#          ([line] + list(f)) and to skip '#' comment lines throughout the
#          file, not just leading ones — matches the idiom used elsewhere
#          in this codebase. Found while investigating a real stall on a
#          live run reading retail_networks (~294K rows); this is a
#          confirmed inefficiency, NOT a confirmed fix for that stall —
#          no profiling was done to prove this was the actual bottleneck.
BUILD_DATE = datetime.now().strftime("%Y%m%d")

# ---------------------------------------------------------------------------
# Well-known service port registry  (v1.4.0)
# Maps SERVICE object base slug (strip SVC_ prefix + heritage suffix) to
# list of (PROTOCOL, PORT) tuples sourced from IANA / vendor documentation.
# Used to gap-fill SERVER_PORTS on SERVICE objects where no port data exists.
# ---------------------------------------------------------------------------
WELL_KNOWN_SERVICE_PORTS = {
    # ── Active Directory / LDAP / Kerberos ───────────────────────────────
    'AD_DC': [
        ('TCP', '88'),          ('UDP', '88'),          # Kerberos
        ('TCP', '135'),                                  # RPC Endpoint Mapper
        ('UDP', '137'),         ('UDP', '138'),          # NetBIOS Name / Datagram
        ('TCP', '139'),                                  # NetBIOS Session
        ('TCP', '389'),         ('UDP', '389'),          # LDAP
        ('TCP', '445'),                                  # SMB
        ('TCP', '464'),         ('UDP', '464'),          # Kerberos password change
        ('TCP', '636'),                                  # LDAPS
        ('TCP', '3268'),        ('TCP', '3269'),         # Global Catalog / GC SSL
        ('TCP', '3389'),                                 # RDP
        ('TCP', '49152-65535'),                          # Dynamic RPC
    ],
    'AD_DC_VIP': [
        ('TCP', '88'),          ('UDP', '88'),
        ('TCP', '389'),         ('UDP', '389'),
        ('TCP', '636'),
        ('TCP', '3268'),        ('TCP', '3269'),
        ('TCP', '445'),
        ('TCP', '49152-65535'),
    ],
    'AD_DC_NONPROD': [   # same as AD_DC — included for _NONPROD variant
        ('TCP', '88'),          ('UDP', '88'),
        ('TCP', '389'),         ('UDP', '389'),
        ('TCP', '636'),
        ('TCP', '3268'),        ('TCP', '3269'),
        ('TCP', '445'),
        ('TCP', '49152-65535'),
    ],
    # ── Automation / Config Management ───────────────────────────────────
    'ANSIBLE': [
        ('TCP', '22'),          # SSH
        ('TCP', '443'),         # Tower / AWX API
        ('TCP', '80'),          # Tower / AWX HTTP callback
    ],
    'CHEF': [
        ('TCP', '443'),         # Chef Infra Server HTTPS
        ('TCP', '80'),          # Chef HTTP redirect
        ('TCP', '9683'),        # Chef push jobs
    ],
    'SATELLITE': [
        ('TCP', '443'),         # Red Hat Satellite web UI
        ('TCP', '80'),          # HTTP redirect
        ('TCP', '5647'),        # Katello agent (AMQP)
        ('TCP', '8140'),        # Puppet agent
        ('TCP', '9090'),        # Capsule / Smart Proxy
    ],
    # ── CI/CD ─────────────────────────────────────────────────────────────
    'CLOUDBEES': [
        ('TCP', '8080'),        # Jenkins HTTP
        ('TCP', '8443'),        # Jenkins HTTPS
        ('TCP', '50000'),       # JNLP agent
        ('TCP', '443'),         # CloudBees CI HTTPS
    ],
    'GITHUB_AUTOMATION': [
        ('TCP', '443'),         # GitHub API / Actions
    ],
    # ── PAM / IAM ─────────────────────────────────────────────────────────
    'CENTRIFY': [
        ('TCP', '8080'),        # Centrify connector HTTP
        ('TCP', '8443'),        # Centrify connector HTTPS
        ('TCP', '389'),         # LDAP proxy
        ('TCP', '636'),         # LDAPS proxy
        ('TCP', '88'),          # Kerberos
    ],
    'BEYONDTRUST': [
        ('TCP', '443'),         # BeyondTrust web console
        ('TCP', '8200'),        # BeyondTrust API
    ],
    'VENAFI': [
        ('TCP', '443'),         # Venafi Trust Protection Platform
        ('TCP', '8443'),        # Venafi API
    ],
    'IAM': [
        ('TCP', '22'),          # SSH (IAM identity-aware proxy)
        ('TCP', '443'),
    ],
    # ── Monitoring / Observability ────────────────────────────────────────
    'SPLUNK': [
        ('TCP', '9997'),        # Forwarder to indexer
        ('TCP', '8089'),        # Management / REST API
        ('TCP', '8000'),        # Web UI
        ('TCP', '8088'),        # HTTP Event Collector (HEC)
        ('UDP', '514'),         # Syslog input
        ('TCP', '514'),         # Syslog TCP
    ],
    'SCOM': [
        ('TCP', '5723'),        # Health Service (agent/gateway to mgmt server)
        ('TCP', '5724'),        # SDK / console connections
        ('TCP', '1433'),        # SQL Server (mgmt server to DB)
        ('TCP', '5985'),        # WinRM HTTP (agentless)
        ('TCP', '5986'),        # WinRM HTTPS (agentless)
    ],
    'SITESCOPE': [
        ('TCP', '8080'),        # HP SiteScope HTTP
        ('TCP', '8443'),        # HP SiteScope HTTPS
        ('TCP', '8006'),        # SiteScope Tomcat shutdown
    ],
    'ITM': [
        ('TCP', '1918'),        # IBM Tivoli Monitoring hub
        ('TCP', '3660'),        # TEMS listener
        ('TCP', '6014'),        # TEMS data warehouse
        ('TCP', '16310'),       # Enterprise Monitor
        ('TCP', '9516'),        # ITM dashboard
    ],
    'UCMDB': [
        ('TCP', '8080'),        # HP Universal CMDB HTTP
        ('TCP', '8443'),        # HP Universal CMDB HTTPS
        ('TCP', '8190'),        # HP Universal CMDB RMI
    ],
    'OBM': [
        ('TCP', '383'),         # OvObsServer (HP OM agent)
        ('TCP', '1099'),        # OBM RMI
        ('TCP', '4454'),        # OBM agent listener
        ('TCP', '9000'),        # OBM web UI
        ('TCP', '443'),
    ],
    'NETCOOL': [
        ('TCP', '4100'),        # IBM Netcool/OMNIbus ObjectServer
        ('TCP', '4300'),        # Netcool Web GUI
        ('TCP', '443'),
    ],
    'THOUSANDEYES': [
        ('TCP', '443'),         # ThousandEyes agent
        ('UDP', '49153-65535'), # Browser agent / path trace
    ],
    'TIDAL': [
        ('TCP', '8443'),        # Tidal Automation HTTPS
        ('TCP', '6602'),        # Tidal master scheduler
    ],
    # ── Security tooling ─────────────────────────────────────────────────
    'GUARDIUM': [
        ('TCP', '16016'),       # Guardium aggregator / collector
        ('UDP', '16016'),
        ('TCP', '8443'),        # Guardium web console
        ('TCP', '9500'),        # S-TAP listener
        ('TCP', '8080'),        # HTTP
    ],
    'QUALYS': [
        ('TCP', '443'),         # Qualys cloud platform
        ('TCP', '80'),          # Qualys HTTP
    ],
    'FIM': [
        ('TCP', '443'),
        ('TCP', '22'),          # SSH-based collection
    ],
    'BIGID': [
        ('TCP', '443'),
        ('TCP', '8080'),
    ],
    # ── Backup / Storage ─────────────────────────────────────────────────
    'NETBACKUP': [
        ('TCP', '1556'),        # NetBackup PBX (unified comms)
        ('TCP', '13724'),       # bprd (request daemon)
        ('TCP', '13782'),       # bpdbm (database manager)
        ('TCP', '13783'),       # bpjobd (job manager)
        ('TCP', '443'),         # NetBackup web UI
        ('TCP', '7394'),        # NetBackup NDMP
    ],
    'PPDM': [
        ('TCP', '443'),         # Dell PowerProtect DM web UI
        ('TCP', '7000'),        # PowerProtect data port
    ],
    'ISILON': [
        ('TCP', '445'),         # SMB
        ('TCP', '2049'),        ('UDP', '2049'),         # NFS
        ('TCP', '8080'),        ('TCP', '8083'),         # OneFS web UI
        ('TCP', '9090'),        # InsightIQ
    ],
    # ── Virtualisation / Cloud infra ──────────────────────────────────────
    'VCENTER': [
        ('TCP', '443'),         # vCenter HTTPS
        ('TCP', '9443'),        # vSphere web client
        ('TCP', '902'),         # vCenter legacy heartbeat
        ('TCP', '2012'),        # vCenter management
        ('TCP', '2020'),        # vCenter SSO
        ('TCP', '7444'),        # Lookup service
    ],
    'VMWARE_HCX': [
        ('TCP', '443'),         # HCX cloud gateway HTTPS
        ('TCP', '8123'),        # HCX control plane
        ('TCP', '9443'),        # HCX HTTPS
        ('TCP', '31031'),       # HCX bulk migration
        ('TCP', '44443'),       # HCX Interconnect
        ('UDP', '500'),         # IPSec IKE
        ('UDP', '4500'),        # IPSec NAT-T
    ],
    'VMWARE_VRA': [
        ('TCP', '443'),         # vRealize Automation
        ('TCP', '8280'),        # vRA appliance management
    ],
    # ── Network / Infrastructure services ────────────────────────────────
    'NTP': [
        ('UDP', '123'),         # NTP (IANA)
    ],
    'DNS': [
        ('TCP', '53'),
        ('UDP', '53'),
    ],
    'SYSLOG': [
        ('UDP', '514'),         # Syslog (IANA)
        ('TCP', '514'),         # Syslog TCP
        ('TCP', '6514'),        # Syslog TLS (RFC 5425)
        ('UDP', '6514'),
    ],
    # ── Package / Artifact management ────────────────────────────────────
    'BOOTSTRAP': [
        ('TCP', '8081'),        # Sonatype Nexus HTTP
        ('TCP', '8443'),        # Sonatype Nexus HTTPS
    ],
    'BOOTSTRAP_NEXUS': [
        ('TCP', '8081'),
        ('TCP', '8443'),
    ],
    # ── Integration / Middleware ──────────────────────────────────────────
    'NIFI': [
        ('TCP', '8443'),        # Apache NiFi HTTPS
        ('TCP', '8080'),        # Apache NiFi HTTP
        ('TCP', '11443'),       # Site-to-site data transfer
        ('TCP', '2181'),        # ZooKeeper coordination
    ],
    # ── Jump / Admin access ───────────────────────────────────────────────
    'JUMP': [
        ('TCP', '22'),          # SSH
        ('TCP', '3389'),        # RDP
        ('TCP', '443'),         # VPN / jump portal
    ],
    'LINUX_ADMIN': [
        ('TCP', '22'),          # SSH
    ],
    'KDUMP': [
        ('TCP', '22'),          # SSH netdump
    ],
    'LPAR2RRD': [
        ('TCP', '443'),
        ('TCP', '8080'),
    ],
    # ── SCCM / Endpoint Management ────────────────────────────────────────
    'SCCM': [
        ('TCP', '80'),          # SCCM management point HTTP
        ('TCP', '443'),         # SCCM management point HTTPS
        ('TCP', '8530'),        # WSUS HTTP
        ('TCP', '8531'),        # WSUS HTTPS
        ('TCP', '10123'),       # Client notification
    ],
    # ── Mainframe ─────────────────────────────────────────────────────────
    'MF_INFRA': [
        ('TCP', '23'),          # TN3270 Telnet
        ('TCP', '992'),         # TN3270 TLS
        ('TCP', '2052'),        # TN3270E variant
    ],
    # ── BigFix ───────────────────────────────────────────────────────────
    'BIGFIX': [
        ('TCP', '52311'),       # BigFix server / relay
        ('UDP', '52311'),
        ('TCP', '9443'),        # BigFix web UI
    ],
}


def _populate_well_known_service_ports(objects):
    """
    v1.4.0: Gap-fill SERVER_PORTS on SERVICE objects using WELL_KNOWN_SERVICE_PORTS.

    Matches on the base slug derived from the object name by stripping:
      - SVC_ prefix
      - Heritage/variant suffixes: _CVS, _HCB, _NONPROD_CVS, _NONPROD_HCB,
        _VIP_CVS, _VIP_HCB, _VIP

    Gap-fill only — never overwrites ports already populated from
    CPC-SERVICE-FLOWS or other enrichment sources.

    Returns count of objects enriched.
    """
    import re as _re
    _SUFFIX = _re.compile(
        r'_(CVS|HCB|NONPROD_CVS|NONPROD_HCB|VIP_CVS|VIP_HCB|VIP)$',
        _re.IGNORECASE
    )

    enriched = 0
    for name, obj in objects.items():
        if obj.obj_type != 'SERVICE':
            continue
        if obj.server_ports:    # already populated — gap-fill only
            continue

        base = name[4:] if name.startswith('SVC_') else name
        base = _SUFFIX.sub('', base)

        ports = WELL_KNOWN_SERVICE_PORTS.get(base)
        if ports:
            obj.server_ports = [{'ai': '', 'pt': port, 'pr': proto}
                                 for proto, port in ports]
            enriched += 1

    return enriched

# ---------------------------------------------------------------------------
# Location short-code map  (CANONICAL_LOCATION → LOC_CODE for object naming)
# ---------------------------------------------------------------------------
LOC_CODE_MAP = {
    # Primary DCs
    "Scottsdale AZ - Shea DC":              "SHEA",
    "Woonsocket RI - RI One":               "RIONE",
    "Woonsocket RI - Corporate":            "RIONE",      # same campus
    "Cumberland RI - 2100 Highland":        "RI2100",
    "Cumberland RI - Corporate":            "RI2100",
    "Middletown CT - Aetna MDC":            "MDC",
    "Windsor CT - Aetna WDC":              "WDC",
    "Phoenix AZ - Aetna DC":               "PHX",
    "Las Vegas NV - Switch Colo":           "LV",
    "Las Vegas NV - Switch DC":             "LV",
    "Atlanta GA - Switch Colo":             "ATL",
    "Atlanta GA - Switch COLO":             "ATL",        # casing variant
    "Atlanta GA - Aetna DC":               "ATL_AETNA",
    "Sparks NV - Switch TRE":              "TRE",
    # Corporate / Call-Center
    "Linthicum MD - Corporate":             "LINTHICUM",
    "Hartford CT - Corporate":             "HARTFORD",
    "Hartford CT - Aetna HQ":             "HARTFORD",
    "Richardson TX - Call Center":          "RIC",
    "Columbia MD - Corporate":              "COLUMBIA",
    "Charlotte NC - Corporate":             "CLT",
    "Buffalo Grove IL - Corporate":         "BUFFGRV",
    "Mount Prospect IL - Corporate":        "MTPROSPECT",
    "Denver CO - Corporate":               "DENVER",
    "Philadelphia PA - Corporate":          "PHL",
    "Watertown MA - Retail DR":             "WATERTOWN",
    # Distribution / Specialty / Other
    "Lumberton NJ - Distribution Center":  "LUMBERTON",
    "Flower Mound TX - Spinks Rd":         "FLOWERMND",
    "Tolleson AZ - Distribution Center":   "TOLLESON",
    "Kapolei HI - Distribution Center":    "KAPOLEI",
    "Indianapolis IN - Omnicare":           "INDY",
    "Orlando FL - Specialty":              "ORLANDO",
    "Wilkes Barre PA - Mail Order":        "WILKESBARRE",
    "San Antonio TX - Corporate":          "SANANTONIO",
    "Knoxville TN - Corporate":            "KNOXVILLE",
    "Pittsburgh PA - Corporate":           "PITTSBURGH",
    # Additional on-prem sites
    "San Antonio TX - Mail Order":         "SANANTONIO_MO",
    "Knoxville TN - Distribution Center":  "KNOXVILLE_DC",
    "Atlanta GA - Specialty":             "ATL_SPEC",
    "Carlstadt NJ - SunGard DR":          "CARLSTADT",
    "Orlando FL - Corporate":             "ORLANDO_CORP",
    "Cloud - AWS US-East1":               "AWS_USE1",
    # Cloud
    "Cloud - GCP US-East4":                "GCP_USE4",
    "Cloud - GCP US-West2":                "GCP_USW2",
    "Cloud - GCP CVS West US 2":           "GCP_USW2",
    "Cloud - Azure East US 2":             "AZ_USE2",
    "Cloud - Azure Central US":            "AZ_USC",
    "Cloud - Azure CVS East US 2":         "AZ_CVS_USE2",
    "Cloud - Azure CVS Central US":        "AZ_CVS_USC",
    "Cloud - Azure CVS":                   "AZ_CVS",
    "Cloud - Azure CVS West US":           "AZ_CVS_USW",
    "Cloud - Azure Aetna East US 2":       "AZ_HCB_USE2",
    "Cloud - Azure UE2 - SecureHub":       "AZ_SECHUB",
    "Cloud - AWS US-East1":                "AWS_USE1",
    "Cloud - GCP US-East4 - CVS":          "GCP_USE4",
    "Cloud - GCP US-East4 - Aetna":        "GCP_USE4_HCB",
}

def loc_code(canonical_location):
    """Return short location code for object naming."""
    if not isinstance(canonical_location, str):
        return "UNKNOWN"
    return LOC_CODE_MAP.get(canonical_location,
           re.sub(r'[^A-Z0-9]', '_', canonical_location.upper())[:12])

# ---------------------------------------------------------------------------
# INFRA classification — delivery_infrastructure
# ---------------------------------------------------------------------------
# Key: (SERVER_CLASS, APP_ACRONYMS_first_token) → infra_platform string
# Used to assign INFRA vs SERVICE/DELIVERY vs skip

# SERVER_CLASS → INFRA platform type
INFRA_SERVER_CLASS_MAP = {
    "ESX Server":          "ESXI",
    "IBM HMC Server":      "IBM_HMC",
    "Ibm Hmc Server":      "IBM_HMC",
    "IBM iSeries LPAR":    "IBM_ISERIES",
    "IBM Mainframe":       "IBM_MF",
    "IBM Mainframe LPAR":  "IBM_MF",
    "Ibm Mainframe Lpar":  "IBM_MF",
    "IBM zOS server":      "IBM_ZOS",
    "Linux Server":        None,   # needs APP_ACRONYMS to disambiguate
    "Windows Server":      None,
    "AIX Server":          None,
    "Hyper-V Server":      "HYPERV",
    "Network Appliance Hardware": "NAS",
}

# APP_ACRONYMS that indicate this row IS the infrastructure (INFRA_Object)
INFRA_ACRONYM_SET = {
    "ESXSystems", "ESXSystemsHCB", "ESXPCI", "ESXSystemsHCBPCI",
    "HMCSystemsCVS", "HMCSystemsPCICVS", "HMCSystemsRXConnect",
    "ESXVMW",    # ESXi VMware mgmt hosts — Windows SERVER_CLASS, AETNA/HCB
    "FMF",       # File Master for Mainframes — mainframe utility, not an app workload
    # ── Database engine acronyms — infra, not app workloads ──────────────────
    "DB2DBE",    # IBM DB2 database engine
    "ORADBE",    # Oracle database engine
    "SQLDBE",    # SQL Server database engine
    "MSSQLDBE",  # MS SQL Server database engine
    "MYSQLDBE",  # MySQL database engine
    "PGDBE",     # PostgreSQL database engine
    "POSTGREDBE",# PostgreSQL variant
    "SYBDBE",    # Sybase database engine
    "CASSDBE",   # Cassandra
    "MONGODBE",  # MongoDB
    "ELASTICDBE",# Elasticsearch
    # ── Middleware / messaging / ESB acronyms ─────────────────────────────────
    "MQue",      # IBM MQ
    "IBMMQ",     # IBM MQ variant
    "MQSERIES",  # IBM MQ Series
    "ACE",       # IBM App Connect Enterprise
    "CVSESL",    # CVS ESL integration bus
    "ACEINTEGRATION",  # ACE integration
}

# APP_ACRONYMS → canonical SERVICE_Object name
SERVICE_ACRONYM_MAP = {
    "VCENTER":          "SVC_VCENTER_CVS",
    "VCenterHCB":       "SVC_VCENTER_HCB",
    "VmwareVra":        "SVC_VMWARE_VRA",
    "Vmware":           "SVC_VMWARE_HCX",   # HCX appliances
    "NetBackup":        "SVC_NETBACKUP",
    "MFInfraSoftware":  "SVC_MF_INFRA",
    "MFSTORAGE":        "SVC_MF_STORAGE",
    "FileServersIsilon":"SVC_ISILON",
    "FMF":              "SVC_MF_INFRA",     # File Master for Mainframes → mainframe infra
    # ── Database engine acronyms → granular INFRA_DB service objects ─────────
    "DB2DBE":           "SVC_INFRA_DB2_ENGINE",
    "ORADBE":           "SVC_INFRA_ORACLE_ENGINE",
    "SQLDBE":           "SVC_INFRA_MSSQL_ENGINE",
    "MSSQLDBE":         "SVC_INFRA_MSSQL_ENGINE",
    "MYSQLDBE":         "SVC_INFRA_MYSQL_ENGINE",
    "PGDBE":            "SVC_INFRA_POSTGRES_ENGINE",
    "POSTGREDBE":       "SVC_INFRA_POSTGRES_ENGINE",
    "SYBDBE":           "SVC_INFRA_SYBASE_ENGINE",
    "CASSDBE":          "SVC_INFRA_CASSANDRA_ENGINE",
    "MONGODBE":         "SVC_INFRA_MONGO_ENGINE",
    "ELASTICDBE":       "SVC_INFRA_ELASTIC_ENGINE",
    # ── Middleware / messaging acronyms → granular INFRA_MW service objects ──
    "MQue":             "SVC_INFRA_IBMMQ_ENGINE",
    "IBMMQ":            "SVC_INFRA_IBMMQ_ENGINE",
    "MQSERIES":         "SVC_INFRA_IBMMQ_ENGINE",
    "ACE":              "SVC_INFRA_ACE_ENGINE",
    "CVSESL":           "SVC_INFRA_ESL_ENGINE",
}

# SERVER_CLASS that maps to a DELIVERY object (not INFRA, not SERVICE)
DELIVERY_SERVER_CLASS_MAP = {
    "Data Power Hosting Server": "DATAPOWER",
}

# APP_ACRONYMS that map to a known EHM SERVICE (for EHM-sourced service objects)
EHM_SERVICE_ACRONYM_MAP = {
    "Guardium":     "SVC_GUARDIUM",      # heritage suffix applied by build function
    "GUARDIANCVS":  "SVC_GUARDIUM",      # heritage=CVS → becomes SVC_GUARDIUM_CVS
    "GuardiumHCB":  "SVC_GUARDIUM",      # heritage=AETNA → becomes SVC_GUARDIUM_HCB
    "GUARDIUMCVS":  "SVC_GUARDIUM",      # heritage=CVS → becomes SVC_GUARDIUM_CVS
    "GuardiumHCBR": "SVC_GUARDIUM",
    "CyberArk":     "SVC_CYBERARK",
    "CyberArkHCB":  "SVC_CYBERARK_HCB",
    "Infoblox":     "SVC_INFOBLOX",
    "InfraQualys":  "SVC_QUALYS",
    "QualysCVS":    "SVC_QUALYS_CVS",
    "QualysHCB":    "SVC_QUALYS_HCB",
    "Splunk":       "SVC_SPLUNK",
    "SplunkHCB":    "SVC_SPLUNK_HCB",
    "ThousandEyes": "SVC_THOUSANDEYES",
    # ── Confirmed in EHM 2026-05-22 (from LGS foundational services review) ──
    "SCCManager":   "SVC_SCCM",          # 125 EHM rows: PBM(59) HCB(54) AZ(9) COLO(2)
    "SCCM":         "SVC_SCCM",          # alternate acronym variant
    "VENAFI":       "SVC_VENAFI",        # 3 EHM rows with PRIMARY_ACRONYM=VENAFI (52 raw — contaminated via APP_ACRONYMS)
    "Tidal":        "SVC_TIDAL",         # 165 EHM rows: PBM(88) HCB(75) AZ(2)
    "SCOM":         "SVC_SCOM",          # 269 EHM rows: PBM(149) HCB(81) AZ(25) COLO(14)
    "BigID":        "SVC_BIGID",         # 2 EHM rows: PBM(2) — minimal, below APP min_members anyway
    "Infra":        None,  # too generic, skip
}

# ---------------------------------------------------------------------------
# EHM-sourced service rollup aggregates
#
# Each entry defines a SVC_*_ALL object that unions the IPs from the listed
# per-heritage SVC_* service objects. Built in step [8c/9] after all service
# objects are assembled, before the summary and write.
#
# Only services whose authoritative source is EHM service acronym routing
# belong here. Services sourced from the CPC template (AD, Qualys, NTP,
# Jump) are rolled up in build_cpc_service_catalog.py instead.
#
# Format: (rollup_name, ports, protocol, [source_object_names])
# ---------------------------------------------------------------------------
EHM_ROLLUP_AGGREGATES = [
    # Source names derived from actual EHM service acronym routing output.
    # Verified against build_canonical_app_objects.py --dry-run 2026-06-15.
    # Format: (rollup_name, ports, protocol, [source_object_names])

    ('SVC_IBM_MQ_ALL',       '1414,1415,9443',        'TCP',
     ['SVC_IBM_MQ', 'SVC_IBM_MQ_CVS', 'SVC_IBM_MQ_HCB']),

    # IIB/ACE objects are named SVC_MIDDLEWARE_IIB_* not SVC_IIB_ACE_*
    ('SVC_IIB_ACE_ALL',      '7800,7080,9443',         'TCP',
     ['SVC_MIDDLEWARE_IIB', 'SVC_MIDDLEWARE_IIB_CVS', 'SVC_MIDDLEWARE_IIB_HCB']),

    ('SVC_GUARDIUM_ALL',     '8500,16016,16018',       'TCP',
     ['SVC_GUARDIUM', 'SVC_GUARDIUM_CVS', 'SVC_GUARDIUM_HCB']),

    # SCOM objects are named SVC_SCOM_EHM_* not SVC_SCOM_*
    ('SVC_SCOM_ALL',         '5723,1270',              'TCP',
     ['SVC_SCOM_EHM', 'SVC_SCOM_EHM_CVS', 'SVC_SCOM_EHM_HCB', 'SVC_SCOM_HCB',
      'SVC_SCOM_CVS']),

    ('SVC_SPLUNK_ALL',       '9997,8089,8000,8443',    'TCP',
     ['SVC_SPLUNK', 'SVC_SPLUNK_CVS', 'SVC_SPLUNK_HCB']),

    # SCCM objects include MECM variants
    ('SVC_SCCM_ALL',         '443,445,8530,8531,10123','TCP',
     ['SVC_SCCM', 'SVC_SCCM_CVS', 'SVC_SCCM_HCB',
      'SVC_SCCM_MECM', 'SVC_SCCM_MECM_CVS', 'SVC_SCCM_MECM_HCB']),

    ('SVC_QUALYS_ALL',       '443,8443',               'HTTPS',
     ['SVC_QUALYS_CVS', 'SVC_QUALYS_HCB']),

    ('SVC_ZIA_PROXY_ALL',    '80,443,9480',            'TCP',
     ['SVC_ZIA_PROXY', 'SVC_ZIA_PROXY_CVS', 'SVC_ZIA_PROXY_HCB']),

    ('SVC_TIDAL_ALL',        '8082,8443',              'TCP',
     ['SVC_TIDAL_CVS', 'SVC_TIDAL_HCB']),

    ('SVC_APPDYNAMICS_ALL',  '8090,443',               'TCP',
     ['SVC_APPDYNAMICS_CVS', 'SVC_APPDYNAMICS_HCB']),

    ('SVC_KAFKA_ALL',        '9092,9093,2181',         'TCP',
     ['SVC_KAFKA', 'SVC_KAFKA_CVS', 'SVC_KAFKA_HCB']),

    # Venafi objects include PKI variants
    ('SVC_VENAFI_ALL',       '443,8443',               'HTTPS',
     ['SVC_VENAFI_CVS', 'SVC_VENAFI_HCB',
      'SVC_VENAFI_PKI_CVS', 'SVC_VENAFI_PKI_HCB']),

    ('SVC_DATAPOWER_ALL',    '443,9443,8443',          'TCP',
     ['SVC_DATAPOWER', 'SVC_DATAPOWER_CVS']),

    ('SVC_VCENTER_ALL',      '443,902,903,9443',       'TCP',
     ['SVC_VCENTER_CVS', 'SVC_VCENTER_HCB']),

    # BigFix objects are named SVC_BIGFIX_EHM_*
    ('SVC_BIGFIX_ALL',       '52311,443',              'TCP',
     ['SVC_BIGFIX_EHM', 'SVC_BIGFIX_EHM_CVS', 'SVC_BIGFIX_EHM_HCB',
      'SVC_BIGFIX_CVS', 'SVC_BIGFIX_HCB']),

    # Ansible objects are named SVC_ANSIBLE_EHM_CVS / SVC_ANSIBLE_HCB
    ('SVC_ANSIBLE_ALL',      '22,443',                 'TCP',
     ['SVC_ANSIBLE_EHM_CVS', 'SVC_ANSIBLE_HCB']),

    # SMTP — CVS only for now (HCB gap documented in build_cpc_service_catalog.py)
    ('SVC_SMTP_ALL',         '25,465,587',             'TCP',
     ['SVC_SMTP_MAIL', 'SVC_SMTP_MAIL_CVS']),
]


# ---------------------------------------------------------------------------
# ENV normalization
# ---------------------------------------------------------------------------
def normalize_env(env_str):
    """Return PROD / NONPROD / DEV from APP_ENVIRONMENTS or PRIMARY_ENV."""
    if not isinstance(env_str, str):
        return "UNKNOWN"
    env_str = env_str.upper()
    if "PROD" in env_str and "NONPROD" not in env_str and "PDEV" not in env_str:
        return "PROD"
    if any(x in env_str for x in ["DEV", "QA", "TEST", "UAT", "PDEV", "PT", "STP", "CTE",
                                    "SANDBOX", "NONPROD"]):
        return "NONPROD"
    if "DR" in env_str:
        return "DR"
    return "UNKNOWN"

# ---------------------------------------------------------------------------
# ROUTING_DOMAIN → RD_SHORT
# ---------------------------------------------------------------------------
RD_SHORT = {
    "Internal-PBM":     "PBM",
    "Internal-HCB":     "HCB",
    "Internal-Retail":  "RETAIL",
    "Cloud-Azure":      "AZ",
    "Cloud-GCP":        "GCP",
    "Cloud-AWS":        "AWS",
    "COLO":             "COLO",
}

def rd_short(routing_domain):
    return RD_SHORT.get(routing_domain, re.sub(r'[^A-Z0-9]', '', routing_domain.upper())[:8])

# ---------------------------------------------------------------------------
# HERITAGE normalization
# ---------------------------------------------------------------------------
def normalize_heritage(heritage_str):
    if not isinstance(heritage_str, str):
        return "UNKNOWN"
    h = heritage_str.strip()
    hu = h.upper()
    if hu in ("CVS", "CAREMARK", "PBM", "SWITCH", "COLO"):
        # Switch COLO is CVS-owned infrastructure
        return "CVS"
    if hu in ("AETNA", "HCB"):
        return "AETNA"
    if hu == "OMNICARE":
        return "OMNICARE"
    # Multi-word / hyphenated variants seen in EHM
    if hu in ("CAREMARK/CVS", "CVSHCD"):
        # CAREMARK/CVS = legacy Caremark under CVS
        # CVSHCD = CVS+HCB shared hosting — treat as MIXED
        return "MIXED" if hu == "CVSHCD" else "CVS"
    if hu == "MIXED":
        return "MIXED"
    return hu

# ---------------------------------------------------------------------------
# File loader
# ---------------------------------------------------------------------------
def read_ccd_csv(path):
    """Read CCD-format CSV, skipping # comment header lines.

    v1.9.2 — was `csv.DictReader([line] + list(f))`: materializes the
    entire remaining file into one list, then builds a SECOND list via
    concatenation, before the reader even starts — real, avoidable work on
    a ~294K-row file like retail_networks. Also only skipped LEADING '#'
    lines. Rewritten to the same generator-based idiom used consistently
    elsewhere in this codebase (build_vpn_registry.py, build_partner_ng.py,
    etc.): `l for l in f if not l.startswith('#')`. NOTE: this was found
    while investigating a real stall during a live run reading this exact
    file, but is a confirmed inefficiency, not a confirmed fix for that
    stall — no profiling was done to prove this line was the bottleneck.
    """
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(l for l in f if not l.startswith('#'))
        return list(reader)

def find_file(directory, glob_pattern):
    """Find first matching file in directory."""
    matches = sorted(glob.glob(os.path.join(directory, glob_pattern)), reverse=True)
    if not matches:
        return None
    return matches[0]

def nan_to_none(val):
    """Treat empty/nan strings as None."""
    if val is None:
        return None
    v = str(val).strip()
    if v.lower() in ('', 'nan', 'none', 'null'):
        return None
    return v

# ---------------------------------------------------------------------------
# IPAM LPM lookup (for SUBNET_CIDRS enrichment)
# ---------------------------------------------------------------------------
def build_ipam_index(all_ip_networks_rows):
    """Return sorted list of (network_obj, row) for LPM."""
    entries = []
    for row in all_ip_networks_rows:
        cidr = nan_to_none(row.get('CIDR') or row.get('cidr'))
        if not cidr:
            continue
        try:
            net = ipaddress.ip_network(cidr, strict=False)
            entries.append((net, row))
        except ValueError:
            pass
    entries.sort(key=lambda x: x[0].prefixlen, reverse=True)
    return entries

def lpm_lookup(ip_str, ipam_index):
    """Return the most specific matching CIDR string for an IP, or None."""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return None
    for net, row in ipam_index:
        if ip in net:
            return str(net)
    return None

# ---------------------------------------------------------------------------
# Canonical object container
# ---------------------------------------------------------------------------
class CanonicalObject:
    def __init__(self, name, obj_type, app_acronym=None, service_role=None,
                 heritage=None, routing_domain=None):
        self.name = name
        self.obj_type = obj_type          # APP / INFRA / SERVICE / DELIVERY
        self.app_acronym = app_acronym
        self.service_role = service_role
        self.heritage = heritage
        self.routing_domain = routing_domain
        self.member_ips = set()
        self.vip_ips = set()
        self.subnet_cidrs = set()
        self.locations = set()
        self.source_datasets = set()
        # Schema v2 fields — populated post-build from supplementary sources
        self.app_architecture = 'unknown'   # single-instance|2-tier|3-tier|n-tier|container|microservice|serverless
        self.role_map         = {}          # {ip: role}  UI|MW|DB|API|CACHE|MQ|PROXY|MGMT|BATCH
        self.snat_ips         = set()       # outbound SNAT source IPs
        self.port_deps        = []          # [{from_role, to_role, app_id, port, proto}]
        self.server_ports     = []          # [{app_id, port, proto}]  — listens on
        self.client_ports     = []          # [{app_id, port, proto}]  — connects to
        self.service_deps     = []          # [{name, dep_type}]       — upstream deps
        self.pci_scope        = 'UNKNOWN'   # YES|NO|UNKNOWN
        self.criticality      = 'UNKNOWN'   # HIGH|MED|LOW|UNKNOWN
        self.non_prod         = False        # v1.3.0: True if all members are NON_PROD

    def add_member(self, ip, canonical_location=None, source=None):
        if ip:
            self.member_ips.add(ip)
        if canonical_location:
            self.locations.add(canonical_location)
        if source:
            self.source_datasets.add(source)

    def to_dict(self, dataset_version):
        member_list = sorted(self.member_ips)
        heritage = self.heritage
        if len(set(
            ('CVS' if h in ('CVS','CAREMARK') else
             'AETNA' if h in ('AETNA','HCB') else h)
            for h in [heritage or '']
        )) > 1:
            heritage = 'MIXED'

        # Serialise PORT_DEPS: FROM>TO:APP_ID:PORT/PROTO pipe-separated
        def _fmt_pd(d):
            if isinstance(d, str): return d
            return f"{d['fr']}>{d['to']}:{d['ai']}:{d['pt']}/{d['pr']}"
        def _fmt_port(p):
            if isinstance(p, str): return p  # guard: skip malformed entries
            prefix = f"{p['ai']}:" if p.get('ai') else ''
            return f"{prefix}{p['pt']}/{p['pr']}"
        def _fmt_sd(s):
            if isinstance(s, str): return s  # guard: skip malformed entries
            return f"{s['nm']}:{s['dt']}" if s.get('dt') else s['nm']

        # Normalize OBJECT_TYPE to base class for downstream consumers
        # (APP/INFRA/SERVICE/DELIVERY) — granular subtype preserved in OBJECT_CLASS
        # e.g. obj_type='DELIVERY_EDH' → OBJECT_TYPE='DELIVERY', OBJECT_CLASS='DELIVERY_EDH'
        base_type = self.obj_type or ''
        for _base in ('APP', 'INFRA', 'SERVICE', 'DELIVERY'):
            if base_type.upper().startswith(_base):
                base_type = _base
                break

        return {
            'OBJECT_NAME':      self.name,
            'OBJECT_TYPE':      base_type,
            'OBJECT_CLASS':     self.obj_type,   # granular subtype
            'APP_ACRONYM':      self.app_acronym or '',
            'SERVICE_ROLE':     self.service_role or '',
            'HERITAGE':         heritage or '',
            'ROUTING_DOMAIN':   self.routing_domain or '',
            'MEMBER_IPS':       '|'.join(member_list),
            'VIP_IPS':          '|'.join(sorted(self.vip_ips)),
            'SUBNET_CIDRS':     '|'.join(sorted(self.subnet_cidrs)),
            'LOCATIONS':        '|'.join(sorted(self.locations)),
            'MEMBER_COUNT':     len(member_list),
            'VIP_COUNT':        len(self.vip_ips),
            'SOURCE_DATASETS':  '|'.join(sorted(self.source_datasets)),
            'DATASET_VERSION':  dataset_version,
            # Schema v2
            'APP_ARCHITECTURE': self.app_architecture or 'unknown',
            'ROLE_MAP':         '|'.join(f"{ip}:{role}" for ip, role in sorted(self.role_map.items())),
            'SNAT_IPS':         '|'.join(sorted(self.snat_ips)),
            'SNAT_COUNT':       len(self.snat_ips),
            'PORT_DEPS':        '|'.join(_fmt_pd(d) for d in self.port_deps),
            'SERVER_PORTS':     '|'.join(_fmt_port(p) for p in self.server_ports),
            'CLIENT_PORTS':     '|'.join(_fmt_port(p) for p in self.client_ports),
            'SERVICE_DEPS':     '|'.join(_fmt_sd(s) for s in self.service_deps),
            'PCI_SCOPE':        self.pci_scope or 'UNKNOWN',
            'CRITICALITY':      self.criticality or 'UNKNOWN',
            'NON_PROD':         'Y' if self.non_prod else 'N',    # v1.3.0
        }

# ---------------------------------------------------------------------------
# Build functions
# ---------------------------------------------------------------------------

def build_app_objects(ehm_rows, min_members, excluded_ips, retail_ips, retail_24s=None, verbose=False):
    """
    Build APP_Objects from ent_host_master grouped by PRIMARY_ACRONYM + ROUTING_DOMAIN.
    Excludes IPs in delivery_infrastructure, delivery_platform, and retail_networks.
    retail_ips: set of /32 IPs. retail_24s: set of /24 supernets covering store /26 CIDRs.

    v1.3.0: NON_PROD support — rows with NON_PROD=Y are built into separate
    _NP-suffixed objects (APP_{ACRONYM}_{RD}_NP). These are always included
    regardless of min_members (every non-prod app with a known acronym is
    worth having as a canonical object for FW rule generation).
    Prod objects continue to use min_members threshold.

    Returns (objects_dict, review_queue, null_acronym_rows)
    """
    objects      = {}        # object_name -> CanonicalObject
    review_queue = []        # sub-threshold prod apps
    null_acronym_rows = []   # rows with no PRIMARY_ACRONYM

    # Pre-build EHM service acronym skip set (upper-cased, case-insensitive match)
    _EHM_SVC_SKIP = {k.upper() for k, v in EHM_SERVICE_ACRONYM_MAP.items() if v is not None}

    for row in ehm_rows:
        ip = nan_to_none(row.get('IP_ADDRESS'))
        if not ip:
            continue
        if ip in excluded_ips:
            continue
        if ip in retail_ips:
            continue
        # Retail /26 containment check via /24 supernet index
        if retail_24s:
            try:
                _ip24 = str(ipaddress.ip_network(f"{ip}/24", strict=False))
                if _ip24 in retail_24s:
                    continue
            except ValueError:
                pass

        acronym = nan_to_none(row.get('PRIMARY_ACRONYM'))
        if not acronym:
            null_acronym_rows.append(row)
            continue

        # Skip known infra/service acronyms — prevents double-classification
        if acronym in INFRA_ACRONYM_SET or acronym in SERVICE_ACRONYM_MAP:
            continue
        if acronym.upper() in _EHM_SVC_SKIP:
            continue

        rd       = nan_to_none(row.get('ROUTING_DOMAIN')) or 'UNKNOWN'
        rd_s     = rd_short(rd)
        heritage = normalize_heritage(nan_to_none(row.get('HERITAGE')))
        loc      = nan_to_none(row.get('CANONICAL_LOCATION'))

        # v1.3.0: NON_PROD detection — separate _NP object namespace
        is_non_prod = (row.get('NON_PROD') or '').strip().upper() == 'Y'
        obj_name = f"APP_{acronym.upper()}_{rd_s}_NP" if is_non_prod else f"APP_{acronym.upper()}_{rd_s}"

        if obj_name not in objects:
            obj = CanonicalObject(
                name=obj_name,
                obj_type='APP',
                app_acronym=acronym,
                heritage=heritage,
                routing_domain=rd,
            )
            obj.non_prod = is_non_prod   # v1.3.0
            objects[obj_name] = obj
        objects[obj_name].add_member(ip, canonical_location=loc, source='EHM')

    # Apply min_members filter — prod objects only; non-prod always included
    final_objects = {}
    for name, obj in objects.items():
        if obj.non_prod:
            final_objects[name] = obj   # always include non-prod objects
        elif len(obj.member_ips) >= min_members:
            final_objects[name] = obj
        else:
            review_queue.append((name, obj))

    if verbose:
        prod_count  = sum(1 for o in final_objects.values() if not o.non_prod)
        np_count    = sum(1 for o in final_objects.values() if o.non_prod)
        print(f"  APP_Objects (prod)   : {prod_count}")
        print(f"  APP_Objects (non-prod): {np_count}")
        print(f"  APP_Objects review queue (< {min_members} members): {len(review_queue)}")
        print(f"  EHM rows with no PRIMARY_ACRONYM: {len(null_acronym_rows)}")

    return final_objects, review_queue, null_acronym_rows


def build_infra_objects(infra_rows, verbose=False):
    """
    Build INFRA_Objects and SERVICE_Objects from delivery_infrastructure.
    Classification logic uses SERVER_CLASS + APP_ACRONYMS since no ROLE column exists.
    Returns (infra_objects, service_objects, delivery_objects_from_infra, unclassified)
    """
    infra_objects = {}      # name -> CanonicalObject
    service_objects = {}
    delivery_objects = {}
    unclassified = []

    for row in infra_rows:
        ip = nan_to_none(row.get('IP_ADDRESS'))
        if not ip or ip == '0.0.0.0':
            continue

        server_class = nan_to_none(row.get('SERVER_CLASS')) or ''
        platform_type = nan_to_none(row.get('PLATFORM_TYPE')) or ''
        app_acronyms_raw = nan_to_none(row.get('APP_ACRONYMS')) or ''
        app_acronyms = [a.strip() for a in app_acronyms_raw.split('|') if a.strip()] if app_acronyms_raw else []
        first_acronym = app_acronyms[0] if app_acronyms else ''

        heritage = normalize_heritage(nan_to_none(row.get('HERITAGE')))
        loc = nan_to_none(row.get('CANONICAL_LOCATION'))
        lc = loc_code(loc)
        env_raw = nan_to_none(row.get('APP_ENVIRONMENTS')) or nan_to_none(row.get('PRIMARY_ENV'))
        env = normalize_env(env_raw)
        rd = nan_to_none(row.get('ROUTING_DOMAIN')) or 'UNKNOWN'

        # --- DELIVERY: DataPower ---
        if server_class == 'Data Power Hosting Server':
            rd_s = rd_short(rd)
            obj_name = f"DELIVERY_DATAPOWER_{rd_s}"
            if obj_name not in delivery_objects:
                delivery_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='DELIVERY',
                    service_role='DATAPOWER', heritage=heritage, routing_domain=rd)
            delivery_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- INFRA: ESXi (primary bulk) ---
        # Match on PLATFORM_TYPE, SERVER_CLASS, or INFRA_ACRONYM_SET token in APP_ACRONYMS.
        # Catches ESXSystems rows with SERVER_CLASS='Server' (not 'ESX Server').
        _is_esxi = (platform_type == 'ESX-HOST' or server_class == 'ESX Server'
                    or any(a in INFRA_ACRONYM_SET and 'ESX' in a.upper()
                           for a in app_acronyms))
        if _is_esxi:
            # Group by location + env; PCI hosts get separate object
            is_pci = 'PCI' in app_acronyms_raw.upper()
            pci_suffix = '_PCI' if is_pci else ''
            env_suffix = env if env != 'UNKNOWN' else 'SHARED'
            # Switch COLO ESXi hosts often have blank HERITAGE — default to CVS
            # (Switch COLO at LV/ATL/TRE is CVS-owned infrastructure)
            _COLO_LOC_CODES = {'LV', 'ATL', 'TRE', 'ATL_SPEC', 'ATL_AETNA'}
            esxi_heritage = heritage
            if esxi_heritage == 'UNKNOWN' and lc in _COLO_LOC_CODES:
                esxi_heritage = 'CVS'
            obj_name = f"INFRA_ESXI_{lc}_{env_suffix}{pci_suffix}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='ESXI', heritage=esxi_heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- INFRA: IBM HMC ---
        if 'HMC' in server_class.upper() or first_acronym in ('HMCSystemsCVS', 'HMCSystemsPCICVS', 'HMCSystemsRXConnect'):
            obj_name = f"INFRA_IBM_HMC_{lc}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='IBM_HMC', heritage=heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- INFRA: IBM iSeries ---
        if server_class == 'IBM iSeries LPAR':
            obj_name = f"INFRA_IBM_ISERIES_{lc}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='IBM_ISERIES', heritage=heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- INFRA: IBM Mainframe / zOS ---
        if server_class in ('IBM Mainframe', 'IBM Mainframe LPAR', 'Ibm Mainframe Lpar', 'IBM zOS server'):
            obj_name = f"INFRA_IBM_MF_{lc}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='IBM_MF', heritage=heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- SERVICE: known APP_ACRONYMS patterns ---
        matched_service = None
        for acr in app_acronyms:
            if acr in SERVICE_ACRONYM_MAP:
                matched_service = SERVICE_ACRONYM_MAP[acr]
                break

        if matched_service:
            if matched_service not in service_objects:
                service_objects[matched_service] = CanonicalObject(
                    name=matched_service, obj_type='SERVICE',
                    service_role=first_acronym, heritage=heritage, routing_domain=rd)
            service_objects[matched_service].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- SERVICE: MF Storage and Infra ---
        if first_acronym in ('MFSTORAGE', 'MFInfraSoftware', 'FileServersIsilon'):
            svc_name = SERVICE_ACRONYM_MAP.get(first_acronym, f"SVC_{first_acronym.upper()}")
            if svc_name not in service_objects:
                service_objects[svc_name] = CanonicalObject(
                    name=svc_name, obj_type='SERVICE',
                    service_role=first_acronym, heritage=heritage, routing_domain=rd)
            service_objects[svc_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- DELIVERY: IBM Integration Bus (IIB) cluster nodes ---------------
        # Multi-value APP_ACRONYMS starting with IIB tokens (e.g. IIBCrypto|IIBENF...)
        if any(a.upper().startswith('IIB') for a in app_acronyms):
            rd_s = rd_short(rd)
            if rd in ('Cloud-GCP', 'Cloud-Azure', 'Cloud-AWS'):
                obj_name = f"DELIVERY_IIB_{lc}"
            else:
                obj_name = f"DELIVERY_IIB_{rd_s}_{lc}"
            if obj_name not in delivery_objects:
                delivery_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='DELIVERY',
                    service_role='IIB', heritage=heritage, routing_domain=rd)
            delivery_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- SKIP: known app acronyms that leaked into delivery_infrastructure ---
        # These are app-layer workloads tracked in EHM — skip here to avoid
        # duplicating IPs across INFRA and APP objects.
        _APP_ACRONYMS_IN_INFRA = {
            'CVSESL', 'DBPL', 'GENERALLEDGERMAINFRAMEGL',
            # App workloads confirmed in delivery_infrastructure (2026-05-22 review)
            'MINUTECLINICEPICCACHE',   # MinuteClinic Epic cache — app, not infra
            'FORECASTREPLENISHMENT',   # Forecast/Replenishment app
            'AVAM', 'AVAP', 'CMA', 'AUTHENTICATIONHUBNGA',  # Auth Hub apps (AETNA)
            'GENELCO',                 # Genelco app (AETNA)
            'COORS',                   # COORS app (CVS in Internal-HCB)
        }
        if any(a in _APP_ACRONYMS_IN_INFRA for a in app_acronyms):
            continue

        # --- CONTAINER-BRIDGE (Linux VMs bridging container networks) ---
        if platform_type == 'CONTAINER-BRIDGE':
            obj_name = f"INFRA_CONTAINER_BRIDGE_{lc}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='CONTAINER-BRIDGE', heritage=heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- Network/hardware Appliances (no APP_ACRONYMS, no SERVER_CLASS match) ---
        if server_class == 'Appliance' or server_class == 'Network Appliance Hardware':
            obj_name = f"INFRA_APPLIANCE_{lc}"
            if obj_name not in infra_objects:
                infra_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='INFRA',
                    service_role='APPLIANCE', heritage=heritage, routing_domain=rd)
            infra_objects[obj_name].add_member(ip, canonical_location=loc, source='INFRA')
            continue

        # --- Unclassified ---
        unclassified.append(row)

    if verbose:
        print(f"  INFRA_Objects: {len(infra_objects)}")
        print(f"  SERVICE_Objects (from INFRA): {len(service_objects)}")
        print(f"  DELIVERY_Objects (DataPower from INFRA): {len(delivery_objects)}")
        print(f"  Unclassified INFRA rows: {len(unclassified)}")

    return infra_objects, service_objects, delivery_objects, unclassified


def build_service_objects_from_ehm(ehm_rows, excluded_ips, verbose=False):
    """
    Supplement SERVICE_Objects from EHM rows where PRIMARY_ACRONYM matches
    known enterprise service names.
    Returns service_objects dict.
    """
    service_objects = {}
    service_acronyms_upper = {k.upper(): v for k, v in EHM_SERVICE_ACRONYM_MAP.items()
                               if v is not None}

    for row in ehm_rows:
        ip = nan_to_none(row.get('IP_ADDRESS'))
        if not ip or ip in excluded_ips:
            continue

        acronym = nan_to_none(row.get('PRIMARY_ACRONYM'))
        if not acronym:
            continue

        svc_name = service_acronyms_upper.get(acronym.upper())
        # NOTE: secondary APP_ACRONYMS lookup removed — it caused contamination
        # (e.g. app servers that USE Venafi/CyberArk appearing as service objects).
        # All service acronym variants must be explicit PRIMARY_ACRONYM entries in
        # EHM_SERVICE_ACRONYM_MAP. Having a service in APP_ACRONYMS means
        # "uses this service", not "is this service infrastructure".
        if not svc_name:
            continue

        heritage = normalize_heritage(nan_to_none(row.get('HERITAGE')))
        rd = nan_to_none(row.get('ROUTING_DOMAIN')) or 'UNKNOWN'
        loc = nan_to_none(row.get('CANONICAL_LOCATION'))

        # Apply heritage suffix unless the map value already has one
        # This ensures single-heritage services get _CVS or _HCB suffix
        if heritage == 'CVS' and not svc_name.endswith('_CVS'):
            obj_name = svc_name + '_CVS'
        elif heritage == 'AETNA' and not svc_name.endswith('_HCB'):
            obj_name = svc_name + '_HCB'
        else:
            obj_name = svc_name  # already suffixed or genuinely MIXED

        if obj_name not in service_objects:
            service_objects[obj_name] = CanonicalObject(
                name=obj_name, obj_type='SERVICE',
                service_role=acronym, heritage=heritage, routing_domain=rd)
        service_objects[obj_name].add_member(ip, canonical_location=loc, source='EHM')

    if verbose:
        print(f"  SERVICE_Objects (from EHM): {len(service_objects)}")

    return service_objects



# ---------------------------------------------------------------------------
# CPC SERVICE name → canonical SVC_* object name
# ---------------------------------------------------------------------------
# Source: ent-ipdataset-CPC-CORE-SERVICES (CPC Master Security Template)
# These are the authoritative SERVICE_Object IPs — AD/DC, Splunk, NTP, etc.
# Heritage split applied where SCOPE/HERITAGE differs (CVS vs HCB)
CPC_SERVICE_NAME_MAP = {
    'active directory':           'SVC_AD_DC',
    'active directory (nonprod)': 'SVC_AD_DC_NONPROD',
    'active directory vip':       'SVC_AD_DC_VIP',
    'centrify':                   'SVC_CENTRIFY',
    'itm':                    'SVC_ITM',
    'ucmdb':                  'SVC_UCMDB',
    'obm non-prod':           'SVC_OBM_NONPROD',
    'obm prod':               'SVC_OBM_PROD',
    'splunk':                 'SVC_SPLUNK',
    'ntp':                    'SVC_NTP',
    'sitescope':              'SVC_SITESCOPE',
    'ansible':                'SVC_ANSIBLE',
    'jump servers':           'SVC_JUMP',
    'rear & linux jump':      'SVC_JUMP',
    'rear/kdump':             'SVC_KDUMP',
    'sat6':                   'SVC_SATELLITE',
    'sattellite':             'SVC_SATELLITE',   # typo in source data
    'bootstrap nexus':        'SVC_BOOTSTRAP_NEXUS',
    'bootstrap':              'SVC_BOOTSTRAP',
    'cloudbees/jenkins':      'SVC_CLOUDBEES',
    'cloudbees':              'SVC_CLOUDBEES',
    'beyond trust':           'SVC_BEYONDTRUST',
    'iam':                    'SVC_IAM',
    'chef':                   'SVC_CHEF',
    'qualys':                 'SVC_QUALYS',
    'qualys scanner':         'SVC_QUALYS',
    'qulays integration':     'SVC_QUALYS',      # typo in source data
    'linux servers to qulays agents': 'SVC_QUALYS',
    'linux admin':            'SVC_LINUX_ADMIN',
    'netcool':                'SVC_NETCOOL',
    'dns':                    'SVC_DNS',
    'syslog':                 'SVC_SYSLOG',
    'nifi':                   'SVC_NIFI',
    'linux servers to nifi servers\n(submit cvs firewall too)': 'SVC_NIFI',
    'ppdm(gcp)':              'SVC_PPDM',
    'kdump':                  'SVC_KDUMP',
    'fim':                    'SVC_FIM',
    'lpar2rrd':               'SVC_LPAR2RRD',
    'bigfix':                 'SVC_BIGFIX',
    'github automation (linux to github)': 'SVC_GITHUB_AUTOMATION',
    # v1.4.2: name variants from build_cpc_service_catalog output
    'tivoli itm':           'SVC_ITM',
    'obm':                  'SVC_OBM_PROD',
    'rear / linux jump':    'SVC_JUMP',
    'red hat satellite 6':  'SVC_SATELLITE',
    'cloudbees ci':         'SVC_CLOUDBEES',
    'beyondtrust':          'SVC_BEYONDTRUST',
    'apache nifi':          'SVC_NIFI',
    'dell ppdm':            'SVC_PPDM',
    'nexus repository':     'SVC_BOOTSTRAP_NEXUS',
    # v1.4.3: per-domain AD service entries — domain FQDN → SVC_AD_* object
    'ad.meritain.com'                               : 'SVC_AD_MERITAIN',
    'aetDMZ.com'                                    : 'SVC_AD_AETNA_DMZ',
    'aetDMZQ.com'                                   : 'SVC_AD_AETNA_DMZ_QA',
    'aetDMZT.com'                                   : 'SVC_AD_AETNA_DMZ_TEST',
    'aeth.aetna.com'                                : 'SVC_AD_AETH_AETNA',
    'aethE.aetnae.com'                              : 'SVC_AD_AETHE_AETNA',
    'aethEQ.aetnaeq.com'                            : 'SVC_AD_AETHE_AETNA_QA',
    'aethET.aetnaet.com'                            : 'SVC_AD_AETHE_AETNA_TEST',
    'aethQ.aetnaq.com'                              : 'SVC_AD_AETH_AETNA_QA',
    'aetna.com'                                     : 'SVC_AD_AETNA',
    'aetnaE.com'                                    : 'SVC_AD_AETNA_EXT',
    'aetnaEQ.com'                                   : 'SVC_AD_AETNA_EXT_QA',
    'aetnaET.com'                                   : 'SVC_AD_AETNA_EXT_TEST',
    'aetnaQ.com'                                    : 'SVC_AD_AETNA_QA',
    'aetnaT.com'                                    : 'SVC_AD_AETNA_TEST',
    'aetnsd.aeth.aetna.com'                         : 'SVC_AD_AETNSD',
    'aetnsdq.aethq.aetnaq.com'                      : 'SVC_AD_AETNSD_QA',
    'aetnsdt.aett.aetnat.com'                       : 'SVC_AD_AETNSD_TEST',
    'aett.aetnat.com'                               : 'SVC_AD_AETH_AETNA_TEST',
    'ahm.corp'                                      : 'SVC_AD_AHM',
    'ahmdmz.corp'                                   : 'SVC_AD_AHM_DMZ',
    'caremarkrx.net'                                : 'SVC_AD_CAREMARKRX',
    'coe.caremarkrx.net'                            : 'SVC_AD_COE_CAREMARKRX',
    'corp.cvs.com'                                  : 'SVC_AD_CORP_CVS',
    'corp.cvscaremark.com'                          : 'SVC_AD_CORP_CVSCAREMARK',
    'corp.omnicare.com'                             : 'SVC_AD_CORP_OMNICARE',
    'cust.meritain.com'                             : 'SVC_AD_MERITAIN_CUST',
    'custtest.cust.meritain.com'                    : 'SVC_AD_MERITAIN_CUST_TEST',
    'cvty.com'                                      : 'SVC_AD_CVTY',
    'dmz.meritain.com'                              : 'SVC_AD_MERITAIN_DMZ',
    'dr.cvs.com'                                    : 'SVC_AD_DR_CVS',
    'ent.cvshealth.com'                             : 'SVC_AD_ENT_CVSHEALTH',
    'ext.cvty.com'                                  : 'SVC_AD_EXT_CVTY',
    'healthds.com'                                  : 'SVC_AD_HEALTHDS',
    'healthehost.com'                               : 'SVC_AD_HEALTHEHOST',
    'healthehostt.com'                              : 'SVC_AD_HEALTHEHOST_TEST',
    'minclinic.local'                               : 'SVC_AD_MINCLINIC',
    'omnicare.com'                                  : 'SVC_AD_OMNICARE',
    'pdc-dmz.local'                                 : 'SVC_AD_PDC_DMZ',
    'pdchs.local'                                   : 'SVC_AD_PDCHS',
    'pdcss.local'                                   : 'SVC_AD_PDCSS',
    'ppom.info'                                     : 'SVC_AD_PPOM',
    'resource.info'                                 : 'SVC_AD_RESOURCE',
    'test.cvscaremark.com'                          : 'SVC_AD_CORP_CVSCAREMARK_TEST',
    'xauth.cofinity.net'                            : 'SVC_AD_COFINITY',
    'xtest.cofinity.net'                            : 'SVC_AD_COFINITY_TEST',
}

# SCOPE → heritage for CPC objects
# hCVS = CVS, HCB = AETNA, Foundation = shared/both
def cpc_heritage(scope_str, heritage_str):
    """Derive heritage from CPC SCOPE and HERITAGE columns."""
    scope = (scope_str or '').upper()
    hval  = (heritage_str or '').upper()
    if hval == 'HCB':
        return 'AETNA'
    if hval == 'CVS':
        return 'CVS'
    if hval == 'FOUNDATION':
        return 'MIXED'
    # Fall through to SCOPE
    if 'HCVS' in scope and 'HCB' not in scope:
        return 'CVS'
    if 'HCB' in scope and 'HCVS' not in scope:
        return 'AETNA'
    return 'MIXED'


def build_service_objects_from_cpc(cpc_rows, verbose=False):
    """
    Build SERVICE_Objects from ent-ipdataset-CPC-CORE-SERVICES.
    This is the authoritative source for enterprise service server IPs
    (AD DC, Splunk, NTP, Centrify, DNS, SYSLOG, Qualys, etc.).

    Rules:
    - Group by SERVICE (normalized) + heritage
    - Heritage split: CVS objects get _CVS suffix, HCB get _HCB, MIXED have no suffix
    - IP_ADDRESS column already has /32 format — strip the /32
    """
    service_objects = {}
    delivery_objects = {}   # NETWORK-class CIDRs (runner pools, CAP subnets)
    cidr_count = 0

    for row in cpc_rows:
        ip_raw = nan_to_none(row.get('IP_ADDRESS'))
        if not ip_raw:
            continue

        dataset_class = nan_to_none(row.get('IP_DATASET_CLASS')) or 'ENTERPRISE'
        service_name_raw = nan_to_none(row.get('SERVICE')) or ''
        svc_key = service_name_raw.strip().lower()
        scope = nan_to_none(row.get('SCOPE')) or ''
        heritage_raw = nan_to_none(row.get('HERITAGE')) or ''
        heritage = cpc_heritage(scope, heritage_raw)
        region = nan_to_none(row.get('REGION')) or ''

        # NETWORK-class rows (IP_DATASET_CLASS=NETWORK) are CIDR subnet objects
        # e.g. GitHub runner pools, CAP infra subnets — NOT individual /32 servers
        if dataset_class == 'NETWORK':
            cidr = ip_raw.strip()
            slug = nan_to_none(row.get('SERVICE_SLUG')) or svc_key
            obj_name = 'DELIVERY_' + re.sub(r'[^A-Z0-9]+', '_', slug.upper()).strip('_')
            if heritage == 'CVS':
                obj_name += '_CVS'
            elif heritage == 'AETNA':
                obj_name += '_HCB'

            # Routing domain from region hint
            if 'gcp' in region.lower() or 'google' in region.lower():
                rd = 'Cloud-GCP'
            elif 'azure' in region.lower() or 'az' in region.lower():
                rd = 'Cloud-Azure'
            else:
                rd = 'Internal-PBM'

            if obj_name not in delivery_objects:
                delivery_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='DELIVERY',
                    service_role=service_name_raw.strip(),
                    heritage=heritage, routing_domain=rd)
            # Add CIDR to subnet_cidrs; no /32 MEMBER_IPS for these
            delivery_objects[obj_name].subnet_cidrs.add(cidr)
            delivery_objects[obj_name].source_datasets.add('CPC-CORE-SVC')
            cidr_count += 1
            continue

        # /32 server rows — standard SERVICE_Object path
        ip = ip_raw.split('/')[0] if '/' in ip_raw else ip_raw

        base_svc_name = CPC_SERVICE_NAME_MAP.get(svc_key)
        if not base_svc_name:
            slug = nan_to_none(row.get('SERVICE_SLUG')) or svc_key
            base_svc_name = 'SVC_' + re.sub(r'[^A-Z0-9]+', '_', slug.upper()).strip('_')

        if heritage == 'CVS':
            obj_name = f'{base_svc_name}_CVS'
        elif heritage == 'AETNA':
            obj_name = f'{base_svc_name}_HCB'
        else:
            obj_name = base_svc_name

        try:
            ip_obj = ipaddress.ip_address(ip)
            if ip_obj.is_private:
                rd = 'Internal-HCB' if heritage == 'AETNA' else 'Internal-PBM'
            else:
                rd = 'Internal-HCB'
        except ValueError:
            rd = 'UNKNOWN'

        if obj_name not in service_objects:
            service_objects[obj_name] = CanonicalObject(
                name=obj_name, obj_type='SERVICE',
                service_role=service_name_raw.strip(),
                heritage=heritage, routing_domain=rd)
        service_objects[obj_name].add_member(ip, canonical_location=None, source='CPC-CORE-SVC')

    if verbose:
        print(f'  SERVICE_Objects (from CPC-CORE-SERVICES): {len(service_objects)}')
        print(f'  DELIVERY_Objects (NETWORK-class CIDRs from CPC): {len(delivery_objects)} objects, {cidr_count} CIDRs')

    return service_objects, delivery_objects


def build_delivery_objects(plat_rows, verbose=False):
    """
    Build DELIVERY_Objects from delivery_platform.
    - PLATFORM_TYPE='KUBERNETES' → GKE clusters, grouped by ROUTING_DOMAIN + CANONICAL_LOCATION + ENV
    - NaN PLATFORM_TYPE + OS_GROUP=Kubernetes or OpenshiftOCP in APP_ACRONYMS → OpenShift nodes
    - NaN PLATFORM_TYPE + Linux → individual Linux delivery nodes (grouped by location + RD)
    Returns delivery_objects dict.
    """
    delivery_objects = {}

    for row in plat_rows:
        ip = nan_to_none(row.get('IP_ADDRESS'))
        if not ip:
            continue

        platform_type = nan_to_none(row.get('PLATFORM_TYPE')) or ''
        os_group = nan_to_none(row.get('OS_GROUP')) or ''
        server_class = nan_to_none(row.get('SERVER_CLASS')) or ''
        app_acronyms_raw = nan_to_none(row.get('APP_ACRONYMS')) or ''
        app_acronyms = [a.strip() for a in app_acronyms_raw.split('|') if a.strip()]

        heritage = normalize_heritage(nan_to_none(row.get('HERITAGE')))
        loc = nan_to_none(row.get('CANONICAL_LOCATION'))
        lc = loc_code(loc)
        rd = nan_to_none(row.get('ROUTING_DOMAIN')) or 'UNKNOWN'
        rd_s = rd_short(rd)
        env_raw = nan_to_none(row.get('APP_ENVIRONMENTS')) or nan_to_none(row.get('PRIMARY_ENV'))
        env = normalize_env(env_raw)
        # v1.4.1: NON_PROD fallback when APP_ENVIRONMENTS/PRIMARY_ENV blank
        if env == 'UNKNOWN':
            _non_prod = (nan_to_none(row.get('NON_PROD')) or '').strip().upper()
            if _non_prod == 'Y':
                env = 'NONPROD'
            elif _non_prod == 'N':
                env = 'PROD'

        # --- GKE / Kubernetes clusters ---
        if platform_type == 'KUBERNETES':
            # For cloud RDs, loc_code already encodes cloud region; skip rd_s prefix
            if rd in ('Cloud-GCP', 'Cloud-Azure', 'Cloud-AWS'):
                obj_name = f"DELIVERY_GKE_{lc}_{env}"
            else:
                obj_name = f"DELIVERY_GKE_{rd_s}_{lc}_{env}"
            if obj_name not in delivery_objects:
                delivery_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='DELIVERY',
                    service_role='GKE', heritage=heritage, routing_domain=rd)
            delivery_objects[obj_name].add_member(ip, canonical_location=loc, source='PLATFORM')
            continue

        # --- OpenShift nodes (NaN PLATFORM_TYPE, OS_GROUP=Kubernetes, or OpenshiftOCP in acronyms) ---
        is_ocp = (os_group == 'Kubernetes' and platform_type == '') or \
                 any('openshift' in a.lower() or 'ocp' in a.lower() for a in app_acronyms)
        if is_ocp:
            if rd in ('Cloud-GCP', 'Cloud-Azure', 'Cloud-AWS'):
                obj_name = f"DELIVERY_OCP_{lc}_{env}"
            else:
                obj_name = f"DELIVERY_OCP_{rd_s}_{lc}_{env}"
            if obj_name not in delivery_objects:
                delivery_objects[obj_name] = CanonicalObject(
                    name=obj_name, obj_type='DELIVERY',
                    service_role='OPENSHIFT', heritage=heritage, routing_domain=rd)
            delivery_objects[obj_name].add_member(ip, canonical_location=loc, source='PLATFORM')
            continue

        # --- Other Linux delivery nodes (grouped by app acronym if present, else location) ---
        primary_acr = nan_to_none(row.get('PRIMARY_ACRONYM'))
        if primary_acr and primary_acr.upper() not in ('OPENSHIFTOCP',):
            obj_name = f"DELIVERY_{primary_acr.upper()}_{rd_s}_{env}"
        else:
            if rd in ('Cloud-GCP', 'Cloud-Azure', 'Cloud-AWS'):
                obj_name = f"DELIVERY_LINUX_{lc}_{env}"
            else:
                obj_name = f"DELIVERY_LINUX_{rd_s}_{lc}_{env}"

        if obj_name not in delivery_objects:
            delivery_objects[obj_name] = CanonicalObject(
                name=obj_name, obj_type='DELIVERY',
                service_role='LINUX_DELIVERY', heritage=heritage, routing_domain=rd)
        delivery_objects[obj_name].add_member(ip, canonical_location=loc, source='PLATFORM')

    if verbose:
        print(f"  DELIVERY_Objects: {len(delivery_objects)}")

    return delivery_objects


def build_vip_index(pool_rows):
    """
    Build member_ip -> set(vip_ips) index from F5-POOL-MEMBERS.
    """
    index = defaultdict(set)
    for row in pool_rows:
        member_ip = nan_to_none(row.get('MEMBER_IP'))
        vip_ip = nan_to_none(row.get('VIP_IP'))
        if member_ip and vip_ip and vip_ip not in ('0.0.0.0', ''):
            index[member_ip].add(vip_ip)
    return index


def apply_vip_attribution(objects_dict, vip_index):
    """Attach VIP_IPS to each object based on member IP → VIP lookup."""
    for obj in objects_dict.values():
        for member_ip in obj.member_ips:
            vips = vip_index.get(member_ip, set())
            obj.vip_ips.update(vips)


def apply_ipam_enrichment(objects_dict, ipam_index):
    """
    Attach SUBNET_CIDRS to each object via LPM against all_IP_networks.

    v1.5.0: Cache LPM results per /24 — vastly reduces repeated lookups.
    Each unique /24 is looked up once; all IPs in that /24 reuse the result.
    """
    cache = {}  # ip_24_str -> cidr_str or None
    for obj in objects_dict.values():
        for member_ip in obj.member_ips:
            # Build /24 key
            parts = member_ip.split('.') if member_ip else []
            if len(parts) != 4:
                continue
            ip_24 = '.'.join(parts[:3]) + '.0'
            if ip_24 not in cache:
                cache[ip_24] = lpm_lookup(member_ip, ipam_index)
            cidr = cache[ip_24]
            if cidr:
                obj.subnet_cidrs.add(cidr)




def merge_service_objects(*service_dicts):
    """
    Merge SERVICE_Objects from multiple sources. If same object name exists
    in multiple sources, merge member IPs.
    """
    merged = {}
    for d in service_dicts:
        for name, obj in d.items():
            if name not in merged:
                merged[name] = obj
            else:
                merged[name].member_ips.update(obj.member_ips)
                merged[name].vip_ips.update(obj.vip_ips)
                merged[name].locations.update(obj.locations)
                merged[name].source_datasets.update(obj.source_datasets)
    return merged


def validate_objects(all_objects, verbose=True):
    """
    Run validation rules from SKILL §9.
    Returns list of violations.
    """
    violations = []

    # Check unique OBJECT_NAMEs
    names = [obj.name for obj in all_objects]
    dups = [n for n in set(names) if names.count(n) > 1]
    for dup in dups:
        violations.append(f"DUPLICATE_NAME: {dup}")

    # Check MEMBER_COUNT consistency
    for obj in all_objects:
        # Guard: coerce server_ports/client_ports to list if set as string
        if isinstance(getattr(obj, 'server_ports', []), str):
            obj.server_ports = []
        if isinstance(getattr(obj, 'client_ports', []), str):
            obj.client_ports = []
        if isinstance(getattr(obj, 'service_deps', []), str):
            obj.service_deps = []
        if isinstance(getattr(obj, 'port_deps', []), str):
            obj.port_deps = []
        if len(obj.member_ips) != obj.to_dict('CHECK').get('MEMBER_COUNT', -1):
            violations.append(f"MEMBER_COUNT_MISMATCH: {obj.name}")

    # Check HERITAGE=MIXED logic (simplified — flag objects with >1 RD)
    for obj in all_objects:
        rds = set()
        # Not possible to check per-IP RD here without EHM join; skip deep check

    if verbose and violations:
        print(f"\n  VALIDATION: {len(violations)} violation(s)")
        for v in violations[:20]:
            print(f"    {v}")
    elif verbose:
        print("  VALIDATION: PASS (0 violations)")

    return violations


def write_review_queue(review_items, null_rows, unclassified_infra, out_path, dataset_version):
    """Write review queue CSV."""
    rows = []
    for name, obj in review_items:
        rows.append({
            'REASON': 'SINGLE_MEMBER',
            'OBJECT_NAME': name,
            'OBJECT_TYPE': obj.obj_type,
            'APP_ACRONYM': obj.app_acronym or '',
            'HERITAGE': obj.heritage or '',
            'ROUTING_DOMAIN': obj.routing_domain or '',
            'MEMBER_IPS': '|'.join(sorted(obj.member_ips)),
            'MEMBER_COUNT': len(obj.member_ips),
            'DATASET_VERSION': dataset_version,
        })
    for row in null_rows:
        rows.append({
            'REASON': 'NULL_APP_ACRONYM',
            'OBJECT_NAME': '',
            'OBJECT_TYPE': 'APP',
            'APP_ACRONYM': '',
            'HERITAGE': nan_to_none(row.get('HERITAGE')) or '',
            'ROUTING_DOMAIN': nan_to_none(row.get('ROUTING_DOMAIN')) or '',
            'MEMBER_IPS': nan_to_none(row.get('IP_ADDRESS')) or '',
            'MEMBER_COUNT': 1,
            'DATASET_VERSION': dataset_version,
        })
    for row in unclassified_infra:
        rows.append({
            'REASON': 'UNCLASSIFIED_INFRA',
            'OBJECT_NAME': '',
            'OBJECT_TYPE': 'INFRA',
            'APP_ACRONYM': nan_to_none(row.get('APP_ACRONYMS')) or '',
            'HERITAGE': nan_to_none(row.get('HERITAGE')) or '',
            'ROUTING_DOMAIN': nan_to_none(row.get('ROUTING_DOMAIN')) or '',
            'MEMBER_IPS': nan_to_none(row.get('IP_ADDRESS')) or '',
            'MEMBER_COUNT': 1,
            'DATASET_VERSION': dataset_version,
        })

    if not rows:
        return

    fieldnames = ['REASON','OBJECT_NAME','OBJECT_TYPE','APP_ACRONYM','HERITAGE',
                  'ROUTING_DOMAIN','MEMBER_IPS','MEMBER_COUNT','DATASET_VERSION']
    with open(out_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _parse_ports_from_flows(flow_list):
    """
    Derive SERVER_PORTS, CLIENT_PORTS, PORT_DEPS from a list of flow dicts.

    Convention:
      - DST_ZONE != 'SaaS'  and  DST_COMPONENT is a service component
        → this service acts as SERVER on those ports (inbound)
      - SRC_COMPONENT is a service component calling something else
        → this service acts as CLIENT on those ports (outbound)

    We use SRC_TYPE / DST_TYPE to distinguish internal components from
    external targets (SaaS endpoints, AD DCs, SQL servers).

    Returns (server_ports, client_ports, port_deps)
    Each is a list of dicts matching the CanonicalObject schema.
    """
    EXTERNAL_TYPES = {
        'SaaS endpoint', 'AD Domain Controller', 'Central Database (service infrastructure)',
        'Central Database/Console (service infrastructure)',
    }
    EXTERNAL_ZONES = {'SaaS', 'External DCs'}

    server_ports = []
    client_ports = []
    port_deps    = []

    seen_srv  = set()
    seen_cli  = set()
    seen_deps = set()

    def _split_ports(ports_raw):
        """Split comma-separated port string, normalise, skip blanks/TBD."""
        out = []
        for tok in re.split(r'[,;]+', ports_raw or ''):
            tok = tok.strip()
            if not tok or tok.upper() in ('TBD', 'N/A', 'NA', ''):
                continue
            # Handle Tidal-style freetext: "Agent → Master: TCP 5591"
            m = re.search(r'(?:TCP|UDP)?\s*(\d+)', tok, re.I)
            if m:
                out.append(m.group(1))
        return out

    for f in flow_list:
        ports_raw = f.get('PORTS', '')
        proto     = (f.get('PROTOCOL') or 'TCP').strip().upper()
        if not ports_raw:
            continue

        dst_zone = f.get('DST_ZONE', '')
        src_type = f.get('SRC_TYPE', '')
        dst_type = f.get('DST_TYPE', '')

        # Classify direction
        is_outbound_to_external = (
            dst_zone in EXTERNAL_ZONES or
            dst_type in EXTERNAL_TYPES
        )

        ports = _split_ports(ports_raw)
        for port in ports:
            if is_outbound_to_external:
                # Service initiates to an external target → CLIENT port
                key = (port, proto)
                if key not in seen_cli:
                    seen_cli.add(key)
                    client_ports.append({'ai': '', 'pt': port, 'pr': proto})
            else:
                # Service receives internal connection → SERVER port
                key = (port, proto)
                if key not in seen_srv:
                    seen_srv.add(key)
                    server_ports.append({'ai': '', 'pt': port, 'pr': proto})

        # PORT_DEPS: normalise SRC/DST component names to short role labels
        def _role(label):
            l = (label or '').lower()
            if 'agent'      in l: return 'AGENT'
            if 'connector'  in l: return 'CONNECTOR'
            if 'scanner'    in l or 'collector' in l: return 'COLLECTOR'
            if 'aggregator' in l: return 'AGGREGATOR'
            if 'forwarder'  in l: return 'FORWARDER'
            if 'server'     in l: return 'SERVER'
            if 'client'     in l: return 'CLIENT'
            if 'gateway'    in l: return 'GATEWAY'
            if 'worker'     in l or 'node' in l: return 'WORKER'
            return 'COMPONENT'

        src_role = _role(f.get('SRC_TYPE', ''))
        dst_role = _role(f.get('DST_TYPE', ''))
        for port in ports:
            key = (src_role, dst_role, port, proto)
            if key not in seen_deps:
                seen_deps.add(key)
                port_deps.append({'fr': src_role, 'to': dst_role,
                                  'ai': '', 'pt': port, 'pr': proto})

    return server_ports, client_ports, port_deps


def enrich_objects_from_flows(objects_dict, flows_by_slug, upstream_deps):
    """
    Post-build enrichment: walk every CanonicalObject, find its SERVICE_SLUG,
    join flows, populate port fields and service dependencies.

    objects_dict: {object_name: CanonicalObject}
    flows_by_slug: {service_slug: [flow_dict, ...]}
    upstream_deps: {service_slug: [{nm, dt}, ...]}
    """
    if not flows_by_slug and not upstream_deps:
        return 0

    # Build slug lookup from object name
    # SVC_CENTRIFY → centrify, SVC_SPLUNK_HCB → splunk, APP_ORACLE_ECOMM → oracle-ecomm
    def _slug_from_name(name):
        # Strip SVC_ / APP_ / INFRA_ / DELIVERY_ prefix and _HERITAGE suffix
        m = re.match(r'^(?:SVC|APP|INFRA|DELIVERY)_(.+?)(?:_CVS|_HCB|_AETNA|_PBM)?$',
                     name, re.I)
        if m:
            return re.sub(r'[_]+', '-', m.group(1)).lower()
        return name.lower()

    # Map known CPC service slugs to canonical object name patterns
    CPC_SLUG_TO_OBJECT = {
        'centrify':        'SVC_CENTRIFY',
        'crowdstrike':     'SVC_CROWDSTRIKE',
        'mecm':            'SVC_SCCM',          # MECM was previously SCCM
        'sccm':            'SVC_SCCM',
        'satellite':       'SVC_SATELLITE',
        'tanium':          'SVC_TANIUM',
        'password-safe':   'SVC_BEYONDTRUST_PS',
        'venafi':          'SVC_VENAFI',
        'guardium':        'SVC_GUARDIUM',
        'qualys':          'SVC_QUALYS',
        'apache-nifi':     'SVC_APACHE_NIFI',
        'tidal':           'SVC_TIDAL',
        'beyondtrust-pra': 'SVC_BEYONDTRUST_PRA',
        'jfrog':           'SVC_JFROG',
        'bigid':           'SVC_BIGID',
        'splunk':          'SVC_SPLUNK',
        'scom':            'SVC_SCOM',
        'tivoli-tws':      'SVC_TIVOLI_TWS',
        'zscaler':         'SVC_ZSCALER',
    }

    enriched = 0
    for obj_name, obj in objects_dict.items():
        # Determine slug — try direct CPC map first, then derive from name
        slug = None
        for cpc_slug, cpc_obj_prefix in CPC_SLUG_TO_OBJECT.items():
            if obj_name.startswith(cpc_obj_prefix):
                slug = cpc_slug
                break
        if slug is None:
            slug = _slug_from_name(obj_name)

        changed = False

        # Port fields from flows
        if slug in flows_by_slug:
            srv, cli, deps = _parse_ports_from_flows(flows_by_slug[slug])
            if srv or cli or deps:
                obj.server_ports = srv
                obj.client_ports = cli
                obj.port_deps    = deps
                changed = True

        # Service dependencies
        if slug in upstream_deps:
            obj.service_deps = upstream_deps[slug]
            changed = True

        if changed:
            enriched += 1

    return enriched



# ─────────────────────────────────────────────────────────────────────────────
# Remote Access service object builder  (v1.9.0)
# ─────────────────────────────────────────────────────────────────────────────
# NET_TYPE → (OBJECT_CLASS, SERVICE_ROLE) mapping
_RA_NETTYPE_CLASS = {
    'RA-POOL-CSA':  ('RA_POOL_CSA',     'RA_POOL_CSA'),
    'RA-SNAT-HCB':  ('RA_SNAT_HCB',     'RA_SNAT_HCB'),
    'RA-CONN-ZPA':  ('RA_CONNECTOR_ZPA','RA-CONN-ZPA'),
}

# Cluster → canonical object name for pool objects
_RA_POOL_NAMES = {
    ('Internal-PBM', 'CVS',   'US_WOR_RI_DC'): 'SVC_CSA_Pools_RI_One',
    ('Internal-PBM', 'CVS',   'US_SCO_AZ_DC'): 'SVC_CSA_Pools_Shea_DC',
    ('Internal-HCB', 'AETNA', 'US_MIC_CT_DC'): 'SVC_SNAT_Pools_MDC',
    ('Internal-HCB', 'AETNA', 'US_WIN_CT_DC'): 'SVC_SNAT_Pools_WDC',
}

# Gateway object definitions — sourced from RAVPN registry
_RA_GATEWAY_DEFS = [
    ('SVC_Cisco_Secure_Access_US_WOR_RI_DC', 'RA_GATEWAY_CSA', 'RA-GATEWAY-CSA',
     'Internal-PBM', 'CVS',   'Woonsocket RI - RI One'),
    ('SVC_Cisco_Secure_Access_US_SCO_AZ_DC', 'RA_GATEWAY_CSA', 'RA-GATEWAY-CSA',
     'Internal-PBM', 'CVS',   'Scottsdale AZ - Shea DC'),
    ('SVC_NetScaler_Gateway_US_LAS_NV_CI',   'RA_GATEWAY_NTX', 'RA-GATEWAY-NTX',
     'COLO',         'CVS',   'Las Vegas NV - Switch COLO'),
]

# ZPA connector cluster → object name
_ZPA_CLUSTER_OBJECTS = {
    'HCB-MID':      'SVC_ZPA_Connector_US_MIC_CT_DC',
    'GCP-EQUINIX':  'SVC_ZPA_Connector_US_GCP_USE1_IS',
    'AWS-HCB':      'SVC_ZPA_Connector_US_AWS_USE1_IS_HCB',
    'AWS-PBM':      'SVC_ZPA_Connector_US_AWS_USE1_IS_PBM',
    'HCB-CLOUD':    'SVC_ZPA_Connector_US_GCP_USE4_IS',
    'CVS-UAT':      'SVC_ZPA_Connector_US_AZR_UE2_IS',
    'NETSCALER-LV': 'SVC_NetScaler_Gateway_US_LAS_NV_CI',
}


def build_ra_service_objects(ipam_rows, ra_dir, dataset_version, verbose=False):
    """
    Build Remote Access service objects from:
      1. all_IP_networks — RA-POOL-CSA and RA-SNAT-HCB subnets → pool objects
      2. ZPA-CONNECTOR-REGISTRY — connector IPs → RA_CONNECTOR_ZPA objects
      3. Static gateway definitions → RA_GATEWAY_CSA / RA_GATEWAY_NTX objects

    Returns dict of {object_name: CanonicalObject}
    """
    import glob as _g
    ra_objects = {}

    # ── Pool objects from IPAM NET_TYPE ──────────────────────────────────────
    pool_cidrs = {}  # (rd, heritage, site_code) → list of CIDRs
    for row in ipam_rows:
        nt = (row.get('NET_TYPE') or '').strip()
        if nt not in ('RA-POOL-CSA', 'RA-SNAT-HCB'):
            continue
        rd   = (row.get('ROUTING_DOMAIN') or '').strip()
        her  = (row.get('HERITAGE') or '').strip()
        sc   = (row.get('SITE_CODE') or '').strip()
        loc  = (row.get('CANONICAL_LOCATION') or '').strip()
        cidr = (row.get('CIDR') or '').strip()
        key  = (rd, her, sc)
        if key not in pool_cidrs:
            pool_cidrs[key] = {'loc': loc, 'nt': nt, 'cidrs': []}
        pool_cidrs[key]['cidrs'].append(cidr)

    for (rd, her, sc), data in pool_cidrs.items():
        obj_name = _RA_POOL_NAMES.get((rd, her, sc))
        if not obj_name:
            continue
        nt = data['nt']
        obj_cls, svc_role = _RA_NETTYPE_CLASS[nt]
        obj = CanonicalObject(
            name=obj_name, obj_type='SERVICE',
            service_role=svc_role,
            heritage=her, routing_domain=rd,
        )
        obj.obj_type     = obj_cls
        obj.locations.add(data['loc'])
        obj.source_datasets.add('build_canonical_app_objects:RA-POOL')
        # Store CIDRs in subnet_cidrs attribute if present, else member_ips
        for cidr in data['cidrs']:
            obj.member_ips.add(cidr)
        ra_objects[obj_name] = obj
        if verbose:
            print(f'    RA pool: {obj_name}  ({len(data["cidrs"])} CIDRs, {nt})')

    # ── ZPA connector objects from registry ──────────────────────────────────
    zpa_files = sorted(_g.glob(os.path.join(ra_dir,
                       'ent-ipdataset-ZPA-CONNECTOR-REGISTRY-v*.csv')))
    if zpa_files:
        zpa_rows = read_ccd_csv(zpa_files[-1])
        by_cluster = {}
        for row in zpa_rows:
            cluster = (row.get('CLUSTER_NAME') or '').strip()
            ip      = (row.get('CONNECTOR_IP') or '').strip()
            rd      = (row.get('ROUTING_DOMAIN') or '').strip()
            her     = (row.get('HERITAGE') or '').strip()
            loc     = (row.get('LOCATION') or '').strip()
            obj_nm  = _ZPA_CLUSTER_OBJECTS.get(cluster)
            if not obj_nm or not ip:
                continue
            if obj_nm not in by_cluster:
                by_cluster[obj_nm] = {'ips': set(), 'rd': rd, 'her': her, 'loc': loc}
            by_cluster[obj_nm]['ips'].add(ip)

        for obj_name, data in by_cluster.items():
            obj = CanonicalObject(
                name=obj_name, obj_type='RA_CONNECTOR_ZPA',
                service_role='RA-CONN-ZPA',
                heritage=data['her'], routing_domain=data['rd'],
            )
            obj.locations.add(data['loc'])
            obj.member_ips.update(data['ips'])
            obj.source_datasets.add('ZPA-CONNECTOR-REGISTRY')
            ra_objects[obj_name] = obj
            if verbose:
                print(f'    ZPA connector: {obj_name}  ({len(data["ips"])} IPs)')

    # ── Gateway objects (static definitions) ─────────────────────────────────
    for (obj_name, obj_cls, svc_role, rd, her, loc) in _RA_GATEWAY_DEFS:
        obj = CanonicalObject(
            name=obj_name, obj_type=obj_cls,
            service_role=svc_role,
            heritage=her, routing_domain=rd,
        )
        obj.locations.add(loc)
        obj.source_datasets.add('RAVPN-GATEWAY-REGISTRY')
        ra_objects[obj_name] = obj
        if verbose:
            print(f'    RA gateway: {obj_name}  ({obj_cls})')

    return ra_objects

def build_ehm_rollup_aggregates(service_objects):
    """
    Step [8c/9]: Build EHM-sourced enterprise rollup aggregates.

    For each entry in EHM_ROLLUP_AGGREGATES, unions the IPs from the listed
    per-heritage SVC_* service objects into a single SVC_*_ALL CanonicalObject.
    Deduplicates on IP. Source objects that do not exist are skipped silently
    (not all heritage variants exist for every service).

    Returns dict of new rollup CanonicalObjects keyed by name.
    """
    rollup_objects = {}

    for rollup_name, ports, protocol, source_names in EHM_ROLLUP_AGGREGATES:
        # Collect all IPs from source objects
        all_ips    = set()
        all_vips   = set()
        all_locs   = set()
        all_ds     = set()
        found_srcs = []

        for src_name in source_names:
            src = service_objects.get(src_name)
            if src is None:
                continue
            all_ips.update(src.member_ips)
            all_vips.update(src.vip_ips)
            all_locs.update(src.locations)
            all_ds.update(src.source_datasets)
            found_srcs.append(src_name)

        if not all_ips:
            continue  # no source objects found — skip quietly

        rollup = CanonicalObject(
            name            = rollup_name,
            obj_type        = 'SERVICE',
            app_acronym     = rollup_name,
            service_role    = rollup_name,
            heritage        = 'MIXED',
            routing_domain  = 'Enterprise',
        )
        rollup.member_ips     = all_ips
        rollup.vip_ips        = all_vips
        rollup.locations      = all_locs
        rollup.source_datasets = all_ds | {'EHM-rollup'}
        rollup.app_architecture = 'n-tier'
        # server_ports must be list of dicts: {'ai': '', 'pt': port, 'pr': proto}
        rollup.server_ports   = [{'ai': '', 'pt': p.strip(), 'pr': protocol}
                                  for p in ports.split(',') if p.strip()]
        rollup.client_ports   = []
        # service_deps must be list of dicts: {'nm': name, 'dt': detail}
        rollup.service_deps   = [{'nm': s, 'dt': 'source'} for s in found_srcs]

        rollup_objects[rollup_name] = rollup

    return rollup_objects


def main():
    parser = argparse.ArgumentParser(
        description='CCD Platform — build_canonical_app_objects.py')
    parser.add_argument('--ipam-dir',     default='./ipam-db',
                        help='Directory containing CCD dataset CSV files')
    parser.add_argument('--fw-dir',       default='./processed_outputs',
                        help='Directory containing fw_host_candidates file')
    parser.add_argument('--out-dir',      default='./processed_outputs',
                        help='Output directory for canonical_app_objects CSV')
    parser.add_argument('--min-members',  type=int, default=1,
                        help='Minimum IPs required to create a prod APP_Object (default: 1). '
                             'Non-prod (_NP) objects are always included regardless of this threshold.')
    parser.add_argument('--flows-csv',    default=None,
                        help='CPC-SERVICE-FLOWS CSV (ent-ipdataset-CPC-SERVICE-FLOWS-v*.csv). '
                             'When supplied, auto-populates PORT_DEPS, SERVER_PORTS, CLIENT_PORTS '
                             'and SERVICE_DEPS on CPC service objects.')
    parser.add_argument('--ra-registry-dir', default=None,
                        help='Directory containing RA registry CSVs '
                             '(default: same as --ipam-dir)')
    parser.add_argument('--dry-run',      action='store_true',
                        help='Print summary without writing output files')
    parser.add_argument('--verbose',      action='store_true', default=True,
                        help='Verbose progress output')
    parser.add_argument('--version',      action='store_true',
                        help='Print version and exit')
    args = parser.parse_args()

    if args.version:
        print(f"build_canonical_app_objects.py {VERSION}")
        import sys; sys.exit(0)

    vb = args.verbose
    dataset_version = f"v{BUILD_DATE}"

    print(f"\nbuild_canonical_app_objects.py {VERSION}")
    print(f"Build date: {BUILD_DATE}")
    print(f"--ipam-dir:   {args.ipam_dir}")
    print(f"--out-dir:    {args.out_dir}")
    print(f"--min-members: {args.min_members}")
    print(f"--dry-run:    {args.dry_run}")
    print()

    # -----------------------------------------------------------------------
    # Load datasets
    # -----------------------------------------------------------------------
    print("[1/9] Loading datasets...")

    ehm_path = find_file(args.ipam_dir, 'ent_host_master_v*.csv')
    infra_path = find_file(args.ipam_dir, 'delivery_infrastructure_v*.csv')
    plat_path = find_file(args.ipam_dir, 'delivery_platform_v*.csv')
    ipam_path = find_file(args.ipam_dir, 'all_IP_networks_v*.csv')
    vip_path = find_file(args.ipam_dir, 'ent-ipdataset-F5-VIP-REGISTRY-*.csv')
    pool_path = find_file(args.ipam_dir, 'ent-ipdataset-F5-POOL-MEMBERS-*.csv')
    shared_reg_path = find_file(args.ipam_dir, 'ent-ipdataset-SHARED-SERVER-REGISTRY-*.csv')

    missing = [p for p in [ehm_path, infra_path, plat_path, ipam_path, pool_path] if not p]
    if missing:
        print(f"ERROR: Missing required input files. Could not find:")
        for p in [ehm_path, infra_path, plat_path, ipam_path, pool_path]:
            if not p:
                print(f"  (no match in {args.ipam_dir})")
        sys.exit(1)

    ehm_rows   = read_ccd_csv(ehm_path)
    infra_rows = read_ccd_csv(infra_path)
    plat_rows  = read_ccd_csv(plat_path)
    ipam_rows  = read_ccd_csv(ipam_path)
    pool_rows  = read_ccd_csv(pool_path) if pool_path else []
    shared_reg_rows = read_ccd_csv(shared_reg_path) if shared_reg_path else []
    # Load all CPC files: base + supplement(s) — glob finds both
    import glob as _glob
    _cpc_paths = sorted(_glob.glob(os.path.join(args.ipam_dir, 'ent-ipdataset-CPC-CORE-SERVICES*.csv')))
    cpc_rows = []
    for _p in _cpc_paths:
        cpc_rows.extend(read_ccd_csv(_p))
    cpc_path = _cpc_paths[0] if _cpc_paths else None

    print(f"  ent_host_master:          {len(ehm_rows):>7,} rows  ({os.path.basename(ehm_path)})")
    print(f"  delivery_infrastructure:  {len(infra_rows):>7,} rows  ({os.path.basename(infra_path)})")
    print(f"  delivery_platform:        {len(plat_rows):>7,} rows  ({os.path.basename(plat_path)})")
    print(f"  all_IP_networks:          {len(ipam_rows):>7,} rows  ({os.path.basename(ipam_path)})")
    print(f"  F5-POOL-MEMBERS:          {len(pool_rows):>7,} rows  ({os.path.basename(pool_path) if pool_path else 'NOT FOUND'})")
    _shared_label = os.path.basename(shared_reg_path) if shared_reg_path else 'NOT FOUND — shared IPs will not be excluded'
    print(f"  SHARED-SERVER-REGISTRY:   {len(shared_reg_rows):>7,} rows  ({_shared_label})")
    _cpc_label = f"{len(_cpc_paths)} file(s): " + ", ".join(os.path.basename(p) for p in _cpc_paths) if _cpc_paths else "NOT FOUND"
    print(f"  CPC-CORE-SERVICES:        {len(cpc_rows):>7,} rows  ({_cpc_label})")

    # Load retail_networks to build exclusion set
    retail_path = find_file(args.ipam_dir, 'retail_networks_v*.csv')
    retail_ips = set()        # individual /32s (fallback — legacy files)
    retail_24s = set()        # /24 supernets of store /26 CIDRs (primary exclusion)
    if retail_path:
        retail_rows = read_ccd_csv(retail_path)
        for row in retail_rows:
            # retail_networks uses CIDR column (/26 store allocations), not IP_ADDRESS
            cidr = nan_to_none(row.get('CIDR') or row.get('cidr')
                               or row.get('IP_ADDRESS') or row.get('ip_address'))
            if not cidr:
                continue
            cidr = cidr.strip()
            try:
                net = ipaddress.ip_network(cidr, strict=False)
                if net.prefixlen == 32:
                    retail_ips.add(str(net.network_address))
                else:
                    # Map each retail CIDR to its containing /24 for fast containment check
                    retail_24s.add(str(net.supernet(new_prefix=min(24, net.prefixlen))))
            except ValueError:
                pass
        print(f"  retail_networks:        {len(retail_24s):>7,} /24s  "
              f"({len(retail_ips)} /32s)  ({os.path.basename(retail_path)})")
    # -----------------------------------------------------------------------
    # Load CPC service flows (optional) — populates port fields on SVC objects
    # -----------------------------------------------------------------------
    flows_by_slug = {}   # service_slug → list of flow dicts

    # Auto-discover if not provided
    _flows_csv = args.flows_csv
    if not _flows_csv:
        import glob as _fglob
        _fp = sorted(_fglob.glob(os.path.join(args.ipam_dir,
                     'ent-ipdataset-CPC-SERVICE-FLOWS*.csv')))
        if not _fp:
            _fp = sorted(_fglob.glob(os.path.join(args.fw_dir,
                         'ent-ipdataset-CPC-SERVICE-FLOWS*.csv')))
        if _fp:
            _flows_csv = _fp[-1]

    if _flows_csv and os.path.isfile(_flows_csv):
        _flow_rows = read_ccd_csv(_flows_csv)
        for r in _flow_rows:
            slug = (r.get('SERVICE_SLUG') or '').strip()
            if slug:
                flows_by_slug.setdefault(slug, []).append(r)
        print(f"  CPC-SERVICE-FLOWS:        {len(_flow_rows):>7,} rows  "
              f"({os.path.basename(_flows_csv)})  "
              f"{len(flows_by_slug)} services")
    else:
        print(f"  CPC-SERVICE-FLOWS:              (not found — port fields will be empty)")

    # Upstream dependency map for SERVICE_DEPS
    # service_slug → list of {nm, dt}
    UPSTREAM_DEPS = {
        'active-directory':  [{'nm':'SVC_DNS',             'dt':'dns'}],
        'centrify':          [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'}],
        'crowdstrike':       [{'nm':'SVC_DNS',             'dt':'dns'}],
        'enterprise-ldap':   [{'nm':'SVC_DNS',             'dt':'dns'}],
        'qualys':            [{'nm':'SVC_DNS',             'dt':'dns'}],
        'scom':              [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'},
                              {'nm':'SVC_SQL_SERVER',      'dt':'data'}],
        'password-safe':     [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'},
                              {'nm':'SVC_SQL_SERVER',      'dt':'data'}],
        'pingid':            [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'},
                              {'nm':'SVC_ENTERPRISE_LDAP', 'dt':'identity'}],
        'mecm':              [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'},
                              {'nm':'SVC_SQL_SERVER',      'dt':'data'}],
        'tidal':             [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'},
                              {'nm':'SVC_SQL_SERVER',      'dt':'data'}],
        'venafi':            [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'}],
        'splunk':            [{'nm':'SVC_APACHE_NIFI',     'dt':'data'}],
        'beyondtrust-pra':   [{'nm':'SVC_ACTIVE_DIRECTORY', 'dt':'auth'}],
        'hashicorp-vault':   [{'nm':'SVC_CONTAINER_PLATFORM','dt':'depends-on'}],
        'wiz':               [{'nm':'SVC_CONTAINER_PLATFORM','dt':'depends-on'}],
        'zscaler':           [{'nm':'SVC_DNS',             'dt':'dns'}],
    }



    # -----------------------------------------------------------------------
    # Build exclusion sets (infra + platform + shared server IPs excluded from APP_Objects)
    # -----------------------------------------------------------------------
    infra_ips = {nan_to_none(r.get('IP_ADDRESS')) for r in infra_rows if nan_to_none(r.get('IP_ADDRESS'))}
    plat_ips  = {nan_to_none(r.get('IP_ADDRESS')) for r in plat_rows  if nan_to_none(r.get('IP_ADDRESS'))}

    # v1.5.0: shared server IPs — must not be claimed by any APP object
    shared_ips = {nan_to_none(r.get('IP')) for r in shared_reg_rows if nan_to_none(r.get('IP'))}
    excluded_from_app = infra_ips | plat_ips | shared_ips

    print(f"\n  INFRA exclusion set: {len(excluded_from_app):,} IPs "
          f"(delivery_infrastructure={len(infra_ips):,} + delivery_platform={len(plat_ips):,} "
          f"+ shared_server={len(shared_ips):,})")

    # Build INFRA_SHARED objects from shared server registry
    # One CanonicalObject per SHARED_OBJECT_NAME — IPs added as members
    infra_shared_objects = {}
    for r in shared_reg_rows:
        ip       = nan_to_none(r.get('IP'))
        obj_name = (r.get('SHARED_OBJECT_NAME') or '').strip()
        obj_cls  = (r.get('OBJECT_CLASS') or 'INFRA_SHARED').strip()
        heritage = normalize_heritage(nan_to_none(r.get('HERITAGE')))
        rd       = (r.get('ROUTING_DOMAIN') or 'UNKNOWN').strip()
        loc      = nan_to_none(r.get('CANONICAL_LOCATION'))
        acr      = (r.get('APP_ACRONYMS') or '').strip()
        if not ip or not obj_name:
            continue
        if obj_name not in infra_shared_objects:
            infra_shared_objects[obj_name] = CanonicalObject(
                name=obj_name,
                obj_type=obj_cls,
                app_acronym=acr,
                heritage=heritage,
                routing_domain=rd,
            )
        infra_shared_objects[obj_name].add_member(ip, canonical_location=loc, source='SHARED-REGISTRY')
    print(f"  INFRA_SHARED objects from registry: {len(infra_shared_objects):,}")

    # -----------------------------------------------------------------------
    # Build IPAM index for LPM enrichment
    # -----------------------------------------------------------------------
    print("\n[2/9] Building IPAM LPM index...")
    ipam_index = build_ipam_index(ipam_rows)
    print(f"  IPAM index: {len(ipam_index):,} networks")

    # -----------------------------------------------------------------------
    # Build F5 VIP index
    # -----------------------------------------------------------------------
    print("\n[3/9] Building F5 VIP attribution index...")
    vip_index = build_vip_index(pool_rows)
    print(f"  VIP index: {len(vip_index):,} member IPs with VIP mappings")

    # -----------------------------------------------------------------------
    # Build object populations
    # -----------------------------------------------------------------------
    print("\n[4/9] Building APP_Objects from ent_host_master...")
    app_objects, app_review_queue, null_acronym_rows = build_app_objects(
        ehm_rows, args.min_members, excluded_from_app, retail_ips,
        retail_24s=retail_24s, verbose=vb)

    print("\n[5/9] Building INFRA_Objects and SERVICE_Objects from delivery_infrastructure...")
    infra_objects, svc_from_infra, delivery_from_infra, unclassified_infra = build_infra_objects(
        infra_rows, verbose=vb)

    print("\n[6/9] Building SERVICE_Objects from ent_host_master (service acronyms)...")
    svc_from_ehm = build_service_objects_from_ehm(
        ehm_rows, excluded_ips=excluded_from_app, verbose=vb)

    print("\n[7/9] Building SERVICE_Objects from CPC-CORE-SERVICES (AD/DC, NTP, Splunk, Centrify...)")
    svc_from_cpc, delivery_from_cpc = build_service_objects_from_cpc(cpc_rows, verbose=vb)

    service_objects = merge_service_objects(svc_from_infra, svc_from_ehm, svc_from_cpc)
    print(f"  SERVICE_Objects merged total: {len(service_objects)}")

    print("\n[8/9] Building DELIVERY_Objects from delivery_platform...")
    delivery_objects_plat = build_delivery_objects(plat_rows, verbose=vb)

    # Merge DELIVERY objects (infra DataPower + platform K8s/OCP + CPC NETWORK-class CIDRs)
    delivery_objects = {}
    delivery_objects.update(delivery_from_infra)
    delivery_objects.update(delivery_objects_plat)
    delivery_objects.update(delivery_from_cpc)
    print(f"  DELIVERY_Objects total: {len(delivery_objects)} ({len(delivery_from_cpc)} CIDR-type from CPC)")

    # v1.5.0: merge shared registry objects — enrichment first
    # v1.5.2: route by OBJECT_CLASS — DELIVERY_* → delivery_objects, rest → infra_objects
    # v1.5.5: GROUP registry delivery objects by (OBJECT_CLASS, HERITAGE, LOCATION)
    #         instead of one-object-per-hostname — collapses 5,443 per-host objects
    #         into ~50-80 named platform groups suitable for PA firewall policy.
    #         e.g. DELIVERY_EDH_PBM_RI2100, DELIVERY_IIB_PBM_SHEA, etc.
    apply_vip_attribution(infra_shared_objects, vip_index)
    apply_ipam_enrichment(infra_shared_objects, ipam_index)

    pre_merge_infra    = len(infra_objects)
    pre_merge_delivery = len(delivery_objects)
    routed_infra       = 0
    routed_delivery    = 0

    # Heritage → short tag for object naming
    _her_tag = {
        'CVS':   'PBM',
        'AETNA': 'HCB',
        'BOTH':  'SHARED',
        '':      'UNKNOWN',
    }

    def _delivery_group_name(obj_cls, heritage, canonical_location, routing_domain):
        """
        Build grouped delivery object name:
          DELIVERY_EDH_PBM_RI2100
          DELIVERY_IIB_HCB_MDC
          DELIVERY_SHARED_APP_PBM_SHEA
          DELIVERY_CONTAINER_HOST_HCB_USE2
        """
        # Strip DELIVERY_ prefix for the platform part
        platform = obj_cls.replace('DELIVERY_', '') if obj_cls.startswith('DELIVERY_') else obj_cls

        # Heritage tag
        her = _her_tag.get((heritage or '').upper(), (heritage or 'UNKNOWN').upper()[:6])

        # Location slug — use loc_code() which already handles the mapping
        loc = loc_code(canonical_location) if canonical_location else rd_short(routing_domain)
        loc = re.sub(r'[^A-Z0-9]', '_', loc.upper()).strip('_')[:12]

        return f"DELIVERY_{platform}_{her}_{loc}"

    for obj_name, obj in infra_shared_objects.items():
        ot = (obj.obj_type or '').upper()
        if ot.startswith('DELIVERY'):
            # Group by (OBJECT_CLASS, HERITAGE, CANONICAL_LOCATION)
            # Use primary location from the object's locations set
            primary_loc = next(iter(sorted(obj.locations))) if obj.locations else None
            group_name  = _delivery_group_name(
                ot,
                obj.heritage or '',
                primary_loc,
                obj.routing_domain or '',
            )

            if group_name not in delivery_objects:
                delivery_objects[group_name] = CanonicalObject(
                    name=group_name,
                    obj_type='DELIVERY',
                    app_acronym=obj.app_acronym,
                    heritage=obj.heritage,
                    routing_domain=obj.routing_domain,
                )
                # Store granular class in service_role for reporting
                delivery_objects[group_name].service_role = ot

            # Add pool member IPs (bridge IPs — SRC of outbound east-west)
            for ip in obj.member_ips:
                delivery_objects[group_name].add_member(
                    ip,
                    canonical_location=primary_loc,
                    source='SHARED-REGISTRY'
                )

            # Carry forward VIP attributions (cluster VIPs — DST of app connections)
            # This ties the F5 VIP to its pool members within the delivery group:
            #   DELIVERY_IIB_HCB_SHEA.VIP_IPS   = F5 INT VIPs fronting IIB pool
            #   DELIVERY_IIB_HCB_SHEA.MEMBER_IPS = IIB bridge IPs behind those VIPs
            for vip_ip in obj.vip_ips:
                delivery_objects[group_name].vip_ips.add(vip_ip)

            routed_delivery += 1
        else:
            # INFRA fallback — should be near-zero with correct registry classification
            infra_objects[obj_name] = obj
            routed_infra += 1

    print(f"\n  Shared registry routing ({len(infra_shared_objects):,} objects):")
    print(f"    → delivery_objects : {routed_delivery:,} grouped into {len(delivery_objects) - pre_merge_delivery} groups  ({pre_merge_delivery} → {len(delivery_objects)})")
    print(f"    → infra_objects    : {routed_infra:,}  ({pre_merge_infra} → {len(infra_objects)})")

    # Show delivery group distribution
    from collections import Counter as _Counter
    grp_dist = _Counter()
    for k in delivery_objects:
        if k not in delivery_from_infra and k not in delivery_objects_plat and k not in delivery_from_cpc:
            parts = k.split('_')
            if len(parts) >= 3:
                grp_dist['_'.join(parts[:3])] += 1
    print(f"\n  Delivery group summary (top 20):")
    for grp, cnt in grp_dist.most_common(20):
        # Count total IPs and VIPs across groups with this prefix
        grp_ips  = sum(len(delivery_objects[k].member_ips)
                       for k in delivery_objects if k.startswith(grp))
        grp_vips = sum(len(delivery_objects[k].vip_ips)
                       for k in delivery_objects if k.startswith(grp))
        print(f"    {grp:<40}: {cnt:>3} groups  {grp_ips:>5} IPs  {grp_vips:>4} VIPs")

    # -----------------------------------------------------------------------
    # VIP attribution and IPAM enrichment
    # infra_objects already includes infra_shared (pre-enriched above)
    # -----------------------------------------------------------------------
    print("\n[9/9] Applying VIP attribution and IPAM enrichment...")
    for obj_dict in [app_objects, service_objects, delivery_objects]:
        apply_vip_attribution(obj_dict, vip_index)
        apply_ipam_enrichment(obj_dict, ipam_index)
    # Enrich only the non-shared infra objects (shared already done above)
    non_shared_infra = {k: v for k, v in infra_objects.items() if k not in infra_shared_objects}
    apply_vip_attribution(non_shared_infra, vip_index)
    apply_ipam_enrichment(non_shared_infra, ipam_index)
    print("  Done.")

    # -----------------------------------------------------------------------
    # Step [8c/9]: EHM service rollup aggregates
    # -----------------------------------------------------------------------
    rollup_svc_objects = build_ehm_rollup_aggregates(service_objects)
    if rollup_svc_objects:
        print(f'\n[8c/9] Building EHM service rollup aggregates...')
        for rname, robj in sorted(rollup_svc_objects.items()):
            n_src = len(robj.service_deps) if robj.service_deps else 0
            print(f'  {rname:<45} {len(robj.member_ips):>5} IPs'
                  f'  (from {n_src} source objects)')
        # Merge rollups into service_objects
        service_objects.update(rollup_svc_objects)
        print(f'  Total rollup objects: {len(rollup_svc_objects)}')

    # -----------------------------------------------------------------------
    # Remote Access service objects  (v1.9.0)
    # -----------------------------------------------------------------------
    _ra_dir = args.ra_registry_dir or args.ipam_dir
    print(f'[8d/9] Building Remote Access service objects (RA pools, ZPA connectors, gateways)...')
    ra_objects = build_ra_service_objects(
        ipam_rows, _ra_dir, dataset_version, verbose=vb)
    print(f'  RA service objects: {len(ra_objects)}')
    # Merge RA objects into service_objects (RA wins on name collision)
    service_objects.update(ra_objects)

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    all_objects_list = (list(app_objects.values()) + list(infra_objects.values()) +
                        list(service_objects.values()) + list(delivery_objects.values()))

    total_members = sum(len(o.member_ips) for o in all_objects_list)
    total_vips    = sum(len(o.vip_ips)    for o in all_objects_list)

    print(f"""
=== CANONICAL OBJECT BUILD SUMMARY ===
  APP_Objects:      {len(app_objects):>5}  ({sum(len(o.member_ips) for o in app_objects.values()):,} member IPs)
  INFRA_Objects:    {len(infra_objects):>5}  ({sum(len(o.member_ips) for o in infra_objects.values()):,} member IPs)
  SERVICE_Objects:  {len(service_objects):>5}  ({sum(len(o.member_ips) for o in service_objects.values()):,} member IPs)
  DELIVERY_Objects: {len(delivery_objects):>5}  ({sum(len(o.member_ips) for o in delivery_objects.values()):,} member IPs)
  ─────────────────────────────────────
  TOTAL objects:    {len(all_objects_list):>5}  ({total_members:,} member IPs, {total_vips:,} VIP attributions)
  Review queue:     {len(app_review_queue):>5}  (single-member APP candidates)
  Null acronym:     {len(null_acronym_rows):>5}  (EHM rows with no PRIMARY_ACRONYM)
  Unclassified INFRA: {len(unclassified_infra):>3}  (delivery_infrastructure rows not matched)
""")

    # Validation
    print("Validation:")
    violations = validate_objects(all_objects_list, verbose=True)

    # -----------------------------------------------------------------------
    # Write outputs
    # -----------------------------------------------------------------------
    if args.dry_run:
        print("\n--dry-run: No files written.")
        print("\nTop 30 APP_Objects by member count:")
        for obj in sorted(app_objects.values(), key=lambda x: len(x.member_ips), reverse=True)[:30]:
            print(f"  {obj.name:<50} {len(obj.member_ips):>5} IPs  {len(obj.vip_ips):>3} VIPs")
        print("\nINFRA_Objects:")
        for obj in sorted(infra_objects.values(), key=lambda x: len(x.member_ips), reverse=True):
            print(f"  {obj.name:<50} {len(obj.member_ips):>5} IPs")
        print("\nSERVICE_Objects:")
        for obj in sorted(service_objects.values(), key=lambda x: len(x.member_ips), reverse=True):
            print(f"  {obj.name:<50} {len(obj.member_ips):>5} IPs")
        print("\nDELIVERY_Objects (top 20):")
        for obj in sorted(delivery_objects.values(), key=lambda x: len(x.member_ips), reverse=True)[:20]:
            print(f"  {obj.name:<60} {len(obj.member_ips):>5} IPs")
        return

    os.makedirs(args.out_dir, exist_ok=True)

    # -----------------------------------------------------------------------
    # Post-build enrichment — port fields + service dependencies
    # -----------------------------------------------------------------------
    print("\n[post-build] Enriching objects from flows and dependency map...")
    _n_enriched = enrich_objects_from_flows(
        {obj.name: obj for obj in all_objects_list},
        flows_by_slug,
        UPSTREAM_DEPS,
    )
    print(f"  Enriched: {_n_enriched} objects with port / dependency data")

    # v1.4.0: gap-fill SERVER_PORTS from well-known port registry
    _all_obj_dict = {obj.name: obj for obj in all_objects_list}
    _wp_enriched  = _populate_well_known_service_ports(_all_obj_dict)
    if _wp_enriched:
        print(f"  Well-known ports : {_wp_enriched} SERVICE objects populated")

    # Main output
    out_csv = os.path.join(args.out_dir, f"canonical_app_objects_{dataset_version}.csv")
    fieldnames = [
        'OBJECT_NAME','OBJECT_TYPE','OBJECT_CLASS','APP_ACRONYM','SERVICE_ROLE','HERITAGE',
        'ROUTING_DOMAIN','MEMBER_IPS','VIP_IPS','SUBNET_CIDRS','LOCATIONS',
        'MEMBER_COUNT','VIP_COUNT','SOURCE_DATASETS','DATASET_VERSION',
        # Schema v2
        'APP_ARCHITECTURE','ROLE_MAP','SNAT_IPS','SNAT_COUNT',
        'PORT_DEPS','SERVER_PORTS','CLIENT_PORTS','SERVICE_DEPS',
        'PCI_SCOPE','CRITICALITY',
        'NON_PROD',       # v1.3.0
    ]
    with open(out_csv, 'w', newline='') as f:
        f.write(f"#STEM=canonical_app_objects\n")
        f.write(f"#VERSION={dataset_version}\n")
        f.write(f"#ROWS={len(all_objects_list)}\n")
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for obj in sorted(all_objects_list, key=lambda x: (x.obj_type, x.name)):
            writer.writerow(obj.to_dict(dataset_version))

    print(f"\nWrote: {out_csv}  ({len(all_objects_list)} rows)")

    # Review queue
    review_csv = os.path.join(args.out_dir, f"canonical_app_objects_review_{dataset_version}.csv")
    write_review_queue(app_review_queue, null_acronym_rows, unclassified_infra,
                       review_csv, dataset_version)
    print(f"Wrote: {review_csv}  ({len(app_review_queue) + len(null_acronym_rows) + len(unclassified_infra)} rows)")


if __name__ == '__main__':
    main()
