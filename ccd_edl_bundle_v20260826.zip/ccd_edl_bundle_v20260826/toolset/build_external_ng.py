#!/usr/bin/env python3
"""
build_external_ng.py  v1.0.1  —  CCD Platform

v1.0.1 — output now nests inside build_network_groups.py's own
Net_Group/NG-YYYYMMDD_vN/ directory (Net_Group/NG-.../External_NG/), not
a separate top-level External_NG/ tree — a full platform export only
needs Net_Group/ and Net_Object/, not N additional directories.
Generates the External-NG source Network-Object hierarchy (NG-INTERNET-FACING)
from the ent-ipdataset-INTERNET-FACING registry, independent of
build_network_groups.py.

Why this exists:
  build_network_groups.py already derives an NG-INTERNET-FACING Tier-1 class
  (from internet_segments_v*.csv, a SNAT+EIF derived dataset), but writes it
  into the same Net_Group/NG-YYYYMMDD_vN/ output as Internal-NG. The EDL
  catalog (build_edl_catalog.py DATASET_SLOTS) expects External-NG as its own
  slot, read from a separate External_NG/NG-YYYYMMDD_vN/ directory
  (_SLOT_PREFIX['external_ng'] = 'NG', subdir 'External_NG'). This script
  builds that slot directly and independently from the source registry,
  rather than splitting build_network_groups.py's internal output.

  Tier-1  NG-INTERNET-FACING
  Tier-2  Per-location breakout   NG-EIF-<SITE_CODE> (LM join) or
                                  NG-EIF-<slugified CANONICAL_LOCATION> if no LM match
  Tier-3  Concatenated CIDR object  AO-EIF-<SITE_CODE or slug>

Input:
  ent-ipdataset-INTERNET-FACING-v*.csv  (required)
    Columns used: CIDR, CANONICAL_LOCATION, HERITAGE, NET_TYPE, SOURCE,
                  ROUTING_DOMAIN, DATA_QUALITY
  location_master_table.csv (or location_master_v*.csv)  (optional — improves
    Tier-2 naming to SITE_CODE convention; script still works without it)

Outputs (written to --out, default ./External_NG/NG-YYYYMMDD_v1):
  network_object_catalog_v<stamp>.csv   TIER,OBJECT_NAME,PARENT,CLASS,
                                         MEMBER_TYPE,VALUE,CIDR_COUNT,SOURCE
                                         (schema matches build_network_groups.py
                                         so build_edl_catalog.py reads it identically)
  ng_manifest.csv                       Tier1_Class,Tier2_Location,Tier3_Object,CIDR_count
  EDL/*.txt                             one EDL per Tier-1/Tier-2/Tier-3 object (unless --no-edl)

Known scope limit (v1.0.0):
  Only ent-ipdataset-INTERNET-FACING is consumed. SNAT pool data
  (FW-SNAT-POOLS / F5-SNAT-POOLS) is NOT yet merged in — the original
  build_network_groups.py comment describes the eventual source as
  "snat+eif" combined. This script covers the EIF half only. Merging SNAT
  pools is a MINOR-version follow-up once the join key (SNAT_CIDR_24 ->
  SITE_CODE) is confirmed against a real run.

Usage:
  python3 build_external_ng.py \\
      --eif ipam-db/ent-ipdataset-INTERNET-FACING-v20260610.csv \\
      --lm  ipam-db/location_master_table.csv \\
      --out External_NG/NG-20260708_v1

  # Auto-discover from {base}/ipam-db/:
  python3 build_external_ng.py --base . [--dry-run]

Versioning: single __version__ = MAJOR.MINOR.PATCH. Dataset inputs/outputs
carry their own CCD version stamps per ccd-versioning-discipline.

Changelog:
  v1.0.0 — 2026-07-08  Initial build. Standalone External-NG generator,
           independent of build_network_groups.py per architecture decision
           (standalone scripts re-deriving from source registries, not a
           split of build_network_groups.py's internal output).
"""
from __future__ import annotations
import argparse, csv, glob, ipaddress, json, os, re, sys
from collections import defaultdict, OrderedDict
from datetime import date

__version__ = "1.0.1"

# ---------------------------------------------------------------------------
# FILE DISCOVERY
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    def _ver_key(path):
        name = os.path.basename(path)
        m = re.search(r'v(\d{8})(?:r(\d+))?', name)
        if m:
            return (int(m.group(1)), int(m.group(2) or 0))
        return (0, 0)
    matches = glob.glob(os.path.join(directory, pattern))
    return max(matches, key=_ver_key) if matches else None


def discover_inputs(base="."):
    ipam_dir = os.path.join(base, "ipam-db")
    lm_canonical = os.path.join(ipam_dir, "location_master_table.csv")
    lm = lm_canonical if os.path.exists(lm_canonical) \
         else _latest(ipam_dir, "location_master_v*.csv")
    return {
        "eif": _latest(ipam_dir, "ent-ipdataset-INTERNET-FACING-v*.csv"),
        "lm":  lm,
    }


def resolve_input(cli_value, discovered_value, name, required=True):
    path = cli_value or discovered_value
    if path and os.path.exists(path):
        print(f"  {name:<22s} {path}  [{'arg' if cli_value else 'auto'}]")
        return path
    if required:
        label = path or "(no match in default locations)"
        print(f"  {name:<22s} NOT FOUND: {label}", file=sys.stderr)
        sys.exit(1)
    if path:
        print(f"  {name:<22s} skipped (not found)")
    return None


def next_version_dir(base_out_dir: str) -> str:
    """Return External_NG/NG-YYYYMMDD_vN, auto-bumping N if today's dir exists."""
    stamp = date.today().strftime('%Y%m%d')
    n = 1
    while True:
        candidate = os.path.join(base_out_dir, f"NG-{stamp}_v{n}")
        if not os.path.exists(candidate):
            return candidate
        n += 1


def latest_net_group_dir(base_dir: str) -> str:
    """Find the most recent Net_Group/NG-YYYYMMDD_vN/ directory.

    v1.0.1 — External-NG now nests inside build_network_groups.py's own
    Net_Group/ version directory (in its own External_NG/ subfolder)
    instead of maintaining a separate top-level External_NG/ tree — a
    full platform export only needs Net_Group/ and Net_Object/, not N
    additional directories. Falls back to creating a fresh dated
    directory using the same NG-YYYYMMDD_vN convention if none exists yet.
    """
    ng_dir = os.path.join(base_dir, 'Net_Group')
    candidates = []
    if os.path.isdir(ng_dir):
        for d in os.listdir(ng_dir):
            m = re.match(r'NG-(\d{8})_v(\d+)$', d)
            if m:
                candidates.append((int(m.group(1)), int(m.group(2)), d))
    if not candidates:
        return next_version_dir(ng_dir)
    candidates.sort()
    return os.path.join(ng_dir, candidates[-1][2])


# ---------------------------------------------------------------------------
# CSV HELPERS
# ---------------------------------------------------------------------------

def read_stamped_csv(path: str):
    """Read a CCD CSV that has #-prefixed header stamps before the real header row."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        lines = f.readlines()
    hdr_idx = next(i for i, ln in enumerate(lines)
                   if not ln.startswith("#") and "," in ln)
    reader = csv.DictReader(lines[hdr_idx:])
    return list(reader)


def valid_cidr(c: str) -> bool:
    if not c or "/" not in str(c):
        return False
    try:
        ipaddress.ip_network(c, strict=False)
        return True
    except ValueError:
        return False


def slugify_location(loc: str) -> str:
    s = re.sub(r'[^A-Za-z0-9]+', '-', loc.strip()).strip('-').upper()
    return s or 'UNKNOWN'


def addr_name_for_cidr(cidr: str) -> str:
    return "addr-" + cidr.replace("/", "_").replace(".", "-")


def write_edl(group_name, cidrs, edl_dir, metadata=None):
    """Write a single PA EDL .txt file — same format as build_network_groups.py."""
    fname = group_name.replace('/', '_') + '.txt'
    path = os.path.join(edl_dir, fname)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(f'# {group_name}\n')
        f.write(f'# Export Date: {date.today().isoformat()}\n')
        f.write(f'# Source: CCD Platform build_external_ng.py v{__version__}\n')
        f.write(f'# Subnets: {len(cidrs)}\n')
        if metadata:
            for k, v in metadata.items():
                f.write(f'# {k}: {v}\n')
        f.write('#\n')
        for cidr in sorted(cidrs, key=lambda c: ipaddress.ip_network(c, strict=False)):
            f.write(f'{cidr}\n')


# ---------------------------------------------------------------------------
# BUILD
# ---------------------------------------------------------------------------

def build(args):
    print(f'build_external_ng.py v{__version__}')
    print()

    # ── Load LM for SITE_CODE naming (optional) ──────────────────────────
    loc_to_sitecode = {}
    if args.lm and os.path.exists(args.lm):
        for row in read_stamped_csv(args.lm):
            name = (row.get('CANONICAL_NAME') or '').strip()
            sc = (row.get('SITE_CODE') or '').strip()
            if name and sc:
                loc_to_sitecode[name] = sc
        print(f'  LM loaded: {len(loc_to_sitecode):,} CANONICAL_NAME -> SITE_CODE mappings')
    else:
        print('  No LM provided — Tier-2 groups will use slugified CANONICAL_LOCATION names')
    print()

    # ── Load INTERNET-FACING registry ─────────────────────────────────────
    rows = read_stamped_csv(args.eif)
    print(f'Processing INTERNET-FACING: {os.path.basename(args.eif)} ({len(rows):,} rows)')

    t2_children = defaultdict(set)   # NG-EIF-<key> -> set(AO name)
    t3 = defaultdict(set)            # AO name -> set(CIDR)
    t2_key_label = {}                # key -> human label (for manifest)
    skipped_bad_cidr = 0
    skipped_no_location = 0

    for row in rows:
        cidr = (row.get('CIDR') or '').strip()
        loc = (row.get('CANONICAL_LOCATION') or '').strip()
        if not valid_cidr(cidr):
            skipped_bad_cidr += 1
            continue
        if not loc:
            skipped_no_location += 1
            key = 'UNKNOWN'
        else:
            key = loc_to_sitecode.get(loc) or slugify_location(loc)
        t2 = f'NG-EIF-{key}'
        ao = f'AO-EIF-{key}'
        t3[ao].add(cidr)
        t2_children[t2].add(ao)
        t2_key_label[t2] = loc or 'Unknown location'

    total_cidrs = sum(len(v) for v in t3.values())
    print(f'  {total_cidrs:,} internet-facing CIDRs across {len(t2_children)} location groups')
    if skipped_bad_cidr:
        print(f'  WARNING: {skipped_bad_cidr} rows skipped — invalid/missing CIDR')
    if skipped_no_location:
        print(f'  WARNING: {skipped_no_location} rows skipped CANONICAL_LOCATION — filed under NG-EIF-UNKNOWN')
    print()

    tier1 = 'NG-INTERNET-FACING'

    if args.dry_run:
        print(json.dumps({
            "dry_run": True,
            "tier1": tier1,
            "tier2_groups": len(t2_children),
            "tier3_objects": len(t3),
            "total_cidrs": total_cidrs,
            "skipped_bad_cidr": skipped_bad_cidr,
            "skipped_no_location": skipped_no_location,
        }, indent=2))
        return

    os.makedirs(args.out, exist_ok=True)

    # ── Catalog CSV (schema matches build_network_groups.py) ─────────────
    catalog = []
    catalog.append(dict(TIER=1, OBJECT_NAME=tier1, PARENT='', CLASS='INTERNET-FACING',
                         MEMBER_TYPE='group', VALUE=';'.join(sorted(t2_children)),
                         CIDR_COUNT=total_cidrs, SOURCE='internet-facing-registry'))
    for t2, aos in sorted(t2_children.items()):
        t2_total = sum(len(t3.get(ao, set())) for ao in aos)
        catalog.append(dict(TIER=2, OBJECT_NAME=t2, PARENT=tier1, CLASS='INTERNET-FACING',
                             MEMBER_TYPE='group', VALUE=';'.join(sorted(aos)),
                             CIDR_COUNT=t2_total, SOURCE='internet-facing-registry'))
        for ao in sorted(aos):
            cidrs = t3.get(ao, set())
            catalog.append(dict(TIER=3, OBJECT_NAME=ao, PARENT=t2, CLASS='',
                                 MEMBER_TYPE='cidr-list', VALUE=';'.join(sorted(cidrs)),
                                 CIDR_COUNT=len(cidrs), SOURCE='internet-facing-registry'))

    stamp = date.today().strftime('%Y%m%d')
    cat_csv = os.path.join(args.out, f'network_object_catalog_v{stamp}.csv')
    cols = ['TIER', 'OBJECT_NAME', 'PARENT', 'CLASS', 'MEMBER_TYPE', 'VALUE', 'CIDR_COUNT', 'SOURCE']
    with open(cat_csv, 'w', newline='') as f:
        f.write(f'#STEM=external_ng_catalog\n#VERSION={stamp}\n#ROWS={len(catalog)}\n')
        f.write(f'#TOOL=build_external_ng.py v{__version__}\n#SOURCE_INPUT={os.path.basename(args.eif)}\n#END_HEADER\n')
        wr = csv.DictWriter(f, fieldnames=cols)
        wr.writeheader()
        for row in catalog:
            wr.writerow(row)

    # ── Manifest (human-readable summary) ─────────────────────────────────
    with open(os.path.join(args.out, 'ng_manifest.csv'), 'w', newline='') as f:
        wr = csv.writer(f)
        wr.writerow(['Tier1_Class', 'Tier2_Location', 'Tier3_Object', 'CIDR_count'])
        for t2, aos in sorted(t2_children.items()):
            for ao in sorted(aos):
                wr.writerow([tier1, f'{t2} ({t2_key_label.get(t2, "")})', ao, len(t3.get(ao, set()))])

    # ── EDL export ─────────────────────────────────────────────────────────
    edl_count = 0
    if not args.no_edl:
        edl_dir = os.path.join(args.out, 'EDL')
        os.makedirs(edl_dir, exist_ok=True)

        all_cidrs = set()
        for cidrs in t3.values():
            all_cidrs |= cidrs
        write_edl(tier1, all_cidrs, edl_dir, metadata={'Tier': '1', 'Class': 'INTERNET-FACING'})
        edl_count += 1

        for t2, aos in sorted(t2_children.items()):
            t2_cidrs = set()
            for ao in aos:
                t2_cidrs |= t3.get(ao, set())
            if t2_cidrs:
                write_edl(t2, t2_cidrs, edl_dir, metadata={'Tier': '2', 'Location': t2_key_label.get(t2, '')})
                edl_count += 1

        for ao, cidrs in sorted(t3.items()):
            if cidrs:
                write_edl(ao, cidrs, edl_dir, metadata={'Tier': '3'})
                edl_count += 1

        print(f'EDL export: {edl_count} files written to {edl_dir}/')

    print(json.dumps({
        "version": __version__,
        "tier1": tier1,
        "tier2_groups": len(t2_children),
        "tier3_objects": len(t3),
        "total_cidrs": total_cidrs,
        "skipped_bad_cidr": skipped_bad_cidr,
        "skipped_no_location": skipped_no_location,
        "edls_written": edl_count,
        "catalog_csv": cat_csv,
        "out_dir": args.out,
    }, indent=2))


def main():
    ap = argparse.ArgumentParser(description='CCD Platform — External-NG (Internet-Facing) builder')
    ap.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    ap.add_argument('--eif', default=None, help='ent-ipdataset-INTERNET-FACING CSV (auto-discovered if omitted)')
    ap.add_argument('--lm', default=None, help='location_master CSV (optional; improves Tier-2 naming)')
    ap.add_argument('--out', default=None, help='output directory (default: ./External_NG/NG-YYYYMMDD_v<N>)')
    ap.add_argument('--base', default='.', help='CCD Platform root directory for auto-discovery (default: .)')
    ap.add_argument('--no-edl', action='store_true', help='skip EDL/*.txt export (EDL is written by default)')
    ap.add_argument('--dry-run', action='store_true', help='report counts without writing files')
    args = ap.parse_args()

    print('Resolving inputs:')
    disc = discover_inputs(args.base)
    args.eif = resolve_input(args.eif, disc.get('eif'), 'eif', required=True)
    args.lm = resolve_input(args.lm, disc.get('lm'), 'lm', required=False)
    print()

    if args.out is None:
        args.out = os.path.join(latest_net_group_dir(args.base), 'External_NG')

    build(args)


if __name__ == '__main__':
    main()
