#!/usr/bin/env python3
"""
build_svc_report.py  v1.0.4
============================
Reads the service_object_catalog_v*.csv produced by build_service_objects.py
and renders a self-contained interactive HTML report.

WHAT THIS SHOWS
---------------
  Left panel   — Tier-1 service class tree (NG-SVC-APP, NG-EXT-INFRA, etc.)
                 Click a class to expand named service objects.
                 Click a service object to see its members in the right panel.

  Right panel  — Member list for the selected service object:
                 /32 host IPs (internal) or CIDR ranges (external/partner).
                 Shows heritage, routing domain, member count.

  Header stats — Object counts per class, total members, heritage breakdown.

  Search box   — Live filter across all object names and member values.

  Cross-links  — "Which locations have hosts in this service?"
                 Joins MEMBER_IPS against all_IP_networks via IPAM LPM
                 (requires --ipam flag; optional).

USAGE
-----
  python3 build_svc_report.py                              # auto-discover
  python3 build_svc_report.py --catalog service_object_catalog_v20260609.csv
  python3 build_svc_report.py --catalog <file> --out Service_Objects.html

Changelog:
  v1.0.4 2026-06-11  discover_inputs(): prefer latest Net_Object/SO-YYYYMMDD_vN/
                     subdir (matches versioned output of build_service_objects.py
                     v1.0.3+). Falls back to flat Net_Object/, network-groups/,
                     processed_outputs/ in order.
  v1.0.0 2026-06-09  Initial build.
"""

import argparse
import csv
csv.field_size_limit(10_000_000)
import datetime
import glob
import html
import json
import os
import re
import sys

__version__ = '1.0.5'


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    def _key(p):
        m = re.search(r'v(\d{8})(?:r(\d+))?', os.path.basename(p))
        return (int(m.group(1)), int(m.group(2) or 0)) if m else (0, 0)
    matches = glob.glob(os.path.join(directory, pattern))
    return max(matches, key=_key) if matches else None


def discover_inputs(base='.'):
    # v1.0.4: prefer latest versioned Net_Object/SO-YYYYMMDD_vN/ subdir
    # (same pattern as build_ng_report.py -> Net_Group/NG-YYYYMMDD_vN/)
    net_obj  = os.path.join(base, 'Net_Object')
    ng_dir   = os.path.join(base, 'network-groups')
    proc_dir = os.path.join(base, 'processed_outputs')

    _so_search = net_obj  # default: flat Net_Object/
    if os.path.isdir(net_obj):
        _versioned = sorted(
            [d for d in os.listdir(net_obj)
             if re.match(r'^SO-\d{8}_v\d+$', d)],
            key=lambda d: (
                re.search(r'(\d{8})_v(\d+)', d).group(1),
                int(re.search(r'_v(\d+)$', d).group(1))
            )
        )
        if _versioned:
            _latest_so = os.path.join(net_obj, _versioned[-1])
            if _latest(net_obj, 'service_object_catalog_v*.csv') or \
               glob.glob(os.path.join(_latest_so, 'service_object_catalog_v*.csv')):
                _so_search = _latest_so  # prefer the versioned subdir

    return {
        'catalog': _latest(_so_search, 'service_object_catalog_v*.csv') or
                   _latest(net_obj,    'service_object_catalog_v*.csv') or
                   _latest(ng_dir,     'service_object_catalog_v*.csv') or
                   _latest(proc_dir,   'service_object_catalog_v*.csv'),
    }


# ---------------------------------------------------------------------------
# Catalog reader
# ---------------------------------------------------------------------------

def read_catalog(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        lines = f.readlines()
    version = 'unknown'
    header_idx = 0
    for i, line in enumerate(lines):
        if line.startswith('#VERSION='):
            version = line.split('=', 1)[1].strip()
        if not line.startswith('#') and ',' in line:
            header_idx = i
            break
    rows = list(csv.DictReader(lines[header_idx:]))
    return [r for r in rows if r.get('OBJECT_NAME')], version


# ---------------------------------------------------------------------------
# Tree builder
# ---------------------------------------------------------------------------

def build_tree(rows):
    nodes = {}
    for r in rows:
        name = r['OBJECT_NAME']
        tier = str(r.get('TIER', ''))
        mt   = (r.get('MEMBER_TYPE') or '').strip()
        val  = (r.get('VALUE') or '').strip()

        members = []
        if mt in ('host-list', 'cidr-list'):
            members = [m for m in val.split(';') if m]

        nodes[name] = {
            'name':           name,
            'tier':           tier,
            'klass':          r.get('CLASS', ''),
            'member_type':    mt,
            'parent':         (r.get('PARENT') or '').strip(),
            'cidr_count':     r.get('CIDR_COUNT', ''),
            'heritage':       r.get('HERITAGE', ''),
            'routing_domain': r.get('ROUTING_DOMAIN', ''),
            'app_acronym':    r.get('APP_ACRONYM', ''),
            'service_role':   r.get('SERVICE_ROLE', ''),
            'members':        members,
            'children':       [],
        }

    for r in rows:
        name   = r['OBJECT_NAME']
        parent = (r.get('PARENT') or '').strip()
        if parent and parent in nodes and name != parent:
            nodes[parent]['children'].append(name)

    for d in nodes.values():
        d['children'].sort()

    roots = sorted([n for n, d in nodes.items() if d['tier'] == '1'])
    return {'nodes': nodes, 'roots': roots}


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

def compute_stats(rows, tree):
    nodes = tree['nodes']
    t1 = [n for n, d in nodes.items() if d['tier'] == '1']
    t3 = [n for n, d in nodes.items() if d['tier'] == '3']

    total_members = sum(len(d['members']) for d in nodes.values())

    heritage_counts = {}
    rd_counts = {}
    for n, d in nodes.items():
        if d['tier'] != '3':
            continue
        h = d['heritage'] or 'Unknown'
        heritage_counts[h] = heritage_counts.get(h, 0) + len(d['members'])
        rd = d['routing_domain'] or 'Unknown'
        rd_counts[rd] = rd_counts.get(rd, 0) + len(d['members'])

    per_class = []
    for n in sorted(t1):
        d = nodes[n]
        child_members = sum(
            len(nodes[c]['members'])
            for c in d['children'] if c in nodes
        )
        per_class.append({
            'klass':   n,
            'objects': len(d['children']),
            'members': child_members,
        })

    return {
        'tier1':          len(t1),
        'total_objects':  len(t3),
        'total_members':  total_members,
        'heritage':       heritage_counts,
        'routing_domain': rd_counts,
        'per_class':      per_class,
    }


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------

def render_html(tree, stats, version, catalog_name):
    payload = json.dumps({'tree': tree, 'stats': stats}, separators=(',', ':'))
    built   = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CCD Service Object Catalog — v{version}</title>
<style>
  :root {{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c2333; --line:#2d3748;
    --ink:#e6edf3; --muted:#8b949e; --cyan:#39d0d8; --amber:#e3b341;
    --green:#3fb950; --violet:#a371f7; --red:#f85149; --blue:#58a6ff;
    --orange:#ffa657; --pink:#f778ba;
    --mono:"SF Mono","JetBrains Mono",Menlo,Consolas,monospace;
    --sans:"IBM Plex Sans",-apple-system,Segoe UI,sans-serif;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--ink);
    font-family:var(--sans); font-size:14px; line-height:1.5; }}
  header {{ padding:22px 28px 16px; border-bottom:1px solid var(--line);
    background:linear-gradient(180deg,#11161f,#0d1117); }}
  h1 {{ margin:0 0 2px; font-size:19px; font-weight:600; }}
  h1 .tag {{ color:var(--cyan); }}
  .sub {{ color:var(--muted); font-size:12.5px; }}
  .stats {{ display:flex; flex-wrap:wrap; gap:14px; padding:16px 28px;
    border-bottom:1px solid var(--line); }}
  .stat {{ background:var(--panel); border:1px solid var(--line);
    border-radius:9px; padding:11px 16px; min-width:104px; }}
  .stat .n {{ font-family:var(--mono); font-size:21px; font-weight:600; }}
  .stat .l {{ color:var(--muted); font-size:11px; text-transform:uppercase;
    letter-spacing:.6px; margin-top:2px; }}
  .stat.cyan .n  {{ color:var(--cyan); }}
  .stat.green .n {{ color:var(--green); }}
  .stat.violet .n {{ color:var(--violet); }}
  .stat.amber .n {{ color:var(--amber); }}
  .wrap {{ display:grid; grid-template-columns:360px 1fr; gap:0;
    height:calc(100vh - 210px); }}
  .left {{ border-right:1px solid var(--line); overflow:auto; padding:14px; }}
  .right {{ overflow:auto; padding:18px 24px; }}
  .search {{ width:100%; padding:9px 12px; background:var(--panel);
    color:var(--ink); border:1px solid var(--line); border-radius:8px;
    font-family:var(--mono); font-size:13px; margin-bottom:12px; }}
  .search:focus {{ outline:none; border-color:var(--cyan); }}
  .t1 {{ margin-bottom:4px; }}
  .t1>.row {{ display:flex; align-items:center; gap:8px; padding:8px 10px;
    border-radius:7px; cursor:pointer; font-weight:600; }}
  .t1>.row:hover {{ background:var(--panel2); }}
  .t1 .cnt {{ margin-left:auto; font-family:var(--mono); font-size:11px;
    color:var(--muted); }}
  .caret {{ width:9px; color:var(--muted); transition:transform .12s; }}
  .open>.row .caret {{ transform:rotate(90deg); }}
  .kids {{ display:none; margin:2px 0 6px 16px;
    border-left:1px solid var(--line); padding-left:8px; }}
  .open>.kids {{ display:block; }}
  .svc {{ padding:5px 9px; border-radius:6px; cursor:pointer;
    font-family:var(--mono); font-size:12px; display:flex; gap:8px;
    align-items:center; }}
  .svc:hover {{ background:var(--panel2); }}
  .svc.sel {{ background:rgba(57,208,216,.12); color:var(--cyan); }}
  .svc .cnt {{ margin-left:auto; color:var(--muted); font-size:11px; }}
  /* Class colour badges */
  .badge {{ font-size:9.5px; padding:1px 6px; border-radius:10px;
    text-transform:uppercase; letter-spacing:.5px; }}
  .b-app      {{ background:rgba(57,208,216,.14);  color:var(--cyan); }}
  .b-infra    {{ background:rgba(163,113,247,.18); color:var(--violet); }}
  .b-service  {{ background:rgba(63,185,80,.16);   color:var(--green); }}
  .b-delivery {{ background:rgba(255,166,87,.18);  color:var(--orange); }}
  .b-cpc      {{ background:rgba(88,166,255,.18);  color:var(--blue); }}
  .b-ext      {{ background:rgba(247,120,186,.18); color:var(--pink); }}
  .b-vpn      {{ background:rgba(227,179,65,.18);  color:var(--amber); }}
  .b-p2p      {{ background:rgba(248,81,73,.18);   color:var(--red); }}
  /* Right panel */
  .detail-header {{ margin-bottom:16px; }}
  .detail-header h2 {{ font-family:var(--mono); font-size:16px; margin:0 0 4px;
    color:var(--cyan); }}
  .detail-meta {{ display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px; }}
  .meta-item {{ background:var(--panel); border:1px solid var(--line);
    border-radius:6px; padding:6px 12px; font-size:12px; }}
  .meta-item .k {{ color:var(--muted); font-size:11px; display:block; }}
  .member-list {{ font-family:var(--mono); font-size:12px; }}
  .member-list .m {{ padding:3px 0; border-bottom:1px solid var(--line);
    display:flex; gap:12px; }}
  .member-list .m:last-child {{ border-bottom:none; }}
  .member-list .ip {{ color:var(--cyan); flex:1; }}
  .member-list .idx {{ color:var(--muted); width:40px; text-align:right; }}
  .empty {{ color:var(--muted); font-style:italic; padding:20px 0; }}
  .chart {{ margin:0 0 20px; }}
  .chart-row {{ display:flex; align-items:center; gap:10px; margin-bottom:6px; }}
  .chart-label {{ font-family:var(--mono); font-size:11px; width:200px;
    color:var(--muted); white-space:nowrap; overflow:hidden;
    text-overflow:ellipsis; }}
  .chart-bar-wrap {{ flex:1; background:var(--panel);
    border-radius:4px; height:14px; overflow:hidden; }}
  .chart-bar {{ height:100%; background:var(--cyan); border-radius:4px;
    transition:width .3s; }}
  .chart-val {{ font-family:var(--mono); font-size:11px; color:var(--muted);
    width:60px; text-align:right; }}
  .hidden {{ display:none; }}
</style>
</head>
<body>
<header>
  <h1>CCD <span class="tag">Service Object Catalog</span></h1>
  <div class="sub">Destination-side PA policy objects &nbsp;·&nbsp; v{version} &nbsp;·&nbsp;
    Built {built} &nbsp;·&nbsp; {html.escape(catalog_name)}</div>
</header>

<div class="stats" id="stats"></div>

<div class="wrap">
  <div class="left">
    <input class="search" id="search" placeholder="Search objects or members…" autocomplete="off">
    <div id="tree"></div>
  </div>
  <div class="right" id="detail">
    <div class="empty">← Select a service object to inspect its members</div>
  </div>
</div>

<script>
const DATA = {payload};

const CLASS_BADGE = {{
  'APP':      ['b-app',      'App'],
  'INFRA':    ['b-infra',    'Infra'],
  'SERVICE':  ['b-service',  'Service'],
  'DELIVERY': ['b-delivery', 'Delivery'],
  'CPC':      ['b-cpc',      'CPC'],
  'EXT_INFRA':['b-ext',      'Ext-Infra'],
  'EXT_SVC':  ['b-ext',      'Ext-Svc'],
  'EXT_APP':  ['b-ext',      'Ext-App'],
  'VPN':      ['b-vpn',      'VPN'],
  'P2P':      ['b-p2p',      'P2P'],
}};

function badge(klass) {{
  const [cls, label] = CLASS_BADGE[klass] || ['', klass];
  return cls ? `<span class="badge ${{cls}}">${{label}}</span>` : '';
}}

function renderStats() {{
  const s = DATA.stats;
  const el = document.getElementById('stats');
  el.innerHTML = `
    <div class="stat cyan"><div class="n">${{s.tier1}}</div><div class="l">Classes</div></div>
    <div class="stat green"><div class="n">${{s.total_objects.toLocaleString()}}</div><div class="l">Service Objects</div></div>
    <div class="stat violet"><div class="n">${{s.total_members.toLocaleString()}}</div><div class="l">Total Members</div></div>
    ${{s.per_class.map(c => `
      <div class="stat">
        <div class="n" style="font-size:16px">${{c.objects}}</div>
        <div class="l">${{c.klass.replace('NG-SVC-','').replace('NG-EXT-','EXT-').replace('NG-','')}}
          <span style="color:var(--muted);font-size:10px"> ${{c.members.toLocaleString()}} members</span>
        </div>
      </div>`).join('')}}`;
}}

function renderTree(filter) {{
  const nodes = DATA.tree.nodes;
  const roots = DATA.tree.roots;
  const el = document.getElementById('tree');
  const q = (filter || '').toLowerCase();

  function matches(node) {{
    if (!q) return true;
    if (node.name.toLowerCase().includes(q)) return true;
    if (node.members && node.members.some(m => m.toLowerCase().includes(q))) return true;
    return false;
  }}

  function renderT1(t1name) {{
    const t1 = nodes[t1name];
    if (!t1) return '';
    const visChildren = t1.children.filter(c => matches(nodes[c] || {{}}));
    if (q && visChildren.length === 0) return '';
    const open = q ? 'open' : '';
    return `<div class="t1 ${{open}}" id="t1-${{t1name}}">
      <div class="row" onclick="toggleT1('${{t1name}}')">
        <span class="caret">▶</span>
        <span>${{t1name}}</span>
        ${{badge(t1.klass)}}
        <span class="cnt">${{t1.children.length}} objs</span>
      </div>
      <div class="kids">
        ${{visChildren.map(c => renderSvc(c)).join('')}}
      </div>
    </div>`;
  }}

  function renderSvc(name) {{
    const n = nodes[name];
    if (!n) return '';
    return `<div class="svc" id="svc-${{name}}" onclick="selectSvc('${{name}}')">
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis">${{name}}</span>
      <span class="cnt">${{n.cidr_count || n.members.length}}</span>
    </div>`;
  }}

  el.innerHTML = roots.map(renderT1).join('');
}}

function toggleT1(name) {{
  const el = document.getElementById('t1-' + name);
  if (el) el.classList.toggle('open');
}}

let selectedSvc = null;
function selectSvc(name) {{
  if (selectedSvc) {{
    const prev = document.getElementById('svc-' + selectedSvc);
    if (prev) prev.classList.remove('sel');
  }}
  selectedSvc = name;
  const el = document.getElementById('svc-' + name);
  if (el) el.classList.add('sel');
  renderDetail(name);
}}

function renderDetail(name) {{
  const n = DATA.tree.nodes[name];
  if (!n) return;
  const panel = document.getElementById('detail');
  const isHostList = n.member_type === 'host-list';
  const memberLabel = isHostList ? 'Host IPs (/32)' : 'CIDR Ranges';
  const metas = [
    ['Class', n.klass],
    ['Heritage', n.heritage || '—'],
    ['Routing Domain', n.routing_domain || '—'],
    ['App Acronym', n.app_acronym || '—'],
    ['Service Role', n.service_role || '—'],
    ['Members', (n.cidr_count || n.members.length).toLocaleString() + ' ' + memberLabel],
  ].filter(([k,v]) => v && v !== '—');

  const memberRows = n.members.map((m, i) =>
    `<div class="m"><span class="idx">${{i+1}}</span><span class="ip">${{m}}</span></div>`
  ).join('');

  panel.innerHTML = `
    <div class="detail-header">
      <h2>${{name}}</h2>
      <div class="detail-meta">
        ${{metas.map(([k,v]) => `<div class="meta-item"><span class="k">${{k}}</span>${{v}}</div>`).join('')}}
      </div>
    </div>
    ${{n.members.length === 0
      ? '<div class="empty">No members</div>'
      : `<div class="member-list">${{memberRows}}</div>`
    }}`;
}}

document.getElementById('search').addEventListener('input', function() {{
  renderTree(this.value);
}});

renderStats();
renderTree('');
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description='Build CCD Service Object Catalog HTML report.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument('--catalog', default=None,
                    help='service_object_catalog_v*.csv (auto-discovered if omitted)')
    ap.add_argument('--out', default=None,
                    help='Output HTML path (default: Service_Objects_Report.html '
                         'alongside catalog)')
    ap.add_argument('--base', default='.',
                    help='CCD Platform root for auto-discovery')
    ap.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    args = ap.parse_args()

    disc = discover_inputs(args.base)
    catalog_path = args.catalog or disc.get('catalog')
    if not catalog_path or not os.path.exists(catalog_path):
        print(f'ERROR: service_object_catalog not found. '
              f'Run build_service_objects.py first, or pass --catalog.',
              file=sys.stderr)
        sys.exit(1)

    out_path = args.out or os.path.join(
        os.path.dirname(catalog_path),
        'Service_Objects_Report.html'
    )

    print(f'build_svc_report.py v{__version__}')
    print(f'  Catalog : {catalog_path}')
    print(f'  Output  : {out_path}')

    rows, version = read_catalog(catalog_path)
    tree  = build_tree(rows)
    stats = compute_stats(rows, tree)
    doc   = render_html(tree, stats, version,
                        os.path.basename(catalog_path))

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(doc)

    t1_count = stats['tier1']
    obj_count = stats['total_objects']
    mem_count = stats['total_members']
    print(f'  Classes : {t1_count}')
    print(f'  Objects : {obj_count:,}')
    print(f'  Members : {mem_count:,}')
    print(f'Done → {out_path}')


if __name__ == '__main__':
    main()
