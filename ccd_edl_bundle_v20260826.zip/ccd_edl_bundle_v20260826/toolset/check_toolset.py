#!/usr/bin/env python3
"""
check_toolset.py  v1.15.9
CCD Platform — Toolset Health Check
CVS Health Information Security

Runs every CCD Platform script in safe (--version / --dry-run / --help) mode
and reports pass/fail. No files are written except the local version/checksum
registry (check_toolset_registry.json) and its history log — both scoped to
this tool's own drift tracking, never to platform datasets.

Usage:
    python3 check_toolset.py              # full check
    python3 check_toolset.py --fast       # version checks only (no dry-runs)
    python3 check_toolset.py --group update   # only run update_* scripts
    python3 check_toolset.py --group build    # only run build_* scripts
    python3 check_toolset.py --no-track   # skip integrity/version registry pass
    python3 check_toolset.py --reset-registry   # wipe registry, re-bootstrap
    python3 check_toolset.py --registry PATH    # use a non-default registry file

Groups: platform, shared, update, build, preprocess, generate

Run from ~/Documents/IP_Lookup/

── Version tracking & integrity checks (v1.6.0+) ──────────────────────────
Two independent problems this addresses, both real and both seen repeatedly
in this file's own changelog before v1.6.0:

1. Hardcoded literal version strings in TESTS go stale every time a script
   legitimately advances (e.g. 'v1.8' still hardcoded after the script moved
   to v1.9.2) and produce a false FAIL. Fixed by switching version tests from
   exact-substring matching to a numeric floor comparison: PASS as long as
   the script's reported version is >= the literal in TESTS. Genuinely
   under-floor versions (regressions) still correctly FAIL.

2. That alone doesn't catch a script's *content* changing without its
   version being bumped, or a version number moving backwards — exactly what
   happened with fw_group_lookup.py this session (session notes claimed
   v0.2.0 registry-integration work; the file on disk was still v0.1.0).
   Fixed by a separate integrity pass: a local JSON registry
   (check_toolset_registry.json) tracks a SHA256 checksum + last-known
   version per script. Each run:
     - unseen script            -> BASELINE (recorded, informational only)
     - checksum unchanged       -> OK, no further check needed
     - checksum changed + version increased  -> ADVANCED (auto-updates the
       registry and appends to check_toolset_version_history.log — no manual
       changelog edit needed)
     - checksum changed + version unchanged  -> FAIL (content changed
       without a version bump — a real versioning-discipline violation)
     - checksum changed + version decreased  -> FAIL (regression)
     - checksum changed, script has no --version test to check -> WARN
       (flagged, not hard-failed, since it can't be verified)
"""

__version__ = '1.15.9'
# v1.15.9 — 2026-08-23  Three floor bumps and one new entry:
#   build_fw_location_topology.py '1.3.0' -> '2.0.4' (v2.0.0 major
#   rewrite: four FW tier registries, new FW_ROLE values PCI-ENFORCEMENT/
#   VPN-EDGE/B2B-EDGE, new output columns EGR_CODE/ADJACENT_EGR_CODE/
#   FW_TIER; v2.0.4 adds hard guard against writing to ipam-db/ directly);
#   build_fw_topology_report.py '1.1' -> '1.3.0' (new PCI/VPN/B2B tabs);
#   build_app_egress_topology.py added as new entry at floor '1.5.0'
#   (produces egress_topology_registry, app_egress_topology,
#   ip_resolution_index; runs after both FW and IPAM pipelines).
# v1.15.6 — 2026-08-21  build_ip_classification_ref.py floor bumped
#   '1.5.0' -> '1.6.0': real WAN_EDGE false-positive fix.
# v1.15.5 — 2026-08-21  Six real floor updates, all from the same
#   session of evidence-based classification fixes across the FW
#   toolset: ipam-db.py 'v3.31' -> 'v3.32' (CX11 EGR_* exemption);
#   fwlookup.py 'v1.19.0' -> 'v1.20.0' (evidence-based is_pub in
#   show_ip_profile()); build_fw_location_topology.py '1.1' -> '1.3.0'
#   (fw_role()/INTERNET_EGRESS_CIDRS EGR_* + is_public_ip() evidence
#   fix -- most critical: would have inverted 6,525 real egress rows);
#   build_fw_snat_pools.py 'v2.' -> 'v2.6' (evidence-based is_public());
#   build_p2p_policy_map.py '1.1.0' -> '1.3.0' (evidence-based
#   is_cvs_side()); validate_ip.py '0.1' -> '0.2.0' (evidence-based
#   route_as_private() -- most consequential: directly gates object
#   creation); build_external_ip_registry.py 'v2.' -> 'v3.0' (floor
#   tightened from meaninglessly broad major-version-only placeholder to
#   the real current version).
# v1.15.4 — 2026-08-21  Real, confirmed gaps closed from this session's
#   real work: (1) ipam-db.py version floor 'v3.23' -> 'v3.31' (stale
#   since v3.23 -- real work this session alone spanned v3.27.1 through
#   v3.31.0: count_rows() field_size_limit fix, two real egress-firewall
#   _AUDIT_VALID_RD extensions, 6 real PCI tier-specific codes, the new
#   ISP-P2P NET_TYPE, egress_fw_mgmt_ips registered as a first-class
#   IPAM_STEMS entry -- the old floor was silently passing this whole
#   time since 3.3x >= 3.23, not a hard failure, but meaningless as a
#   regression check). (2) build_IP_Network_Egress_FW_topology.py floor
#   '1.13.0' -> '1.17.0', same silent-staleness class. (3) real, confirmed
#   gap: build_custom_objects.py had NO check_toolset entry at all despite
#   being an active script with real work this session (v1.7.1 -> v1.8.0)
#   -- added --version test. (4) build_ip_classification_ref.py -- brand
#   new script this session (real evidence-based IP PUBLIC/PRIVATE/
#   PROVIDER_NETWORK classification, replacing the old bucket-membership
#   reconstruction), given its own real --version flag (v1.3.0) and
#   added here rather than left untracked from day one.
# v1.15.3 — 2026-08-19  Two changes for ipam-db.py v3.23.0: (1) stale
#   version floor 'v3.18.0' -> 'v3.23' (MAJOR.MINOR only, per convention,
#   so future PATCH bumps don't need a check_toolset edit); the floor
#   comparison in run_test() meant the old value was never actually
#   failing (3.22.0 >= 3.18.0), so this was silent staleness, not a real
#   bug. (2) New test asserting 'public_ipv4_ipam' appears in ipam-db.py
#   --list output -- coverage for the four new IP-classification extract
#   stems (public_ipv4_ipam, private_ipv4_ipam, partner_provider_ipv4_ipam,
#   ip_classification_needs_review) added this session. Only checks the
#   stem is known to IPAM_STEMS/--list, not that a real rebuild ran --
#   that needs both all_IP_networks and ip_classification_ref registered
#   first, which this fast pass doesn't set up.
#   NOT execution-tested against a live ipam-db/ in this session --
#   verify with a real --list run before relying on it.
# v1.15.2 — 2026-08-16  build_master_object_set.py added -- Stage 5 of
#          the master object consolidation initiative, built this same
#          session. Two real tests (--help, --version), matching the
#          convention already used for the other object-consolidation
#          scripts.
# v1.15.1 — 2026-08-15  Two real fixes: (1) apply_ehm_enrichment.py and
#          build_ipdataset_objects.py tests REMOVED -- confirmed
#          genuinely gone from disk (Michael confirmed no copy exists,
#          not a deployment gap like fwlookup.py/generate_fw_rule_
#          report.py were this same session), same precedent as the
#          update_asi.py removal: pull the test entirely rather than
#          leave a permanent expected failure or misfile it under
#          _EXPECTED (which is for deliberately-retired tools -- these
#          two need rebuilding from scratch, not deployment, so neither
#          existing category fit). Also cleaned the dangling
#          'build_ipdataset_objects dry-run' FAST_SKIP entry. (2)
#          build_IP_Network_Egress_FW_topology dry-run TIMEOUT_OVERRIDE
#          bumped 240 -> 450: real run confirmed 224.3s passing, then a
#          later run of the same config era exceeded 240s and timed
#          out -- root-caused to call COUNT (once per unmatched /24
#          subnet discovered) growing with each config ingestion, not a
#          per-call regression (query_route_db_knowledge() itself is
#          still the fast bucketed v1.12.0 implementation).
# v1.15.0 — 2026-08-15  Real session: (1) six stale floors bumped with
#          real evidence from today's confirmed runs (build_fw_rule_db.py
#          1.15->1.19.3, collect_fw_bundle.sh 2.0->2.3.0, geo_ip.py
#          1.2->1.3, fwlookup.py v1.16.0->v1.19.0, generate_fw_rule_
#          report.py 2.0->2.2.0, build_fw_config_manifest.py 2.7->2.8,
#          build_fw_route_db.py 0.11.0->0.13.0, build_fw_group_db.py
#          0.5.0->0.8.0); (2) asa_ftd_identity.py added with ZERO prior
#          coverage here (confirmed via grep before adding, same
#          discipline as every other "new" entry in this file) despite
#          being a real, load-bearing dependency of two other scripts'
#          fw_device_identity join; (3) NEW real feature: data freshness
#          checking. check_ip_dataset_freshness()/check_geoip_freshness()
#          flag ip_dataset.py-managed feeds and geo_ip.py's IP2Location/
#          ip2asn source files that have gone stale -- a real, previously
#          invisible gap: this file checked whether TOOLS drifted but had
#          zero visibility into whether the DATA those tools depend on
#          had gone stale. Honest limitation documented in the function's
#          own docstring: parses ip_dataset.py --list's printed table via
#          regex rather than reading ip_dataset.json directly, since that
#          registry's real internal schema wasn't available to verify
#          field names against -- this is inherently more fragile than
#          reading structured JSON, and should be switched over if/when
#          ip_dataset.py gains a machine-readable output mode. New flags:
#          --skip-freshness, --stale-days, --geo-stale-days,
#          --ip-dataset-script, --geo-dataset-dir. Reported as WARN
#          (non-fatal, doesn't affect exit code), same bar as existing
#          integrity WARNs.
# v1.14.29 — 2026-08-03  Real session, four stale floors bumped, one new
#          script added (zero coverage before this):
#            - build_ftd_p2p_registry.py: '0.8.0' -> '0.12.0' (real
#              manager-field rewrite gap closed v0.11.0, then local
#              MANAGER_ALIASES retired entirely in favor of importing
#              from build_fw_config_manifest.py v0.12.0).
#            - build_fw_config_manifest.py: '2.6' -> '2.7' (FW_POLICIES/
#              manager-subdirectory identity resolution -- the piece
#              build_ftd_p2p_registry.py v0.12.0 now imports from).
#            - setup_fw_configs.sh: '2.6' -> '2.9' (v2.7.0 baseline-zip
#              auto-rebuild fallback; v2.8.0 checksum-aware decide_copy()
#              at all six ingestion sites, replacing raw mtime-only "-nt"
#              comparison; v2.9.0 FMC security-zone JSON ingestion;
#              v2.9.1 fixed a real "set -e" bug that silently killed the
#              whole script on the first ordinary skip decision on any
#              re-run; v2.9.2 added the ZERO MATCH guardrail after that
#              exact silence was found to have hidden 101 real device
#              configs across 4 zips for an unknown number of prior
#              runs).
#            - collect_fw_bundle.sh: '1.9' -> '2.0' (pa_config_parser.py
#              -- a hard required dependency of 4 builder scripts,
#              confirmed by direct grep -- was silently absent from
#              every bundle this script ever produced; now collected).
#            - build_fw_device_master.py: NEW script and coverage, floor
#              '1.1'.
#          See each row's own comment for what was and wasn't directly
#          observed/tested this session.
#          of the 5 new rows are --dry-run tests (--help/--version only,
#          same treatment as other new build_*.py additions before
#          this).

# v1.14.27 — 2026-07-30  preprocess_p2.py: added --dry-run test (was
#          --version-only). Real timed run on Michael's machine: 3.967s
#          total against real production-scale data (1,387 new hosts,
#          25,444-row all_IP_networks, 11,560-site location_master) --
#          no TIMEOUT_OVERRIDE needed. Confirmed via the actual run
#          output that this is a genuine smoke test, not a "full run
#          minus write" -- and that the Stage 2 gate check fires before
#          the dry-run branch, reporting CLEAR either way. Added to
#          FAST_SKIP alongside preprocess_p1. Note found in passing,
#          not fixed here: 'preprocess_p1 dry-run' has been sitting in
#          FAST_SKIP with no corresponding TESTS row since before this
#          session -- either a dangling leftover or a gap worth filling
#          the same way this entry just was; flagged, not assumed.
# v1.14.26 — 2026-07-30  MERGE: two independent v1.14.25 edits existed --
#          this session's ingest_pipeline_2.py/build_unresolved_ip_
#          registry.py/update_ipam.py coverage (delivered earlier this
#          session) and a separate v1.14.25 (this file, as re-uploaded)
#          adding build_f5_datasets.py's new --version floor + its
#          --out-dir/--import fix context. Neither one built on the
#          other -- a real version collision, not a simple re-save.
#          Took the re-uploaded file (has the build_f5_datasets.py work)
#          as base and re-applied this session's three changes on top
#          rather than silently overwriting either side:
#            - update_ipam.py: --help-only -> --version + --dry-run
#              (verified against real source this session)
#            - ingest_pipeline_2.py: new, --version only (orchestrator,
#              same treatment as build_object_pipeline.py)
#            - build_unresolved_ip_registry.py: new, --version + --dry-run
#          See each row's own comment for exactly what was and wasn't
#          directly observed. FAST_SKIP updated for the two new dry-run
#          rows. No content from the build_f5_datasets.py edit was
#          touched or re-verified here -- carried forward as-is.
# v1.14.25 — 2026-07-30  build_f5_datasets.py: added a real --version
#          floor test ('1.4', new -- this script had no --version flag
#          at all before v1.4.0, so only --dry-run could be exercised
#          here). Real, confirmed gap fixed the same day in that
#          script: --out-dir defaulted to './ipam-db' directly,
#          writing every run's output straight into the live
#          registered dataset directory without ever going through
#          ipam-db.py --import -- found live, orphaned v20260730 F5
#          dataset copies sitting unregistered next to the still-
#          current v20260701 files. See that script's own v1.3.0/
#          v1.4.0 changelog.
# v1.14.24 — 2026-07-30  build_fw_rule_db.py floor bumped '1.9.0' -> '1.10':
#          real bug fixed -- the ASA and FTD loops lacked the device-level
#          dedup the PA loop has had since v1.7.1 (Known Gap 3 in the
#          ccd-fw-pipeline skill). Confirmed real duplicate-parse impact
#          in a same-day production run: e.g. RRIWSDC-SEC-INT-VPN-01
#          parsed 4x across dated captures before the fix. Floor kept at
#          MAJOR.MINOR ('1.10') per this file's own convention -- a
#          future PATCH bump on build_fw_rule_db.py won't require another
#          check_toolset.py edit. See that script's own v1.10.0 changelog.
# v1.14.23 — 2026-07-30  build_vpn_registry.py floor bumped '1.12.0' ->
#          '1.13.0': real gap fixed -- the "all configs UNCHANGED"
#          short-circuit path never printed import instructions,
#          confirmed to have directly caused build_3p_report.py to read
#          a stale, pre-enrichment VPN dataset from ipam-db/ the same
#          day. See that script's own v1.13.0 changelog.
# v1.14.22 — 2026-07-30  build_3p_report.py floor bumped '1.3.0' ->
#          '1.4.0': real IPAM/GeoIP enrichment wired into build_vpn_
#          section() -- the third and last of this report's three
#          connection-type sections. Completed two pre-existing,
#          never-filled placeholder field groups (cvs_subnet_ipam,
#          peer_geo_country/peer_geo_cc/peer_asn/peer_asn_org). See
#          that script's own v1.4.0 changelog.
# v1.14.21 — 2026-07-30  build_vpn_registry.py floor bumped '1.11.0' ->
#          '1.12.0': real IPAM/EHM + GeoIP enrichment wired into
#          VPN-PROTECTED-SUBNETS via the shared ipam_enrichment.py
#          module, same pattern as the P2P-family scripts the same day.
#          See that script's own v1.12.0 changelog.
# v1.14.20 — 2026-07-30  build_3p_report.py floor bumped '1.2.0' ->
#          '1.3.0': real IPAM/GeoIP enrichment wired into the dashboard
#          (mpls_ftd, mpls_net4wir sections). Fixed a real, confirmed
#          hardcoded site/city_state bug in build_ftd_section() along
#          the way (every FTD circuit showed 'Scottsdale AZ' regardless
#          of real manager). See that script's own v1.3.0 changelog.
# v1.14.19 — 2026-07-30  Two floor bumps for enrichment coverage
#          reporting (found via direct question about where enrichment
#          data goes -- console showed index-loading success but never
#          per-row match results):
#          build_ftd_p2p_registry.py '0.7.0' -> '0.8.0'
#          build_p2p_link_registry.py '1.5.0' -> '1.6.0'
#          See each script's own new changelog entry.
# v1.14.18 — 2026-07-30  build_ftd_p2p_registry.py floor bumped '0.6.0'
#          -> '0.7.0': real IPAM/EHM + GeoIP enrichment wired in via the
#          shared ipam_enrichment.py module (cvs_app/cvs_location/
#          cvs_rd + geo_* columns on every P2P-FTD-PROTECTED-SUBNETS
#          row), same pattern as build_p2p_link_registry.py v1.5.0. See
#          that script's own v0.7.0 changelog.
# v1.14.17 — 2026-07-30  build_p2p_link_registry.py floor bumped '1.4.0'
#          -> '1.5.0': real IPAM/EHM + GeoIP enrichment wired in via the
#          new shared ipam_enrichment.py module (CVS_APP/CVS_LOCATION/
#          CVS_RD + GEO_* columns on every P2P-PROTECTED-SUBNETS row).
#          See that script's own v1.5.0 changelog and the
#          ccd-fw-pipeline skill's new "Shared IPAM/EHM/GeoIP
#          enrichment" section.
# v1.14.16 — 2026-07-30  build_p2p_link_registry.py floor bumped '1.3.0'
#          -> '1.4.0': same lexicographic-sort bug found the same day in
#          3 sibling scripts, confirmed here at the existing-registry
#          carry-forward auto-discovery call site. See that script's
#          own v1.4.0 changelog.
# v1.14.15 — 2026-07-30  build_p2p_policy_map.py floor bumped '1.0.9' ->
#          '1.1.0': same lexicographic-sort bug found the same day in
#          build_3p_report.py and build_vpn_registry.py, confirmed here
#          at 2 call sites (all_IP_networks, ent_host_master). Not
#          theoretical: ent_host_master_v20260427r13.csv is a real
#          tracked revision -- with r1..r13 present, the old code would
#          have picked r9, not r13. See that script's own v1.1.0
#          changelog.
# v1.14.14 — 2026-07-30  Two floor bumps:
#          build_ftd_p2p_registry.py '0.5.0' -> '0.6.0': real duplicate
#          manager confirmed (RRICMDC-SEC-INT-PRD-MGT / rricmdc-sec-int-
#          prd-mgt-01 / rrimdc-sec-int-prd-mgt-01 are the same real FMC
#          manager) and fixed with an explicit MANAGER_ALIASES table,
#          not a fuzzy heuristic. See that script's own v0.6.0 changelog.
#          build_vpn_registry.py '1.10.1' -> '1.11.0': same
#          lexicographic-sort bug found and fixed in build_3p_report.py
#          v1.2.0 the same day, confirmed present at all 4 existing-
#          registry auto-discovery call sites in this file. See that
#          script's own v1.11.0 changelog.
# v1.14.13 — 2026-07-30  build_3p_report.py floor bumped '1.1.0' ->
#          '1.2.0': real, confirmed bug fixed -- find_latest()'s plain
#          lexicographic sort silently picked a stale file once a
#          same-day revision suffix reached double digits ('r10' sorts
#          before 'r2' as a string). Demonstrated directly, not
#          theoretical, given r7 already exists in real production data.
#          See that script's own v1.2.0 changelog. Worth checking
#          whether build_vpn_registry.py has the identical bug -- that
#          script's docstring claimed the same auto-discovery pattern,
#          not yet independently verified.
# v1.14.12 — 2026-07-30  build_partner_ip_map.py floor bumped '1.0' ->
#          '1.1': real gap fixed, same class as build_ftd_p2p_registry.py
#          v0.5.0 the same day -- wrote proper #STEM= header metadata for
#          both its datasets but never printed the ipam-db.py --import
#          instructions. Also: this session confirmed build_p2p_link_
#          registry.py, build_p2p_policy_map.py, and build_partner_ip_
#          map.py were never added to the ccd-fw-pipeline skill's
#          documented tier structure at all -- fixed there (new Tier
#          4.5), not in this file.
# v1.14.11 — 2026-07-30  build_ftd_p2p_registry.py floor bumped '0.4.0'
#          -> '0.5.0': real gap fixed -- the script wrote proper #STEM=/
#          #VERSION=/#ROWS= header metadata for all 3 of its datasets but
#          never printed the ipam-db.py --import instructions to
#          actually register them, unlike every other build script in
#          this pipeline. See that script's own v0.5.0 changelog.
# v1.14.10 — 2026-07-30  build_fw_route_db.py floor bumped '0.10.0' ->
#          '0.11.0': real, confirmed misleading summary-output wording
#          fixed -- 'Skipped (no interface data): 206' followed by '(of
#          which had 0 routes...): 376' implied a subset relationship
#          that doesn't exist (376 > 206, a real contradiction caught
#          directly from an actual full-estate run). Data/counting logic
#          was already correct, only the print wording was wrong. See
#          that script's own v0.11.0 changelog.
# v1.14.9 — 2026-07-30  build_fw_route_db.py floor bumped '0.9.0' ->
#          '0.10.0': real duplicate-route bug found and fixed, confirmed
#          against real production data (mid-fmc-pci-1 cluster upload --
#          a device's raw config's static 'route' directive and its
#          *_ROUTES.csv export both reported the identical route, and
#          v0.9.0's merge never deduplicated). 82 real duplicate rows
#          found and removed on this one cluster alone. See that
#          script's own v0.10.0 changelog.
# v1.14.8 — 2026-07-30  build_IP_Network_Egress_FW_topology.py floor
#          bumped '1.12.0' -> '1.13.0': real production crash fixed
#          (KeyError: 'interfaces' -- v1.12.0's cache-structure rewrite
#          missed a second consumer, validate_route_via_db(), found via
#          an actual production run, not caught by this session's
#          earlier testing). See that script's own v1.13.0 changelog.
# v1.14.7 — 2026-07-30  setup_fw_configs.sh floor bumped '2.5' -> '2.6':
#          real gap fixed, confirmed against an actual production run --
#          *_ROUTES.csv files dropped into FW_CONF_UPDATES/ as zips were
#          being silently discarded (no handler matched that file
#          pattern). New handler routes them into FW_ROUTES/, matching
#          build_fw_route_db.py v0.9.0's --routes-dir default. See that
#          script's own v2.6.0 changelog for the full account.
# v1.14.6 — 2026-07-30  collect_ipam_db_files.sh floor bumped '1.4' ->
#          '1.5': real design fix, defaults flipped so the script bundles
#          ONLY all_IP_networks + location_master by default (the only
#          two IPAM datasets that aren't rebuildable from raw source
#          data), with fw-db/*.sqlite dropped from scope entirely
#          (collect_fw_bundle.sh --with-intel owns that bundle) and
#          ipdatasets/ now opt-in via --with-ipdatasets. See that
#          script's own v1.5.0 changelog for the full account.
# v1.14.5 — 2026-07-30  collect_fw_bundle.sh floor bumped '1.6' -> '1.7':
#          real design fix, defaults flipped so the script bundles ONLY
#          the query tools by default (the actual point of the script),
#          with raw estate/built intel now opt-in via --with-estate/
#          --with-intel/--with-all instead of opt-out. Also fixed a real
#          pre-existing bug found while making that change: CCD_GROUPS_DB/
#          CCD_OBJECTS_DB were never pre-initialized (unlike every sibling
#          path variable), causing an unbound-variable crash under
#          set -u whenever INCLUDE_INTEL is false -- previously only
#          reachable via the rare --no-intel flag, now the default path.
#          See that script's own v1.7.0 changelog for the full account.
# v1.14.4 — 2026-07-30  Real bug fixed, not a missing script: every
#          TESTS entry for the EDL bundle collector was typo'd
#          'collect-edl_bundle.sh' (hyphen after "collect") since the row
#          was first added 2026-07-24 -- the real file has always been
#          'collect_edl_bundle.sh' (all underscores), confirmed via `ls`
#          against the real uploaded file. This means the 2026-07-24 fix
#          that was supposed to close a real coverage gap silently
#          introduced the exact FAIL ("Script not found") it was meant
#          to prevent, for every run since. Fixed the name in both TESTS
#          entries and the matching FAST_SKIP entry (which had the same
#          stale hyphenated description string, so it was silently never
#          matching either). Floor was also stale as a direct
#          consequence -- '1.4' was correct when first set, but since
#          the test never actually ran against the real script,
#          ADVANCED-tracking never got the chance to notice the real
#          file has since moved to v2.1.0. Confirmed --version (0.01s,
#          immediate exit) and --dry-run (real isolated run: zero files
#          written) directly against the real file before shipping.
# v1.14.3 — 2026-07-30  build_IP_Network_Egress_FW_topology.py floor
#          bumped '1.11.0' -> '1.12.0': the real fix for the 240s
#          dry-run timeout, root-caused and fixed this session (see that
#          script's own v1.12.0 changelog -- O(interfaces+routes) linear
#          scan in query_route_db_knowledge(), called ~1,730 times,
#          fixed via /16-bucketing, 27.7x speedup confirmed on real
#          data). TIMEOUT_OVERRIDE left at 240s rather than lowered --
#          no real post-fix dry-run timing available yet to know the
#          genuinely new number.
# v1.14.2 — 2026-07-30  Added coverage for build_3p_report.py -- genuinely
#          new script, previously zero TESTS entries (confirmed via grep
#          before adding, not just an unbumped floor). Report-builder
#          only (reads already-built VPN/P2P registry CSVs, not raw
#          configs) -- no --dry-run flag exists on this script (confirmed
#          via argparse inspection), so only --version is covered here.
#          Confirmed real: 0.07-0.11s, exit 0, output
#          'build_3p_report.py 1.1.0' (no 'v' prefix -- confirmed
#          extract_version() handles this fine, unlike most scripts in
#          this toolset which do prefix with 'v'). Also confirmed
#          build_p2p_link_registry.py and build_vpn_registry.py floors
#          (1.3.0 / 1.10.1) already match the real files uploaded
#          alongside this one -- no change needed for either.
# v1.14.1 — 2026-07-30  Pure floor update: build_p2p_link_registry.py
#          floor bumped '1.2.0' -> '1.3.0', confirmed against the real
#          v1.3.0 file (unrelated to this session's PA-parsing work --
#          real, independent fixes to that script's own carry-forward
#          keying and noise-guard visibility, see its own changelog).
#          Also confirmed via diff: the build_fw_rule_db.py and
#          build_fw_route_db.py files uploaded alongside it are byte-
#          identical to what this session already shipped (v1.9.0/
#          v0.9.0) -- no floor change needed for either.
# v1.14.0 — 2026-07-30  Real, confirmed bug fixed: run_integrity_pass()'s
#          version-checking always ran `[sys.executable, script] + args`
#          -- unconditionally via Python, with NO check for script type.
#          For a .sh script this means literally running e.g.
#          `python3 collect_fw_bundle.sh --version`, asking Python to
#          parse bash source as Python -- confirmed this is the exact,
#          single root cause behind BOTH real shell-script WARNs seen in
#          the same actual health-check run: "collect_fw_bundle.sh ...
#          could not parse a version from output" (the --version TESTS
#          row existed and was correct; the subprocess invocation running
#          it was not) and "setup_fw_configs.sh ... no --version test
#          defined for this script" (compounded further -- that script
#          had no --version flag at all yet either, see its own v2.5.0).
#          run_test() already had correct, script-type-aware command
#          building (.py needs the interpreter + NEEDS_VENV_PYTHON check;
#          .sh needs a ./ prefix and no interpreter) -- run_integrity_
#          pass() just never used it, an independent, drifted copy of the
#          same concern. Extracted the shared build_cmd() helper (used by
#          both run_test() and run_integrity_pass() now) so this class of
#          bug has exactly one place to go wrong, not two.
#
#          Also added the missing setup_fw_configs.sh --version TESTS row
#          (floor '2.5', confirmed against the real v2.5.0 file which
#          added the --version flag this test needed to exist at all --
#          see that script's own changelog), and updated 10 stale ADVANCED
#          version floors directly from this run's own real detected
#          versions: ipam-db.py (v3.17.0→v3.18.0), build_vpn_registry.py
#          (v1.6.0→v1.10.1), build_fw_rule_db.py (v1.7.1→v1.9.0 --
#          confirmed one version ahead of what this run detected, v1.8.0,
#          since v1.9.0 was already complete and about to ship at the
#          time this fix was made), fwlookup.py (v1.13.0→v1.16.0),
#          build_fw_route_db.py (v0.5.1→v0.9.0 -- same reasoning as
#          build_fw_rule_db.py, this run detected v0.8.0 but v0.9.0 was
#          already complete), build_fw_group_db.py (v0.3.1→v0.5.0),
#          build_p2p_link_registry.py (v1.1.0→v1.2.0), build_p2p_policy_
#          map.py (v1.0.6→v1.0.9), build_IP_Network_Egress_FW_topology.py
#          (v1.3→v1.11.0), build_fw_interface_inventory.py
#          (v1.5.0→v1.7.0).
#
#          NOT fixed this pass, flagged instead: build_IP_Network_Egress_
#          FW_topology dry-run timed out at 240s in the same real run --
#          don't have that script to investigate. Worth checking whether
#          it's a genuine regression from this session's fw_route_db.py
#          device-identity changes (that script very plausibly consumes
#          fw_route_db.sqlite) before assuming it's unrelated pre-existing
#          flakiness. collect-edl_bundle.sh FAILs (script not found) are
#          also unchanged -- confirmed pre-existing per this file's own
#          earlier comments at that TESTS entry, not something introduced
#          here.
# v1.13.0 — 2026-07-29  Two real gaps closed, both found while testing
#          collect_fw_bundle.sh v1.6.0 and collect_ipam_db_files.sh
#          v1.4.0's new --max-zip-size/auto-split fix (real problem: both
#          scripts' zip output could be massive at production scale --
#          fw_rule_db.sqlite alone is documented at 1.4GB+ -- with no
#          size guard at all before this fix):
#          1. collect_fw_bundle.sh's version floor was '1.0', stale since
#             its very first TESTS entry (2026-07-24) -- real version is
#             now 1.6.0 (five real feature/fix versions since, per that
#             script's own changelog). Confirmed directly against the
#             real v1.6.0 file's --version output before bumping, not
#             assumed from its changelog header alone.
#          2. collect_ipam_db_files.sh had ZERO coverage here despite
#             being a real, actively-used platform script (confirmed via
#             `grep` -- no TESTS row referenced it at all before this).
#             This is the script now known to combine the entire
#             ipam-db/ AND ipdatasets/ registries into one --zip with no
#             size limit prior to v1.4.0 -- exactly the kind of script
#             this file's whole purpose is to keep verified working.
#             Added --version (floor '1.4', confirmed against the real
#             v1.4.0 file) and --dry-run (confirmed by reading the actual
#             DRY_RUN branch: exits at line 358, strictly before
#             mkdir/cp/zip -- genuinely skips every write, not just the
#             final one). Timed at 0.13s in this environment against a
#             9-file synthetic registry; --dry-run does no file-content
#             parsing (only `du -sh` per registered file), so real
#             production's ~50-60 registered files should stay well
#             under the 120s default even though this sandbox's fixture
#             is far smaller -- added to FAST_SKIP since it's cheap
#             either way, no TIMEOUT_OVERRIDE needed.
# v1.12.0 — 2026-07-27  build_p2p_protected_subnets.py's test entry
#          removed entirely (not just left with a matching floor, as
#          v1.11.0 did). Real finding: it writes to the exact same
#          output path as build_p2p_link_registry.py's own
#          subnet_records (ent-ipdataset-P2P-PROTECTED-SUBNETS-v*.csv) --
#          confirmed by reading both scripts directly, not assumed.
#          build_p2p_protected_subnets.py's own docstring claimed
#          build_p2p_link_registry.py's version was "counts only, no
#          CIDRs," but build_p2p_link_registry.py's subnet_records
#          genuinely has a CIDR field, contradicting that. Confirmed
#          discarded, not merely superseded -- build_p2p_link_registry.py
#          is the authoritative source for this dataset going forward.
#          Testing a discarded script's version serves no purpose and
#          risks a false "healthy" signal for something no longer meant
#          to run.
# v1.11.0 — 2026-07-27  build_vpn_registry.py's version floor finally
#          closed -- had no --version test at all since v1.9.0's own
#          changelog first flagged it; now verified 1.6.0 directly
#          against the real uploaded file. Also fixed two more stale
#          floors found the same way: build_p2p_link_registry.py
#          (1.0 -> 1.1.0), build_p2p_policy_map.py (1.0 -> 1.0.6).

# v1.10.0 — 2026-07-27  Nine stale version floors found and fixed, verified
#          against real, freshly-uploaded copies of each script rather than
#          memory: ipam-db.py (v3.16 -> v3.17.0 -- real, high-value fix,
#          since v3.17.0 fixed the exact orphaned-file/in-place-registration
#          incident that happened this same session; confirmed via a real
#          test that ipam-db.py v3.16.15, the actual version that appeared
#          during a real mid-session revert today, now correctly FAILS
#          against this floor, where the old v3.16 floor would have
#          silently passed it). fwlookup.py (v1.9 -> v1.13.0 -- real,
#          high-value fix, v1.9 predates auto-discovery, the object-
#          resolution security fix, --rule-consistency, and
#          --broad-src-public-dst, all built the same day). fw_route_db.py
#          (0.4 -> 0.4.1), build_fw_route_db.py (0.4 -> 0.5.1),
#          fw_group_lookup.py (0.2 -> 0.4.0), build_fw_group_db.py
#          (0.2 -> 0.3.1), build_fw_interface_inventory.py (1.2 -> 1.5.0),
#          build_ftd_p2p_registry.py (0.3 -> 0.4.0), build_fw_rule_db.py
#          (1.6 -> 1.7.1, NOT 1.7.2 -- the uploaded copy this session
#          verified against shows 1.7.1; 1.7.2 was fixed and shipped the
#          same day but its deployment isn't confirmed, so this floor
#          uses only what could be directly verified). Verified the
#          underlying version_tuple() comparison itself handles multi-
#          part versions correctly (1.13 > 1.9 as versions, not as
#          strings or floats, where naive comparison would get this
#          wrong) before trusting any of these bumps. build_vpn_registry.py
#          STILL has no --version test at all (only --help) -- not fixed
#          this pass, since the real current version wasn't available to
#          verify against; needs the actual file, not a guess.
# v1.9.2 — 2026-07-24  Fixed a stale build_fw_config_manifest.py floor:
#             it was still '2.4' despite the script having been at v2.5.0
#             since the DROPPED-reconciliation fix earlier this session --
#             missed updating it at the time. Now '2.6' to match the
#             script's new ORCHESTRATION SIGNAL feature (v2.6.0).
# v1.9.1 — 2026-07-24  Removed the two check_pci_designation_integrity.py
#             test entries -- confirmed the script does not exist on disk
#             (both tests failing with "Script not found:
#             check_pci_designation_integrity.py"), not a transient issue.
#             Was never in _EXPECTED, just these two TESTS entries. If the
#             script is recreated or relocated, re-add its version and
#             functional tests then.
# v1.9.0 — 2026-07-24  Three additions from the FW-toolset review session:
#             - collect-edl_bundle.sh: real, pre-existing gap -- the script
#               has supported --version since its own v1.4.0 (2026-07-23)
#               but was never added to this suite at all, not even to
#               _EXPECTED. Added --version (floor '1.4') and --dry-run
#               tests, both added to FAST_SKIP matching convention.
#             - collect_fw_bundle.sh: new script (v1.0.0, 2026-07-24) that
#               packages both the raw FW config/policy estate and the
#               built FW intelligence artifacts (fw_route_db, fw_rule_db,
#               fw_group_db, topology CSV/HTML, manifest, SNAT pools,
#               interface inventory, P2P registry) for distribution.
#               Added --version (floor '1.0') and --dry-run tests, dry-run
#               added to FAST_SKIP.
#             - build_fw_route_db.py floor bumped '0.3' -> '0.4' to match
#               the just-shipped v0.4.0 (fixed a same-day-rerun
#               sqlite3.IntegrityError crash from tables never being
#               cleared, and a silent duplicate-hostname drop that had zero
#               accounting in the printed summary -- both confirmed real
#               incidents on Yggdrasil, not theoretical).
#             Also fixed pre-existing drift in this file's own docstring
#             header (line 3 said v1.8.1, __version__ said v1.8.3) while
#             touching this file for the above -- both now read v1.9.0.
# v1.8.3 — 2026-07-24  New PCI_DESIGNATION integrity check, following the
#           2026-07-22/23 corruption incident (raw 'Yes'/'No' landing in
#           PCI_DESIGNATION across ent_host_master, delivery_infrastructure,
#           and delivery_platform -- 9,636 rows total, root-caused to three
#           preprocess_p1.py CMDB ingestion paths and fixed in v2.11.2,
#           cleaned up via remediate_pci_designation.py). The root cause is
#           fixed and the existing corruption was remediated, but nothing
#           was watching for a recurrence -- new check_pci_designation_
#           integrity.py spot-checks all three masters every run and this
#           file now tracks it (functional check + --version for integrity
#           tracking, same two-test pattern used for build_fw_rule_db.py in
#           v1.8.2). Read-only, always exits 0 (informational, same
#           convention as ipam-db.py --cross-check) -- the "TOTAL CORRUPT: 0"
#           substring match is what actually gates pass/fail here.
# v1.8.2 — 2026-07-22  Two real gaps closed from an actual run
#           (106/107 passed, 1 fail, 1 warn):
#             - enrich_zscaler_flows.py confirmed RETIRED by Michael
#               directly (not "not yet built" -- it existed, is gone, and
#               is not coming back). Moved from TESTS (where its absence
#               registered as a hard FAIL every run) to _EXPECTED, same
#               precedent already set for build_f5_vip_registry.py
#               ("replaced by build_f5_datasets.py" -- kept as a
#               documented warn-only record rather than deleted outright,
#               so the retirement stays visible instead of silently
#               disappearing from this file's history).
#             - build_fw_rule_db.py WARN'd every run since it started
#               being integrity-tracked ("content changed, no --version
#               test defined") -- confirmed directly: the script DOES
#               support --version (it went v1.6.6 -> v1.6.7 in a real
#               session), TESTS just only ever exercised --help for it,
#               and run_integrity_pass()/build_version_arg_map() only
#               track scripts with an exact ['--version'] test entry.
#               Added the missing --version test (floor '1.6', matching
#               the format already used for its siblings
#               build_fw_route_db.py/build_fw_group_db.py) alongside the
#               existing --help test rather than replacing it -- this
#               clears the WARN and lets real version bumps on this
#               script show as ADVANCED like every other tracked script.
# v1.8.1 — 2026-07-20  Fixed a real regression from a real full run:
#           build_IP_Network_Egress_FW_topology dry-run timed out at the
#           120s default on real production-scale data (my sandbox test
#           only had a handful of rows, ran in 1.29s -- not representative).
#           TIMEOUT_OVERRIDE extended to 240s. Also added headroom for
#           three others that ran slower on real data than in sandbox
#           testing but hadn't failed yet (build_fw_interface_inventory 60s,
#           build_fw_location_topology 42s, resolve_unknown_subnets 40s) --
#           proactive, not reactive, given they're trending the same
#           direction as the one that did fail.
# v1.8.0 — 2026-07-20  Batch addition: the remaining 17 of the 18 scripts
#           from collect_ccd_platform.py v1.1.0's follow-up list, verified
#           via the check-toolset-add-tool skill (build_p2p_link_registry.py
#           was already added in v1.7.1). Three real surprises found by
#           actually running everything instead of assuming a template:
#             - enrich_eir.py: --input/--ext-obj are required, and argparse
#               validates required args before this script's own manual
#               `if args.version:` check runs -- --version alone genuinely
#               fails (rc=2, usage error). No standalone-safe flag except
#               --help.
#             - classify_net_type.py: --dry-run correctly sys.exit(1)s on
#               a REAL, separate bug -- its VALID_NET_TYPES vocabulary is
#               stale and rejects RA-POOL-CSA/RA-CONN-ZPA/RA-SNAT-HCB,
#               added to the platform months before this script's list was
#               last touched. Not this suite's bug to route around; flagged
#               to Michael directly. --help used instead.
#             - build_object_pipeline.py: confirmed a 9-stage orchestrator
#               (calls build_network_groups.py, generate_csna_hostgroups.py,
#               and 6 more as subprocesses) -- --dry-run deliberately NOT
#               tested, both for propagation-verification cost and
#               cumulative runtime (generate_csna_hostgroups.py alone needs
#               300s). --version only.
#           10 new dry-run tests added to FAST_SKIP, matching convention.
#           No TIMEOUT_OVERRIDE needed -- slowest real timing was
#           resolve_unknown_subnets.py at 33.4s, well under the 120s default.
# v1.7.1 — 2026-07-20  First entry from the "20 scripts collect_ccd_platform.py
#           tracks but check_toolset.py doesn't yet" follow-up (see
#           collect_ccd_platform.py v1.1.0's changelog), verified via the
#           new check-toolset-add-tool skill: build_p2p_link_registry.py
#           (--version + --dry-run, both confirmed clean -- dry-run gates
#           both the file write and the dsr_register() call, no side
#           effects). 18 more to go; two of the original 20
#           (update_compute_substrate.py, find_unmatched_source_subnets.py)
#           are not yet added pending resolution of the cross-tool
#           inconsistency flagged in collect_ccd_platform.py v1.1.0 --
#           check_toolset.py's _EXPECTED says not-yet-built, that has NOT
#           been overridden without confirmation.
# v1.7.0 — 2026-07-20  Actually RAN the 3 dry-run tests added in v1.6.9
#           (not just --fast mode, which skips them) and found all three
#           needed real fixes -- exactly the discipline this whole session
#           has been about:
#             - generate_csna_hostgroups dry-run: times out at the default
#               120s (confirmed 136.9s on a direct timed run -- --dry-run
#               here skips only the final write, not the actual host-group
#               computation, so it's inherently slow on real data, not a
#               fluke). New TIMEOUT_OVERRIDE dict (same lookup-by-
#               description pattern as FAST_SKIP) added; this test gets 300s.
#             - generate_csna_map_v2 dry-run: fails in THIS sandbox only
#               (no csna_output/*.csv test fixture here) -- expected to
#               work on real data, left as-is.
#             - generate_fw_rule_report dry-run: wrong flag entirely --
#               --dry-run requires --log unless --check or --splunk is
#               passed, so bare --dry-run was never a complete invocation.
#               Switched to --check, the actual safe file-existence-check
#               mode. That in turn surfaced a REAL bug in the target
#               script: check_files() referenced an undefined INFO marker,
#               crashing with NameError whenever an optional file (e.g.
#               vpn_partners) was legitimately absent. Fixed in
#               generate_fw_rule_report.py itself (now v2.0.1) by adding
#               the missing INFO constant. --check confirmed fast (0.17s),
#               removed from FAST_SKIP.
# v1.6.9 — 2026-07-20  The remaining 5 generate_*.py scripts confirmed
#           active/used (not legacy, per Michael) and ADDED, each matched
#           to its real verified flag support rather than a uniform
#           template: generate_csna_map_v2.py (--dry-run only, no
#           --version flag exists), generate_fw_rule_report.py (both,
#           confirmed clean), generate_ipam_hierarchy_report.py (--version
#           only, no --dry-run exists), generate_ipam_map.py and
#           generate_partner_map.py (--help only -- neither has --version
#           or --dry-run, and partner_map's default --output is a real
#           HTML file, so --help is the only safe invocation).
# v1.6.8 — 2026-07-20  Two real gaps ADDED, cross-validated against
#           collect_ccd_platform.py's own SCRIPTS manifest (same floor
#           versions independently confirmed there): hostname_translate.py
#           (v1.0 -- self-reports as "htrans.py" in --version output, a
#           harmless cosmetic mismatch noted inline) and
#           generate_csna_hostgroups.py (v4.0.3 -- Stage 6 of the canonical
#           pipeline, required after FOUR different master-dataset imports
#           per ipam-db.py's own _print_next_steps(), had zero coverage
#           until now). Five other scripts absent from BOTH this file and
#           collect_ccd_platform.py's manifest (generate_csna_map_v2.py,
#           generate_fw_rule_report.py, generate_ipam_hierarchy_report.py,
#           generate_ipam_map.py, generate_partner_map.py) were
#           deliberately NOT added -- two independent tools missing the
#           same 5 scripts points toward "possibly legacy, needs
#           confirmation" rather than "confirmed active gap," same
#           situation as the v1.6.2 build_all_ip_networks.py /
#           build_retail_site_codes.py retirements.
# v1.6.7 — 2026-07-20  Merged two divergent branches of this file back
#           together (v1.6.2, developed in parallel, had never seen the
#           v1.6.3-v1.6.6 work and vice versa). From v1.6.2: ip_dataset.py,
#           geo_ip.py, update_fw_reference_data.py, iplookup.sh test
#           entries; the full FW_Rule_Request_Tool block (ccd_api.py,
#           query_ccd.py, validate_ip.py, build_ccd_object_db.py,
#           build_ccd_group_db.py, Flask import test); resolve_venv_python()
#           and the NEEDS_VENV_PYTHON override in run_test() (ccd_api.py is
#           the one script here with a non-stdlib dependency). Merged the
#           venv-detection override into run_test() alongside the existing
#           v1.6.1 missing-script os.path.isfile() check rather than
#           replacing it -- both are real, independent fixes and needed to
#           coexist in the same dispatch logic. Confirmed no duplicate
#           entries existed in either branch before merging (grepped v1.6.6
#           for every v1.6.2-only script name -- zero matches). All new/
#           merged entries re-run and confirmed passing after the merge.
# v1.6.6 — 2026-07-20  Test REMOVED: update_asi.py (confirmed EOL/legacy —
#           app_subnet_index is actually kept current via full rebuild,
#           build_app_subnet_index.py -> ipam-db.py --import directly;
#           the current registry entry's imported_by is a bare ipam-db.py
#           version string, not update_asi.py's own signature, confirming
#           the delta-update path was never really the one in use).
#           fw_rule_extraction_translation.py -- also confirmed EOL, but
#           was never added to this suite in the first place, so no test
#           to remove there. Same precedent as the v1.6.2 removals
#           (build_all_ip_networks.py, build_retail_site_codes.py):
#           retired scripts get their test pulled entirely, not left as a
#           permanent expected failure.
# v1.6.5 — 2026-07-20  Two more real, pre-existing gaps ADDED:
#           build_fw_config_manifest.py v2.4.0 (--version + --dry-run, both
#             confirmed clean) and generate_fw_config_requests.py v1.2.0
#             (--version + --show-age-histogram -- this script has NO
#             --dry-run flag; a bare run always writes a real
#             FW_config_requests_<date>.csv, so its own documented
#             read-only mode is used instead).
# v1.6.4 — 2026-07-20  build_ext_canonical_objects.py upgraded from a
#           --help-only test to real --version + --dry-run tests (confirmed
#           it supports both: --version prints and sys.exit(0)s cleanly, no
#           fallthrough to the real build; --dry-run genuinely skips all
#           file writes per write_output()). Closes the same "help-only,
#           falls back to a generic WARN on checksum drift" gap flagged for
#           the other --help-only build scripts.
# v1.6.3 — 2026-07-20  Two real, pre-existing gaps in this suite ADDED:
#           build_geo_block_objects.py v1.0.2 (geo-block EDL/PA object
#             generation) and build_ipdataset_objects.py v1.1.1 (provider
#             IP-dataset EDL generation, called by build_object_pipeline.py
#             Stage 2.5) — both active, both already support --version and
#             --dry-run, simply never had TESTS rows. Same category as the
#             build_ftd_p2p_registry.py gap found 2026-07-17.
# v1.6.2 — 2026-07-20  Two tests REMOVED (scripts retired, confirmed via
#           `find` against real Yggdrasil disk):
#           build_all_ip_networks.py — archived in Z_Old_tools/ and
#             IP_Datasets_Raw/4-15-updates_ip_lookup/CCD_Maps_Pipeline/.
#           build_retail_site_codes.py — not found even in archives; fully
#             removed or renamed. Worth a follow-up if its functionality
#             is still needed under a new name.
#           These are the same two scripts the v1.6.1 os.path.isfile() fix
#           correctly started failing instead of false-passing — this
#           removes them from TESTS entirely rather than leaving them as
#           permanent expected failures.
# v1.6.1 — 2026-07-20  Fixed a pre-existing false-PASS bug (not introduced by
#           v1.6.0, but surfaced by it): run_test() trusted "any output" as
#           success for --help tests, but a genuinely missing script still
#           produces output — python3's own "can't open file" stderr message
#           — so a missing script could report PASS. Several --help tests
#           also use the script's own name as the expected substring, which
#           the interpreter's error text echoes too, so those weren't safe
#           either. Fixed by checking os.path.isfile() before running, same
#           as the v1.6.0 integrity pass already did (which is how this was
#           caught: it correctly excluded two missing scripts from tracking
#           while the old --help tests still showed them as PASS). Michael:
#           worth confirming whether build_all_ip_networks.py and
#           build_retail_site_codes.py actually exist in IP_Lookup/ — the
#           2026-07-20 run suggests they may not.
# v1.6.0 — 2026-07-20  Version/checksum drift tracking added:
#           - run_test() version checks switched from exact-substring match
#             to numeric floor comparison (actual >= literal in TESTS), so
#             legitimate version advances no longer need this file edited.
#           - New local registry (check_toolset_registry.json) + history log
#             (check_toolset_version_history.log) track a SHA256 checksum and
#             last-known version per script across runs; flags content changes
#             that weren't accompanied by a version bump, and version
#             regressions, going forward.
#           - New flags: --no-track, --reset-registry, --registry PATH.
#           - Four known-stale literal floors corrected from live 2026-07-20
#             run: ipam-db.py v3.15->v3.16, build_canonical_app_objects.py
#             v1.8->v1.9, build_user_access_objects.py v1.0->v1.8,
#             fwlookup.py v1.5->v1.9. fw_group_lookup.py's v0.2 floor left
#             as-is — the script is genuinely still v0.1.0 (real, separate,
#             already-flagged gap; not a stale test).
# v1.5.5 — 2026-07-02  setup_fw_configs.sh: --version → --help.
# v1.5.4 — 2026-07-02  run_test(): shell scripts (.sh) now invoked with ./
#           prefix so macOS zsh finds them in cwd without PATH entry.
#           setup_fw_configs.sh restored to TESTS from _EXPECTED.
# v1.5.3 — 2026-07-02  setup_fw_configs.sh moved to _EXPECTED — not in cwd.
# v1.5.2 — 2026-07-02  Version corrections from live Yggdrasil run:
#           ipam-db.py v3.15.14 → v3.15 prefix.
#           build_external_ip_registry.py v1. → v2. (script at v2.0.0).
#           build_fw_snat_pools.py v1. → v2. (script at v2.0.2).
#           build_hr_location_index.py help → version check v2.
#           setup_fw_configs.sh added with expected v2.
#           update_compute_substrate.py, build_f5_vip_registry.py moved
#           to _EXPECTED (not on disk). build_fw_rule_db.py, fwlookup.py,
#           build_zpa_connector_registry.py ADDED. FAST_SKIP updated.
# v1.4.0 — 2026-06-16  update_compute_substrate.py v1.0.0 ADDED (new pipeline
#           stage between update_app and update_asi; derives COMPUTE_SUBSTRATE
#           from EHM + IPAM, writes compute_substrate_vDATE.csv to ipam-db/).
#           update_app.py expected v1.9 → v1.10 (--vmware-enrich flag added).
#           ipam-db.py expected v3.15.12 → v3.15.14 (COMPUTE-SUBSTRATE added
#           to ENT_DESCRIPTORS and _DIFF_CONFIG).
# v1.3.1 — ipam-db.py version corrected to v3.15.12.
# v1.3.0 — Version updates for June 2026 session (continued):
#           build_canonical_app_objects.py expected v1.8 → v1.8 (prefix match OK,
#             but docstring header fixed from v1.0.0 to v1.8.3)
#           build_cpc_service_catalog.py expected v1.2 (covers v1.2.1 — OK)
#           check_toolset.py docstring header corrected from v1.0.0 to v1.3.0
# v1.2.0 — Version updates for June 2026 session:
#           update_app.py expected v1.8 → v1.9 (APP_NAMES fallback pass)
#           build_canonical_app_objects.py expected v1.5 → v1.8 (standalone rebuild)
#           preprocess_p1.py expected '1.' → '2.' (now v2.x series)
#           build_cpc_core_services.py test REMOVED (script retired)
#           build_cpc_service_catalog.py v1.2.0 ADDED (replacement)
#           build_user_access_objects.py v1.0.0 ADDED (new this session)
# v1.1.0 — Updated two stale TESTS version strings:
#           ipam-db.py expected 'v3.13' → 'v3.15' (current v3.15.8)
#           update_app.py expected 'v1.7' → 'v1.8' (current v1.8)
#           All other entries use prefix matching and were unaffected.

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime

# ── ANSI ──────────────────────────────────────────────────────────────────────
GRN = '\033[0;32m'; RED = '\033[0;31m'; YEL = '\033[0;33m'
BLD = '\033[1m';    RST = '\033[0m';    CYN = '\033[0;36m'

# ── Version/checksum registry (v1.6.0+) ────────────────────────────────────────
DEFAULT_REGISTRY = 'check_toolset_registry.json'
DEFAULT_HISTORY  = 'check_toolset_version_history.log'

# Matches a fully-specified version literal like 'v1.8', '0.2', 'v3.16.2'.
# Deliberately does NOT match wildcard/prefix-style literals like 'v2.' or
# '1.' (trailing dot, no digit after) — those keep the old substring
# behavior, since they're intentional "any 2.x" sentinels, not real floors.
_VERSION_LITERAL_RE = re.compile(r'^v?\d+(\.\d+){0,2}$')
_VERSION_EXTRACT_RE = re.compile(r'v?(\d+\.\d+(?:\.\d+)?)')


def is_version_like(s):
    return bool(s) and bool(_VERSION_LITERAL_RE.match(s))


def extract_version(text):
    """Pull the first version-looking token out of a script's --version output."""
    m = _VERSION_EXTRACT_RE.search(text or '')
    return m.group(1) if m else None


def version_tuple(s):
    """'1.9.2' -> (1, 9, 2). Missing components pad with 0 so '1.9' == '1.9.0'."""
    if not s:
        return (0, 0, 0)
    parts = s.lstrip('vV').split('.')
    nums = []
    for p in parts[:3]:
        try:
            nums.append(int(p))
        except ValueError:
            nums.append(0)
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums)


def sha256_of_file(path):
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def load_registry(path):
    if not os.path.isfile(path):
        return {'schema_version': 1, 'scripts': {}}
    try:
        with open(path) as f:
            data = json.load(f)
            data.setdefault('scripts', {})
            return data
    except (json.JSONDecodeError, OSError):
        return {'schema_version': 1, 'scripts': {}}


def save_registry(path, data):
    data['schema_version'] = data.get('schema_version', 1)
    data['last_run'] = datetime.now().isoformat(timespec='seconds')
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def append_history(path, line):
    try:
        with open(path, 'a') as f:
            f.write(f'{datetime.now().isoformat(timespec="seconds")}  {line}\n')
    except OSError:
        pass  # history log is best-effort; never block a run over it

# ── Test definitions ──────────────────────────────────────────────────────────
# Each entry: (group, script, args, expected_in_stdout, description)
# expected_in_stdout: substring that must appear in stdout for PASS (or None)

def resolve_venv_python():
    """Mirrors start_ccd_api.sh's own venv-detection logic exactly: use
    ./venv/bin/python3 if a venv directory exists in the current working
    directory, else fall back to whatever interpreter is running
    check_toolset.py itself. Relative to cwd, matching how every other
    test in this file already invokes scripts (this tool is always run
    from IP_Lookup/, same as start_ccd_api.sh assumes). Needed because
    ccd_api.py is the one script in this whole toolset with an external
    pip dependency (Flask) -- every other test here is pure-stdlib, so
    this gap never mattered until now. Defined here, before TESTS,
    because TESTS is evaluated at import time and calls this immediately.
    """
    venv_python = os.path.join('venv', 'bin', 'python3')
    if os.path.isfile(venv_python):
        return venv_python
    return sys.executable


TESTS = [
    # ── Platform ──────────────────────────────────────────────────────────────
    ('platform', 'ipam-db.py',
     ['--version'],
     'v3.32', 'Registry version check'),

    ('platform', 'ipam-db.py',
     ['--list'],
     'files present', 'Registry --list'),

    # v1.15.0-equivalent: new coverage for the four IP-classification
    # extract stems added in ipam-db.py v3.23.0 (public_ipv4_ipam,
    # private_ipv4_ipam, partner_provider_ipv4_ipam,
    # ip_classification_needs_review), auto-rebuilt from all_IP_networks x
    # ip_classification_ref. Checks the stem shows up in --list's "Other
    # Registered Datasets" section (IPAM_STEMS-driven, generic fallback --
    # see do_list()'s known_keys logic), not that any data was rebuilt --
    # a real rebuild needs both source stems registered first, which this
    # fast integrity pass doesn't set up. NOT execution-tested against a
    # live ipam-db/ in this session -- verify manually against a registry
    # that already has all_IP_networks + ip_classification_ref imported.
    ('platform', 'ipam-db.py',
     ['--list'],
     'public_ipv4_ipam', 'Registry --list shows IP classification extracts'),

    ('platform', 'ipam-db.py',
     ['--cross-check'],
     'HIGH:   0', 'Cross-check 0 violations'),

    ('platform', 'ipam-db.py',
     ['--backup', '--dry-run'],
     'DRY RUN', 'Backup dry-run'),

    ('platform', 'ipam-db.py',
     ['--checksum-init', '--dry-run'],
     'DRY RUN', 'Checksum-init dry-run'),

    # ── Shared library ────────────────────────────────────────────────────────
    ('shared', None,
     ['-c', "import ccd_host_enrichment as e; "
            "print('ccd_host_enrichment v' + e.__version__ + ' OK')"],
     'OK', 'Shared enrichment library import'),

    # ip_dataset.py / geo_ip.py -- foundational modules many other scripts
    # import from (update_fw_reference_data.py's GeoIP cache step calls
    # geo_ip.GeoIPLookup directly, for one real example). Registered in
    # collect_ccd_platform.py already; were never actually run here.
    ('shared', 'ip_dataset.py',
     ['--version'],
     '1.25', 'ip_dataset version'),

    ('shared', 'geo_ip.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '1.2' -> '1.3'. Added
     # GeoIPLookup.rdap_lookup() -- RDAP/structured-WHOIS: issuing
     # Internet Registry, registrant org, network block, abuse contact.
     # Ported byte-for-byte from fwlookup.py's own real, working
     # rdap_lookup(), verified against realistic synthetic RDAP JSON
     # (org name, abuse contact, CIDR, dates all parse correctly) --
     # moved here so every consumer of geo_ip.py shares one real
     # implementation instead of each needing its own copy.
     '1.3', 'geo_ip version'),

    # hostname_translate.py -- real gap found 2026-07-20, cross-validated
    # against collect_ccd_platform.py's own SCRIPTS manifest (floor 'v1.'
    # there too). Self-reports as "htrans.py" in --version output, not its
    # actual filename -- harmless for this floor check (only the number is
    # extracted), but a real cosmetic mismatch worth knowing about.
    ('shared', 'hostname_translate.py',
     ['--version'],
     '1.0', 'hostname_translate version'),

    # ── Update scripts ────────────────────────────────────────────────────────
    ('update', 'update_app.py',
     ['--version'],
     'v1.10', 'update_app version'),

    ('update', 'update_app.py',
     ['--enrich-only', '--dry-run'],
     'DRY-RUN', 'update_app dry-run'),

    ('update', 'update_infrastructure.py',
     ['--version'],
     'v1.2', 'update_infrastructure version'),

    ('update', 'update_infrastructure.py',
     ['--enrich-only', '--dry-run'],
     'DRY-RUN', 'update_infrastructure dry-run'),

    ('update', 'update_platform.py',
     ['--version'],
     'v1.2', 'update_platform version'),

    ('update', 'update_platform.py',
     ['--enrich-only', '--dry-run'],
     'DRY-RUN', 'update_platform dry-run'),

    # v1.14 (2026-07-30): upgraded from --help-only. Read update_ipam.py's
    # actual source this session (not inferred from docstring) while
    # scoping ingest_pipeline_2.py: confirmed -V/--version is a real
    # argparse action='version' exiting before any file I/O (ran clean,
    # 'update_ipam.py v1.14', rc=0), and --dry-run's write-skip is a clean
    # `if not args.dry_run: write_ccd_csv(...)` gate with no side effects
    # before it. Could not observe a clean 0-exit --dry-run run in this
    # session -- no real all_IP_networks present -- it correctly
    # [ERROR]s and exits 1 on a missing IPAM file, which is the expected
    # "no test fixture here" case per the check-toolset-add-tool skill,
    # not a script bug. Should pass cleanly in the real IP_Lookup
    # environment where all_IP_networks actually exists; worth a real
    # confirmed run to verify rather than taking this comment's word for it.
    ('update', 'update_ipam.py',
     ['--version'],
     'v1.14', 'update_ipam version'),

    ('update', 'update_ipam.py',
     ['--dry-run'],
     '', 'update_ipam dry-run'),

    ('update', 'update_network.py',
     ['--help'],
     'update_network', 'update_network help'),

    ('update', 'update_location.py',
     ['--help'],
     'update_location', 'update_location help'),

    ('update', 'update_fw_reference_data.py',
     ['--version'],
     '1.4', 'update_fw_reference_data version'),

    # apply_ehm_enrichment.py -- REMOVED 2026-08-15, confirmed genuinely
    # gone (not deployed elsewhere, not renamed -- Michael confirmed no
    # copy exists). Real script (Qualys/VAE enrichment patch merger into
    # EHM), was passing as recently as a prior session, lost at some
    # point (workstation refresh suspected, never confirmed). Pulled
    # entirely rather than left as a permanent expected failure or moved
    # to _EXPECTED -- _EXPECTED is for deliberately-retired tools, and
    # this one needs to be rebuilt from scratch, not just re-copied, so
    # neither status is accurate. Re-add a real test here once it exists
    # again.

    # ── Build scripts ─────────────────────────────────────────────────────────
    ('build', 'build_canonical_app_objects.py',
     ['--version'],
     'v1.9', 'build_canonical_app_objects version'),

    ('build', 'build_cpc_service_catalog.py',
     ['--version'],
     'v1.2', 'build_cpc_service_catalog version'),

    ('build', 'build_user_access_objects.py',
     ['--version'],
     'v1.8', 'build_user_access_objects version'),

    ('build', 'build_external_ip_registry.py',
     ['--version'],
     # v1.15.5 -- 2026-08-21: floor tightened 'v2.' -> 'v3.0'. Script
     # advanced to v3.0.0 (EIP-side enrichment asymmetry fix) and the
     # floor was sitting at just 'v2.' -- meaninglessly broad, wouldn't
     # catch a real regression back to any v2.x.
     'v3.0', 'build_external_ip_registry version'),

    ('build', 'build_app_subnet_index.py',
     ['--help'],
     'subnet', 'build_app_subnet_index help'),

    ('build', 'build_fw_snat_pools.py',
     ['--version'],
     'v2.6', 'build_fw_snat_pools version'),

    ('build', 'build_location_master.py',
     ['--help'],
     '', 'build_location_master help'),

    ('build', 'build_network_device_master.py',
     ['--help'],
     '', 'build_network_device_master help'),

    ('build', 'build_hr_location_index.py',
     ['--version'],
     'v2.', 'build_hr_location_index version'),

    ('build', 'build_csna_site_registry.py',
     ['--help'],
     '', 'build_csna_site_registry help'),

    ('build', 'build_vpn_registry.py',
     ['--help'],
     '', 'build_vpn_registry help'),

    ('build', 'build_vpn_registry.py',
     ['--version'],
     # Real gap closed 2026-07-27: this script had no --version test at
     # all, only --help, ever since v1.9.0's own changelog first flagged
     # it. Verified 1.6.0 directly against the real uploaded file, not
     # assumed from memory.
     '1.13.0', 'build_vpn_registry version'),

    ('build', 'build_placeholder_networks.py',
     ['--help'],
     '', 'build_placeholder_networks help'),

    ('build', 'build_ext_canonical_objects.py',
     ['--version'],
     '1.3', 'build_ext_canonical_objects version'),

    ('build', 'build_ext_canonical_objects.py',
     ['--dry-run'],
     '', 'build_ext_canonical_objects dry-run'),

    ('build', 'build_ip_allocation_model.py',
     ['--help'],
     '', 'build_ip_allocation_model help'),

    ('build', 'build_geoip_db.py',
     ['--help'],
     '', 'build_geoip_db help'),

    ('build', 'build_fw_rule_db.py',
     ['--help'],
     '', 'build_fw_rule_db help'),

    ('build', 'build_fw_rule_db.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '1.15' -> '1.19.3'. Real,
     # confirmed session covering: v1.19.2 (fw_name_from_filename() no
     # longer collapsed genuinely distinct devices sharing a first-
     # underscore prefix -- confirmed real case: PAZSHDC-SEC-EXT-
     # MPLSWEST-02-TCS_Noida.config vs ...-TCS.config, two separately-
     # confirmed real partner circuits) and v1.19.3 (parse_pa_cli()'s
     # flat-policy fallback matched ANY command containing the substring
     # 'show running security-policy', not just that exact command --
     # 'show running security-policy-addresses' also matched and got
     # double-parsed against the same device, guaranteed key collision
     # on the second pass; confirmed via the real production config file
     # that produced the collision, not just code review -- root-caused
     # to two live command captures in one show-tech bundle, fixed by
     # exact-match instead of substring-match).
     # v1.15.8 -- 2026-08-22: floor bumped '1.19.3' -> '1.20.0'. Added
     # ip_context CSV export to ipam-db/ at end of every real build.
     '1.20.0', 'build_fw_rule_db version'),

    # build_fw_ip_catalog.py -- new 2026-07-30, previously ZERO coverage
    # here (confirmed via grep before adding this, same discipline noted
    # for collect_ipam_db_files.sh below). Flat, per-(IP,rule,direction)
    # cross-reference joining fw_rule_db.sqlite against fw_group_db.sqlite
    # -- answers "which firewall/rule is this IP actually in" directly,
    # something neither source database answers alone. v1.9.0 added
    # FW_SEGMENT/FW_ROLE (fw_config_manifest.py) wiring plus a third
    # object-resolution fallback tier (the manifest's own FW_NAME->
    # HOSTNAME lookup, for multi-context ASA devices whose real hostname
    # bears no textual relationship to the filename-derived identity --
    # confirmed real, no regex could bridge this, the manifest already
    # has the answer as data).
    ('build', 'build_fw_ip_catalog.py',
     ['--help'],
     '', 'build_fw_ip_catalog help'),

    ('build', 'build_fw_ip_catalog.py',
     ['--version'],
     '1.9', 'build_fw_ip_catalog version'),

    # build_master_object_catalog.py -- new 2026-08-01. Scans
    # fw_group_db.sqlite for exact-duplicate address-group content across
    # differently-named groups -- the foundation for object-set
    # reduction: can't consolidate redundant objects without first
    # knowing which ones are genuinely redundant. v1.2.0 separates real
    # (human-named) duplication from FMC_INLINE_{src,dst}_rule_<id> auto-
    # generated per-rule noise (confirmed real: 11,761 of 25,224 total
    # clusters on a live run), and further separates SAME_NAME_MULTI_
    # DEVICE (one real name legitimately repeated across devices --
    # nothing to rename) from genuine multi-name drift.
    ('build', 'build_master_object_catalog.py',
     ['--help'],
     '', 'build_master_object_catalog help'),

    ('build', 'build_master_object_catalog.py',
     ['--version'],
     '1.2', 'build_master_object_catalog version'),

    # analyze_object_naming_patterns.py -- new 2026-08-01. Root-cause
    # tagging for build_master_object_catalog.py's clusters -- RETAIL_
    # TEMPLATE, MIGRATION_SUFFIX, NUMBERED_REPLICA, SEPARATOR_VARIANT,
    # TYPO_VARIANT, PBM_TICKET, TUFIN_TICKET, all confirmed real
    # patterns from actual fleet data, not invented categories. v1.1.0
    # fixed a real 'field larger than field limit (131072)' crash --
    # Python's csv module caps field size well below what a real 245+
    # member cluster's joined name list needs.
    ('build', 'analyze_object_naming_patterns.py',
     ['--help'],
     '', 'analyze_object_naming_patterns help'),

    ('build', 'analyze_object_naming_patterns.py',
     ['--version'],
     '1.3', 'analyze_object_naming_patterns version'),

    # build_canonical_object_map.py -- new 2026-08-01. Proposes one
    # canonical name per real duplicate cluster plus a full (device,
    # legacy_name) -> canonical_name mapping -- the actual master-
    # object-set backbone. PROPOSES ONLY -- never renames, consolidates,
    # or modifies any real object or firewall; output is a review
    # artifact. v1.1.0/v1.2.0/v1.3.0 all real fixes found reviewing
    # actual output from a live run: canonical selection was picking
    # typos ('VodelEast' over 'VordelEast') and cryptic codes over
    # clearly better names (length removed as a scoring factor, replaced
    # with cryptic-code detection and a device-frequency tiebreak);
    # confidence tiering was first over-promoted then over-corrected
    # (TYPO_VARIANT's redundant co-firing alongside a genuine high-
    # confidence tag was demoting ~80 real clusters that shouldn't have
    # been); large mixed clusters get an honest LARGE_CLUSTER_CAVEAT
    # flag rather than a guessed, unvalidated size-based confidence
    # downgrade.
    ('build', 'build_canonical_object_map.py',
     ['--help'],
     '', 'build_canonical_object_map help'),

    ('build', 'build_canonical_object_map.py',
     ['--version'],
     '1.3', 'build_canonical_object_map version'),

    # build_master_object_set.py -- NEW 2026-08-16, Stage 5 of the master
    # object consolidation initiative (see ROADMAP_object_creation.md).
    # Built this same session -- materializes Stage 3's canonical_object_
    # map.py proposal into a real, queryable dataset (master_object_set +
    # master_object_crosswalk), scoped to CONFIDENCE=HIGH clusters only.
    # Real bug found and fixed on its very first live run: Python's
    # default csv.field_size_limit (131072 bytes) was too small for real
    # catalog rows with 100+ member groups -- fixed in v1.0.1 with the
    # same csv.field_size_limit() call already established in build_fw_
    # rule_db.py for the identical reason.
    ('build', 'build_master_object_set.py',
     ['--help'],
     '', 'build_master_object_set help'),

    ('build', 'build_master_object_set.py',
     ['--version'],
     '1.0.1', 'build_master_object_set version'),

    # build_fmc_zone_map.py -- new 2026-08-01. Ingests real FMC REST API
    # security-zone-by-device pulls (GET /object/securityzones/<id>
    # ?expanded=true) into a flat (FMC, zone, device, interface) map --
    # closes part of the real FMC gap confirmed earlier this session
    # (FMC rules have no real device identity and no zone-to-interface
    # mapping at all). Tested directly against 2 real uploaded API pulls,
    # not synthetic data -- correctly distinguishes the by-device shape
    # (real device attribution) from the flat all-zones shape (no device
    # attribution, explicitly flagged and skipped rather than silently
    # mishandled). Full multi-FMC ingestion not yet run as of this
    # floor's introduction.
    ('build', 'build_fmc_zone_map.py',
     ['--help'],
     '', 'build_fmc_zone_map help'),

    ('build', 'build_fmc_zone_map.py',
     ['--version'],
     '1.0', 'build_fmc_zone_map version'),

    ('build', 'build_zpa_connector_registry.py',
     ['--version'],
     'v1.0', 'build_zpa_connector_registry version'),

    ('build', 'build_zpa_connector_registry.py',
     ['--dry-run'],
     'Dry run', 'build_zpa_connector_registry dry-run'),

    # build_geo_block_objects.py / build_ipdataset_objects.py -- real,
    # pre-existing gaps in this suite (script exists, is active, has both
    # --version and --dry-run, was simply never added). Found 2026-07-20
    # while reviewing uploaded files, same category as the
    # build_ftd_p2p_registry.py gap found 2026-07-17.
    ('build', 'build_geo_block_objects.py',
     ['--version'],
     'v1.0', 'build_geo_block_objects version'),

    ('build', 'build_geo_block_objects.py',
     ['--dry-run'],
     '', 'build_geo_block_objects dry-run'),

    # build_ipdataset_objects.py -- REMOVED 2026-08-15, confirmed
    # genuinely gone (Michael confirmed no copy exists). Was real and
    # active as recently as a prior session (had both --version and
    # --dry-run). Pulled entirely rather than left failing every run --
    # same reasoning as apply_ehm_enrichment.py's removal above. Re-add
    # once it exists again.

    # ── FW lookup tools ───────────────────────────────────────────────────────
    ('build', 'fwlookup.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped 'v1.16.0' -> 'v1.19.0'.
     # Removed the private rdap_lookup() (132 lines) that had been the
     # only real implementation of RDAP in the whole toolset -- moved to
     # geo_ip.py's GeoIPLookup.rdap_lookup() so every consumer shares one
     # copy. Both call sites (--profile section (4)b, --dns quick RDAP
     # summary) now go through _geo.rdap_lookup(ip), with graceful
     # degradation (clear error string, not AttributeError) if geo_ip.py
     # is missing or older than v1.3.0. Also fixed a stale docstring
     # header (was v1.17.1 while __version__ correctly said v1.18.0).
     # v1.15.5 -- 2026-08-21: floor bumped 'v1.19.0' -> 'v1.20.0'.
     # Real evidence-based show_ip_profile() is_pub fix -- same
     # category-2-vs-3 blind spot fixed across the whole toolset
     # this session.
     'v1.20.0', 'fwlookup version'),

    # FW routing/group-lookup/topology databases -- added 2026-07-17.
    # build_ftd_p2p_registry.py was a real, pre-existing gap in this suite,
    # found while adding the rest -- independent of anything new.
    # v1.14.29 -- 2026-08-03: floor bumped '0.8.0' -> '0.12.0'. v0.11.0
    # fixed a real gap: deduplicate_manager_records() only ever decided
    # which duplicate ROWS to drop, never rewrote the manager field on
    # rows it kept -- confirmed real, three raw spellings of one FMC
    # manager still fragmenting output after the v0.6.0 fix. v0.12.0
    # then removed this file's own local MANAGER_ALIASES/
    # canonicalize_manager entirely in favor of importing both from
    # build_fw_config_manifest.py v2.7.0, which now does the same
    # resolution as part of its own FW_POLICIES/ walk -- one canonical
    # table instead of two copies that could drift out of sync.
    ('build', 'build_ftd_p2p_registry.py',
     ['--version'],
     '0.12.0', 'build_ftd_p2p_registry version'),

    ('build', 'build_fw_route_db.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '0.11.0' -> '0.13.0'. Real
     # run confirmed today: 601 devices added (464 ASA/FTD, 137 PA),
     # 1,890 interfaces, 75,445 routes, 56,520 sidecar-route merges, 84
     # genuine cross-source route duplicates removed.
     # v1.15.7 -- 2026-08-21: floor bumped '0.13.0' -> '0.16.0'. Real
     # IPAM LPM enrichment added to fw_routes and fw_interfaces tables.
     '0.16.0', 'build_fw_route_db version'),

    ('build', 'fw_route_db.py',
     ['--version'],
     '0.4.1', 'fw_route_db version'),

    ('build', 'build_fw_group_db.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '0.5.0' -> '0.8.0'. Real run
     # confirmed today: 393 real devices matched against asa_ftd_
     # identity.py's registry, 133,927 address-groups, 1,772,573
     # resolved (device, group, cidr) member rows.
     # v1.15.7 -- 2026-08-21: floor bumped '0.8.0' -> '0.11.0'. Real
     # IPAM LPM enrichment added to fw_group_members and fw_objects.
     '0.11.0', 'build_fw_group_db version'),

    ('build', 'asa_ftd_identity.py',
     ['--version'],
     # NEW 2026-08-15 -- previously ZERO coverage here (confirmed via
     # grep before adding this, same discipline used for every other
     # "new" entry in this file). Real, load-bearing dependency of both
     # build_fw_group_db.py and build_fw_rule_db.py's fw_device_identity
     # join -- was entirely absent from collect_fw_bundle.sh until this
     # same session (see that script's own v2.1.0 changelog entry
     # above). Floor set at 1.3.0: v1.2.0 fixed a real, dangerous
     # collision-classifier bug (the win-fw-equinix-ftd HA group that
     # caused the v1.18.2 251,418-row regression was initially labeled
     # safe to auto-merge); v1.3.0 fixed resolve_canonical_groups()
     # double-counting a device_key reachable from multiple near-
     # duplicate hostname spellings (confirmed real: 268 vs 226 on a
     # live 794-device registry, root-caused and reproduced directly
     # against the real production config, not just code review).
     '1.3.0', 'asa_ftd_identity version'),

    ('build', 'fw_group_lookup.py',
     ['--version'],
     '0.4.0', 'fw_group_lookup version'),

    # build_p2p_link_registry.py -- legacy ASA-based P2P registry (the
    # counterpart to build_ftd_p2p_registry.py's FTD/FMC parser above --
    # see CCD_VPN_P2P_Link_Pipeline_v1_0.docx for why both exist). Verified
    # 2026-07-20 via the check-toolset-add-tool skill: --version clean
    # (1.0.1), --dry-run confirmed to gate both the file write AND the
    # dsr_register() call behind args.dry_run -- no side effects. Fails in
    # THIS sandbox only (no IP_Datasets_Raw/P2P_CONFIGS/ test fixture),
    # fast (0.07s) when it does run.
    ('build', 'build_p2p_link_registry.py',
     ['--version'],
     '1.6.0', 'build_p2p_link_registry version'),

    # build_3p_report.py -- previously ZERO coverage (confirmed via grep
    # before adding this; genuinely new script, not just an unbumped
    # floor). Report-builder, reads already-built CSV datasets (VPN peer/
    # subnet registries, P2P/FTD link registries) rather than raw configs
    # -- no --dry-run flag exists (confirmed via argparse inspection; only
    # --data-dir/--out-dir/--title/--version), so only --version is safe
    # and available to test here. Confirmed real: 0.11s, exit 0, output
    # 'build_3p_report.py 1.1.0' (no 'v' prefix, unlike most scripts in
    # this toolset -- extract_version() handles this fine, confirmed).
    ('build', 'build_3p_report.py',
     ['--version'],
     '1.4.0', 'build_3p_report version'),

    ('build', 'build_p2p_link_registry.py',
     ['--dry-run'],
     '', 'build_p2p_link_registry dry-run'),

    ('build', 'build_p2p_policy_map.py',
     ['--version'],
     # v1.15.5 -- 2026-08-21: floor bumped '1.1.0' -> '1.3.0'.
     # Real evidence-based is_cvs_side() fix.
     '1.3.0', 'build_p2p_policy_map version'),

    ('build', 'build_partner_ip_map.py',
     ['--version'],
     '1.1', 'build_partner_ip_map version'),

    # build_fw_config_manifest.py / generate_fw_config_requests.py -- real,
    # pre-existing gaps found 2026-07-20 alongside build_geo_block_objects.py
    # and build_ipdataset_objects.py. Both confirmed: --version exits via
    # sys.exit(0) before any file access. generate_fw_config_requests.py has
    # NO --dry-run flag at all -- a bare run always writes a real
    # FW_config_requests_<date>.csv, so --show-age-histogram (the script's
    # own documented safe/read-only mode) is used instead of a dry-run test.
    # v1.14.29 -- 2026-08-03: floor bumped '2.6' -> '2.7'. v2.7.0 added
    # FW_POLICIES/ manager-subdirectory identity resolution
    # (canonicalize_manager() + MANAGER_ALIASES, new MANAGER_RAW/
    # MANAGER_CANONICAL output columns) -- this manifest already solved
    # this exact problem for FW_CONFIGS/ device files (device_stem()/
    # hostname_match()/_PARTNER_ALIASES), just never extended to manager
    # subdirectories until build_ftd_p2p_registry.py came to depend on
    # them with no shared resolution to call into and reinvented the
    # mechanism locally. Now the one canonical source other scripts
    # import from (see build_ftd_p2p_registry.py's own v0.12.0 entry).
    ('build', 'build_fw_config_manifest.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '2.7' -> '2.8'. Real fix
     # confirmed against a live v20260803 run: hostname_match() gained a
     # token-set comparison rule for word-order transposition (e.g.
     # 'Ashburn-CCVA-Primary' vs 'CCVA-Ashburn-Primary' -> CLOSE), placed
     # last in the rule chain so all 5 existing rules stay unaffected --
     # regression-tested directly, plus confirmed the negative case
     # (genuinely different device names sharing some tokens) correctly
     # stays MISMATCH, not falsely folded into CLOSE.
     '2.8', 'build_fw_config_manifest version'),

    ('build', 'build_fw_config_manifest.py',
     ['--dry-run'],
     '', 'build_fw_config_manifest dry-run'),

    # build_fw_device_master.py -- new 2026-08-03. The persistent device-
    # identity registry that should have existed all along: promotes
    # build_fw_config_manifest.py's MANAGER_CANONICAL resolutions into a
    # CONFIRMED-alias table across runs (additive, never destructive),
    # flags HOSTNAME_MISMATCH rows as UNRESOLVED for human review rather
    # than auto-merging, and separately tracks a real per-device
    # DEVICE_ID + SHA256 with a cumulative, append-only changelog of
    # actual content-replacement events -- not just a per-run snapshot.
    # --dry-run requires a real fw_config_manifest CSV to already exist
    # in --ipam-dir (hard-errors otherwise, by design, same "don't guess
    # a source" discipline as everything else this session) -- expected
    # to be present in a normal ~/Documents/IP_Lookup/ checkout after
    # build_fw_config_manifest.py has run at least once.
    ('build', 'build_fw_device_master.py',
     ['--version'],
     '1.1', 'build_fw_device_master version'),

    ('build', 'build_fw_device_master.py',
     ['--dry-run'],
     '', 'build_fw_device_master dry-run'),

    ('build', 'generate_fw_config_requests.py',
     ['--version'],
     '1.2', 'generate_fw_config_requests version'),

    ('build', 'generate_fw_config_requests.py',
     ['--show-age-histogram'],
     'age distribution', 'generate_fw_config_requests age-histogram'),

    # ── 18 scripts collect_ccd_platform.py tracked but this suite didn't,
    # verified 2026-07-20 via the check-toolset-add-tool skill. Each flag
    # choice below reflects what was actually confirmed, not a template --
    # see the skill's own changelog entry for the three real surprises this
    # batch produced (enrich_eir.py's required args blocking even
    # --version; classify_net_type.py's --dry-run correctly refusing to
    # proceed on a real, separate stale-vocabulary bug -- not this suite's
    # problem to fix; build_object_pipeline.py's --dry-run deliberately
    # NOT tested, 9-stage orchestrator including generate_csna_hostgroups.py
    # which alone needs the 300s override).
    # v1.15.4-equivalent: floor bumped '1.13.0' -> '1.17.0' -- real work
    # landed this session (v1.14.0-v1.17.1): (LOCATION,HERITAGE) false-tie
    # fix, /16-sibling disambiguation, retail_networks integration
    # (previously never an input at all), Ctrl-C/progress-bar handling,
    # and v1.17.1's Stage 7 confirmation gate (ipam-db.py --import no
    # longer runs unconditionally -- see --yes flag). MAJOR.MINOR only
    # per convention; the v1.17.1 patch-level bump doesn't need its own
    # floor edit.
    ('build', 'build_IP_Network_Egress_FW_topology.py',
     ['--version'],
     '1.17.0', 'build_IP_Network_Egress_FW_topology version'),

    ('build', 'build_IP_Network_Egress_FW_topology.py',
     ['--dry-run'],
     '', 'build_IP_Network_Egress_FW_topology dry-run'),

    # build_custom_objects.py -- real, confirmed gap: never had a
    # check_toolset entry at all despite being an active, real-work
    # script (v1.7.1 -> v1.8.0 this session: LOCATIONS field cap fix,
    # closing the real csv field_size_limit incident tied to the
    # retail-heavy RI-ONE-SEC-DMZ object's 305,490-char LOCATIONS
    # field). Added now rather than left absent.
    ('build', 'build_custom_objects.py',
     ['--version'],
     '1.8.0', 'build_custom_objects version'),

    ('build', 'build_ip_classification_ref.py',
     ['--version'],
     # v1.15.5 -- 2026-08-21: floor bumped '1.4.0' -> '1.5.0'. Added
     # real next-step --import instructions after writing output files.
     # v1.15.6 -- 2026-08-21: floor bumped '1.5.0' -> '1.6.0'. Real
     # false-positive fix: WAN_EDGE removed from NDM evidence tier --
     # SD-WAN routers' 11.0.0.0/8 connected subnets were wrongly
     # classified PUBLIC.
     '1.9.0', 'build_ip_classification_ref version'),

    # plugin_audit_patterns.py -- real gap: never had a check_toolset
    # entry. Confirmed it's the real live code behind --broad-src-public-dst
    # (fw_audit_patterns.py is dead code -- the real logic migrated to
    # fw_lookup_plugins/plugin_audit_patterns.py). Added v1.15.5 rather
    # than left untracked. Note: this is a plugin module, not a standalone
    # script -- it has no --version flag of its own, so only the
    # PLUGIN_VERSION constant can be checked. Using --help which triggers
    # the plugin discovery path in fwlookup.py; can't test PLUGIN_VERSION
    # directly from check_toolset without a real fw_rule_db available.
    # Tracking it here so content changes without version bumps are caught
    # by the SHA256 integrity check even if the version floor is loose.
    ('build', 'plugin_audit_patterns.py',
     ['-c', "import importlib.util, sys; "
            "spec = importlib.util.spec_from_file_location('m', 'fw_lookup_plugins/plugin_audit_patterns.py'); "
            "m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); "
            "print('plugin_audit_patterns v' + m.PLUGIN_VERSION)"],
     '1.1.0', 'plugin_audit_patterns version'),

    ('build', 'build_edl_catalog.py',
     ['--version'],
     '1.5', 'build_edl_catalog version'),

    ('build', 'build_edl_catalog.py',
     ['--dry-run'],
     '', 'build_edl_catalog dry-run'),

    ('build', 'build_f5_datasets.py',
     ['--version'],
     # v1.4.0 confirmed shipped 2026-07-30: real -V/--version flag added
     # -- this script had none before, so only --dry-run could be
     # exercised here (couldn't catch a version regression or a
     # content change without a version bump). Also v1.3.0 same day:
     # --out-dir default fixed from './ipam-db' (was writing straight
     # into the live registered dataset directory, bypassing ipam-
     # db.py --import entirely -- confirmed real, found orphaned
     # v20260730 copies sitting unregistered next to the still-current
     # v20260701 files) to './processed_outputs', plus the missing
     # ipam-db.py --import instructions added.
     # v1.15.7 -- 2026-08-21: floor bumped '1.4' -> '1.5.0'. Real IPAM
     # LPM enrichment added -- VIP and member IPs now cross-referenced
     # against all_IP_networks for accurate ROUTING_DOMAIN/CANONICAL_LOCATION.
     '1.5.0', 'build_f5_datasets version'),

    ('build', 'build_f5_datasets.py',
     ['--dry-run'],
     '', 'build_f5_datasets dry-run'),

    ('build', 'build_fw_interface_inventory.py',
     ['--version'],
     '1.7.0', 'build_fw_interface_inventory version'),

    ('build', 'build_fw_interface_inventory.py',
     ['--dry-run'],
     '', 'build_fw_interface_inventory dry-run'),

    ('build', 'build_fw_location_topology.py',
     ['--version'],
     # v1.15.9 -- 2026-08-23: floor bumped '1.3.0' -> '2.0.4'. v2.0.0
     # major rewrite: four FW tier registries (egress_fw_mgmt_ips,
     # cvs_pci_fw_mgmt_ips, vpn/b2b optional), new FW_ROLE values
     # (PCI-ENFORCEMENT, VPN-EDGE, B2B-EDGE), new output columns
     # (EGR_CODE, EGRESS_LOGICAL, MGMT_PLANE, ADJACENT_EGR_CODE,
     # FW_TIER, ROUTING_FABRIC). v2.0.4 adds hard guard refusing
     # to write to ipam-db/ directly.
     '2.0.4', 'build_fw_location_topology version'),

    ('build', 'build_fw_location_topology.py',
     ['--dry-run'],
     '', 'build_fw_location_topology dry-run'),

    ('build', 'build_fw_topology_report.py',
     ['--version'],
     # v1.15.9 -- 2026-08-23: floor bumped '1.1' -> '1.3.0'. New roles:
     # PCI-ENFORCEMENT (rose), VPN-EDGE (orange), B2B-EDGE (fuchsia).
     # New tabs: PCI Enforcement, VPN/B2B.
     '1.3.0', 'build_fw_topology_report version'),

    ('build', 'build_app_egress_topology.py',
     ['--version'],
     # v1.15.9 -- 2026-08-23: new entry. Produces egress_topology_registry,
     # app_egress_topology, ip_resolution_index. Runs after both FW and
     # IPAM pipelines are current. Not gated by Tier 1 signal.
     '1.5.0', 'build_app_egress_topology version'),

    ('build', 'build_app_egress_topology.py',
     ['--dry-run'],
     '', 'build_app_egress_topology dry-run'),

    ('build', 'build_network_groups.py',
     ['--version'],
     '1.8', 'build_network_groups version'),

    ('build', 'build_network_groups.py',
     ['--dry-run'],
     '', 'build_network_groups dry-run'),

    ('build', 'build_ng_report.py',
     ['--version'],
     '1.3', 'build_ng_report version'),

    # build_object_pipeline.py --dry-run deliberately NOT tested -- see
    # block comment above.
    ('build', 'build_object_pipeline.py',
     ['--version'],
     '1.7', 'build_object_pipeline version'),

    # ingest_pipeline_2.py -- new 2026-07-30. Same orchestrator class as
    # build_object_pipeline.py directly above, and --dry-run deliberately
    # NOT tested here for the same reason: it's a multi-stage wrapper that
    # shells out to preprocess_p2.py (x2), five separate update_*.py
    # commit stages, and build_unresolved_ip_registry.py -- every one of
    # which already has its own TESTS row elsewhere in this file. Its own
    # --dry-run logic is confirmed non-interactive end-to-end (no input()
    # prompt fires while self.dry_run is set -- verified this session,
    # smoke-tested against 7 stub scripts) but still needs real
    # preprocess_p2.py/ipam-db.py output on disk to run past Stage 0 in
    # this sandbox, so a real dry-run pass wasn't observed here. --version
    # confirmed clean (rc=0, 'ingest_pipeline_2.py v0.9.0'). v0.9.0 --
    # first draft, several of its own commit-stage flag assumptions are
    # still marked verified=False in its own STAGE_CONFIG; don't treat a
    # green check_toolset run as confirmation those are correct.
    ('build', 'ingest_pipeline_2.py',
     ['--version'],
     'v0.9.0', 'ingest_pipeline_2 version'),

    ('build', 'build_service_objects.py',
     ['--version'],
     '1.2', 'build_service_objects version'),

    ('build', 'build_service_objects.py',
     ['--dry-run'],
     '', 'build_service_objects dry-run'),

    ('build', 'build_shared_server_registry.py',
     ['--version'],
     '1.1', 'build_shared_server_registry version'),

    ('build', 'build_shared_server_registry.py',
     ['--dry-run'],
     '', 'build_shared_server_registry dry-run'),

    # build_unresolved_ip_registry.py -- new 2026-07-30, Group-B "unmappable,
    # tracked" registry for ingest_pipeline_2.py. --version confirmed clean
    # (rc=0, 'build_unresolved_ip_registry.py v1.0.0'). --dry-run correctly
    # [ERROR]s and exits 1 when no p2_unmapped_*.csv exists yet -- same
    # "no test fixture in this sandbox" case as update_ipam.py above, not a
    # bug. Will exit clean once preprocess_p2.py has produced a real
    # p2_unmapped file, which it does as a normal part of the pipeline_2
    # flow this script feeds.
    ('build', 'build_unresolved_ip_registry.py',
     ['--version'],
     'v1.0.0', 'build_unresolved_ip_registry version'),

    ('build', 'build_unresolved_ip_registry.py',
     ['--dry-run'],
     '', 'build_unresolved_ip_registry dry-run'),

    ('build', 'ccd_schema.py',
     ['--version'],
     '1.1', 'ccd_schema version'),

    # classify_net_type.py --dry-run deliberately NOT tested -- it
    # correctly sys.exit(1)s when NET_TYPE values fall outside its
    # VALID_NET_TYPES vocabulary, and that vocabulary is currently stale
    # (rejects RA-POOL-CSA/RA-CONN-ZPA/RA-SNAT-HCB, added to the platform
    # months before this script's list was last touched). Real, separate
    # bug, flagged to Michael directly -- not something to route around
    # with a test that expects failure.
    ('build', 'classify_net_type.py',
     ['--help'],
     '', 'classify_net_type help'),

    # enrich_eir.py: --input and --ext-obj are required, and argparse
    # validates required args before this script's own manual
    # `if args.version:` check ever runs -- so --version alone genuinely
    # fails with a usage error (confirmed: rc=2, "the following arguments
    # are required"). No standalone-safe way to check version or dry-run;
    # --help is the only flag argparse's own -h handling exempts from
    # required-arg validation.
    ('build', 'enrich_eir.py',
     ['--help'],
     '', 'enrich_eir help'),

    ('build', 'enrich_fw_service_objects.py',
     ['--version'],
     '1.0', 'enrich_fw_service_objects version'),

    ('build', 'enrich_fw_service_objects.py',
     ['--dry-run'],
     '', 'enrich_fw_service_objects dry-run'),

    ('build', 'preflight_lm_check.py',
     ['--version'],
     '1.0', 'preflight_lm_check version'),

    ('build', 'resolve_unknown_subnets.py',
     ['--dry-run'],
     '', 'resolve_unknown_subnets dry-run'),

    # Shared helper modules -- imported by other scripts, not run
    # standalone, so tested the same way ccd_host_enrichment is above:
    # import cleanly, no --version flag to check.
    ('shared', None,
     ['-c', "import ipam_lookup as m; print('ipam_lookup OK')"],
     'OK', 'ipam_lookup shared module import'),

    ('shared', None,
     ['-c', "import ipam_db_registry as m; print('ipam_db_registry OK')"],
     'OK', 'ipam_db_registry shared module import'),

    # FW_Rule_Request_Tool -- added 2026-07-17, closing the gap where this
    # entire subsystem was invisible to this test suite despite writing to
    # ccd_objects.sqlite/ccd_groups.sqlite in production. All five .py files
    # got a real SCRIPT_VERSION constant + --version flag added at the same
    # time (neither existed before, same gap class as build_partner_ip_map.py
    # earlier this session). The two shell scripts and the HTML frontend have
    # no version convention, so they're existence/import checks instead.
    ('build', 'ccd_api.py',
     ['--version'],
     '0.1', 'ccd_api version'),

    ('build', 'query_ccd.py',
     ['--version'],
     '0.1', 'query_ccd version'),

    ('build', 'validate_ip.py',
     ['--version'],
     # v1.15.5 -- 2026-08-21: floor bumped '0.1' -> '0.2.0'. Real
     # evidence-based route_as_private() fix -- this one gates object
     # creation, so the most consequential of the batch.
     '0.2.0', 'validate_ip version'),

    ('build', 'build_ccd_object_db.py',
     ['--version'],
     '0.1', 'build_ccd_object_db version'),

    ('build', 'build_ccd_group_db.py',
     ['--version'],
     '0.1', 'build_ccd_group_db version'),

    ('shared', None,
     ['-c', "import ccd_api as m; print('ccd_api imports OK')"],
     'OK', 'ccd_api Flask app import (does not start the server)'),

    # start_ccd_api.sh / stop_ccd_api.sh deliberately have NO automated test
    # here. Checked directly (2026-07-17): neither script parses any
    # arguments at all -- no --help, no case/getopts on $1. Unlike
    # setup_fw_configs.sh (which genuinely supports --help), any invocation
    # of these two -- with --help, --version, or no args -- just runs the
    # real start/stop sequence, ignoring whatever flag was passed. There's
    # no safe way to functionally test them here without either starting a
    # real Flask server or sending a real kill signal during a routine,
    # unattended test run. collect_ccd_platform.py's existence-only check
    # (added the same day) is the right level of verification for these two
    # until/unless the scripts themselves get a real --help path added.


    # ── Shell scripts ─────────────────────────────────────────────────────────
    ('build', 'iplookup.sh',
     ['--version'],
     'v3.36', 'iplookup version'),

    ('build', 'setup_fw_configs.sh',
     ['--help'],
     '', 'setup_fw_configs help'),

    # v1.14.0: real gap fixed -- setup_fw_configs.sh had no --version test
    # at all, confirmed real (a run against the actual v2.4.0 file produced
    # the WARN "content changed, no --version test defined for this
    # script"). The script itself had no --version FLAG either until its
    # own v2.5.0 -- both fixed together, see that script's own changelog.
    # v1.14.29 -- 2026-08-03: floor bumped '2.6' -> '2.9'. Real, multi-
    # part work this session: v2.7.0 added auto-rebuild of the baseline
    # zip from its extracted folder when missing instead of hard-
    # failing. v2.8.0 replaced all six ingestion decision sites' raw
    # mtime-only "-nt" comparison with a shared, checksum-aware
    # decide_copy() (SHA-256 + mtime) -- confirmed real damage from the
    # old logic: a file re-copied with a fresh mtime but identical
    # content was logged as a fake UPDATE, and a genuinely different-
    # content file with an OLDER mtime was silently indistinguishable
    # from an ordinary skip. v2.9.0 added FMC security-zone JSON
    # ingestion (content-detected, not filename-guessed) into
    # IP_Datasets_Raw/FMC_SecZone_Interfaces/. v2.9.1 fixed a severe bug
    # found from a real failed run: the "decision=$(decide_copy ...)"
    # call sites (bare command-substitution assignments) aborted the
    # whole script under this file's own "set -euo pipefail" the
    # instant decide_copy() returned its normal non-zero SKIP/CONFLICT
    # exit code -- meaning the very first ordinary skip decision on any
    # re-run killed the entire pipeline, silently, no error text.
    # v2.9.2 added the actual guardrail: any zip in FW_CONF_UPDATES/
    # matching zero files across any pattern now triggers a loud,
    # dedicated warning instead of the old silent "Extracting X.zip ..."
    # followed by nothing -- confirmed real: this exact silence had
    # hidden 101 real device configs (68 PA, 24 ASA, 9 FTD) across 4
    # zips for an unknown number of prior runs before being found by
    # accident this session.
    ('build', 'setup_fw_configs.sh',
     ['--version'],
     '2.9', 'setup_fw_configs version'),

    # v1.14.4: real bug found -- this was never a missing-script gap at
    # all. The real file is 'collect_edl_bundle.sh' (all underscores);
    # every TESTS entry here was typo'd 'collect-edl_bundle.sh' (hyphen
    # after "collect") since this row was first added 2026-07-24, so the
    # "gap fix" itself silently introduced the very failure it was
    # trying to close -- confirmed via `ls`, the real file has never had
    # a hyphen in its name. Floor was also stale as a direct consequence:
    # '1.4' was correct AT THE TIME this row was added, but because the
    # typo meant this test has never once actually run against the real
    # script, ADVANCED-tracking never got a chance to notice the real
    # file has since moved to v2.1.0. Confirmed --version (immediate
    # exit, no side effects) and --dry-run (real isolated run: zero
    # files written, diff empty) directly against the real uploaded
    # file before fixing either the name or the floor.
    ('build', 'collect_edl_bundle.sh',
     ['--version'],
     '2.1.0', 'collect_edl_bundle version'),

    ('build', 'collect_edl_bundle.sh',
     ['--dry-run'],
     '', 'collect_edl_bundle dry-run'),

    # collect_fw_bundle.sh -- new 2026-07-24, packages both the raw FW
    # config/policy estate and the built FW intelligence artifacts
    # (fw_route_db, fw_rule_db, fw_group_db, topology CSV/HTML, manifest,
    # SNAT pools, interface inventory, P2P registry) for distribution.
    # v1.13.0: floor was stale at '1.0' since this row's introduction --
    # real version confirmed 1.6.0 (added --max-zip-size/auto-split via
    # zip -s, see that script's own v1.6.0 changelog).
    ('build', 'collect_fw_bundle.sh',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '2.0' -> '2.3.0'. Two real,
     # confirmed gaps closed this session: v2.1.0 collected
     # asa_ftd_identity.py (hard, load-bearing dependency of build_fw_
     # group_db.py/build_fw_rule_db.py's fw_device_identity join --
     # completely absent from the bundle before this). v2.3.0 collected
     # setup_fw_configs.sh (Tier 0 of the pipeline -- the script every
     # other stage's input ultimately comes from -- never bundled in any
     # prior version, only referenced in comments/error text; confirmed
     # via grep before fixing, same discipline as the pa_config_parser.py
     # and asa_ftd_identity.py gaps before it).
     '2.3.0', 'collect_fw_bundle version'),

    ('build', 'collect_fw_bundle.sh',
     ['--dry-run'],
     '', 'collect_fw_bundle dry-run'),

    # collect_ipam_db_files.sh -- previously had ZERO coverage here
    # (confirmed via grep before adding this). Reads ipam-db.py's and
    # ip_dataset.py's registries and copies every registered file to a
    # dated output dir, optionally zipped. v1.13.0: added after this
    # script gained --max-zip-size/auto-split (v1.4.0) for the same
    # oversized-zip problem collect_fw_bundle.sh had. --dry-run confirmed
    # safe by reading the actual script: the DRY_RUN branch exits before
    # mkdir/cp/zip, so it genuinely performs zero writes, not just skips
    # the last step. Timed at 0.13s against a 9-file synthetic registry
    # (no file-content parsing happens in dry-run, only `du -sh` per
    # file, so real production's larger registry should stay fast too --
    # added to FAST_SKIP below on that basis, revisit if a real
    # production run shows otherwise).
    ('build', 'collect_ipam_db_files.sh',
     ['--version'],
     '1.5', 'collect_ipam_db_files version'),

    ('build', 'collect_ipam_db_files.sh',
     ['--dry-run'],
     '', 'collect_ipam_db_files dry-run'),

    # ── Preprocess ────────────────────────────────────────────────────────────
    ('preprocess', 'preprocess_p1.py',
     ['--version'],
     # v1.15.7 -- 2026-08-21: floor tightened '2.' -> '2.12.0'. Real
     # is_unowned_public_ip() fix + ip_classification_ref integration.
     '2.12.0', 'preprocess_p1 version'),

    ('preprocess', 'preprocess_p2.py',
     ['--version'],
     '1.', 'preprocess_p2 version'),

    # preprocess_p2.py --dry-run -- added 2026-07-30, real run confirmed on
    # Michael's machine: 3.967s total (1,387 hosts, 25,444-row
    # all_IP_networks, 11,560-site location_master) -- well under the 120s
    # default, no TIMEOUT_OVERRIDE needed. Confirmed a genuine smoke test
    # (full computation runs, only the 7 candidate-file writes are
    # skipped -- unlike generate_csna_hostgroups.py's "full run minus
    # write" pattern). Also confirmed the Stage 2 gate check runs and
    # reports CLEAR even under --dry-run, before the dry-run branch
    # itself engages.
    ('preprocess', 'preprocess_p2.py',
     ['--dry-run'],
     'DRY RUN', 'preprocess_p2 dry-run'),

    # ── Generators ────────────────────────────────────────────────────────────
    ('generate', 'generate_canonical_app_objects_explorer.py',
     ['--help'],
     '', 'generate_canonical_app_objects_explorer help'),

    ('generate', 'generate_network_infra_map.py',
     ['--help'],
     '', 'generate_network_infra_map help'),

    ('generate', 'generate_location_map.py',
     ['--help'],
     '', 'generate_location_map help'),

    # generate_csna_hostgroups.py -- real, significant gap found 2026-07-20.
    # This is Stage 6 of the canonical pipeline: ipam-db.py's own
    # _print_next_steps() lists "Regenerate CSNA FW hostgroups" as the
    # required next step after FOUR different master-dataset imports
    # (location_master, csna_site_registry, all_IP_networks, ent_host_master)
    # -- yet it had zero automated health-check coverage until now. Cross-
    # validated against collect_ccd_platform.py's own SCRIPTS manifest
    # (floor 'v4.' there too). Both --version and --dry-run confirmed
    # clean: --dry-run returns before any os.makedirs/file write.
    ('generate', 'generate_csna_hostgroups.py',
     ['--version'],
     '4.0', 'generate_csna_hostgroups version'),

    ('generate', 'generate_csna_hostgroups.py',
     ['--dry-run'],
     '', 'generate_csna_hostgroups dry-run'),

    # The following 5 were confirmed active/used (not legacy) 2026-07-20 --
    # each verified individually since they don't share a uniform flag set:
    #   csna_map_v2       : --dry-run only (no --version flag at all;
    #                        version prints unconditionally in normal
    #                        output but there's no dedicated flag to check
    #                        it in isolation, so this only gets checksum-
    #                        drift tracking via the WARN path, not real
    #                        version tracking -- same honest limitation as
    #                        other --help-only entries in this suite)
    #   fw_rule_report     : has both --version and --dry-run, confirmed
    #                        clean (dry-run returns before any HTML write)
    #   ipam_hierarchy_report : has --version, no --dry-run at all -- only
    #                        --version is safe to test
    #   ipam_map           : no --version, no --dry-run -- --help only
    #   partner_map        : no --version, no --dry-run, default --output
    #                        is a real HTML file -- --help only
    ('generate', 'generate_csna_map_v2.py',
     ['--dry-run'],
     '', 'generate_csna_map_v2 dry-run'),

    ('generate', 'generate_fw_rule_report.py',
     ['--version'],
     # v1.14.30 -- 2026-08-15: floor bumped '2.0' -> '2.2.0'. Added
     # opt-in --rdap-unknown flag + write_unknown_dest_rdap_csv(),
     # scoped deliberately to only the already-deduplicated UNKNOWN-
     # classified destinations (not the main per-rule enrichment loop --
     # RDAP is a live network call, firing it per-row across a report
     # covering tens of thousands of sessions would be a real problem).
     # Functionally tested: correctly scoped to UNKNOWN only, RDAP-
     # failure case handled, non-UNKNOWN IPs excluded, graceful
     # degradation confirmed when geo_ip.py is missing/outdated. Also
     # caught and fixed a real operator-precedence bug introduced during
     # this same change (`d.get('apps') or [][:5]` silently returning
     # ALL apps instead of the first 5) before it shipped.
     '2.2.0', 'generate_fw_rule_report version'),

    ('generate', 'generate_fw_rule_report.py',
     ['--check'],
     '', 'generate_fw_rule_report check'),

    ('generate', 'generate_ipam_hierarchy_report.py',
     ['--version'],
     '1.1', 'generate_ipam_hierarchy_report version'),

    ('generate', 'generate_ipam_map.py',
     ['--help'],
     '', 'generate_ipam_map help'),

    ('generate', 'generate_partner_map.py',
     ['--help'],
     '', 'generate_partner_map help'),
]

# Scripts not yet on disk — warn only, do not fail
_EXPECTED = [
    ('update_compute_substrate.py', 'v1.0'),  # pipeline stage not yet built
    ('build_f5_vip_registry.py',    'v1.'),   # replaced by build_f5_datasets.py
    ('find_unmatched_source_subnets.py', 'v1.'),  # utility — may be retired
    ('enrich_zscaler_flows.py',     'v2.0'),  # RETIRED (confirmed by Michael
                                               # 2026-07-22) -- will not return,
                                               # kept here as a permanent record
                                               # rather than a pending build
]

# ── Fast-mode overrides: version/help only, skip dry-runs ────────────────────
FAST_SKIP = {
    'update_app dry-run',
    'update_infrastructure dry-run',
    'update_platform dry-run',
    'update_ipam dry-run',
    'build_unresolved_ip_registry dry-run',
    'Backup dry-run',
    'Checksum-init dry-run',
    'Cross-check 0 violations',
    'Registry --list',
    'preprocess_p1 dry-run',
    'preprocess_p2 dry-run',
    'build_zpa_connector_registry dry-run',
    'build_geo_block_objects dry-run',
    'build_ext_canonical_objects dry-run',
    'build_fw_config_manifest dry-run',
    'generate_csna_hostgroups dry-run',
    'generate_csna_map_v2 dry-run',
    'build_IP_Network_Egress_FW_topology dry-run',
    'build_edl_catalog dry-run',
    'build_f5_datasets dry-run',
    'build_fw_interface_inventory dry-run',
    'build_fw_location_topology dry-run',
    'build_network_groups dry-run',
    'build_service_objects dry-run',
    'build_shared_server_registry dry-run',
    'enrich_fw_service_objects dry-run',
    'resolve_unknown_subnets dry-run',
    'collect_edl_bundle dry-run',
    'collect_fw_bundle dry-run',
    'collect_ipam_db_files dry-run',
}

# Per-test timeout override (default 120s). Confirmed 2026-07-20:
# generate_csna_hostgroups.py --dry-run takes 136.9s on a real run (timed
# directly, not a fluke) -- it skips only the final file write, not the
# actual host-group computation over the full dataset, so it's inherently
# a "full run minus the write," not a fast smoke test. Real production-
# scale data (this platform's real CSNA export is 100K+ rows) will likely
# take longer still, not shorter, than this sandbox's test.
#
# 2026-07-20 update: a real run on Michael's machine confirmed my sandbox
# timing was not representative for several others too -- sparse test
# fixtures ran fast, real production-scale data did not.
# build_IP_Network_Egress_FW_topology dry-run genuinely TIMED OUT at the
# 120s default (my sandbox: 1.29s on a handful of rows). Given headroom
# for further data growth, not just today's observed time.
TIMEOUT_OVERRIDE = {
    'generate_csna_hostgroups dry-run': 300,
    'build_IP_Network_Egress_FW_topology dry-run': 450,  # v1.15.1: bumped
        # 240 -> 450. Real run confirmed 224.3s passing, then a
        # subsequent same-config-era run exceeded 240s and timed out --
        # not necessarily a regression. query_route_db_knowledge() (see
        # its v1.12.0 bucketed-lookup fix) is O(bucket size) per call,
        # fast on its own, but it's called once per unmatched /24
        # subnet (see the real print at "[Route DB] Validating egress
        # routing for {len(unmatched_raw):,} unmatched..." in the
        # script's own output) -- so total wall time scales with how
        # many subnets got discovered THIS run, which grows every time
        # more raw configs are ingested. 450s gives real headroom
        # without masking a genuine regression outright; if a future run
        # blows past 450s too, that's worth investigating as a real
        # slowdown rather than assumed data growth.
    'build_fw_interface_inventory dry-run': 180,          # real run: 59.9s
    'build_fw_location_topology dry-run': 180,            # real run: 41.5s
    'resolve_unknown_subnets dry-run': 180,               # real run: 40.3s
    'build_f5_datasets dry-run': 120,                     # real run: 26.7s -- default is enough headroom already, listed for visibility
}


# ── Runner ────────────────────────────────────────────────────────────────────

NEEDS_VENV_PYTHON = {'ccd_api.py'}  # extend here if another script
                                      # ever gains a non-stdlib dependency


def build_cmd(script, args):
    """Shared command-builder for run_test() and run_integrity_pass() --
    v1.14.0 fix. Confirmed real, single root cause behind BOTH shell-
    script WARNs in the same health-check run ('collect_fw_bundle.sh ...
    could not parse a version from output' and, before setup_fw_configs.sh
    got its own --version TESTS row, the same class of failure would have
    hit it too): run_integrity_pass() had its OWN, separate, incomplete
    command-building logic that always launched
    `[sys.executable, script] + args` -- unconditionally via Python,
    with no check for script type at all. For a .sh script, that means
    literally running `python3 collect_fw_bundle.sh --version`, i.e.
    asking Python to interpret bash syntax as Python source -- it fails
    (or produces garbage) well before reaching anything resembling a
    real version string, hence "could not parse a version from output".
    run_test() already had the correct, script-type-aware branching
    (.py needs the interpreter + NEEDS_VENV_PYTHON check; .sh needs a
    ./ prefix and no interpreter at all) -- run_integrity_pass() just
    never used it, a duplicate/drifted implementation of the same
    concern this file's own run_test() docstring already warns about.
    Extracted here so there is exactly one place this logic can drift
    from correct, not two."""
    if script is None:
        py = resolve_venv_python() if any(n in ' '.join(args) for n in NEEDS_VENV_PYTHON) \
            else sys.executable
        return [py] + args
    elif script.endswith('.py'):
        py = resolve_venv_python() if script in NEEDS_VENV_PYTHON else sys.executable
        return [py, script] + args
    elif script.endswith('.sh'):
        # Shell scripts need ./ prefix on macOS to run from cwd
        sh = script if os.sep in script else './' + script
        return [sh] + args
    else:
        return [script] + args


def run_test(script, args, expected, description, fast=False):
    """Run one test. Returns (passed, duration_s, output_snippet, error).

    NEEDS_VENV_PYTHON below is the only interpreter-selection special case
    -- ccd_api.py is the one script in this whole toolset with an external
    pip dependency (Flask), so it's the only one that can fail purely
    because of *which* interpreter ran it, not because of a real problem.
    Deliberately NOT expressed by changing what `script` looks like in
    TESTS (a tuple was tried first and broke run_integrity_pass(),
    unique_scripts(), and build_version_arg_map() -- all three assume
    `script` is always a plain string or None, since they use it as a
    filesystem path and a registry dict key). This keeps TESTS completely
    uniform; the interpreter override lives only here, where the process
    actually gets launched."""
    if fast and description in FAST_SKIP:
        return None, 0, '', ''   # skip

    # v1.7.0: per-test timeout override, same lookup-by-description pattern
    # as FAST_SKIP. Default 120s is fine for nearly everything; some tests
    # are legitimately slower on real production-scale data than in any
    # sandbox (see TIMEOUT_OVERRIDE definition for the confirmed case).
    timeout = TIMEOUT_OVERRIDE.get(description, 120)

    # Pre-existing gap fixed in v1.6.1: a missing script does NOT raise
    # FileNotFoundError from subprocess.run() here, because the executable
    # being launched is python3 (always found) — python3 then fails on its
    # own with "can't open file: No such file or directory" on stderr. Since
    # --help tests previously treated "any output" as success, and several
    # --help tests use the script's own name as the expected substring (which
    # the interpreter's own error text also contains), a genuinely missing
    # script could silently report PASS. Check existence explicitly first.
    if script and (script.endswith('.py') or script.endswith('.sh')) and not os.path.isfile(script):
        return False, 0, '', f'Script not found: {script}'

    # v1.14.0: was its own inline copy of this branching -- now delegates
    # to build_cmd(), the same helper run_integrity_pass() uses, closing
    # the drift gap that caused the collect_fw_bundle.sh/setup_fw_configs.sh
    # integrity-check WARNs (see build_cmd()'s own docstring).
    cmd = build_cmd(script, args)

    t0 = time.time()
    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=timeout
        )
    except FileNotFoundError:
        return False, 0, '', f'Script not found: {script}'
    except subprocess.TimeoutExpired:
        return False, 0, '', f'Timed out after {timeout}s'
    except Exception as e:
        return False, 0, '', str(e)

    elapsed = time.time() - t0
    combined = result.stdout + result.stderr

    # PASS conditions:
    # 1. Exit code 0 (or 1 for --help which some scripts return 0, some 1)
    # 2. Expected substring found (if specified)
    # 3. --help exits non-zero but produces output — treat as pass
    exit_ok = result.returncode == 0
    if args and args[0] == '--help':
        exit_ok = len(combined.strip()) > 0  # has output = pass
    if args and args[:2] == ['-c'] and script is None:
        exit_ok = result.returncode == 0

    # Version tests ('--version' + a fully-specified literal like 'v1.8') use
    # a numeric floor comparison instead of exact substring matching, so a
    # legitimate version advance (v1.8 -> v1.9.2) still passes without this
    # file needing an edit. Wildcard-style literals ('v2.', '1.') and every
    # non-version test keep the original substring behavior unchanged.
    if args and args[0] == '--version' and is_version_like(expected):
        actual_ver = extract_version(combined)
        expected_ok = actual_ver is not None and version_tuple(actual_ver) >= version_tuple(expected)
    else:
        expected_ok = (not expected) or (expected.lower() in combined.lower())
    passed = exit_ok and expected_ok

    # Snippet for failure diagnostics
    snippet = ''
    if not passed:
        lines = combined.strip().splitlines()
        snippet = '\n'.join(lines[:8]) if lines else '(no output)'

    return passed, elapsed, snippet, result.stderr.strip()[:200] if not passed else ''


def build_version_arg_map(tests):
    """script -> args, for every TESTS row whose args is exactly ['--version']."""
    m = {}
    for group, script, test_args, expected, desc in tests:
        if script and test_args == ['--version']:
            m[script] = test_args
    return m


def unique_scripts(tests):
    seen = []
    for group, script, test_args, expected, desc in tests:
        if script and script not in seen:
            seen.append(script)
    return seen


def run_integrity_pass(tests, registry_path, history_path):
    """Checksum + version drift tracking across every unique script in TESTS.

    Returns (n_baseline, n_ok, n_advanced, n_warn, n_fail, fail_details).
    fail_details is a list of (group, description) tuples so failures here
    can be folded into the main summary/failed-tests list.
    """
    registry = load_registry(registry_path)
    scripts_reg = registry['scripts']
    version_args = build_version_arg_map(tests)
    now = lambda: datetime.now().isoformat(timespec='seconds')

    n_baseline = n_ok = n_advanced = n_warn = n_fail = 0
    fail_details = []
    dirty = False

    print(f'{BLD}── INTEGRITY & VERSION TRACKING ─────────────────────{RST}')

    for script in unique_scripts(tests):
        if not os.path.isfile(script):
            continue  # reported as a normal test failure elsewhere; skip here

        digest = sha256_of_file(script)
        entry = scripts_reg.get(script)

        # ── Unseen script: bootstrap a baseline, no pass/fail judgment ──────
        if entry is None:
            actual_ver = None
            if script in version_args:
                try:
                    r = subprocess.run(build_cmd(script, version_args[script]),
                                        capture_output=True, text=True, timeout=30)
                    actual_ver = extract_version(r.stdout + r.stderr)
                except Exception:
                    actual_ver = None
            scripts_reg[script] = {
                'version': actual_ver, 'sha256': digest,
                'first_seen': now(), 'last_updated': now(),
            }
            n_baseline += 1
            dirty = True
            ver_note = f'  (v{actual_ver})' if actual_ver else ''
            print(f'  {CYN}○{RST}  {script:<45}  BASELINE{ver_note}')
            append_history(history_path, f'BASELINE  {script}  v{actual_ver}')
            continue

        # ── Checksum unchanged: nothing to do, keep output quiet ────────────
        if entry.get('sha256') == digest:
            n_ok += 1
            continue

        # ── Checksum changed: need the version story to interpret it ───────
        if script in version_args:
            try:
                r = subprocess.run(build_cmd(script, version_args[script]),
                                    capture_output=True, text=True, timeout=30)
                actual_ver = extract_version(r.stdout + r.stderr)
            except Exception:
                actual_ver = None

            old_ver = entry.get('version')

            if actual_ver is None:
                n_warn += 1
                print(f'  {YEL}!{RST}  {script:<45}  WARN  content changed, '
                      f'could not parse a version from output')
                append_history(history_path, f'CONTENT-CHANGED-VERSION-UNPARSEABLE  {script}')
                scripts_reg[script]['sha256'] = digest
                scripts_reg[script]['last_updated'] = now()
                dirty = True
                continue

            old_t, new_t = version_tuple(old_ver), version_tuple(actual_ver)

            if new_t > old_t:
                n_advanced += 1
                dirty = True
                print(f'  {GRN}\u25b2{RST}  {script:<45}  ADVANCED  v{old_ver} \u2192 v{actual_ver}')
                append_history(history_path, f'ADVANCED  {script}  v{old_ver} -> v{actual_ver}')
                scripts_reg[script] = {
                    'version': actual_ver, 'sha256': digest,
                    'first_seen': entry.get('first_seen', now()),
                    'last_updated': now(),
                }
            elif new_t == old_t:
                n_fail += 1
                desc = f'{script}: content changed, version NOT bumped (still v{old_ver})'
                fail_details.append(('integrity', desc))
                print(f'  {RED}\u2717{RST}  {script:<45}  FAIL  content changed, '
                      f'version not bumped (still v{old_ver})')
                append_history(history_path, f'NO-VERSION-BUMP  {script}  v{old_ver}  content changed')
                # Deliberately do NOT update the stored checksum here — leave
                # the registry pointing at the last known-good state so this
                # keeps failing (and stays visible) until it's actually fixed.
            else:
                n_fail += 1
                desc = f'{script}: version regressed v{old_ver} \u2192 v{actual_ver}'
                fail_details.append(('integrity', desc))
                print(f'  {RED}\u2717{RST}  {script:<45}  FAIL  REGRESSION  '
                      f'v{old_ver} \u2192 v{actual_ver}')
                append_history(history_path, f'REGRESSION  {script}  v{old_ver} -> v{actual_ver}')
                # Same reasoning — don't paper over a regression by recording it.
        else:
            n_warn += 1
            print(f'  {YEL}!{RST}  {script:<45}  WARN  content changed, '
                  f'no --version test defined for this script')
            append_history(history_path, f'CONTENT-CHANGED-NO-VERSION-TEST  {script}')
            scripts_reg[script]['sha256'] = digest
            scripts_reg[script]['last_updated'] = now()
            dirty = True

    if dirty:
        save_registry(registry_path, registry)

    print(f'  {CYN}{n_baseline} baseline \u00b7 {n_ok} unchanged \u00b7 {n_advanced} advanced '
          f'\u00b7 {n_warn} warn \u00b7 {n_fail} fail{RST}')
    print()

    return n_baseline, n_ok, n_advanced, n_warn, n_fail, fail_details


# ── Data freshness checking (v1.15.0) ──────────────────────────────────────────
# Real gap: this file checks whether TOOLS have drifted (checksum/version),
# but nothing here ever checked whether the DATA those tools depend on has
# gone stale. ip_dataset.py-managed external feeds (cloud IP ranges, threat
# intel, SaaS provider blocks) and geo_ip.py's IP2Location/ip2asn source
# files both need periodic refresh to stay useful -- a script passing every
# integrity check while running against a 4-month-old threat-intel feed is
# a real, silent risk this tool had no visibility into.
#
# Honest limitation: ip_dataset.py's real registry (ip_dataset.json) schema
# isn't available to verify field names against -- rather than guess at
# internal keys that might not match, this parses ip_dataset.py --list's
# own printed table (the one real, confirmed format seen in actual
# terminal output) via regex. This is inherently more fragile than reading
# structured JSON directly -- if ip_dataset.py's --list formatting changes,
# this parser breaks. If ip_dataset.py gains a machine-readable output mode
# (e.g. --list --json) in the future, this should be switched to use it
# instead of continuing to scrape decorative text.
DEFAULT_STALE_DAYS     = 60  # ip_dataset.py-managed feeds
DEFAULT_GEO_STALE_DAYS = 45  # geo_ip.py IP2Location/ip2asn source files

_IPDATASET_ROW_RE = re.compile(
    r'^\s*(ENT|STD)\s+(\S.*?)\s+'
    r'(ENTERPRISE|CLOUD|IAAS|SAAS|PARTNER|OTHER)\s+'
    r'(\d{8})\s+'
    r'([\d.]+)\s+'
    r'([\d,]+)\s+'
    r'(.*)$'
)


def check_ip_dataset_freshness(script='ip_dataset.py', stale_days=DEFAULT_STALE_DAYS):
    """Run `ip_dataset.py --list`, parse its printed table, flag any
    dataset whose Data Ver (YYYYMMDD) is older than stale_days.

    Returns (n_checked, n_stale, stale_rows) where stale_rows is a list of
    (tier, name, data_ver, age_days) tuples, sorted oldest-first.
    Returns (0, 0, []) if the script can't be found or run -- reported by
    the caller as a WARN, same bar as every other optional-check failure
    in this file, not a hard FAIL (a missing/unrunnable ip_dataset.py is
    already caught by the normal --version/--list tests elsewhere in
    TESTS; this function's only job is the age check, not existence).
    """
    if not os.path.isfile(script):
        return 0, 0, []

    try:
        r = subprocess.run([sys.executable, script, '--list'],
                            capture_output=True, text=True, timeout=30)
    except Exception:
        return 0, 0, []

    now = datetime.now()
    n_checked = 0
    stale = []

    for line in (r.stdout or '').splitlines():
        m = _IPDATASET_ROW_RE.match(line)
        if not m:
            continue
        tier, name, _cls, data_ver, _pyver, _rows, _rest = m.groups()
        try:
            dt = datetime.strptime(data_ver, '%Y%m%d')
        except ValueError:
            continue  # not a real date -- skip rather than guess
        n_checked += 1
        age_days = (now - dt).days
        if age_days > stale_days:
            stale.append((tier, name, data_ver, age_days))

    stale.sort(key=lambda t: -t[3])
    return n_checked, len(stale), stale


def check_geoip_freshness(dataset_dir='.', stale_days=DEFAULT_GEO_STALE_DAYS):
    """Check mtime of geo_ip.py's real source files under
    <dataset_dir>/ip_geo/ -- IP2Location LITE DB1/DB11, country info,
    ip2asn, and the optional US-geo supplement. Filenames match geo_ip.py's
    own DB1_NAME/DB11_NAME/COUNTRY_NAME/ASN_NAME/USGEO_NAME constants
    exactly, not guessed independently.

    Returns (n_checked, n_stale, n_missing, stale_rows) where stale_rows is
    a list of (filename, age_days) tuples for files that exist but are
    older than stale_days. Missing files are reported separately since
    "absent" and "stale" call for different remediation (download vs.
    refresh), and geo_ip.py already treats some of these as optional
    (US-geo supplement) so a missing file isn't automatically a problem.
    """
    ip_geo_dir = os.path.join(dataset_dir, 'ip_geo')
    files = {
        'IP2LOCATION-LITE-DB1.CIDR.CSV':        True,   # required
        'IP2LOCATION-LITE-DB11.CIDR.CSV':       True,   # required
        'IP2LOCATION-COUNTRY-INFORMATION.CSV':  True,   # required
        'ip2asn-v4.tsv':                        True,   # required
        'us_geo_networksdb.tsv':                False,  # optional supplement
    }

    now = time.time()
    n_checked = n_stale = n_missing = 0
    stale = []

    for fname, required in files.items():
        path = os.path.join(ip_geo_dir, fname)
        if not os.path.isfile(path):
            if required:
                n_missing += 1
            continue
        n_checked += 1
        age_days = int((now - os.path.getmtime(path)) / 86400)
        if age_days > stale_days:
            n_stale += 1
            stale.append((fname, age_days))

    stale.sort(key=lambda t: -t[1])
    return n_checked, n_stale, n_missing, stale


def print_freshness_section(ip_dataset_script, geo_dataset_dir,
                             stale_days, geo_stale_days):
    """Print the DATA FRESHNESS report section. Non-fatal -- everything
    here is a WARN, never counted toward n_fail, since stale data is an
    operational signal to act on, not a broken script."""
    print(f'{BLD}── DATA FRESHNESS ───────────────────────────────────{RST}')

    n_checked, n_stale, stale_rows = check_ip_dataset_freshness(
        ip_dataset_script, stale_days)
    if n_checked == 0:
        print(f'  {YEL}–{RST}  ip_dataset.py --list produced no parseable rows '
              f'(not found, or output format changed)')
    else:
        print(f'  ip_dataset.py: {n_checked} datasets checked, '
              f'{n_stale} older than {stale_days}d')
        for tier, name, data_ver, age in stale_rows[:10]:
            print(f'    {YEL}!{RST}  [{tier}] {name:<45}  v{data_ver}  '
                  f'({age}d old)')
        if len(stale_rows) > 10:
            print(f'    {YEL}...and {len(stale_rows) - 10} more{RST}')

    n_geo_checked, n_geo_stale, n_geo_missing, geo_stale_rows = \
        check_geoip_freshness(geo_dataset_dir, geo_stale_days)
    if n_geo_checked == 0 and n_geo_missing == 0:
        print(f'  {YEL}–{RST}  geo_ip.py ip_geo/ directory not found at '
              f'{os.path.join(geo_dataset_dir, "ip_geo")}')
    else:
        print(f'  geo_ip.py:     {n_geo_checked} source files checked, '
              f'{n_geo_stale} older than {geo_stale_days}d, '
              f'{n_geo_missing} required file(s) missing')
        for fname, age in geo_stale_rows:
            print(f'    {YEL}!{RST}  {fname:<45}  ({age}d old)')
        if n_geo_missing:
            print(f'    {RED}x{RST}  {n_geo_missing} required source file(s) '
                  f'missing -- run geo_ip.py --update')

    print()
    return n_stale + n_geo_stale + n_geo_missing


def main():
    p = argparse.ArgumentParser(
        description='CCD Platform toolset health check')
    p.add_argument('--fast', action='store_true',
                   help='Version/help checks only — skip dry-runs (~30s vs ~3min)')
    p.add_argument('--group', metavar='GROUP',
                   help='Run only one group: platform|shared|update|build|preprocess|generate')
    p.add_argument('--no-track', action='store_true',
                   help='Skip the integrity/version registry pass entirely')
    p.add_argument('--reset-registry', action='store_true',
                   help='Delete the existing registry and re-bootstrap from this run')
    p.add_argument('--registry', metavar='PATH', default=DEFAULT_REGISTRY,
                   help=f'Registry file path (default: {DEFAULT_REGISTRY})')
    p.add_argument('--skip-freshness', action='store_true',
                   help='Skip the ip_dataset.py / geo_ip.py data freshness check')
    p.add_argument('--stale-days', type=int, default=DEFAULT_STALE_DAYS,
                   help=f'ip_dataset.py-managed feeds older than this many days are '
                        f'flagged (default: {DEFAULT_STALE_DAYS})')
    p.add_argument('--geo-stale-days', type=int, default=DEFAULT_GEO_STALE_DAYS,
                   help=f'geo_ip.py source files older than this many days are '
                        f'flagged (default: {DEFAULT_GEO_STALE_DAYS})')
    p.add_argument('--ip-dataset-script', default='ip_dataset.py',
                   help='Path to ip_dataset.py (default: ip_dataset.py, cwd)')
    p.add_argument('--geo-dataset-dir', default='.',
                   help='Directory containing geo_ip.py\'s ip_geo/ subdirectory '
                        '(default: current directory)')
    p.add_argument('--version', action='version',
                   version=f'check_toolset.py v{__version__}')
    args = p.parse_args()

    if args.reset_registry and os.path.isfile(args.registry):
        os.remove(args.registry)
        print(f'{YEL}Registry reset: {args.registry} removed — re-bootstrapping.{RST}')

    print(f'\n{BLD}CCD Platform — Toolset Health Check  v{__version__}{RST}')
    print(f'  {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    print(f'  Working dir: {os.getcwd()}')
    if args.fast:
        print(f'  {YEL}Fast mode — dry-runs skipped{RST}')
    if args.group:
        print(f'  Group filter: {args.group}')
    print()

    results   = []
    n_pass    = 0
    n_fail    = 0
    n_skip    = 0
    n_warn    = 0
    current_group = None

    tests = [t for t in TESTS
             if not args.group or t[0] == args.group]

    integrity_fail_details = []
    if not args.no_track:
        (_n_base, _n_ok, _n_adv, integ_warn, integ_fail,
         integrity_fail_details) = run_integrity_pass(
            tests, args.registry, DEFAULT_HISTORY)
        n_fail += integ_fail
        n_warn += integ_warn

    for group, script, test_args, expected, description in tests:
        if group != current_group:
            current_group = group
            print(f'{BLD}── {group.upper()} ─────────────────────────────────────{RST}')

        passed, elapsed, snippet, error = run_test(
            script, test_args, expected, description, fast=args.fast)

        if passed is None:
            n_skip += 1
            print(f'  {YEL}–{RST}  {description:<50}  skipped (fast mode)')
            results.append((group, description, 'SKIP', 0, '', ''))
            continue

        if passed:
            n_pass += 1
            t_str = f'{elapsed:.1f}s' if elapsed > 0.5 else ''
            print(f'  {GRN}✓{RST}  {description:<50}  {CYN}{t_str}{RST}')
            results.append((group, description, 'PASS', elapsed, '', ''))
        else:
            n_fail += 1
            print(f'  {RED}✗{RST}  {description:<50}  {RED}FAIL{RST}')
            if snippet:
                for line in snippet.splitlines()[:4]:
                    print(f'      {RED}{line}{RST}')
            if error:
                print(f'      {RED}stderr: {error[:120]}{RST}')
            results.append((group, description, 'FAIL', elapsed, snippet, error))

    # ── Expected scripts (warn only) ─────────────────────────────────────────
    if not args.group or args.group in ('build', 'update'):
        expected_any = False
        for script, expected_ver in _EXPECTED:
            if not os.path.isfile(script):
                if not expected_any:
                    print(f'{BLD}── EXPECTED (warn only) ─────────────────────────────{RST}')
                    expected_any = True
                print(f'  {YEL}–{RST}  {script:<50}  not on disk (target {expected_ver})')
        if expected_any:
            print()

    # ── Data freshness (v1.15.0) ─────────────────────────────────────────────
    n_freshness_warn = 0
    if not args.skip_freshness:
        n_freshness_warn = print_freshness_section(
            args.ip_dataset_script, args.geo_dataset_dir,
            args.stale_days, args.geo_stale_days)
        n_warn += n_freshness_warn

    # ── Summary ───────────────────────────────────────────────────────────────
    total = n_pass + n_fail
    print()
    print(f'{BLD}═══ RESULTS ════════════════════════════════════════{RST}')
    print(f'  {GRN}PASS : {n_pass:>3}{RST}')
    if n_fail:
        print(f'  {RED}FAIL : {n_fail:>3}{RST}')
    if n_warn:
        print(f'  {YEL}WARN : {n_warn:>3}{RST}  (integrity + data freshness — flagged, not counted as failing)')
    if n_skip:
        print(f'  {YEL}SKIP : {n_skip:>3}{RST}')
    print(f'  Total: {total:>3} tested  ({n_pass}/{total} passed)')

    if n_fail:
        print(f'\n{RED}Failed tests:{RST}')
        for group, desc, status, _, snip, err in results:
            if status == 'FAIL':
                print(f'  {RED}✗{RST}  [{group}] {desc}')
        for group, desc in integrity_fail_details:
            print(f'  {RED}✗{RST}  [{group}] {desc}')
    else:
        print(f'\n  {GRN}{BLD}All tests passed ✓{RST}')

    print()
    sys.exit(0 if n_fail == 0 else 1)


if __name__ == '__main__':
    main()
