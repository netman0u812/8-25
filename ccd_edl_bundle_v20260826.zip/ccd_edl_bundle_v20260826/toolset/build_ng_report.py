#!/usr/bin/env python3
# =============================================================================
#  build_ng_report.py
# =============================================================================
#  WHAT THIS SCRIPT DOES (read this first)
#  -----------------------------------------------------------------------------
#  build_network_groups.py produces a "network object catalog" CSV that lists
#  every firewall network group in the CCD source hierarchy:
#       Tier-1  = business-unit / business-function class (NG-DATACENTER, NG-RETAIL...)
#       Tier-2  = the specific site/location (keyed by SITE_CODE) OR, for retail,
#                 a region group (NG-RETAIL-PHARMA-EAST) and state group
#                 (NG-RETAIL-PHARMA-TX)
#       Tier-3  = the actual CIDR / /26 address objects (the only tier with IPs)
#
#  This script turns that flat CSV into ONE self-contained, interactive HTML
#  page: a drill-down explorer (click a Tier-1 class to see its locations, click
#  a location to see its CIDRs), a live search box, and summary statistics.
#  No web server, no internet, no dependencies — just open the .html file.
#
#  WHY A SEPARATE SCRIPT
#  -----------------------------------------------------------------------------
#  The grouping builder owns the DATA. This owns the PRESENTATION. Keeping them
#  apart means the report can be regenerated/restyled without touching the
#  build logic, and the same catalog can feed both iplookup and this report.
#
#  HOW TO RUN IT
#  -----------------------------------------------------------------------------
#     python build_ng_report.py --catalog network_object_catalog_v20260530.csv
#     python build_ng_report.py --catalog <file> --out my_report.html
#
#  The catalog is the #-stamped CSV from build_network_groups.py. This script
#  skips those #VERSION/#STEM header lines automatically.
# =============================================================================

from __future__ import annotations
import argparse        # command-line flags

# ---------------------------------------------------------------------------
# FILE DISCOVERY HELPERS
# ---------------------------------------------------------------------------

def _latest(directory, pattern):
    """
    Return the latest versioned file matching glob pattern in directory.
    Sorts by (date, revision) numerically so r18 > r9 > bare.
    Pattern: vYYYYMMDD or vYYYYMMDDrN
    """
    import glob, re as _re
    def _ver_key(path):
        name = os.path.basename(path)
        m = _re.search(r'v(\d{8})(?:r(\d+))?', name)
        if m:
            return (int(m.group(1)), int(m.group(2) or 0))
        return (0, 0)
    matches = glob.glob(os.path.join(directory, pattern))
    return max(matches, key=_ver_key) if matches else None


def discover_inputs(base="."):
    """
    Auto-discover the latest version of every CCD Platform input dataset
    from the standard directory layout under base:
        {base}/ipam-db/            IPAM, LM, SNAT, CPC, EIF datasets
        {base}/network-groups/     network_object_catalog, internet_segments
        {base}/processed_outputs/  canonical_app_objects, EIR
    Returns a dict keyed by input name; values are paths or None.
    """
    ipam_dir = os.path.join(base, "ipam-db")
    ng_dir   = os.path.join(base, "network-groups")
    proc_dir = os.path.join(base, "processed_outputs")

    # v1.3.1: prefer latest versioned Net_Group/NG-YYYYMMDD_vN/ catalog
    _ng_base = os.path.join(base, "Net_Group")
    if os.path.isdir(_ng_base):
        import re as _re
        _versioned = sorted(
            [d for d in os.listdir(_ng_base)
             if _re.match(r'^NG-\d{8}_v\d+$', d)],
            key=lambda d: (
                _re.search(r'(\d{8})_v(\d+)', d).group(1),
                int(_re.search(r'_v(\d+)$', d).group(1))
            )
        )
        if _versioned:
            _latest_ng = os.path.join(_ng_base, _versioned[-1])
            _vc = _latest(_latest_ng, "network_object_catalog_v*.csv")
            if _vc:
                ng_dir = _latest_ng  # override to versioned output dir
    lm_canonical = os.path.join(ipam_dir, "location_master_table.csv")
    lm = lm_canonical if os.path.exists(lm_canonical) \
         else _latest(ipam_dir, "location_master_v*.csv")
    return {
        "ipam":          _latest(ipam_dir,  "all_IP_networks_v*.csv"),
        "lm":            lm,
        "retail":        _latest(ipam_dir,  "retail_networks_v*.csv"),
        "inet_segments": _latest(ng_dir,    "internet_segments_v*.csv"),
        "cpc_services":  _latest(ipam_dir,  "ent-ipdataset-CPC-CORE-SERVICES-v*.csv"),
        "app_objects":   _latest(proc_dir,  "canonical_app_objects_v*.csv"),
        "catalog":       _latest(ng_dir,    "network_object_catalog_v*.csv"),
        "snat":          _latest(ipam_dir,  "ent-ipdataset-FW-SNAT-POOLS-v*.csv"),
        "eif":           _latest(ipam_dir,  "ent-ipdataset-INTERNET-FACING-v*.csv"),
        "eir":           _latest(proc_dir,  "external_ip_registry_v*.csv"),
    }


def resolve_input(cli_value, discovered_value, name, required=True):
    """
    Resolve an input path: prefer explicit CLI value, fall back to auto-discovery.
    Prints the resolved path so every run is auditable. Exits on required-missing.
    """
    path = cli_value or discovered_value
    if path and os.path.exists(path):
        print(f"  {name:<22s} {path}  [{'arg' if cli_value else 'auto'}]")
        return path
    if required:
        label = path or "(no match in default locations)"
        print(f"  {name:<22s} NOT FOUND: {label}", file=sys.stderr)
        sys.exit(1)
    if path:
        print(f"  {name:<22s} skipped (not found)")
    return None

import csv             # read the catalog CSV
import json            # embed the data as JSON inside the HTML for the JS to use
import html            # escape any text that goes into the page
import os              # file paths
import sys             # clean error exit
import datetime        # build timestamp

__version__ = "1.3.2"
# v1.3.1 — discover_inputs() now finds catalog in ./Net_Group/NG-YYYYMMDD_vN/
#           (latest versioned output from build_network_groups.py v1.7.5+).
#           HTML report written into same versioned directory by default.


def read_catalog(path: str):
    """
    Read the #-stamped network_object_catalog CSV into a list of dict rows.

    WHAT IT DOES
    ------------
    Opens the catalog, skips the leading lines that start with '#' (the
    #STEM / #VERSION / #ROWS / #TOOL / #END_HEADER stamps), then parses the
    real CSV header and rows. Also pulls the #VERSION value out so the report
    can show which catalog version it was built from.

    PARAMETERS
    ----------
    path : str
        Path to network_object_catalog_v*.csv.

    RETURNS
    -------
    tuple(list[dict], str)
        (rows, catalog_version)
    """
    with open(path, newline="", encoding="utf-8-sig") as f:
        lines = f.readlines()

    # Find the catalog version stamp and the first real (non-#) header line.
    version = "unknown"
    header_idx = 0
    for i, line in enumerate(lines):
        if line.startswith("#VERSION="):
            version = line.split("=", 1)[1].strip()
        if not line.startswith("#") and "," in line:
            header_idx = i
            break

    reader = csv.DictReader(lines[header_idx:])
    rows = [r for r in reader if r.get("OBJECT_NAME")]
    return rows, version


def build_tree(rows):
    """
    Reorganize the flat catalog rows into a nested tree the UI can drill into.

    WHAT IT DOES
    ------------
    The catalog is flat (one row per object, with a PARENT pointer). This walks
    those rows and builds:
        tier1 -> { meta, children: [tier2 names] }
        tier2 -> { meta, children: [tier3 / state-group names] }
        leaf  -> { meta, cidrs: [...] }
    For retail, the chain is Tier-1 (NG-RETAIL) -> region group -> state group
    -> /26 objects, so region groups are treated as an intermediate parent.

    WHY IT WORKS THIS WAY
    ---------------------
    Building the parent->children map once here keeps the JavaScript simple:
    the page just renders whatever children a node has, regardless of whether
    the node is a datacenter location or a retail region.

    PARAMETERS
    ----------
    rows : list[dict]
        Catalog rows.

    RETURNS
    -------
    dict
        A JSON-serializable structure: {"nodes": {...}, "roots": [...]}
        where each node has name, tier, klass, member_type, cidrs, children.
    """
    nodes = {}

    # First pass: create a node for every object.
    for r in rows:
        name = r["OBJECT_NAME"]
        tier = str(r.get("TIER", ""))
        # CIDR leaves: MEMBER_TYPE 'cidr' (single /26) or 'cidr-list' (group of CIDRs)
        cidrs = []
        mt = (r.get("MEMBER_TYPE") or "").strip()
        val = (r.get("VALUE") or "").strip()
        if mt == "cidr":
            cidrs = [val] if val else []
        elif mt == "cidr-list":
            cidrs = [c for c in val.split(";") if c]
        nodes[name] = {
            "name": name,
            "tier": tier,
            "klass": r.get("CLASS", ""),
            "member_type": mt,
            "parent": (r.get("PARENT") or "").strip(),
            "cidr_count": r.get("CIDR_COUNT", ""),
            "cidrs": cidrs,
            "children": [],
        }

    # Second pass: wire children onto parents (skip CIDR-literal members, which
    # are stored on the node itself, not as separate nodes).
    for r in rows:
        name = r["OBJECT_NAME"]
        parent = (r.get("PARENT") or "").strip()
        if parent and parent in nodes:
            nodes[parent]["children"].append(name)

    # Roots = Tier-1 nodes (tier exactly '1') that have at least one child.
    # Tier-1 nodes with no children are aggregator labels only (e.g. NG-CORPORATE
    # which groups NG-CORP-EAST/INTL/WEST but those sub-groups are themselves roots).
    # Showing empty tier-1 nodes produces blank entries in the left tree. v1.3.2
    roots = sorted([n for n, d in nodes.items()
                    if d["tier"] == "1" and len(d["children"]) > 0])
    # Sort children for stable display.
    for d in nodes.values():
        d["children"].sort()
    return {"nodes": nodes, "roots": roots}


def compute_stats(rows, tree):
    """
    Compute the summary numbers shown in the report header.

    WHAT IT DOES
    ------------
    Counts Tier-1 classes, Tier-2 locations, retail region/state groups, total
    CIDR/­/26 objects, and a per-Tier-1 child count for the overview chart.

    PARAMETERS
    ----------
    rows : list[dict]
    tree : dict (from build_tree)

    RETURNS
    -------
    dict
        Summary numbers + a list of (class, location_count, cidr_count) for the chart.
    """
    nodes = tree["nodes"]
    t1 = [n for n, d in nodes.items() if d["tier"] == "1"]
    t2 = [n for n, d in nodes.items() if d["tier"] == "2"]
    region = [n for n, d in nodes.items() if d["tier"] == "2-region"]
    state = [n for n, d in nodes.items() if d["tier"] == "2-state"]
    leaves = [n for n, d in nodes.items() if d["cidrs"]]
    total_cidrs = sum(len(d["cidrs"]) for d in nodes.values())

    # Per-Tier-1: count descendant CIDRs and direct children, for the bar chart.
    def descendant_cidrs(name, seen=None):
        if seen is None:
            seen = set()
        if name in seen:
            return 0
        seen.add(name)
        d = nodes.get(name)
        if not d:
            return 0
        total = len(d["cidrs"])
        for c in d["children"]:
            total += descendant_cidrs(c, seen)
        return total

    per_class = []
    for n in sorted(t1):
        per_class.append({
            "klass": n,
            "children": len(nodes[n]["children"]),
            "cidrs": descendant_cidrs(n),
        })

    return {
        "tier1": len(t1),
        "tier2": len(t2),
        "region": len(region),
        "state": len(state),
        "leaves": len(leaves),
        "total_cidrs": total_cidrs,
        "per_class": per_class,
    }


def render_html(tree, stats, version, catalog_name):
    """
    Produce the full self-contained HTML document as a string.

    WHAT IT DOES
    ------------
    Embeds the tree + stats as JSON inside a <script> tag, then ships a compact
    vanilla-JS UI that renders the drill-down, search, and summary. All CSS and
    JS are inline so the file works offline with no dependencies.

    DESIGN
    ------
    Operational NOC aesthetic: dark slate ground, monospace for object names and
    CIDRs (they are identifiers, not prose), a single cyan accent for interaction,
    amber for retail, restrained. Dense and legible, not decorative.

    PARAMETERS
    ----------
    tree : dict
    stats : dict
    version : str
    catalog_name : str

    RETURNS
    -------
    str
        The complete HTML document.
    """
    payload = json.dumps({"tree": tree, "stats": stats}, separators=(",", ":"))
    built = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    # The HTML/CSS/JS. Braces that belong to CSS/JS are doubled so .format()
    # only substitutes the named fields.
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CCD Network Object Catalog — v{version}</title>
<style>
  :root {{
    --bg:#0d1117; --panel:#161b22; --panel2:#1c2333; --line:#2d3748;
    --ink:#e6edf3; --muted:#8b949e; --cyan:#39d0d8; --amber:#e3b341;
    --green:#3fb950; --violet:#a371f7; --red:#f85149;
    --mono:"SF Mono", "JetBrains Mono",Menlo,Consolas,monospace;
    --sans:"IBM Plex Sans",-apple-system,Segoe UI,sans-serif;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--ink); font-family:var(--sans);
    font-size:14px; line-height:1.5; }}
  header {{ padding:22px 28px 16px; border-bottom:1px solid var(--line);
    background:linear-gradient(180deg,#11161f,#0d1117); }}
  h1 {{ margin:0 0 2px; font-size:19px; letter-spacing:.3px; font-weight:600; }}
  h1 .tag {{ color:var(--cyan); }}
  .sub {{ color:var(--muted); font-size:12.5px; }}
  .stats {{ display:flex; flex-wrap:wrap; gap:14px; padding:16px 28px;
    border-bottom:1px solid var(--line); }}
  .stat {{ background:var(--panel); border:1px solid var(--line); border-radius:9px;
    padding:11px 16px; min-width:104px; }}
  .stat .n {{ font-family:var(--mono); font-size:21px; font-weight:600; }}
  .stat .l {{ color:var(--muted); font-size:11px; text-transform:uppercase;
    letter-spacing:.6px; margin-top:2px; }}
  .stat.cyan .n {{ color:var(--cyan); }} .stat.amber .n {{ color:var(--amber); }}
  .stat.green .n {{ color:var(--green); }} .stat.violet .n {{ color:var(--violet); }}
  .wrap {{ display:grid; grid-template-columns:340px 1fr; gap:0; height:calc(100vh - 200px); }}
  .left {{ border-right:1px solid var(--line); overflow:auto; padding:14px; }}
  .right {{ overflow:auto; padding:18px 24px; }}
  .search {{ width:100%; padding:9px 12px; background:var(--panel); color:var(--ink);
    border:1px solid var(--line); border-radius:8px; font-family:var(--mono);
    font-size:13px; margin-bottom:12px; }}
  .search:focus {{ outline:none; border-color:var(--cyan); }}
  .t1 {{ margin-bottom:4px; }}
  .t1 > .row {{ display:flex; align-items:center; gap:8px; padding:8px 10px;
    border-radius:7px; cursor:pointer; font-weight:600; }}
  .t1 > .row:hover {{ background:var(--panel2); }}
  .t1 .row .cnt {{ margin-left:auto; font-family:var(--mono); font-size:11px;
    color:var(--muted); }}
  .caret {{ width:9px; color:var(--muted); transition:transform .12s; display:inline-block; }}
  .open > .row .caret {{ transform:rotate(90deg); }}
  .kids {{ display:none; margin:2px 0 6px 16px; border-left:1px solid var(--line);
    padding-left:8px; }}
  .open > .kids {{ display:block; }}
  .t2 {{ padding:5px 9px; border-radius:6px; cursor:pointer; font-family:var(--mono);
    font-size:12px; display:flex; gap:8px; align-items:center; }}
  .t2:hover {{ background:var(--panel2); }}
  .t2.sel {{ background:rgba(57,208,216,.12); color:var(--cyan); }}
  .t2 .cnt {{ margin-left:auto; color:var(--muted); font-size:11px; }}
  .badge {{ font-size:9.5px; padding:1px 6px; border-radius:10px; text-transform:uppercase;
    letter-spacing:.5px; font-family:var(--sans); }}
  .b-region {{ background:rgba(227,179,65,.18); color:var(--amber); }}
  .b-state {{ background:rgba(63,185,80,.16); color:var(--green); }}
  .b-loc {{ background:rgba(57,208,216,.14); color:var(--cyan); }}
  .b-inet {{ background:rgba(99,102,241,.25); color:#818cf8; }}
  .chip-t4 {{ border-color:rgba(99,102,241,.3); }}
  .t4-section {{ margin:12px 0 4px; border-top:1px solid var(--border); padding-top:8px; }}
  .t4-hdr {{ font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); margin-bottom:6px; }}
  .t4-group {{ margin-bottom:16px; }}
  .t4-grp-hdr {{ font-size:12px; font-weight:600; color:var(--muted); margin-bottom:8px; padding:4px 0; border-bottom:1px solid var(--border); }}
  .detail-h {{ font-family:var(--mono); font-size:16px; margin:0 0 4px; }}
  .detail-sub {{ color:var(--muted); font-size:12.5px; margin-bottom:16px; }}
  .cidrs {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    gap:7px; }}
  .cidr {{ background:var(--panel); border:1px solid var(--line); border-radius:7px;
    padding:8px 11px; font-family:var(--mono); font-size:12.5px; }}
  .cidr .o {{ color:var(--muted); font-size:10.5px; }}
  .empty {{ color:var(--muted); font-style:italic; padding:40px; text-align:center; }}
  .chip {{ display:inline-block; background:var(--panel); border:1px solid var(--line);
    border-radius:6px; padding:3px 9px; margin:2px; font-family:var(--mono);
    font-size:11.5px; cursor:pointer; }}
  .chip:hover {{ border-color:var(--cyan); color:var(--cyan); }}
  footer {{ padding:10px 28px; color:var(--muted); font-size:11px;
    border-top:1px solid var(--line); }}
</style>
</head>
<body>
<header>
  <h1>CCD <span class="tag">Network Object Catalog</span></h1>
  <div class="sub">Source: {catalog} &nbsp;·&nbsp; catalog v{version} &nbsp;·&nbsp; built {built}
    &nbsp;·&nbsp; Tier-1 business class → location / retail region+state → /26 CIDR objects</div>
</header>
<div class="stats" id="stats"></div>
<div class="wrap">
  <div class="left">
    <input class="search" id="q" placeholder="search object / CIDR / class…" autocomplete="off">
    <div id="tree"></div>
  </div>
  <div class="right" id="detail">
    <div class="empty">Select a class on the left, then a location to view its CIDR objects.</div>
  </div>
</div>
<footer>CCD Platform · build_ng_report.py v{rv} · network-grouping model: LOCATION × IP · retail = function × region × state · zero EDLs</footer>
<div id="t4panel" style="padding:16px 24px;border-top:1px solid var(--border);background:var(--bg2)"></div>
<script>
const DATA = {payload};
const N = DATA.tree.nodes, ROOTS = DATA.tree.roots, S = DATA.stats;

// ---- summary stats ----
const statDefs = [
  ["tier1","Tier-1 classes","cyan"],
  ["tier2","Site locations","violet"],
  ["region","Retail regions","amber"],
  ["state","Retail states","amber"],
  ["leaves","CIDR objects","green"],
  ["total_cidrs","Total CIDRs","green"],
];
document.getElementById('stats').innerHTML = statDefs.map(([k,l,c])=>
  `<div class="stat ${{c}}"><div class="n">${{(S[k]||0).toLocaleString()}}</div><div class="l">${{l}}</div></div>`
).join('');

// ---- helpers ----
function badge(node){{
  if(node.tier==='2-region')  return '<span class="badge b-region">region</span>';
  if(node.tier==='2-state')   return '<span class="badge b-state">state</span>';
  if(node.tier==='2')         return '<span class="badge b-loc">site</span>';
  if(node.tier==='4-inet')    return '<span class="badge b-inet">inet-seg</span>';
  if(node.tier==='4-cpc')     return '<span class="badge b-cpc">cpc-svc</span>';
  if(node.tier==='4-app')     return '<span class="badge b-app">app</span>';
  return '';
}}
function descCidrs(name, seen){{
  seen=seen||new Set(); if(seen.has(name)) return 0; seen.add(name);
  const d=N[name]; if(!d) return 0;
  let t=d.cidrs.length; for(const c of d.children) t+=descCidrs(c,seen); return t;
}}

// ---- left tree (Tier-1 -> children) ----
function renderTree(filter){{
  const host=document.getElementById('tree'); host.innerHTML='';
  const f=(filter||'').toLowerCase();
  ROOTS.forEach(r1=>{{
    const d=N[r1];
    // filter: show class if it or any descendant matches
    if(f && !matchTree(r1,f)) return;
    const el=document.createElement('div'); el.className='t1';
    el.innerHTML=`<div class="row"><span class="caret">▶</span>${{r1}}
      <span class="cnt">${{descCidrs(r1).toLocaleString()}} cidr</span></div>
      <div class="kids"></div>`;
    const kids=el.querySelector('.kids');
    d.children.forEach(c2=>{{
      if(f && !matchTree(c2,f) && !r1.toLowerCase().includes(f)) return;
      kids.appendChild(t2row(c2,f));
    }});
    el.querySelector('.row').onclick=()=>el.classList.toggle('open');
    if(f) el.classList.add('open');
    host.appendChild(el);
  }});
}}
function t2row(name,f){{
  const d=N[name]; const div=document.createElement('div');
  div.className='t2';
  div.innerHTML=`${{badge(d)}}<span>${{name}}</span><span class="cnt">${{descCidrs(name).toLocaleString()}}</span>`;
  div.onclick=(e)=>{{e.stopPropagation(); selectNode(name);
    document.querySelectorAll('.t2.sel').forEach(x=>x.classList.remove('sel'));
    div.classList.add('sel');}};
  return div;
}}
function matchTree(name,f){{
  if(name.toLowerCase().includes(f)) return true;
  const d=N[name]; if(!d) return false;
  if(d.cidrs.some(c=>c.toLowerCase().includes(f))) return true;
  return d.children.some(c=>matchTree(c,f));
}}

// ---- right detail pane ----
function selectNode(name){{
  const d=N[name]; const host=document.getElementById('detail');
  if(!d){{host.innerHTML='<div class="empty">not found</div>';return;}}
  let body=`<div class="detail-h">${{name}} ${{badge(d)}}</div>
    <div class="detail-sub">class ${{d.klass||'—'}} · ${{descCidrs(name).toLocaleString()}} CIDR objects below this node</div>`;
  // If this node has child groups (region->states, or state has none), show them as chips.
  const childGroups=d.children.filter(c=>N[c] && N[c].tier && N[c].tier.startsWith('2'));
  if(childGroups.length){{
    body+='<div style="margin-bottom:16px">'+childGroups.map(c=>
      `<span class="chip" onclick="selectNode('${{c}}')">${{c}} <span style="color:var(--muted)">${{descCidrs(c)}}</span></span>`
    ).join('')+'</div>';
  }}
  // Tier-4 children (inet/cpc/app objects parented to this Tier-2 node)
  const t4Groups=d.children.filter(c=>N[c] && N[c].tier && N[c].tier.startsWith('4-'));
  if(t4Groups.length){{
    const byClass={{'4-inet':[]}};
    t4Groups.forEach(c=>{{const t=N[c].tier; if(byClass[t]) byClass[t].push(c);}});
    const t4labels={{'4-inet':'Internet Segments'}};
    ['4-inet'].forEach(cls=>{{
      if(!byClass[cls].length) return;
      body+=`<div class="t4-section"><div class="t4-hdr">${{t4labels[cls]}}</div>`;
      body+=byClass[cls].map(c=>`<span class="chip chip-t4" onclick="selectNode('${{c}}')">${{badge(N[c])}} ${{c}} <span style="color:var(--muted)">${{N[c].cidr_count}}</span></span>`).join('');
      body+='</div>';
    }});
  }}
  // Collect the actual CIDRs under this node (direct + via Tier-3 children).
  const cidrs=collectCidrs(name);
  if(cidrs.length){{
    body+=`<div class="cidrs">`+cidrs.map(c=>
      `<div class="cidr">${{c.cidr}}<div class="o">${{c.obj}}</div></div>`).join('')+`</div>`;
  }} else if(!childGroups.length){{
    body+='<div class="empty">No CIDR objects directly under this node.</div>';
  }}
  host.innerHTML=body;
}}
function collectCidrs(name, seen){{
  seen=seen||new Set(); if(seen.has(name)) return []; seen.add(name);
  const d=N[name]; if(!d) return [];
  let out=d.cidrs.map(c=>({{cidr:c,obj:name}}));
  // descend into Tier-3 children (CIDR groups / objects), but not into other
  // Tier-2 groups (those are shown as chips to drill into separately) UNLESS
  // this is a state group whose children are the /26 objects themselves.
  d.children.forEach(c=>{{
    const cd=N[c]; if(!cd) return;
    if(cd.tier==='3' || cd.cidrs.length) out=out.concat(collectCidrs(c,seen));
  }});
  // dedupe by cidr
  const map={{}}; out.forEach(o=>map[o.cidr]=o);
  return Object.values(map).sort((a,b)=>a.cidr.localeCompare(b.cidr));
}}

document.getElementById('q').addEventListener('input',e=>renderTree(e.target.value));
renderTree('');

// ---- Tier-4 orphan panel (INET/CPC/APP with no Tier-2 parent) ----
function renderTier4Panel(){{
  const orphans={{'4-inet':[]}};
  Object.entries(N).forEach(([name,d])=>{{
    if(d.tier && d.tier.startsWith('4-') && (!d.parent || !N[d.parent])){{
      if(orphans[d.tier]) orphans[d.tier].push(name);
    }}
  }});
  const total=Object.values(orphans).reduce((s,a)=>s+a.length,0);
  if(!total) return;
  const labels={{'4-inet':'Internet Segments (SNAT+EIF)'}};
  const host=document.getElementById('t4panel');
  if(!host) return;
  let html='<div style="font-size:13px;font-weight:600;margin-bottom:12px;color:var(--fg)">Tier-4 Objects</div>';
  ['4-inet'].forEach(cls=>{{
    if(!orphans[cls].length) return;
    html+=`<div class="t4-group"><div class="t4-grp-hdr">${{labels[cls]}} <span class="cnt">${{orphans[cls].length}}</span></div>`;
    html+=orphans[cls].sort().map(n=>`<span class="chip chip-t4" onclick="selectNode('${{n}}')">${{badge(N[n])}} ${{n}} <span style="color:var(--muted)">${{N[n].cidr_count}}</span></span>`).join('');
    html+='</div>';
  }});
  host.innerHTML=html;
}}
renderTier4Panel();
</script>
</body>
</html>""".format(version=html.escape(version), catalog=html.escape(catalog_name),
                  built=built, payload=payload, rv=__version__)


def main():
    ap = argparse.ArgumentParser(
        description="Generate a self-contained interactive HTML report from a "
                    "network_object_catalog CSV (build_network_groups.py output).")
    ap.add_argument("--catalog", default=None, help="network_object_catalog_v*.csv (auto-discovered if omitted)")
    ap.add_argument("--base", default=".", help="CCD Platform root directory for auto-discovery (default: .)")
    ap.add_argument("--out", help="output HTML path (default: alongside catalog)")
    ap.add_argument("--version", action="store_true", help="print version and exit")
    args = ap.parse_args()

    if args.version:
        print(f"build_ng_report.py v{__version__}")
        return

    # ── File discovery ──────────────────────────────────────────────────────
    print("Input files:")
    disc = discover_inputs(args.base)
    args.catalog = resolve_input(args.catalog, disc["catalog"], "network_object_catalog", required=True)
    print()

    rows, cat_version = read_catalog(args.catalog)
    if not rows:
        sys.exit("ERROR: no rows parsed from catalog (check the file).")

    tree = build_tree(rows)
    stats = compute_stats(rows, tree)
    doc = render_html(tree, stats, cat_version, os.path.basename(args.catalog))

    # If --out not specified, write report into the same versioned Net_Group dir
    # as the catalog (e.g. ./Net_Group/NG-20260610_v1/ng_report_20260610.html)
    _out_raw = args.out or os.path.dirname(args.catalog) or "."
    if os.path.isdir(_out_raw) or _out_raw.endswith(os.sep) or _out_raw.endswith("/"):
        _stem = f"ng_report_{cat_version}" if cat_version else "ng_report"
        out = os.path.join(_out_raw, f"{_stem}.html")
    else:
        out = _out_raw
    with open(out, "w", encoding="utf-8") as f:
        f.write(doc)

    print(json.dumps({
        "version": __version__,
        "catalog": args.catalog,
        "catalog_version": cat_version,
        "tier1_classes": stats["tier1"],
        "site_locations": stats["tier2"],
        "retail_regions": stats["region"],
        "retail_states": stats["state"],
        "cidr_objects": stats["leaves"],
        "total_cidrs": stats["total_cidrs"],
        "report": out,
    }, indent=2))


if __name__ == "__main__":
    main()
