#!/usr/bin/env python3
"""
build_object_pipeline.py  v1.8.2  —  CCD Platform
==========================================
Bundles the full object pipeline into a single command:

  Stage 0  build_cpc_service_catalog.py    →  CPC-CORE-SERVICES (prerequisite)
           build_canonical_app_objects.py  →  canonical_app_objects (prerequisite)
           build_user_access_objects.py    →  canonical_user_access_objects (prerequisite)
           build_custom_objects.py         →  canonical_custom_objects (optional — CUSTOM
                                               OBJECT_TYPE, curated abstractions that don't
                                               fit APP/INFRA/SERVICE/DELIVERY/USER_ACCESS)
  Stage 1  build_network_groups.py         →  Net_Group/NG-YYYYMMDD_vN/
  Stage 1.5 build_external_ng.py          →  External_NG/NG-YYYYMMDD_vN/  (External-NG EDL slot)
  Stage 1.6 build_partner_ng.py           →  Partner_NG/NG-YYYYMMDD_vN/   (Partner-NG EDL slot)
  Stage 2  build_ng_report.py             →  ng_report_YYYYMMDD.html (date-stamped)
  Stage 2.5 build_ipdataset_objects.py    →  Net_Object/IPDATASET-vDATE/  (Cloud Services)
  Stage 2.6 build_geo_block_objects.py    →  Net_Object/IPDATASET-vDATE/  (Geo-Block EDL)
  Stage 2.7 build_ip_classification_objects.py → Net_Object/IPDATASET-vDATE/
                                              (external_no: CVS_INTERNET_FACING_*, CVS_INTERNAL_PUBLIC_*
                                               partner_no:  VPN_PEER_*, PARTNER_PROTECTED_*, CVS_PROTECTED_*
                                               fw_infra:    FW_INTF_*, F5_VIP_*, ZPA_CONNECTOR_*)
  Stage 3  build_service_objects.py        →  Net_Object/SO-YYYYMMDD_vN/
  Stage 4  build_svc_report.py            →  svc_report_YYYYMMDD.html (date-stamped)
  Stage 5  build_edl_catalog.py           →  edl_catalog.html (rebuilt with new versions)
  Stage 6  generate_csna_hostgroups.py    →  csna_output/ (Stealthwatch host groups)
  Stage 7  collect-edl_bundle.sh          →  ccd_objects_YYYYMMDD.zip  (optional --collect flag)
  Stage 8  object-viewer-web-service.sh   (optional --serve flag)

Gates:
  - Aborts after Stage 1 if ng_overlap_violations.csv contains HIGH violations.
  - Stage 6 (CSNA) runs continuity_check() internally — FAIL on duplicate IPs
    causes non-zero exit; pipeline logs the failure but does not abort (CSNA
    output is Stealthwatch-bound, not PA-bound — non-blocking for PA deployment).
  - Each stage must exit 0 before the next stage runs (except Stage 6).
  - Stages 1.5 and 1.6 are optional, same pattern as 2.5/2.6: silently skipped
    if the script isn't found on disk, non-fatal (warn + continue) if the
    script fails. Neither blocks Stage 2 or later.
  - All output is logged to pipeline_run_YYYYMMDD_HHMMSS.log alongside this script.

Usage:
  python3 build_object_pipeline.py                  # full run, auto-discover
  python3 build_object_pipeline.py --dry-run        # counts only, no files written
  python3 build_object_pipeline.py --ng-only        # Stages 1-2 only
  python3 build_object_pipeline.py --svc-only       # Stages 3-4 only (NG dir must exist)
  python3 build_object_pipeline.py --obj-only       # Stage 0 only (canonical objects)
  python3 build_object_pipeline.py --skip-obj       # Skip Stage 0 (objects already built)
  python3 build_object_pipeline.py --skip-csna      # Skip Stage 6 (CSNA generation)
  python3 build_object_pipeline.py --skip-cloud     # Skip Stage 2.5 (ipdataset objects)
  python3 build_object_pipeline.py --skip-geo       # Skip Stage 2.6 (geo-block objects)
  python3 build_object_pipeline.py --skip-external-ng  # Skip Stage 1.5 (External-NG)
  python3 build_object_pipeline.py --skip-partner-ng   # Skip Stage 1.6 (Partner-NG)
  python3 build_object_pipeline.py --serve          # launch web server after pipeline
  python3 build_object_pipeline.py --serve --port 9090
  python3 build_object_pipeline.py --collect           # run collect-edl_bundle.sh after pipeline
  python3 build_object_pipeline.py --base ~/Documents/IP_Lookup
  python3 build_object_pipeline.py --no-edl         # suppress EDL export (EDL is ON by default)

Changelog:
  v1.8.2  2026-07-23  Bugfix (correction to v1.8.1): Stage 0's --egress-dir
                      for build_custom_objects.py was pointed at proc_dir
                      (processed_outputs) — wrong.
                      build_IP_Network_Egress_FW_topology.py's own default
                      --out-ipam-dir is <base>/FW-Egress_Out, verified by
                      reading that script directly rather than assuming
                      co-location with processed_outputs. Now points at
                      base/FW-Egress_Out. If build_IP_Network_Egress_FW_
                      topology.py is ever run with --out-ipam-dir override,
                      this Stage 0 call needs the same override — no
                      mechanism yet to detect that automatically.
  v1.8.1  2026-07-23  Bugfix: Stage 0 now passes --egress-dir explicitly to
                      build_custom_objects.py (was relying on that script's
                      relative default "./processed_outputs" matching cwd —
                      worked only by coincidence when the orchestrator's cwd
                      equaled --base). build_custom_objects.py's new
                      EGRESS_TRAFFIC class (v1.2.0+, requires
                      ent-ipdataset-EGRESS-FW-TOPOLOGY as a second input)
                      would have silently produced 0 EGRESS_TRAFFIC objects
                      with no pipeline error if invoked with a mismatched
                      cwd — Stage 0 treats build_custom_objects.py failure
                      as non-fatal and the script itself doesn't error on
                      a missing topology file, only warns, so this failure
                      mode would not have surfaced in the pipeline summary.
                      Known residual risk: if the topology CSV simply
                      doesn't exist yet in proc_dir on a given run, Stage 0
                      will still report success with EGRESS_TRAFFIC silently
                      absent — worth a --require-egress-topology flag or
                      similar in a future version if that's not acceptable.
  v1.8.0  2026-07-23  Stage 0: build_custom_objects.py wired in — builds
                      canonical_custom_objects (CUSTOM OBJECT_TYPE). Optional/
                      non-fatal like Stages 2.5/2.6/1.5/1.6 (its output isn't
                      a Stage 3 dependency the way cpc_catalog/canon_apps/
                      user_access are) — silently skipped if not found,
                      warns and continues if it fails. Runs inside the
                      --skip-obj group alongside the other three Stage 0
                      builders. First registered class: AETNA_HCB_172.
  v1.7.0  2026-07-08  Stage 1.5 (build_external_ng.py) and Stage 1.6
                      (build_partner_ng.py) added — populate the
                      External-NG and Partner-NG EDL catalog slots that
                      build_edl_catalog.py has expected since its 7-tab
                      layout (v1.2.0) but that nothing in the pipeline was
                      writing to. Both scripts are standalone (re-derive
                      independently from the VPN/P2P/Internet-Facing source
                      registries, not a split of Stage 1's internal output).
                      New flags: --skip-external-ng, --skip-partner-ng.
                      Optional/non-fatal, same pattern as Stages 2.5/2.6.
                      Also fixed stale docstring header version (was v1.4.0,
                      __version__ was already at v1.6.1 — see
                      ccd-versioning-discipline Rule 1).
  v1.6.0  2026-06-23  Stage 7: collect-edl_bundle.sh wired in via --collect flag.
                      Runs after Stage 6 (CSNA), packages edl_catalog.html +
                      all EDL files (NG + SO + IPDATASET) into a distributable
                      ccd_objects_YYYYMMDD.zip. Non-fatal; skipped by default.
                      Web server stage renumbered Stage 8 in docstring.
  v1.5.0  2026-06-23  Stage 2.6: build_geo_block_objects.py added — generates
                      country-level geo-block EDL files (GEO-BLOCK-NG/GH/KZ/
                      SN/PK/UZ/KG/AF/TJ/TM/RU/IR/CN) into the same
                      Net_Object/IPDATASET-vDATE/ directory as Stage 2.5.
                      --skip-geo flag added to bypass Stage 2.6.
                      build_edl_catalog.py updated to 8-tab layout via v1.3.0.
  v1.4.0  2026-06-22  Stage 2.5: build_ipdataset_objects.py added — generates
                      Cloud Services provider address objects (AWS/Azure/GCP/
                      Zscaler/CrowdStrike/etc.) into Net_Object/IPDATASET-vDATE/.
                      --skip-cloud flag added to bypass Stage 2.5.
                      build_edl_catalog.py updated to 7-tab layout via v1.2.0.
  v1.3.1  2026-06-15  Stage 0: ipam-db --import added after each build script.
                      (build_cpc_service_catalog → build_canonical_app_objects
                      → build_user_access_objects). These are prerequisites for
                      Stage 3 (service objects) and must be current.
                      Stage 6: generate_csna_hostgroups.py added. CSNA runs
                      after EDL catalog — non-blocking (Stealthwatch output).
                      Duplicate IP enforcement is handled inside CSNA via
                      continuity_check(); pipeline logs FAIL but does not abort.
                      New flags: --obj-only, --skip-obj, --skip-csna.
  v1.2.1  2026-06-12  Stage 5: pass --base to build_edl_catalog.py.
  v1.2.0  2026-06-12  Stage 5: build_edl_catalog.py wired in (optional).
  v1.1.0  2026-06-12  Run-date injection into edl_catalog.html topbar.
  v1.0.0  2026-06-12  Initial build.
"""

from __future__ import annotations

import argparse
import csv
import os
import re
import subprocess
import sys
import signal
from datetime import datetime, timezone
from pathlib import Path

__version__ = "1.9.0"
# v1.9.0  2026-08-23  Stage 2.7: build_ip_classification_objects.py added.
#                     Generates three EDL object families from registered
#                     ipdatasets: external_no (CVS_INTERNET_FACING_*,
#                     CVS_INTERNAL_PUBLIC_*), partner_no (VPN_PEER_*,
#                     PARTNER_PROTECTED_*, CVS_PROTECTED_*), and fw_infra
#                     (FW_INTF_*, F5_VIP_*, ZPA_CONNECTOR_*). Fills the
#                     external_no and partner_no catalog slots that existed
#                     in build_edl_catalog.py but had 0 objects. Closes
#                     the public/private IANA block classification gap in
#                     the EDL address object model. --skip-ipclass flag added.
#                     Non-fatal, same pattern as Stages 2.5/2.6.
# v1.8.2  2026-07-23  Bugfix: Stage 0's --egress-dir corrected from proc_dir
#                     to base/FW-Egress_Out (topology script's real default).
# v1.8.1  2026-07-23  Bugfix: Stage 0 passes --egress-dir explicitly to
#                     build_custom_objects.py instead of relying on cwd
#                     coincidentally matching --base. See changelog above.
# v1.8.0  2026-07-23  Stage 0: build_custom_objects.py wired in (CUSTOM
#                     OBJECT_TYPE, canonical_custom_objects). Optional/
#                     non-fatal, grouped under --skip-obj with the other
#                     three Stage 0 builders.
# v1.7.0  2026-07-08  Stage 1.5/1.6: build_external_ng.py, build_partner_ng.py added.
# v1.6.1  2026-06-23  Stage 7: pass --dry-run through to collect-edl_bundle.sh
#                     when pipeline runs with --dry-run --collect. Previously
#                     Stage 7 was skipped entirely in dry-run mode.
# v1.6.0  2026-06-23  Stage 7: collect-edl_bundle.sh — --collect flag packages
#                     EDL bundle (NG + SO + IPDATASET) into distributable zip.
#                     Non-fatal; skipped by default. Web server → Stage 8.
# v1.5.0  2026-06-23  Stage 2.6: build_geo_block_objects.py — Geo-Block EDL
#                     files for 13 high-risk countries into IPDATASET-vDATE/.
#                     --skip-geo flag added. build_edl_catalog.py v1.3.0 adds
#                     Geo-Block tab (8-tab layout).
# v1.4.0  2026-06-22  Stage 2.5: build_ipdataset_objects.py — Cloud Services
#                     provider address objects (AWS/Azure/GCP/etc.) into
#                     Net_Object/IPDATASET-vDATE/. --skip-cloud flag added.
# v1.3.1  2026-06-15  Stage 0: ipam-db --import added after each build script
#                     so downstream stages always see current CPC-CORE-SERVICES,
#                     CANONICAL-APP-OBJECTS, and CANONICAL-USER-ACCESS-OBJECTS.
#                     Without this, Stage 3 used stale ipam-db data.
# v1.3.0  2026-06-15  Stage 0 (canonical objects) + Stage 6 (CSNA) added.
#                     --obj-only, --skip-obj, --skip-csna flags added.
#                     EDL export now ON by default for Stage 1 + 3 (was opt-in).
#                     --edl replaced with --no-edl to suppress. Stage 5 always
#                     has fresh EDL files to catalog.
# v1.2.1  2026-06-12  Stage 5: pass --base to build_edl_catalog.py.

# ── ANSI colours (disabled when stdout is not a tty) ─────────────────────────
def _use_color():
    return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()

def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if _use_color() else text

def green(t):  return _c("32", t)
def yellow(t): return _c("33", t)
def red(t):    return _c("31", t)
def bold(t):   return _c("1",  t)
def cyan(t):   return _c("36", t)
def gray(t):   return _c("90", t)


# ── Logging ───────────────────────────────────────────────────────────────────

class Tee:
    """Write to both a file and stdout simultaneously."""
    def __init__(self, path: str):
        self._f = open(path, 'w', encoding='utf-8')
        self._stdout = sys.stdout

    def write(self, data: str):
        self._stdout.write(data)
        # Strip ANSI for the log file
        clean = re.sub(r'\033\[[0-9;]*m', '', data)
        self._f.write(clean)

    def flush(self):
        self._stdout.flush()
        self._f.flush()

    def isatty(self):
        return self._stdout.isatty()

    def close(self):
        self._f.close()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _latest_versioned_dir(parent: str, prefix: str) -> str | None:
    """Return the latest NG-YYYYMMDD_vN or SO-YYYYMMDD_vN directory."""
    if not os.path.isdir(parent):
        return None
    pat = re.compile(rf'^{re.escape(prefix)}(\d{{8}})_v(\d+)$')
    hits = []
    for d in os.listdir(parent):
        m = pat.match(d)
        if m:
            hits.append((m.group(1), int(m.group(2)), d))
    if not hits:
        return None
    hits.sort(key=lambda x: (x[0], x[1]))
    return os.path.join(parent, hits[-1][2])


def _latest_file(directory: str, pattern: str) -> str | None:
    import glob as _g
    def _key(p):
        m = re.search(r'v(\d{8})(?:r(\d+))?', os.path.basename(p))
        return (int(m.group(1)), int(m.group(2) or 0)) if m else (0, 0)
    matches = [f for f in _g.glob(os.path.join(directory, pattern))
               if '__MACOSX' not in f]
    return max(matches, key=_key) if matches else None


def _check_overlap_violations(ng_dir: str) -> int:
    """Return count of HIGH violations in ng_overlap_violations.csv."""
    viol_path = os.path.join(ng_dir, 'ng_overlap_violations.csv')
    if not os.path.exists(viol_path):
        return 0
    high = 0
    try:
        with open(viol_path, newline='', encoding='utf-8') as f:
            for row in csv.DictReader(f):
                if row.get('SEVERITY', '').upper() == 'HIGH':
                    high += 1
    except Exception:
        pass
    return high


def _run(label: str, cmd: list[str], dry_run: bool = False) -> int:
    """Run a subprocess, stream output, return exit code."""
    print()
    print(bold(f"── {label} " + "─" * max(0, 68 - len(label))))
    print(gray("  " + " ".join(cmd)))
    print()
    if dry_run and '--dry-run' not in cmd:
        # We add --dry-run for the builders; report scripts don't support it
        pass
    result = subprocess.run(cmd, text=True, env=os.environ.copy())
    return result.returncode


def _inject_date_into_report(html_path: str, run_date: str) -> None:
    """
    Patch a generated ng_report / svc_report HTML to show the run date below
    the existing <div class="sub"> subtitle line.
    """
    if not os.path.exists(html_path):
        return
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    if 'class="run-date"' in html:
        return  # already injected

    css = (
        '\n  .run-date { font-size:12px; color:#888; margin-top:4px; '
        'letter-spacing:.02em; }\n'
    )
    html = html.replace('</style>', css + '</style>', 1)

    date_tag = f'<div class="run-date">Report date: {run_date}</div>'
    html = re.sub(
        r'(<div class="sub">.*?</div>)',
        r'\1' + '\n  ' + date_tag,
        html, count=1, flags=re.DOTALL
    )

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"  {green('✓')} Injected run date ({run_date}) into {os.path.basename(html_path)}")


def _inject_date_into_edl_catalog(base: str, run_date: str) -> None:
    """
    Stamp the run date into the edl_catalog.html topbar.

    The topbar ends with:
        <div class="spacer"></div>
        <div class="ver-tag" id="ver-tag">—</div>

    We insert a matching date pill immediately before the ver-tag:
        <div class="date-tag">YYYY-MM-DD</div>
        <div class="ver-tag" id="ver-tag">—</div>

    The CSS uses the same .ver-tag styling (monospace, muted, pill) with a
    slightly different background so it reads as a separate badge.

    Safe to run multiple times — skips if date-tag is already present.
    """
    catalog_path = os.path.join(base, 'edl_catalog.html')
    if not os.path.exists(catalog_path):
        print(gray("  [edl_catalog.html not found — skipping date injection]"))
        return

    with open(catalog_path, 'r', encoding='utf-8') as f:
        html = f.read()

    if 'class="date-tag"' in html:
        # Already stamped — update the date value in place
        html = re.sub(
            r'<div class="date-tag">[\d-]+</div>',
            f'<div class="date-tag">{run_date}</div>',
            html, count=1
        )
        with open(catalog_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"  {green('✓')} Updated run date in edl_catalog.html → {run_date}")
        return

    # Inject the CSS rule alongside the existing .ver-tag block
    css_addition = (
        '\n  #topbar .date-tag {\n'
        '    font-family: var(--mono); font-size: 10px; color: var(--muted);\n'
        '    background: var(--bg2); border: 1px solid var(--border);\n'
        '    border-radius: 3px; padding: 2px 7px;\n'
        '  }\n'
    )
    # Insert after the .ver-tag CSS block (ends with the closing brace + blank line)
    html = html.replace(
        '#topbar .ver-tag {\n    font-family: var(--mono); font-size: 10px; color: var(--muted);\n    background: var(--bg3); border: 1px solid var(--border);\n    border-radius: 3px; padding: 2px 7px;\n  }',
        '#topbar .ver-tag {\n    font-family: var(--mono); font-size: 10px; color: var(--muted);\n    background: var(--bg3); border: 1px solid var(--border);\n    border-radius: 3px; padding: 2px 7px;\n  }' + css_addition,
        1
    )

    # Insert the date pill before the ver-tag div in the topbar HTML
    date_pill = f'<div class="date-tag">{run_date}</div>\n    '
    html = html.replace(
        '<div class="ver-tag" id="ver-tag">—</div>',
        date_pill + '<div class="ver-tag" id="ver-tag">—</div>',
        1
    )

    with open(catalog_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"  {green('✓')} Injected run date ({run_date}) into edl_catalog.html topbar")


# ── Main pipeline ─────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="CCD Platform — full network/service object pipeline runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument('--version',  action='version', version=f'%(prog)s {__version__}')
    ap.add_argument('--base',     default='.',
                    help='CCD Platform root directory (default: .)')
    ap.add_argument('--dry-run',  action='store_true',
                    help='Pass --dry-run to builders; skip report + server stages')
    ap.add_argument('--ng-only',  action='store_true',
                    help='Run Stages 1-2 only (network groups + NG report)')
    ap.add_argument('--svc-only', action='store_true',
                    help='Run Stages 3-4 only (service objects + SVC report)')
    ap.add_argument('--no-edl',   action='store_true',
                    help='Suppress --edl flag (EDL export is ON by default for Stage 1 + 3)')
    ap.add_argument('--serve',    action='store_true',
                    help='Launch object-viewer-web-service.sh after the pipeline completes')
    ap.add_argument('--port',     default='8080',
                    help='Port for the web server (default: 8080)')
    ap.add_argument('--no-svc',   action='store_true',
                    help='Alias for --ng-only')
    ap.add_argument('--obj-only',  action='store_true',
                    help='Run Stage 0 only (canonical objects pre-build)')
    ap.add_argument('--skip-obj',  action='store_true',
                    help='Skip Stage 0 (canonical objects already built)')
    ap.add_argument('--skip-csna', action='store_true',
                    help='Skip Stage 6 (CSNA host group generation)')
    ap.add_argument('--skip-cloud', action='store_true',
                    help='Skip Stage 2.5 (ipdataset Cloud Services objects)')
    ap.add_argument('--skip-geo',   action='store_true',
                    help='Skip Stage 2.6 (geo-block EDL object generation)')
    ap.add_argument('--skip-ipclass', action='store_true',
                    help='Skip Stage 2.7 (IP classification objects — FW intf, partner, public/private IANA)')
    ap.add_argument('--skip-external-ng', action='store_true',
                    help='Skip Stage 1.5 (External-NG EDL slot generation)')
    ap.add_argument('--skip-partner-ng',  action='store_true',
                    help='Skip Stage 1.6 (Partner-NG EDL slot generation)')
    ap.add_argument('--collect',    action='store_true',
                    help='Run collect-edl_bundle.sh after Stage 6 to package '
                         'all EDL files into ccd_objects_YYYYMMDD.zip (Stage 7)')
    args = ap.parse_args()

    base = os.path.abspath(args.base)
    run_ts   = datetime.now().strftime('%Y%m%d_%H%M%S')
    run_date = datetime.now().strftime('%Y-%m-%d')
    log_path = os.path.join(base, f'pipeline_run_{run_ts}.log')

    # Redirect stdout to tee (file + console)
    tee = Tee(log_path)
    sys.stdout = tee

    ng_only   = args.ng_only or args.no_svc
    svc_only  = args.svc_only
    obj_only  = args.obj_only
    skip_obj  = args.skip_obj
    skip_csna = args.skip_csna
    skip_cloud = args.skip_cloud
    skip_geo      = args.skip_geo
    skip_ipclass  = args.skip_ipclass
    skip_external_ng = args.skip_external_ng
    skip_partner_ng  = args.skip_partner_ng

    # ── Banner ────────────────────────────────────────────────────────────────
    print(bold(cyan("\n╔══════════════════════════════════════════════════════════════════════╗")))
    print(bold(cyan(  "║     CCD Platform — Object Pipeline Runner  v" + __version__ + "                    ║")))
    print(bold(cyan(  "╚══════════════════════════════════════════════════════════════════════╝")))
    print(f"  Base    : {base}")
    print(f"  Run     : {run_date}  {datetime.now().strftime('%H:%M:%S')}")
    print(f"  Log     : {log_path}")
    if args.dry_run:
        print(f"  Mode    : {yellow('DRY-RUN — no files will be written')}")
    if args.no_edl:
        print(f"  EDL     : {yellow('suppressed (--no-edl)')}")
    else:
        print(f"  EDL     : {green('ON (default — Stage 1 + 3 will export EDL files)')}")
    if skip_geo:
        print(f"  Geo-Block: {yellow('skipped (--skip-geo)')}")
    if getattr(args, 'collect', False):
        print(f"  Bundle  : {green('ON (--collect — Stage 7 will package EDL bundle)')}")
    if ng_only:
        print(f"  Scope   : {yellow('NG only (Stages 1-2)')}")
    elif svc_only:
        print(f"  Scope   : {yellow('SVC only (Stages 3-4)')}")
    print()

    # ── Locate scripts ────────────────────────────────────────────────────────
    scripts = {
        'cpc_catalog': os.path.join(base, 'build_cpc_service_catalog.py'),
        'canon_apps':  os.path.join(base, 'build_canonical_app_objects.py'),
        'user_access': os.path.join(base, 'build_user_access_objects.py'),
        'custom_objects': os.path.join(base, 'build_custom_objects.py'),
        'ng_build':    os.path.join(base, 'build_network_groups.py'),
        'external_ng': os.path.join(base, 'build_external_ng.py'),
        'partner_ng':  os.path.join(base, 'build_partner_ng.py'),
        'ng_report':   os.path.join(base, 'build_ng_report.py'),
        'svc_build':   os.path.join(base, 'build_service_objects.py'),
        'svc_report':  os.path.join(base, 'build_svc_report.py'),
        'edl_catalog': os.path.join(base, 'build_edl_catalog.py'),
        'ipdataset':   os.path.join(base, 'build_ipdataset_objects.py'),
        'geo_block':   os.path.join(base, 'build_geo_block_objects.py'),
        'ip_class':    os.path.join(base, 'build_ip_classification_objects.py'),
        'csna':        os.path.join(base, 'generate_csna_hostgroups.py'),
        'collect':     os.path.join(base, 'collect-edl_bundle.sh'),
        'webserver':   os.path.join(base, 'object-viewer-web-service.sh'),
    }

    missing = []
    for name, path in scripts.items():
        if name == 'webserver' and not args.serve:
            continue
        if name in ('edl_catalog', 'csna', 'geo_block', 'ipdataset', 'ip_class', 'collect',
                    'external_ng', 'partner_ng', 'custom_objects'):  # optional — warn, don't hard-stop
            continue
        if name in ('cpc_catalog', 'canon_apps', 'user_access') and args.skip_obj:
            continue
        if not os.path.exists(path):
            missing.append(path)

    if missing:
        print(red("ERROR: Required script(s) not found:"))
        for p in missing:
            print(f"  {red('✗')} {p}")
        sys.exit(1)

    errors = []


    # ─────────────────────────────────────────────────────────────────────────
    # Stage 0 — Canonical object pre-build
    # build_cpc_service_catalog → build_canonical_app_objects → build_user_access_objects
    # These are prerequisites for Stage 3 (service objects). Run before NG build
    # so the canonical objects are current when service objects executes.
    # Skip with --skip-obj if objects were just built in a prior run.
    # ─────────────────────────────────────────────────────────────────────────
    if not skip_obj and not svc_only:
        # Each script has its own CLI — none take --base.
        # All default to ./ipam-db and ./processed_outputs relative to cwd,
        # so we pass explicit paths derived from base.
        ipam_dir = os.path.join(base, 'ipam-db')
        proc_dir = os.path.join(base, 'processed_outputs')
        stage0_scripts = [
            (
                'build_cpc_service_catalog.py',
                scripts['cpc_catalog'],
                'CPC service catalog',
                ['--ipam-dir', ipam_dir, '--out-dir', proc_dir],
                'CPC-CORE-SERVICES',
            ),
            (
                'build_canonical_app_objects.py',
                scripts['canon_apps'],
                'Canonical app objects',
                ['--ipam-dir', ipam_dir, '--out-dir', proc_dir],
                'CANONICAL-APP-OBJECTS',
            ),
            (
                'build_user_access_objects.py',
                scripts['user_access'],
                'User access objects',
                ['--ipam-dir', ipam_dir, '--out-dir', proc_dir],
                'CANONICAL-USER-ACCESS-OBJECTS',
            ),
            (
                'build_custom_objects.py',
                scripts['custom_objects'],
                'Custom objects',
                ['--ipam-dir', ipam_dir, '--out-dir', proc_dir,
                 '--egress-dir', os.path.join(base, 'FW-Egress_Out'),
                 '--net-object-dir', os.path.join(base, 'Net_Object')],
                'CANONICAL-CUSTOM-OBJECTS',
            ),
        ]
        for script_name, script_path, label, extra_args, import_type in stage0_scripts:
            if not os.path.exists(script_path):
                print(yellow(f"\n⚠  Stage 0: {script_name} not found — skipping {label}"))
                errors.append(f"Stage 0: {script_name} not found")
                continue
            cmd = [sys.executable, script_path] + extra_args
            if args.dry_run:
                cmd.append('--dry-run')
            rc = _run(f"Stage 0 — {script_name}", cmd)
            if rc != 0:
                if script_name == 'build_custom_objects.py':
                    # Non-fatal — CUSTOM objects aren't a Stage 3 dependency
                    # the way the other three Stage 0 outputs are.
                    print(yellow(f"\n⚠  Stage 0: {label} failed (exit {rc}) — continuing pipeline."))
                    errors.append(f"Stage 0: {script_name} failed")
                    continue
                print(red(f"\n✗ Stage 0: {label} failed (exit {rc}) — aborting pipeline."))
                print(red(f"  Fix {script_name} before running the full pipeline."))
                sys.exit(rc)
            else:
                print(f"\n  {green('✓')} Stage 0 — {label} complete")

            # Import output into ipam-db so downstream stages see current data
            if not args.dry_run and import_type:
                import glob as _glob
                # Find the file just written to proc_dir
                pattern = {
                    'CPC-CORE-SERVICES':            'ent-ipdataset-CPC-CORE-SERVICES-v*.csv',
                    'CANONICAL-APP-OBJECTS':        'canonical_app_objects_v*.csv',
                    'CANONICAL-USER-ACCESS-OBJECTS':'canonical_user_access_objects_*.csv',
                    'CANONICAL-CUSTOM-OBJECTS':     'canonical_custom_objects_v*.csv',
                }.get(import_type)
                if pattern:
                    matches = sorted(
                        [f for f in _glob.glob(os.path.join(proc_dir, pattern))
                         if '__MACOSX' not in f],
                        key=lambda p: os.path.getmtime(p)
                    )
                    if matches:
                        latest = matches[-1]
                        ipam_db = os.path.join(base, 'ipam-db.py')
                        imp_cmd = [sys.executable, ipam_db,
                                   '--import', latest,
                                   '--type', import_type]
                        imp_rc = _run(f"Stage 0 — ipam-db import {import_type}", imp_cmd)
                        if imp_rc != 0:
                            print(yellow(f"\n⚠  Stage 0: ipam-db import failed for {import_type}"))
                            errors.append(f"Stage 0: ipam-db --import {import_type} failed")
                        else:
                            print(f"\n  {green('✓')} Stage 0 — {import_type} imported to ipam-db")
                    else:
                        print(yellow(f"\n⚠  Stage 0: no output file found for {import_type} — skipping import"))

        if not args.dry_run:
            print(f"\n  {green('✓')} Stage 0 complete — canonical objects current")

    if obj_only:
        _summary(errors, run_date, log_path, base, args)
        sys.stdout = tee._stdout
        tee.close()
        return

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 1 — build_network_groups.py
    # ─────────────────────────────────────────────────────────────────────────
    if not svc_only:
        cmd = [sys.executable, scripts['ng_build'], '--base', base]
        if args.dry_run:
            cmd.append('--dry-run')
        if not args.no_edl:
            cmd.append('--edl')  # EDL export on by default — Stage 5 needs it

        rc = _run("Stage 1 — build_network_groups.py", cmd)
        if rc != 0:
            print(red(f"\n✗ Stage 1 failed (exit {rc}) — aborting pipeline."))
            sys.exit(rc)

        # Gate: check overlap violations
        if not args.dry_run:
            ng_parent = os.path.join(base, 'Net_Group')
            ng_dir    = _latest_versioned_dir(ng_parent, 'NG-')
            if ng_dir:
                high = _check_overlap_violations(ng_dir)
                if high > 0:
                    print()
                    print(red(f"✗ GATE FAILED: {high} HIGH violation(s) in ng_overlap_violations.csv"))
                    print(red("  Resolve overlaps in IPAM before deploying. Pipeline aborted."))
                    print(gray(f"  Details: {os.path.join(ng_dir, 'ng_overlap_violations.csv')}"))
                    sys.exit(1)
                else:
                    print(f"\n  {green('✓')} Overlap gate passed — 0 HIGH violations")
                    print(f"  {green('✓')} Output: {ng_dir}")
        print(f"\n  {green('✓')} Stage 1 complete")

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 1.5 — build_external_ng.py (External-NG EDL slot)
    # Populates External_NG/NG-YYYYMMDD_vN/ from ent-ipdataset-INTERNET-FACING.
    # Standalone — does not depend on Stage 1's output. Optional: silently
    # skipped if the script isn't installed, non-fatal if it fails.
    # ─────────────────────────────────────────────────────────────────────────
    if not svc_only and not skip_external_ng:
        if os.path.exists(scripts['external_ng']):
            cmd = [sys.executable, scripts['external_ng'], '--base', base]
            if args.dry_run:
                cmd.append('--dry-run')
            if args.no_edl:
                cmd.append('--no-edl')
            rc = _run('Stage 1.5 — build_external_ng.py', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 1.5 (External-NG) failed (exit {rc}) — continuing pipeline.'))
                errors.append('Stage 1.5: build_external_ng.py')
            else:
                print(f"\n  {green('✓')} Stage 1.5 complete")
        else:
            print(gray('\n  [Stage 1.5 skipped — build_external_ng.py not found]'))
    elif skip_external_ng:
        print(gray('\n  [Stage 1.5 skipped — --skip-external-ng]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 1.6 — build_partner_ng.py (Partner-NG EDL slot)
    # Populates Partner_NG/NG-YYYYMMDD_vN/ from VPN/P2P partner registries.
    # Standalone — does not depend on Stage 1's output. Optional: silently
    # skipped if the script isn't installed, non-fatal if it fails.
    # NG-P2P-PARTNERS will be empty until a subnet-level P2P-PROTECTED-SUBNETS
    # dataset exists — see build_partner_ng.py docstring for the known gap.
    # ─────────────────────────────────────────────────────────────────────────
    if not svc_only and not skip_partner_ng:
        if os.path.exists(scripts['partner_ng']):
            cmd = [sys.executable, scripts['partner_ng'], '--base', base]
            if args.dry_run:
                cmd.append('--dry-run')
            if args.no_edl:
                cmd.append('--no-edl')
            rc = _run('Stage 1.6 — build_partner_ng.py', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 1.6 (Partner-NG) failed (exit {rc}) — continuing pipeline.'))
                errors.append('Stage 1.6: build_partner_ng.py')
            else:
                print(f"\n  {green('✓')} Stage 1.6 complete")
        else:
            print(gray('\n  [Stage 1.6 skipped — build_partner_ng.py not found]'))
    elif skip_partner_ng:
        print(gray('\n  [Stage 1.6 skipped — --skip-partner-ng]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 2 — build_ng_report.py
    # ─────────────────────────────────────────────────────────────────────────
    if not svc_only and not args.dry_run:
        cmd = [sys.executable, scripts['ng_report'], '--base', base]

        rc = _run("Stage 2 — build_ng_report.py", cmd)
        if rc != 0:
            print(yellow(f"\n⚠  Stage 2 (NG report) failed (exit {rc}) — continuing pipeline."))
            errors.append("Stage 2: build_ng_report.py")
        else:
            # Inject run date into every .html in the versioned NG dir
            ng_parent = os.path.join(base, 'Net_Group')
            ng_dir    = _latest_versioned_dir(ng_parent, 'NG-')
            if ng_dir:
                for fname in os.listdir(ng_dir):
                    if fname.endswith('.html'):
                        _inject_date_into_report(os.path.join(ng_dir, fname), run_date)
            print(f"\n  {green('✓')} Stage 2 complete")
    elif not svc_only and args.dry_run:
        print(gray("\n  [Stage 2 skipped — dry-run mode]"))

    if ng_only:
        _summary(errors, run_date, log_path)
        sys.stdout = tee._stdout
        tee.close()
        return

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 2.5 — build_ipdataset_objects.py (Cloud Services)
    # Generates provider-organised address objects for AWS/Azure/GCP/etc.
    # Output goes to Net_Object/IPDATASET-vDATE/ and is picked up by the
    # EDL catalog as the Cloud Services tab.
    # Skip with --skip-cloud or --ng-only.
    # ─────────────────────────────────────────────────────────────────────────
    if not ng_only and not skip_cloud:
        if os.path.exists(scripts['ipdataset']):
            cmd = [sys.executable, scripts['ipdataset'], '--base', base]
            if args.dry_run:
                cmd.append('--dry-run')
            rc = _run('Stage 2.5 — build_ipdataset_objects.py', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 2.5 (Cloud Services objects) failed (exit {rc}) — continuing.'))
                errors.append('Stage 2.5: build_ipdataset_objects.py')
            else:
                print(f'\n  {green("✓")} Stage 2.5 complete — Cloud Services objects written')
        else:
            print(gray('\n  [Stage 2.5 skipped — build_ipdataset_objects.py not found]'))
    elif skip_cloud:
        print(gray('\n  [Stage 2.5 skipped — --skip-cloud flag]'))
    elif ng_only:
        print(gray('\n  [Stage 2.5 skipped — --ng-only flag]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 2.6 — build_geo_block_objects.py (Geo-Block EDL)
    # Generates per-country and combined EDL files for 13 high-risk countries
    # sourced from IP2Location LITE DB1. Azure China CIDRs are excluded from
    # the China block. Output goes into the same Net_Object/IPDATASET-vDATE/
    # directory as Stage 2.5 and is picked up by the EDL catalog Geo-Block tab.
    # Non-fatal: failure logs a warning but does not abort the pipeline.
    # Skip with --skip-geo, --skip-cloud (both skip 2.5+2.6), or --ng-only.
    # ─────────────────────────────────────────────────────────────────────────
    if not ng_only and not skip_cloud and not skip_geo:
        if os.path.exists(scripts['geo_block']):
            cmd = [sys.executable, scripts['geo_block'], '--base', base]
            if args.dry_run:
                cmd.append('--dry-run')
            rc = _run('Stage 2.6 — build_geo_block_objects.py', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 2.6 (Geo-Block objects) failed (exit {rc}) — continuing.'))
                errors.append('Stage 2.6: build_geo_block_objects.py')
            else:
                print(f'\n  {green("✓")} Stage 2.6 complete — Geo-Block EDL objects written')
        else:
            print(gray('\n  [Stage 2.6 skipped — build_geo_block_objects.py not found]'))
    elif skip_geo:
        print(gray('\n  [Stage 2.6 skipped — --skip-geo flag]'))
    elif skip_cloud:
        print(gray('\n  [Stage 2.6 skipped — --skip-cloud flag]'))
    elif ng_only:
        print(gray('\n  [Stage 2.6 skipped — --ng-only flag]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 2.7 — build_ip_classification_objects.py
    # Generates three families of infrastructure address objects from registered
    # ipdatasets:
    #   external_no  — CVS_INTERNET_FACING_* / CVS_INTERNAL_PUBLIC_* (IANA blocks)
    #   partner_no   — VPN_PEER_* / PARTNER_PROTECTED_* / CVS_PROTECTED_*
    #   fw_infra     — FW_INTF_* / F5_VIP_* / ZPA_CONNECTOR_*
    # Fills the external_no and partner_no catalog slots (previously empty).
    # Output goes to Net_Object/IPDATASET-vDATE/ alongside 2.5/2.6.
    # Non-fatal: failure logs a warning but does not abort the pipeline.
    # Skip with --skip-ipclass or --ng-only.
    # ─────────────────────────────────────────────────────────────────────────
    if not ng_only and not skip_ipclass:
        if os.path.exists(scripts['ip_class']):
            cmd = [sys.executable, scripts['ip_class'], '--base', base]
            if args.dry_run:
                cmd.append('--dry-run')
            rc = _run('Stage 2.7 — build_ip_classification_objects.py', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 2.7 (IP classification objects) failed (exit {rc}) — continuing.'))
                errors.append('Stage 2.7: build_ip_classification_objects.py')
            else:
                print(f'\n  {green("✓")} Stage 2.7 complete — IP classification objects written')
        else:
            print(gray('\n  [Stage 2.7 skipped — build_ip_classification_objects.py not found]'))
    elif skip_ipclass:
        print(gray('\n  [Stage 2.7 skipped — --skip-ipclass flag]'))
    elif ng_only:
        print(gray('\n  [Stage 2.7 skipped — --ng-only flag]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 3 — build_service_objects.py
    # ─────────────────────────────────────────────────────────────────────────
    if not ng_only:
        cmd = [sys.executable, scripts['svc_build'], '--base', base]
        if args.dry_run:
            cmd.append('--dry-run')
        if not args.no_edl:
            cmd.append('--edl')  # EDL export on by default — Stage 5 needs it

        rc = _run("Stage 3 — build_service_objects.py", cmd)
        if rc != 0:
            print(yellow(f"\n⚠  Stage 3 (service objects) failed (exit {rc}) — continuing to report stage."))
            errors.append("Stage 3: build_service_objects.py")
        else:
            print(f"\n  {green('✓')} Stage 3 complete")

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 4 — build_svc_report.py
    # ─────────────────────────────────────────────────────────────────────────
    if not ng_only and not args.dry_run:
        cmd = [sys.executable, scripts['svc_report'], '--base', base]

        rc = _run("Stage 4 — build_svc_report.py", cmd)
        if rc != 0:
            print(yellow(f"\n⚠  Stage 4 (SVC report) failed (exit {rc})."))
            errors.append("Stage 4: build_svc_report.py")
        else:
            # Inject run date into every .html in the versioned SO dir
            so_parent = os.path.join(base, 'Net_Object')
            so_dir    = _latest_versioned_dir(so_parent, 'SO-')
            if so_dir:
                for fname in os.listdir(so_dir):
                    if fname.endswith('.html'):
                        _inject_date_into_report(os.path.join(so_dir, fname), run_date)
            print(f"\n  {green('✓')} Stage 4 complete")
    elif not ng_only and args.dry_run:
        print(gray("\n  [Stage 4 skipped — dry-run mode]"))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 5 — build_edl_catalog.py
    # Date injection runs AFTER the catalog is written, not before.
    # ─────────────────────────────────────────────────────────────────────────
    if not args.dry_run:
        if os.path.exists(scripts['edl_catalog']):
            cmd = [sys.executable, scripts['edl_catalog'], '--base', base]
            rc = _run("Stage 5 — build_edl_catalog.py", cmd)
            if rc != 0:
                print(yellow(f"\n⚠  Stage 5 (EDL catalog) failed (exit {rc})."))
                errors.append("Stage 5: build_edl_catalog.py")
            else:
                # Stamp run date into the freshly-written catalog
                print()
                print(bold(f"── edl_catalog.html date stamp " + "─" * 40))
                _inject_date_into_edl_catalog(base, run_date)
                print(f"\n  {green('✓')} Stage 5 complete")
        else:
            print(gray("\n  [Stage 5 skipped — build_edl_catalog.py not found]"))
    else:
        print(gray("\n  [Stage 5 skipped — dry-run mode]"))


    # ─────────────────────────────────────────────────────────────────────────
    # Stage 6 — generate_csna_hostgroups.py (Stealthwatch host groups)
    # Non-blocking: CSNA output goes to Stealthwatch, not PA. A duplicate IP
    # failure in continuity_check() is logged but does not abort the pipeline.
    # CRITICAL: CSNA enforces no-duplicate IPs via _seen_cidr set and
    # continuity_check(). If this stage fails, investigate the unresolved CSV
    # in csna_output/ before importing to Stealthwatch.
    # Skip with --skip-csna.
    # ─────────────────────────────────────────────────────────────────────────
    if not args.dry_run and not skip_csna and not ng_only:
        if os.path.exists(scripts['csna']):
            csna_out = os.path.join(base, 'csna_output')
            cmd = [
                sys.executable, scripts['csna'],
                '--ipam-dir',   os.path.join(base, 'ipam-db'),
                '--nms-dir',    base,
                '--out-dir',    csna_out,
            ]
            rc = _run("Stage 6 — generate_csna_hostgroups.py", cmd)
            if rc != 0:
                print(yellow(f"\n⚠  Stage 6 (CSNA) failed (exit {rc})."))
                print(yellow("   Check csna_output/ for continuity_check failures."))
                print(yellow("   Duplicate IPs in the XML will cause Stealthwatch import rejection."))
                errors.append("Stage 6: generate_csna_hostgroups.py — check for duplicate IPs")
            else:
                print(f"\n  {green('✓')} Stage 6 complete — CSNA host groups written to {csna_out}/")
        else:
            print(gray("\n  [Stage 6 skipped — generate_csna_hostgroups.py not found]"))
    elif args.dry_run:
        print(gray("\n  [Stage 6 skipped — dry-run mode]"))
    elif skip_csna:
        print(gray("\n  [Stage 6 skipped — --skip-csna flag]"))

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 7 — collect-edl_bundle.sh (optional --collect flag)
    # Packages edl_catalog.html + all EDL files (NG, SO, IPDATASET) into a
    # distributable ccd_objects_YYYYMMDD.zip. Requires the catalog to have been
    # written by Stage 5. Non-fatal: failure logs a warning, pipeline continues.
    # ─────────────────────────────────────────────────────────────────────────
    if getattr(args, 'collect', False):
        if os.path.exists(scripts['collect']):
            cmd = ['bash', scripts['collect'], '--out', base]
            if args.dry_run:
                cmd.append('--dry-run')
            rc = _run('Stage 7 — collect-edl_bundle.sh', cmd)
            if rc != 0:
                print(yellow(f'\n⚠  Stage 7 (EDL bundle) failed (exit {rc}).'))
                print(yellow('   Check that Stage 5 completed and EDL dirs are present.'))
                errors.append('Stage 7: collect-edl_bundle.sh')
            else:
                if not args.dry_run:
                    # Find the zip just written and report its path
                    import glob as _glob
                    zips = sorted(
                        _glob.glob(os.path.join(base, 'ccd_objects_*.zip')),
                        key=os.path.getmtime
                    )
                    zip_path = zips[-1] if zips else os.path.join(base, 'ccd_objects_*.zip')
                    print(f'\n  {green("✓")} Stage 7 complete — {zip_path}')
                else:
                    print(f'\n  {green("✓")} Stage 7 dry-run complete')
        else:
            print(gray('\n  [Stage 7 skipped — collect-edl_bundle.sh not found]'))
    else:
        print(gray('\n  [Stage 7 skipped — use --collect to package EDL bundle]'))

    # ─────────────────────────────────────────────────────────────────────────
    # Summary
    # ─────────────────────────────────────────────────────────────────────────
    _summary(errors, run_date, log_path, base, args)

    # ─────────────────────────────────────────────────────────────────────────
    # Stage 8 — web server (optional --serve flag)
    # ─────────────────────────────────────────────────────────────────────────
    if args.serve and not args.dry_run:
        print()
        print(bold(f"── Stage 8 — object-viewer-web-service.sh " + "─" * 28))
        print(f"\n  {cyan('Starting local server on 127.0.0.1:' + args.port)}")
        print(f"  {cyan('Open: http://127.0.0.1:' + args.port + '/edl_catalog.html')}")
        print(gray("  Stop: Ctrl-C\n"))
        # Restore real stdout so the server can print to console
        sys.stdout = tee._stdout
        tee.close()
        try:
            subprocess.run(['bash', scripts['webserver'], args.port])
        except KeyboardInterrupt:
            print("\n  Server stopped.")

    else:
        sys.stdout = tee._stdout
        tee.close()


def _summary(errors, run_date, log_path, base='.', args=None):
    print()
    print(bold("── Pipeline Summary " + "─" * 51))
    print(f"  Run date : {run_date}")
    print(f"  Log      : {log_path}")

    # Show output locations
    ng_parent = os.path.join(base, 'Net_Group')
    so_parent = os.path.join(base, 'Net_Object')
    ng_dir = _latest_versioned_dir(ng_parent, 'NG-')
    so_dir = _latest_versioned_dir(so_parent, 'SO-')
    csna_dir = os.path.join(base, 'csna_output')
    if ng_dir:
        print(f"  NG dir   : {ng_dir}")
    if so_dir:
        print(f"  SO dir   : {so_dir}")
    if os.path.isdir(csna_dir):
        print(f"  CSNA dir : {csna_dir}")
    # Show latest bundle zip if one was written this run
    import glob as _glob
    zips = sorted(_glob.glob(os.path.join(base, 'ccd_objects_*.zip')), key=os.path.getmtime)
    if zips:
        print(f"  Bundle   : {zips[-1]}")

    if errors:
        print()
        print(yellow(f"  ⚠  {len(errors)} stage(s) had warnings:"))
        for e in errors:
            print(yellow(f"     • {e}"))
    else:
        print(f"\n  {green('✓ All stages completed successfully.')}")

    if args and args.serve and not (args and args.dry_run):
        pass  # server message already printed above
    elif not (args and args.dry_run):
        port = args.port if args else '8080'
        srv  = os.path.join(base, 'object-viewer-web-service.sh')
        if os.path.exists(srv):
            print(f"\n  To view reports:")
            print(f"    {cyan('./object-viewer-web-service.sh')}")
            print(f"    {cyan('http://127.0.0.1:' + port + '/edl_catalog.html')}")
    print()


if __name__ == "__main__":
    main()
