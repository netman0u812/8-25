#!/usr/bin/env bash
# object-viewer-web-service.sh — CCD Platform local HTTP server
# Usage: ./object-viewer-web-service.sh [port]
# Serves ~/Documents/IP_Lookup/ on 127.0.0.1 only.
# Stop: Ctrl-C (clean exit)
#
# Changelog:
#   v1.1.0  2026-07-23  Launches ccd_local_server.py instead of the plain
#                       `python3 -m http.server` -- adds the draft-object
#                       write API (POST /api/draft-object, GET
#                       /api/draft-objects, DELETE /api/draft-object/<label>,
#                       GET /api/ipam-preview) used by the custom-object
#                       wizard embedded in edl_catalog.html. Falls back to
#                       plain http.server with a warning if
#                       ccd_local_server.py isn't present yet, so this
#                       script still works standalone during rollout.
#   v1.0.0  2026-07-23  Added hard-refresh reminder to startup output.

VERSION="1.1.0"
PORT=${1:-8080}
ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "CCD Platform — Local Server  v$VERSION"
echo "  Root : $ROOT"
echo "  URL  : http://127.0.0.1:$PORT/edl_catalog.html"
echo "  Stop : Ctrl-C"
echo ""
echo "  ⚠  edl_catalog.html embeds its data — a normal reload can serve a"
echo "     stale cached copy even after the file on disk has been rebuilt."
echo "     If pages/objects look out of date, hard-refresh instead:"
echo "       Safari              : Cmd+Option+R"
echo "       Chrome/Edge/Firefox : Cmd+Shift+R  (Ctrl+Shift+R on Windows/Linux)"
echo "     Still stale? Open in an incognito/private window, or open DevTools"
echo "     -> Network tab -> check \"Disable cache\" -> reload."
echo ""

cd "$ROOT"
if [[ -f "$ROOT/ccd_local_server.py" ]]; then
    python3 ccd_local_server.py "$PORT" 2>&1 | grep -v "^127\."
else
    echo "  ⚠  ccd_local_server.py not found — falling back to plain static"
    echo "     serving. The custom-object wizard's write API (draft-object"
    echo "     save/delete, live preview) will not work until it's deployed."
    echo ""
    python3 -m http.server "$PORT" --bind 127.0.0.1 2>&1 | grep -v "^127\."
fi
