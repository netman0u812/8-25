#!/usr/bin/env python3
"""
ccd_local_server.py  v1.2.0
CCD Platform — Local HTTP server with a minimal write API for draft custom
object classes
CVS Health Information Security

Serves static files exactly like `python3 -m http.server` (same directory,
same behavior for GET/HEAD), plus a small write-capable API used by the
custom-object wizard embedded in edl_catalog.html:

  POST /api/draft-object
    Body: JSON spec (same shape as draft_obj/*.json -- see
          build_custom_objects.py's build_from_spec() docstring).
    Validates the spec using the EXACT SAME rules build_custom_objects.py
    itself uses for --draft-dir (imported directly from that file, not
    reimplemented -- single source of truth, so this server can never
    accept a spec that build_custom_objects.py would go on to reject).
    On success: writes draft_obj/<LABEL>.json, returns
    200 {"ok": true, "path": "..."}.
    On validation failure: writes nothing, returns
    400 {"ok": false, "error": "..."}.

  GET /api/draft-objects
    Returns 200 {"drafts": [{"label", "valid", "error", "spec"}, ...]} --
    every *.json file currently in draft_obj/, each re-validated on read
    (a spec that's become invalid since it was written is reported as
    such, not silently hidden).

  DELETE /api/draft-object/<label>
    Removes draft_obj/<label>.json if present and <label> is a validated
    identifier. Returns 200 {"ok": true} or 404 {"ok": false}.

  GET /api/ipam-preview?source=ipam&filters=<url-encoded JSON>
    Runs the given filter list against a sample of the currently loaded
    IPAM/topology rows and returns match counts, a HERITAGE/ROUTING_DOMAIN
    breakdown, and an overlap check against every currently-registered
    custom object (ipam-db/canonical_custom_objects_v*.csv), for the
    wizard's live preview. Read-only -- never writes anything. See
    _handle_preview() and _check_overlaps() below.

  POST /api/validate-cidrs
    Body: {"cidrs": ["10.1.2.0/24", ...]}
    For the wizard's "explicit" flow (manual paste or EDL-format file
    upload, one CIDR per line). Per CIDR: whether it parses, whether it
    falls within known/allocated IPAM space (contained_in_ipam), and
    whether it's already claimed by another registered custom object
    (claimed_by). Read-only. See _validate_cidrs().

Security posture:
  - Binds to 127.0.0.1 only -- never reachable from outside this machine,
    same as the plain http.server this replaces.
  - The only filesystem write this process ever performs is writing a
    validated JSON spec to draft_obj/<label>.json, where <label> has
    already passed the identifier regex. No shell-outs, no eval, no exec.
  - This server does NOT run build_custom_objects.py itself. Writing a
    draft spec here does not build, import, or publish anything -- that
    still requires running build_custom_objects.py by hand (or via the
    topology script's auto-chain), same as before this existed.

Usage:
  python3 ccd_local_server.py [port]     # default 8080

Changelog:
  v1.2.0  2026-07-23  New POST /api/validate-cidrs for the wizard's
                      "explicit" flow (manual paste or EDL-file upload,
                      one CIDR per line). Checks each CIDR: parses,
                      contained within known IPAM address space
                      (_ipam_containment_index), and not already claimed
                      by another registered custom object
                      (_check_overlaps_per_cidr, the per-CIDR sibling of
                      /api/ipam-preview's _check_overlaps). No APM
                      registry involved -- an earlier design tied this
                      flow to an APM Application Id registry; that
                      dependency was dropped entirely in favor of a plain
                      label + CIDR list.
  v1.1.0  2026-07-23  /api/ipam-preview now also returns 'overlaps': cross-
                      references the draft's matched CIDRs against every
                      currently-registered object in ipam-db/canonical_
                      custom_objects_v*.csv. Large candidate sets are
                      sampled (first _OVERLAP_SAMPLE_CAP CIDRs) to stay
                      responsive as an on-demand check rather than a
                      per-keystroke one.
  v1.0.0  2026-07-23  Initial build.
"""

import http.server
import importlib.util
import json
import os
import re
import socketserver
import sys
import urllib.parse
from pathlib import Path

VERSION = '1.2.0'
# v1.2.0  2026-07-23  New POST /api/validate-cidrs for the wizard's
# "explicit" flow (manual paste or EDL-file upload, one CIDR per line):
# checks each CIDR parses, falls within known IPAM address space
# (_ipam_containment_index), and isn't already claimed by another
# registered custom object (_check_overlaps_per_cidr). No APM registry
# involved -- that dependency was dropped from this flow entirely.
# v1.1.0  2026-07-23  /api/ipam-preview now also returns 'overlaps': cross-
# references the draft's matched CIDRs against every currently-registered
# object in ipam-db/canonical_custom_objects_v*.csv (see _check_overlaps).
# Large candidate sets are sampled (_OVERLAP_SAMPLE_CAP) to stay responsive
# as an on-demand check. See module docstring changelog for full detail.
# v1.0.0  2026-07-23  Initial build.

ROOT = Path(__file__).resolve().parent
DRAFT_DIR = ROOT / 'draft_obj'
LABEL_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')

# ── Import validation (and the row-matching logic for previews) directly
# from build_custom_objects.py. Single source of truth: this server must
# never accept a spec that build_custom_objects.py itself would reject,
# and the preview must use the identical filter semantics the real build
# will use. Reimplementing either set of rules here would let the two
# drift out of sync silently. ──────────────────────────────────────────────
_bco_path = ROOT / 'build_custom_objects.py'
if not _bco_path.is_file():
    print(f'[FATAL] build_custom_objects.py not found at {_bco_path} -- '
          f'cannot validate draft specs. Exiting.', file=sys.stderr)
    sys.exit(1)

_spec_loader = importlib.util.spec_from_file_location('build_custom_objects', _bco_path)
bco = importlib.util.module_from_spec(_spec_loader)
_spec_loader.loader.exec_module(bco)


def _safe_draft_path(label):
    """Path for draft_obj/<label>.json, or None if label isn't a safe
    identifier. The only thing standing between a request body and a
    filesystem write -- validated strictly, no exceptions, no path
    traversal possible since LABEL_RE forbids '/', '.', and leading
    non-letters entirely."""
    if not isinstance(label, str) or not LABEL_RE.match(label):
        return None
    return DRAFT_DIR / f'{label}.json'


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        # Keep static-asset request logging quiet; API calls print their
        # own explicit lines below instead.
        if self.path.startswith('/api/'):
            super().log_message(fmt, *args)

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
        except ValueError:
            return None, 'invalid Content-Length header'
        if length <= 0 or length > 1_000_000:  # 1 MB cap -- specs are tiny
            return None, 'missing or oversized request body'
        raw = self.rfile.read(length)
        try:
            return json.loads(raw), None
        except (ValueError, UnicodeDecodeError) as e:
            return None, f'invalid JSON: {e}'

    # ── Routing ──────────────────────────────────────────────────────────
    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == '/api/draft-objects':
            return self._list_drafts()
        if parsed.path == '/api/ipam-preview':
            return self._handle_preview(urllib.parse.parse_qs(parsed.query))
        return super().do_GET()

    def do_POST(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/draft-object':
            return self._create_draft()
        if path == '/api/validate-cidrs':
            return self._validate_cidrs()
        self._send_json(404, {'ok': False, 'error': 'not found'})

    def do_DELETE(self):
        m = re.match(r'^/api/draft-object/([^/]+)$', urllib.parse.urlsplit(self.path).path)
        if m:
            return self._delete_draft(urllib.parse.unquote(m.group(1)))
        self._send_json(404, {'ok': False, 'error': 'not found'})

    # ── Draft CRUD ───────────────────────────────────────────────────────
    def _list_drafts(self):
        DRAFT_DIR.mkdir(exist_ok=True)
        drafts = []
        for path in sorted(DRAFT_DIR.glob('*.json')):
            try:
                with open(path, encoding='utf-8') as f:
                    spec = json.load(f)
            except (OSError, ValueError) as e:
                drafts.append({'label': path.stem, 'valid': False,
                                'error': f'unreadable: {e}', 'spec': None})
                continue
            ok, err = bco._validate_draft_spec(spec)
            drafts.append({'label': path.stem, 'valid': ok,
                            'error': (None if ok else err), 'spec': spec})
        self._send_json(200, {'drafts': drafts})

    def _create_draft(self):
        spec, err = self._read_json_body()
        if err:
            return self._send_json(400, {'ok': False, 'error': err})
        ok, err = bco._validate_draft_spec(spec)
        if not ok:
            return self._send_json(400, {'ok': False, 'error': err})
        path = _safe_draft_path(spec.get('label'))
        if path is None:
            return self._send_json(400, {'ok': False, 'error': 'invalid label'})
        DRAFT_DIR.mkdir(exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(spec, f, indent=2)
        print(f'  [draft-object] wrote {path.relative_to(ROOT)}')
        self._send_json(200, {'ok': True, 'path': str(path.relative_to(ROOT))})

    def _delete_draft(self, label):
        path = _safe_draft_path(label)
        if path is None:
            return self._send_json(400, {'ok': False, 'error': 'invalid label'})
        if not path.is_file():
            return self._send_json(404, {'ok': False, 'error': 'not found'})
        path.unlink()
        print(f'  [draft-object] deleted {path.relative_to(ROOT)}')
        self._send_json(200, {'ok': True})

    # ── Explicit/uploaded CIDR list validation (read-only) ──────────────
    def _validate_cidrs(self):
        """POST /api/validate-cidrs   body: {"cidrs": ["10.1.2.0/24", ...]}
        Used by the wizard's "explicit" flow (manual paste or EDL-format
        file upload -- one CIDR per line, parsed client-side, sent here as
        a plain list either way). For each CIDR checks:
          - valid_cidr: does it parse at all
          - contained_in_ipam: does it fall within (or exactly match) some
            row in all_IP_networks -- i.e. is this legitimately allocated
            address space, not typo'd or made-up
          - claimed_by: any currently-registered custom object (any type,
            not just other explicit ones) that already covers this address
            space, via the same _check_overlaps used by /api/ipam-preview
        Read-only -- never writes anything."""
        body, err = self._read_json_body()
        if err:
            return self._send_json(400, {'ok': False, 'error': err})
        cidrs = body.get('cidrs') if isinstance(body, dict) else None
        if not isinstance(cidrs, list) or not cidrs:
            return self._send_json(400, {'ok': False, 'error': 'cidrs must be a non-empty list'})

        ipam_rows = _preview_rows('ipam')
        ipam_nets = _ipam_containment_index(ipam_rows) if ipam_rows else None

        results = []
        clean_cidrs = []
        for raw in cidrs:
            raw = str(raw).strip()
            entry = {'cidr': raw, 'valid_cidr': False, 'contained_in_ipam': False,
                      'matched_supernet': None, 'claimed_by': []}
            try:
                net = _ip_mod().ip_network(raw, strict=False)
            except ValueError:
                results.append(entry)
                continue
            entry['valid_cidr'] = True
            entry['cidr'] = str(net)
            if ipam_nets is not None:
                for existing in ipam_nets:
                    if net.subnet_of(existing) or net == existing:
                        entry['contained_in_ipam'] = True
                        entry['matched_supernet'] = str(existing)
                        break
            clean_cidrs.append(entry['cidr'])
            results.append(entry)

        overlaps_by_cidr = _check_overlaps_per_cidr(clean_cidrs)
        for entry in results:
            if entry['valid_cidr']:
                entry['claimed_by'] = overlaps_by_cidr.get(entry['cidr'], [])

        all_clean = all(r['valid_cidr'] and r['contained_in_ipam'] and not r['claimed_by'] for r in results)
        self._send_json(200, {'ok': True, 'results': results, 'all_clean': all_clean})

    # ── Live preview (read-only) ────────────────────────────────────────
    def _handle_preview(self, query):
        """?source=ipam|topology&filters=<url-encoded JSON list>
        Runs the wizard's current filter set against the real, currently
        loaded IPAM/topology rows and returns match counts + a HERITAGE/
        ROUTING_DOMAIN breakdown, using build_custom_objects.py's own
        row_matches semantics (via a throwaway build_from_spec call with
        group=False) so the preview can never disagree with what a real
        build would produce. Purely read-only -- never writes anything."""
        source = (query.get('source') or [''])[0]
        filters_raw = (query.get('filters') or ['[]'])[0]
        if source not in ('ipam', 'topology'):
            return self._send_json(400, {'ok': False, 'error': 'source must be ipam or topology'})
        try:
            filters = json.loads(filters_raw)
            if not isinstance(filters, list):
                raise ValueError('filters must be a JSON list')
        except ValueError as e:
            return self._send_json(400, {'ok': False, 'error': f'invalid filters: {e}'})

        rows = _preview_rows(source)
        if rows is None:
            return self._send_json(503, {
                'ok': False,
                'error': f'no {source} data loaded on this server -- run '
                         f'build_custom_objects.py at least once so the source '
                         f'CSVs are discoverable, or check --ipam-dir/--egress-dir'})

        probe_spec = {
            'label': 'PREVIEW', 'source': source, 'cidr_field': 'CIDR',
            'heritage_field': 'HERITAGE', 'location_field': 'CANONICAL_LOCATION',
            'routing_domain_field': 'ROUTING_DOMAIN' if source == 'topology' else '',
            'filters': filters, 'group': False,
        }
        ok, err = bco._validate_draft_spec(probe_spec)
        if not ok:
            return self._send_json(400, {'ok': False, 'error': err})

        objs = bco.build_from_spec(probe_spec, rows, dataset_version='preview', verbose=False)
        obj = next(iter(objs.values()), None)
        matched_cidrs = len(obj.subnet_cidrs) if obj else 0
        collapsed = sorted(obj.subnet_cidrs) if obj else []
        heritage_counts, rd_counts = _breakdown(rows, filters)
        overlaps = _check_overlaps(collapsed)

        self._send_json(200, {
            'ok': True,
            'matched_cidrs': matched_cidrs,
            'source_rows_scanned': len(rows),
            'heritage_breakdown': heritage_counts,
            'routing_domain_breakdown': rd_counts,
            'overlaps': overlaps,
        })


# ── Preview data cache ───────────────────────────────────────────────────
# Loaded lazily on first preview request, from wherever build_custom_objects.py
# itself would look (same --ipam-dir/--egress-dir defaults). Cached for the
# life of the server process -- restart the server to pick up newer source
# files, same staleness contract as re-running build_custom_objects.py.
_row_cache = {}


def _preview_rows(source):
    if source in _row_cache:
        return _row_cache[source]
    if source == 'ipam':
        path = bco.find_file(str(ROOT / 'ipam-db'), 'all_IP_networks_v*.csv')
    else:
        path = bco.find_file(str(ROOT / 'FW-Egress_Out'), 'ent-ipdataset-EGRESS-FW-TOPOLOGY-v*.csv')
    if not path:
        _row_cache[source] = None
        return None
    rows = bco.read_ccd_csv(path)
    _row_cache[source] = rows
    return rows


# ── Overlap check against existing custom objects ───────────────────────
# Cross-references a draft's matched CIDRs against the currently-registered
# canonical_custom_objects_v*.csv in ipam-db/ -- the same file build_edl_
# catalog.py's import-verification trusts as source of truth (see that
# script's _find_import_verified_versioned_dir). Read-only, best-effort:
# any single bad CIDR is skipped rather than failing the whole check, and
# very large candidate sets are sampled to keep this responsive as an
# on-demand button click rather than a per-keystroke call.
_OVERLAP_SAMPLE_CAP = 300
_custom_objects_cache = None


def _load_existing_custom_objects():
    global _custom_objects_cache
    if _custom_objects_cache is not None:
        return _custom_objects_cache
    path = bco.find_file(str(ROOT / 'ipam-db'), 'canonical_custom_objects_v*.csv')
    if not path:
        _custom_objects_cache = []
        return _custom_objects_cache
    import ipaddress as _ip
    rows = bco.read_ccd_csv(path)
    objects = []
    for row in rows:
        cidrs_str = row.get('SUBNET_CIDRS') or ''
        if not cidrs_str:
            continue
        nets = []
        for c in cidrs_str.split('|'):
            c = c.strip()
            if not c:
                continue
            try:
                nets.append(_ip.ip_network(c))
            except ValueError:
                continue
        if nets:
            objects.append({'name': row.get('OBJECT_NAME', ''), 'nets': nets})
    _custom_objects_cache = objects
    return objects


def _check_overlaps(new_cidr_strs, max_results=15):
    """Returns a list of {object_name, overlapping_cidrs, sampled} for every
    currently-registered custom object that shares address space with the
    new spec's CIDRs, sorted by overlap count descending, capped at
    max_results. 'sampled' is true if the new CIDR set was too large to
    check exhaustively and a random-order prefix was used instead."""
    import ipaddress as _ip
    new_nets = []
    for c in new_cidr_strs:
        try:
            new_nets.append(_ip.ip_network(c))
        except ValueError:
            continue
    sampled = len(new_nets) > _OVERLAP_SAMPLE_CAP
    if sampled:
        new_nets = new_nets[:_OVERLAP_SAMPLE_CAP]

    existing = _load_existing_custom_objects()
    results = []
    for obj in existing:
        overlap_count = 0
        for new_net in new_nets:
            for existing_net in obj['nets']:
                if new_net.overlaps(existing_net):
                    overlap_count += 1
                    break
        if overlap_count:
            results.append({
                'object_name': obj['name'],
                'overlapping_cidrs': overlap_count,
                'sampled': sampled,
            })
    results.sort(key=lambda r: -r['overlapping_cidrs'])
    return results[:max_results]


def _check_overlaps_per_cidr(cidr_strs):
    """Like _check_overlaps, but returns a dict keyed by CIDR string instead
    of aggregated by object -- {cidr: [{'object_name': ...}, ...]} -- for
    /api/validate-cidrs, where each individual pasted/uploaded CIDR needs
    its own claimed-by list rather than one aggregate count."""
    import ipaddress as _ip
    existing = _load_existing_custom_objects()
    out = {}
    for c in cidr_strs:
        try:
            net = _ip.ip_network(c)
        except ValueError:
            continue
        claimants = []
        for obj in existing:
            for existing_net in obj['nets']:
                if net.overlaps(existing_net):
                    claimants.append({'object_name': obj['name']})
                    break
        out[c] = claimants
    return out


_ipam_index_cache = None


def _ip_mod():
    import ipaddress
    return ipaddress


def _ipam_containment_index(ipam_rows, max_networks=30000):
    """Parses every row's CIDR field from all_IP_networks into a flat list
    of ip_network objects, cached for the life of the process. Used by
    /api/validate-cidrs to check whether a hand-entered/uploaded CIDR falls
    within legitimately allocated space. Capped at max_networks as a
    sanity bound -- the real dataset is ~25K rows, well under this."""
    global _ipam_index_cache
    if _ipam_index_cache is not None:
        return _ipam_index_cache
    import ipaddress as _ip
    nets = []
    for row in ipam_rows[:max_networks]:
        cidr = (row.get('CIDR') or '').strip()
        if not cidr:
            continue
        try:
            nets.append(_ip.ip_network(cidr, strict=False))
        except ValueError:
            continue
    _ipam_index_cache = nets
    return nets


def _breakdown(rows, filters):
    """HERITAGE and ROUTING_DOMAIN counts among rows matching filters,
    reusing build_from_spec's own row_matches logic via a private re-check
    (cheap: rows are already in memory, filters are a handful of clauses)."""
    def row_matches(row):
        for f in filters:
            field = f.get('field', '')
            val = (row.get(field) or '').strip()
            ftype = f.get('type')
            if ftype == 'equals' and val != f.get('value'):
                return False
            if ftype == 'not_equals' and val == f.get('value'):
                return False
            if ftype == 'in' and val not in (f.get('values') or []):
                return False
            if ftype == 'cidr_within':
                try:
                    import ipaddress
                    if not ipaddress.ip_network(val, strict=False).subnet_of(
                            ipaddress.ip_network(f.get('supernet'))):
                        return False
                except Exception:
                    return False
        return True

    heritage_counts, rd_counts = {}, {}
    for row in rows:
        if not row_matches(row):
            continue
        her = (row.get('HERITAGE') or '(blank)').strip() or '(blank)'
        heritage_counts[her] = heritage_counts.get(her, 0) + 1
        rd = (row.get('ROUTING_DOMAIN') or '(blank)').strip() or '(blank)'
        rd_counts[rd] = rd_counts.get(rd, 0) + 1
    return heritage_counts, rd_counts


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    DRAFT_DIR.mkdir(exist_ok=True)
    with socketserver.TCPServer(('127.0.0.1', port), Handler) as httpd:
        httpd.allow_reuse_address = True
        print(f'ccd_local_server.py v{VERSION}')
        print(f'  Root      : {ROOT}')
        print(f'  Draft dir : {DRAFT_DIR}')
        print(f'  URL       : http://127.0.0.1:{port}/edl_catalog.html')
        print(f'  API       : POST /api/draft-object')
        print(f'              GET  /api/draft-objects')
        print(f'              DELETE /api/draft-object/<label>')
        print(f'              GET  /api/ipam-preview?source=..&filters=..')
        print(f'  Stop      : Ctrl-C')
        print()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print('\nStopped.')


if __name__ == '__main__':
    main()
