---
name: ccd-edl-object-pipeline
description: CCD Platform EDL network object pipeline — build_object_pipeline.py orchestration, all stages (0-7), what feeds each stage from IPAM, output structure (APP_/SVC_/INFRA_/DELIVERY_/CVS_/VPN_/FW_INTF_/FW_MGMT_/AWS-/AZURE-), EDL catalog families (12 total incl. fw_mgmt), bundle structure, app-to-FW egress topology chain, CVS PBM PCI FW registry, and relationship to Tufin FW rule normalization. Use whenever asked about the EDL pipeline, network address objects, object groups, build_canonical_app_objects.py, build_network_groups.py, build_service_objects.py, build_ipdataset_objects.py, build_ip_classification_objects.py, build_app_egress_topology.py, edl_catalog.html, or the ccd_edl_bundle. Read before modifying any object pipeline script or proposing a run order.
sources: [chat]
aliases: [edl_pipeline, build_object_pipeline, network_objects, address_objects, app_objects, edl_bundle, net_group, net_object, canonical_app_objects, service_objects, cloud_services_objects, ip_classification_objects, app_egress_topology]
---

# CCD Platform — EDL Network Object Pipeline

**Last confirmed:** 2026-08-23 (EDL bundle v20260823)
**Orchestrator:** `build_object_pipeline.py` v1.9.0

---

## What the EDL Pipeline Is

The EDL pipeline is the bridge between the CCD Platform's IPAM intelligence
layer and the Palo Alto firewall enforcement layer. Firewalls pull plain-text
IP lists (EDL files) from `ccd_local_server.py` over HTTP. When IPAM changes
→ rebuild objects → firewalls pull updated EDLs → FW rules reflect reality.

---

## Pipeline Stages — Confirmed 2026-08-23

```
Stage 0    build_cpc_service_catalog.py        required  CPC core services
           build_canonical_app_objects.py       required  APP_{ACRONYM}_{ZONE}
           build_user_access_objects.py         required  user access objects
           build_custom_objects.py              optional  custom/draft objects
             --skip-obj to skip all Stage 0

Stage 1    build_network_groups.py              required  Net_Group/NG-*/EDL/
Stage 1.5  build_external_ng.py                optional  --skip-external-ng
Stage 1.6  build_partner_ng.py                 optional  --skip-partner-ng
Stage 2    build_ng_report.py                  required
Stage 2.5  build_ipdataset_objects.py          optional  --skip-cloud
           Cloud Services: AWS-*/AZURE-*/GCP-*/ZSCALER-ALL etc.
           Source: ipdatasets/ip_dataset.json registry (55 datasets)
           Reads SERVICE+REGION fields → per-service-per-region EDL objects
           Output: Net_Object/IPDATASET-vDATE/edl/ (flat, lowercase)
           Key: networksdb/tor-exit-nodes/spamhaus excluded; MIN_ROWS=50

Stage 2.6  build_geo_block_objects.py          optional  --skip-geo
           Same IPDATASET-vDATE/edl/ output directory as Stage 2.5

Stage 2.7  build_ip_classification_objects.py  optional  --skip-ipclass
           Four families, all flat into IPDATASET-vDATE/edl/:
             external_no  CVS_INTERNET_FACING_{HERITAGE}_{ZONE}  (45 objects)
                          CVS_INTERNAL_PUBLIC_{HERITAGE}_{ZONE}
                          Source: public_ipv4_ipam, private_ipv4_ipam
             partner_no   VPN_PARTNER_{PEER_KEY}                 (1,027 objects)
                          CVS_VPN_PROTECTED_{KEY}
                          P2P_PARTNER_{NAME} / CVS_P2P_PROTECTED_{NAME}
                          PARTNER_PROVIDER_{NAME}
                          Source: VPN-PROTECTED-SUBNETS, P2P-PROTECTED-SUBNETS
                          Key: CVS_LOCATION empty = partner side; populated = CVS side
             fw_infra     FW_INTF_OUTSIDE_{ZONE} / FW_INTF_INSIDE_{ZONE} (36 objects)
                          F5_VIP_{HERITAGE}_{ZONE}
                          ZPA_CONNECTOR_{SITE}
                          Source: FW-INTERFACE-INVENTORY (NAMEIF field), F5-VIP-REGISTRY
             fw_mgmt      FW_MGMT_{EGR_CODE}  one per egress cluster  (18 objects)
                          FW_MGMT_ALL_EGRESS  all 38 egress FW mgmt IPs combined
                          Source: egress_fw_mgmt_ips_v*.csv (MGMT_IP as /32)
                          Use: Panorama/FMC management access rules, policy scoping

Stage 3    build_service_objects.py            required  Net_Object/SO-*/EDL/
Stage 4    build_svc_report.py                 required
Stage 5    build_edl_catalog.py                optional  edl_catalog.html
Stage 6    generate_csna_hostgroups.py         optional  --skip-csna
Stage 7    collect_edl_bundle.sh               optional  --collect flag
```

---

## IPDATASET edl/ — Combined Flat Directory (2026-08-23)

All IPDATASET objects write to `Net_Object/IPDATASET-v20260823/edl/` (flat,
lowercase). collect_edl_bundle.sh reads only this path. Current counts:

```
3,985  Stage 2.5  Cloud Services (AWS-EC2-USE1, AZURE-CLOUD-EUS2, GCP-ALL, etc.)
1,089  Stage 2.7  IP classification (CVS_INTERNET_FACING_*, VPN_PARTNER_*, FW_INTF_*)
   18  Stage 2.7  FW_MGMT (FW_MGMT_EGR_MDC, FW_MGMT_EGR_WDC... + FW_MGMT_ALL_EGRESS)
  ~14  Stage 2.6  Geo-Block (GEO-BLOCK-NG, GEO-BLOCK-RU, etc.)
  ~150 topology   EGRESS-VERIFIED-PRIVATE-*, EGRESS-INFERRED-PUBLIC-* etc.
─────
~5,256 total
```

---

## EDL Catalog Families (10 total — edl_catalog.html)

| ID | Label | Builder | Objects |
|----|-------|---------|---------|
| internal_ng | Internal-NG | build_network_groups.py | 750 |
| external_ng | External-NG | build_external_ng.py | 13 |
| partner_ng | Partner-NG | build_partner_ng.py | 1,260 |
| internal_no | Internal-NO | build_service_objects.py | 4,034 |
| user_access | User-Access | build_user_access_objects.py | 44 |
| custom_objects | Custom Objects | build_custom_objects.py | 148 |
| external_no | External-NO | build_ip_classification_objects.py | 45 |
| partner_no | Partner-NO | build_ip_classification_objects.py | 1,027 |
| fw_infra | FW-Infra | build_ip_classification_objects.py | 36 |
| fw_mgmt | FW-Mgmt | build_ip_classification_objects.py | 18 |
| cloud_services | Cloud Services | build_ipdataset_objects.py | 3,985 |
| geo_block | Geo-Block | build_geo_block_objects.py | 14 |

external_no, partner_no, fw_infra, fw_mgmt were 0 objects before 2026-08-23.

---

## App-to-FW Egress Topology Chain

**New as of 2026-08-23** — `build_app_egress_topology.py` v1.5.0

The complete intelligence chain from any IP to its physical egress FW:

```
Any IP address
  ↓
IP Resolution Type:
  APP_SERVER → all_IP_networks CIDR match → ROUTING_DOMAIN
  VIP        → F5-VIP-REGISTRY.ROUTING_DOMAIN (direct, already enriched)
             → POOL_MEMBER_IPS → backend app server IPs
  SNAT       → FW-SNAT-POOLS.HOSTNAME → egress_fw_mgmt_ips.EGR_CODE
  FW_MGMT    → egress_fw_mgmt_ips.MGMT_IP → EGR_CODE direct
  FW_INTF    → FW-INTERFACE-INVENTORY.NAMEIF → ROUTING_DOMAIN
  ↓
ROUTING_DOMAIN (Internal-PBM, Internal-HCB, EGR_MDC-TC, etc.)
  ↓
EGR_CODE (from egress_topology_registry)
  ↓
EGRESS_LOGICAL + FW_HOSTNAMES + MGMT_IPS
```

Three output datasets registered to ipam-db:

**egress_topology_registry** — master egress cluster map:
```
EGR_CODE, EGRESS_LOGICAL, ROUTING_DOMAINS, FW_HOSTNAMES, MGMT_IPS, FW_COUNT
EGR_MDC   MDC-Middletown  EGR_MDC-TC|EGR_MDC-TI  mid-fw-glr-pa-a|mid-fw-glr-pa-b  2
EGR_WDC   WDC-Windsor     EGR_WDC-TC              win-fw-glr-pa-a|win-fw-glr-pa-b  2
EGR_SHEAW SHEA-DC-EGRESS  EGR_SHEAW-TC|TI         PAZSHDC-SEC-EXTWIR-PA-01/02      2
EGR_SHEAE SHEA-DC-EXT     Internet-Facing          PAZSHDC-SEC-EXT-NET-PA-01/02     2
EGR_RI1   RI-ONE-SEC-DMZ  EGR_RI1-TC|TI           RRIWSCP-SEC-EXT-EMPTEMP-PA-01/02 2
EGR_CMEP  CME-HUB-PROD    EGR_MDC-TI|PCIWDC*      cme-fw-hubprodglr-1/2/3/4        4
EGR_CMEN  CME-HUB-NONPROD EGR_CMEN-TC             cme-fw-nonprodglr-1/2            2
EGR_LV    LAS-VEGAS-COLO  EGR_MDC-TC|EGR_SHEAW-TC lgs1501/02-ext-pa-fw01/02        2
EGR_RIRETAIL RI-RETAIL-EXTFTD ...                 RRIWSDC-SEC-EXTFTD-01-04         4
EGR_MDCO  MDC-Office      ...                      mid-fw-officeext-pa-a/b          2
EGR_CMC   CMC-HUB         ...                      cmc-fw-hubprodglr-1/2            2
EGR_PCIMDCAPP/SYS/WEB  MDC PCI tiers              mid-fw-pciprod-*                 2 each
EGR_PCIWDCAPP/SYS/WEB  WDC PCI tiers              win-fw-pciprod-*                 2 each
```

CRITICAL: EGR_LV (LAS-VEGAS-COLO) serves BOTH EGR_MDC-TC AND EGR_SHEAW-TC —
it is a backup/overflow path for multiple routing domains, not just local egress.
EGR_CMEP (CME-HUB-PROD) similarly carries WDC PCI routing domains.

**app_egress_topology** — CIDR_24 × EGR_CODE:
```
CIDR_24, APM_IDS, APP_ACRONYMS, ROUTING_DOMAIN, EGR_CODE,
EGRESS_LOGICAL, FW_HOSTNAMES, MGMT_IPS, HERITAGE, PCI_DESIGNATION
```

**ip_resolution_index** — any IP → full context chain:
```
IP_ADDRESS, RESOLUTION_TYPE, APM_IDS, APP_ACRONYMS, ROUTING_DOMAIN,
EGR_CODE, EGRESS_LOGICAL, FW_HOSTNAMES, MGMT_IPS, CHAIN_DETAIL
```

---

## Routing Domain → EGR_CODE Key Facts

- `Internal-PBM` → EGR_RI1 (primary), EGR_RIRETAIL (retail)
- `Internal-HCB` → EGR_MDC, EGR_WDC, EGR_CMEP
- `EGR_MDC-TC`   → EGR_MDC + EGR_LV (backup)
- `EGR_SHEAW-TC` → EGR_SHEAW + EGR_LV (backup)
- `Internet-Facing` → EGR_SHEAE (Shea external internet edge)
- PCI domains (EGR_PCIMDCAPP-TC etc.) → dedicated PCI tier FWs only

Source of truth: egress_fw_mgmt_ips_v*.csv (ipam-db)
NOT fw_location_topology INTERNET_EGRESS_CLUSTER field — that field is
unreliable (missing for many FWs, uses Panorama device-group labels not RDs).

---

## Common Run Patterns

```bash
# Full rebuild + bundle
python3 build_object_pipeline.py --collect

# Skip object pre-build (canonical objects already current)
python3 build_object_pipeline.py --skip-obj --collect

# Already ran 2.5/2.6/2.7 manually — just rebuild catalog + bundle
python3 build_object_pipeline.py --skip-obj --skip-cloud --skip-geo --skip-ipclass --collect

# Dry run
python3 build_object_pipeline.py --dry-run

# Regenerate egress topology + full chain
python3 build_IP_Network_Egress_FW_topology.py
python3 build_object_pipeline.py --skip-obj --collect
```

---

## FW_MGMT Objects — Done (2026-08-23)

`build_ip_classification_objects.py` v1.3.0 added the `fw_mgmt` family:

```
FW_MGMT_EGR_MDC           2 IPs  (mid-fw-glr-pa-a/b)
FW_MGMT_EGR_WDC           2 IPs  (win-fw-glr-pa-a/b)
FW_MGMT_EGR_SHEAW         2 IPs
FW_MGMT_EGR_SHEAE         2 IPs
FW_MGMT_EGR_RI1           2 IPs
FW_MGMT_EGR_CMEP          4 IPs
FW_MGMT_EGR_CMEN          2 IPs
FW_MGMT_EGR_LV            2 IPs
FW_MGMT_EGR_RIRETAIL      4 IPs
FW_MGMT_EGR_CMC           2 IPs
FW_MGMT_EGR_MDCO          2 IPs
FW_MGMT_EGR_PCIMDCAPP     2 IPs  (Aetna HCB PCI)
FW_MGMT_EGR_PCIMDCSYS     2 IPs
FW_MGMT_EGR_PCIMDCWEB     2 IPs
FW_MGMT_EGR_PCIWDCAPP     2 IPs
FW_MGMT_EGR_PCIWDCSYS     2 IPs
FW_MGMT_EGR_PCIWDCWEB     2 IPs
FW_MGMT_ALL_EGRESS        38 IPs  (all egress FW mgmt IPs combined)
```

Source: `egress_fw_mgmt_ips_v*.csv` (MGMT_IP field, stored as /32 host routes).

---

## CVS PBM-Side PCI FW Registry — New (2026-08-23)

`cvs_pci_fw_mgmt_ips_v20260824.csv` — 22 FWs across 8 EGR_CODEs.
Separate file from `egress_fw_mgmt_ips` — these are internal PCI zone
enforcement FWs, NOT internet egress FWs. Schema identical for pipeline
compatibility.

```
EGR_PCISHEA      Shea-DC-PCI        10 VLAN contexts (FPR4145)  PCI-PBM
EGR_PCIRIWSDC    RI-Woonsocket-PCI  RRIWSDC-INTPCIFTD-01/02     PCI-PBM
EGR_PCICUMBER    Cumberland-PCI     RRICMDC-INT-PCI-01/02        PCI-PBM
EGR_PCIHOL       Holton-PCI         HOL-SEC-M1A-PCI-01           PCI-PBM
EGR_PCIPIH       Pittsburgh-PCI     PIH-SEC-M1A-PCI-01           PCI-PBM
EGR_PCIPTXSNMO   SanAntonio-PCI     ptxsnmosecintpcimdf-1        PCI-PBM
EGR_PCIGCP_USE4  GCP-PCI-USEast4    egc-use4-pci-ftd-01-vm       PCI-PBM|CLOUD
EGR_PCIGCP_USW2  GCP-PCI-USWest2    egc-usw2-pci-ftd-01-vm       PCI-PBM|CLOUD
```

CRITICAL: These are zone enforcement FWs — internet egress for their
subnets still goes through the main PBM egress path (EGR_RI1-TC).
Do NOT add their ROUTING_DOMAINs to STATIC_RD_TO_EGR — that would
corrupt the Internal-PBM → EGR_RI1 mapping for 7,738 subnets.

A full `pci_topology_registry` and `pci_subnet_index` are planned as
separate datasets (blocked on Internal-PBM/HCB → EGR_* IPAM translation).

---

## Relationship to FW Rule Normalization

```
Phase 1 (done):   fw_rule_db — inventory of existing rules
Phase 2 (needed): build_rule_abstraction.py — map rules to EDL objects
Phase 3 (done):   EDL object model — normalized target address library
Phase 4 (future): Tufin import — topology-specific rule push via EGR_CODE
```

Given an app (APM_ID):
→ app_egress_topology → EGR_CODE(s)
→ egress_topology_registry → FW_HOSTNAMES
→ fw_rule_db WHERE FW_NAME IN hostnames
→ rules to review / normalize / push
