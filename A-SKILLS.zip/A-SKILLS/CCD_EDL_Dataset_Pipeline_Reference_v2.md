# CCD Platform — EDL Dataset & Object Pipeline Reference

**CVS Health Information Security — CCD Platform**
Last updated: 2026-07-08 (v2 — see §11 Revision Notes)

---

## 1. Overview

The CCD object pipeline produces EDL (External Dynamic List) datasets from the IPAM and host master datasets, organized into families that map to `build_edl_catalog.py`'s catalog tabs. Each family serves a different role in Palo Alto Networks firewall policy:

| Family | Source script | Palo Alto role | Count (last confirmed) |
|--------|--------------|----------------|-------------------|
| **Internal Network Groups (NG)** | `build_network_groups.py` | Policy source side — "where is the traffic coming from?" (internal/RFC1918) | 727 EDL files (v20260623) |
| **External-NG** | `build_external_ng.py` | Policy source side — internet-facing CVS/Aetna CIDRs (BGP-announced, SNAT) | 13 EDL files (v20260708 test run) |
| **Partner-NG** | `build_partner_ng.py` | Policy source side — third-party B2B VPN/P2P partner subnets | 37 EDL files (v20260708 test run; VPN only — see §3.7) |
| **Service Objects (SO)** | `build_service_objects.py` | Policy destination side — "what application/server is being reached?" | 3,213 EDL files (v20260623) |
| **Cloud Services (IPDATASET)** | `build_ipdataset_objects.py` | External provider IP blocks for allow/block policy | 810 EDL files (v20260624) |
| **Geo-Block** | `build_geo_block_objects.py` | Country-based IP block lists | 14 EDL files (13 countries + ALL) |
| **User-Access** | `build_user_access_objects.py` | Policy source side — user-origin traffic (LAN/RA VPN/ZPA/VDI/Citrix/WLAN) | not covered in this doc — see `canonical_user_access_objects` output |

All families are assembled by `build_object_pipeline.py` and browsable via `edl_catalog.html` (served by `object-viewer-web-service.sh`). `build_edl_catalog.py`'s `DATASET_SLOTS` defines 9 tabs total (Internal-NG, External-NG, Partner-NG, Internal-NO, External-NO, Partner-NO, User-Access, Cloud Services, Geo-Block); External-NO and Partner-NO remain lifecycle-managed placeholders pending the FW Rule Lifecycle intent-policy delivery framework — not covered by this pipeline.

---

## 2. Filesystem Layout

```
~/Documents/IP_Lookup/
│
├── Net_Group/
│   └── NG-{DATE}_v{N}/               # e.g. NG-20260623_v4
│       ├── EDL/                       # One .txt per network group object
│       │   ├── AO-{NAME}.txt          # Address Object: /32 host lists
│       │   └── NG-{NAME}.txt          # Network Group: subnet summaries
│       └── ccd_network_groups.set     # Panorama CLI import bundle
│
├── External_NG/
│   └── NG-{DATE}_v{N}/               # written by build_external_ng.py — SAME
│       ├── EDL/                       # dir-naming convention as Net_Group (NG- prefix,
│       │   ├── AO-EIF-{SITE_CODE}.txt # _SLOT_PREFIX['external_ng']='NG' in
│       │   └── NG-EIF-{SITE_CODE}.txt # build_edl_catalog.py), just under its own subdir
│       ├── network_object_catalog_v{DATE}.csv
│       └── ng_manifest.csv
│
├── Partner_NG/
│   └── NG-{DATE}_v{N}/               # written by build_partner_ng.py — same
│       ├── EDL/                       # convention as External_NG above
│       │   ├── AO-VPN-{SITE}-{PARTNER}.txt
│       │   ├── NG-VPN-{SITE}.txt
│       │   └── NG-VPN-PARTNERS.txt
│       ├── network_object_catalog_v{DATE}.csv
│       └── ng_manifest.csv
│
├── Net_Object/
│   ├── SO-{DATE}_v{N}/               # e.g. SO-20260623_v4
│   │   ├── EDL/                       # One .txt per service object
│   │   │   ├── APP_{ACRONYM}_{BU}.txt
│   │   │   ├── SVC_{NAME}_{BU}.txt
│   │   │   ├── DELIVERY_{NAME}.txt
│   │   │   ├── INFRA_{TYPE}_{SITE}.txt
│   │   │   └── NG-SVC-*.txt           # Aggregate super-groups
│   │   └── service_objects_v{DATE}.set  # Panorama CLI import bundle
│   │
│   └── IPDATASET-v{DATE}/            # Run-date versioned (not data-date)
│       ├── edl/                       # lowercase — Cloud Services EDLs
│       │   ├── {PROVIDER}-{SCOPE}.txt  # e.g. AZURE-US-ALL.txt
│       │   └── GEO-BLOCK-{CC}.txt      # e.g. GEO-BLOCK-CN.txt
│       ├── ipdataset_manifest_v{DATE}.csv
│       ├── ipdataset_objects_v{DATE}.set
│       ├── geo_block_manifest_v{DATE}.csv
│       └── geo_block_objects_v{DATE}.set
│
└── FW-Egress_Out/                     # Output dir for egress topology scripts
```

**Critical path note:** NG and SO use uppercase `EDL/`; IPDATASET uses lowercase `edl/`. The catalog JavaScript and `collect-edl_bundle.sh` both depend on this distinction.

---

## 3. Network Groups (NG)

### 3.1 Purpose

Network Groups represent the **source side** of firewall policy. They answer: *"Which enterprise location is this traffic coming from?"* Each object is a location-scoped collection of IPAM subnets associated with a specific site or business unit.

### 3.2 Three-Tier Hierarchy

The NG model is strictly hierarchical. CIDRs live only at Tier 3; Tiers 1 and 2 are aggregating groups.

```
Tier 1 — Business Unit / Site Type
  e.g. NG-BU-DATACENTER, NG-BU-CORPORATE, NG-BU-RETAIL

Tier 2 — Location
  e.g. NG-CORAM-COLUMBIA-SC-CORAM  (subnets for Coram Columbia SC)

Tier 3 — Address Object (leaf CIDR list)
  AO-CORAM-COLUMBIA-SC-CORAM  (the actual /24s and /25s)
```

The `.set` file reflects this: Tier-3 address objects are defined first (`set address addr-…`), then assembled into Tier-2 address-groups, which are assembled into Tier-1 groups.

### 3.3 Object Naming Conventions

| Prefix | Meaning | Example |
|--------|---------|---------|
| `AO-{BU}-{CITY}-{ST}-{TYPE}` | Address Object — leaf CIDR list for one location | `AO-CORAM-COLUMBIA-SC-CORAM` |
| `NG-{BU}-{CITY}-{ST}-{TYPE}` | Network Group — references one or more AOs | `NG-CORAM-COLUMBIA-SC-CORAM` |
| `AO-AWS`, `AO-AZURE`, `AO-GCP` | Cloud routing domain aggregates | `AO-AWS` |
| `NG-DR-{SITE}` | DR site groups | `NG-DR-SPARKS-NV-SWITCH-TRE` |

The CITY and STATE fields derive from `CANONICAL_LOCATION` in `location_master`. The TYPE field is `LOCATION_TYPE` (e.g. CORAM, CAREPLUS, CALL-CENTER, OMNICARE).

### 3.4 EDL File Format

```
# AO-CORAM-COLUMBIA-SC-CORAM
# Export Date: 2026-06-23
# Source: CCD Platform build_network_groups.py v1.8.4
# Subnets: 5
# Tier: 3
#
10.49.232.128/25
10.49.152.0/24
...
```

One CIDR per line. Comments only in the header block.

### 3.5 Panorama Import

`ccd_network_groups.set` contains the full Panorama CLI command sequence:

1. `set address addr-{cidr}` — defines leaf address objects (Tier 3)
2. `set address-group {AO-name} static [...]` — assembles Tier-3 groups
3. `set address-group {NG-name} static [...]` — assembles Tier-2 aggregates
4. `set address-group {BU-name} static [...]` — assembles Tier-1 super-groups

Import with: `load config partial from ccd_network_groups.set`

### 3.6 Generating

```bash
# Full run (from IP_Lookup base dir)
python3 build_network_groups.py --dry-run
python3 build_network_groups.py

# Pipeline stage 1
python3 build_object_pipeline.py  # runs stages 0–8 in sequence
```

### 3.7 External-NG and Partner-NG

`build_network_groups.py` internally derives `NG-INTERNET-FACING`, `NG-VPN-PARTNERS`,
and `NG-P2P-PARTNERS` Tier-1 classes (from `internet_segments`, VPN, and P2P source
data respectively) — but historically wrote them into the same `Net_Group/NG-{DATE}_vN/`
output as Internal-NG. `build_edl_catalog.py`'s `DATASET_SLOTS` has expected External-NG
and Partner-NG as their own catalog tabs since its 7-tab layout (v1.2.0), read from
separate `External_NG/` and `Partner_NG/` directories — but nothing in the pipeline was
writing to those directories, so both tabs sat empty as lifecycle-managed placeholders.

**Resolution (2026-07-08):** Two standalone scripts, `build_external_ng.py` and
`build_partner_ng.py`, re-derive this content directly from the source registries
(independent of `build_network_groups.py`'s internal computation) and write it to the
`External_NG/` and `Partner_NG/` slots respectively. Wired into `build_object_pipeline.py`
as Stage 1.5 and Stage 1.6.

**`build_external_ng.py`** — Tier-1 `NG-INTERNET-FACING`, Tier-2 per location
(`NG-EIF-{SITE_CODE}`, LM-joined), Tier-3 concatenated CIDR object
(`AO-EIF-{SITE_CODE}`). Source: `ent-ipdataset-INTERNET-FACING-v*.csv`. **Scope limit:**
only consumes INTERNET-FACING — SNAT pool data (FW-SNAT-POOLS/F5-SNAT-POOLS) is not yet
merged in, unlike `build_network_groups.py`'s internal `tier4_inet` logic which combines
both ("snat+eif"). Confirmed test run against the 2026-07-08 collect: 138 CIDRs → 6
location groups → 13 EDL files.

**`build_partner_ng.py`** — Tier-1 `NG-VPN-PARTNERS` (+ `NG-P2P-PARTNERS` if subnet-level
P2P data exists), Tier-2 per gateway site (`NG-VPN-{SITE}`), Tier-3 per partner
(`AO-VPN-{SITE}-{PARTNER}`). Source: `ent-ipdataset-VPN-PROTECTED-SUBNETS-v*.csv`,
excluding `direction=LOCAL` rows. Confirmed test run: 99 CIDRs → 4 gateway sites → 37
EDL files.

**Known data gap — `NG-P2P-PARTNERS`:** The registered `ipam-db/` collect contains
`ent-ipdataset-P2P-LINK-REGISTRY-v*.csv`, but this is a tunnel/link-level summary
(`cvs_subnet_count`/`partner_subnet_count` columns — counts only, no actual CIDR column).
Neither `build_partner_ng.py` nor `build_network_groups.py`'s own `--p2p-subs` discovery
(which looks for a differently-named `ent-ipdataset-P2P-PROTECTED-SUBNETS-v*.csv`) can
populate `NG-P2P-PARTNERS` until a subnet-level P2P export exists. Both scripts detect
this and skip with an explicit warning rather than fabricating CIDRs from the summary
counts.

**Generating:**

```bash
python3 build_external_ng.py --dry-run
python3 build_external_ng.py
# Pipeline stage 1.5

python3 build_partner_ng.py --dry-run
python3 build_partner_ng.py
# Pipeline stage 1.6
```

---

## 4. Service Objects (SO)

### 4.1 Purpose

Service Objects represent the **destination side** of firewall policy. They answer: *"What application server or infrastructure component is being reached?"* Each object is a named collection of /32 host IPs belonging to a specific application or service, scoped to a business unit.

### 4.2 Object Classes

| Prefix | Class | Source | Example |
|--------|-------|--------|---------|
| `APP_{ACRONYM}_{BU}` | Application | `ent_host_master` + `app_subnet_index` | `APP_SPLUNKENTNONPCI_AZ` |
| `SVC_{NAME}_{BU}` | Infrastructure Service | CPC core services dataset | `SVC_AD_CORP_CVS_CVS` |
| `DELIVERY_{NAME}` | Platform Delivery | Delivery infrastructure dataset | `DELIVERY_SHARED_APP_PBM_SHEA` |
| `INFRA_{TYPE}_{SITE}` | Physical Infrastructure | ESXi/IBM HW inventory | `INFRA_ESXI_SHEA_PROD` |
| `NG-SVC-*` | Aggregate super-groups | Assembled from above | `NG-SVC-APP`, `NG-SVC-CPC` |

BU suffix values: `PBM` (Internal-PBM / CVS Caremark), `HCB` (Internal-HCB / Aetna), `AZ` (Azure), `GCP`, `AWS`, `COLO`, `INTERNET`, `RETAIL`, `UNKNOWN`.

### 4.3 EDL File Format

```
# APP_SPLUNKENTNONPCI_AZ
# Tier: 3
# Class: APP
# Generated by build_service_objects.py v1.0.5
# CIDRs: 11
10.74.9.37/32
10.74.9.38/32
...
```

All entries are /32 host addresses. One per line. Header metadata only.

### 4.4 Panorama Import — `.set` File

`service_objects_v{DATE}.set` is the DESTINATION-side counterpart to `ccd_network_groups.set`:

```
# DESTINATION SIDE of PA policy rules.
# Use alongside network_groups_v*.set (source side).

# ===== NG-SVC-APP — APP objects =====
set address host-10_242_82_68 ip-netmask 10.242.82.68/32
set address-group APP_1EPLAT_AZ static [ host-10_242_82_68 ... ]
...
```

Individual host address objects are named `host-{ip_with_underscores}`.

### 4.5 Counts (v20260623)

| Class | Object count |
|-------|-------------|
| APP | 2,725 |
| SVC | 269 |
| DELIVERY | 135 |
| INFRA | 78 |
| NG-SVC super-groups | 6 |
| **Total** | **3,213** |

### 4.6 Generating

```bash
python3 build_service_objects.py --dry-run
python3 build_service_objects.py
# Pipeline stage 3
```

---

## 5. Cloud Services (IPDATASET)

### 5.1 Purpose

Cloud Services EDLs contain the publicly routable IP blocks published by cloud providers and SaaS vendors. They are used to allow or monitor enterprise traffic to these external destinations. Unlike NG/SO, these are entirely external (non-RFC1918) addresses.

### 5.2 Source Registry — `ip_dataset.json`

`build_ipdataset_objects.py` reads filenames from `ip_dataset.json` (in `ipdatasets/`). **No hardcoded filenames.** The registry maps dataset serial numbers to filenames, categories, and metadata. The script processes all 35 registered datasets across three categories: IAAS, SAAS, and PARTNER.

### 5.3 Output Directory Versioning

The output directory is `Net_Object/IPDATASET-v{TODAY}` where TODAY is the **run date** (not the data date). This ensures the catalog's latest-directory sort always finds the current run.

### 5.4 EDL File Naming

```
{PROVIDER}-{SCOPE}.txt

Examples:
  AZURE-CLOUD-GLOBAL.txt     # All Azure global CIDRs
  AZURE-US-ALL.txt           # Azure US regions only
  AZURE-BACKUP-ALL.txt       # Azure Backup service tag
  CROWDSTRIKE-ALL.txt        # CrowdStrike Falcon sensor IPs
  ZSCALER-ALL.txt            # Zscaler proxy egress IPs
```

### 5.5 EDL File Format

```
# AZURE-CLOUD-GLOBAL — generated by build_ipdataset_objects.py v1.1.1
# 33362 CIDRs — 20260623
102.133.0.0/19
102.133.0.192/32
...
```

Mixed prefix lengths (unlike SO which is all /32). Header line includes CIDR count and data date.

### 5.6 Manifest File

`ipdataset_manifest_v{DATE}.csv` catalogs every object produced:

```
OBJECT_NAME,OBJECT_TYPE,CIDR_COUNT,SOURCE
CROWDSTRIKE-ALL,STATIC-GROUP,155,crowdstrike/ALL
AZURE-CLOUD-GLOBAL,EDL,33362,azure/Cloud-Global
...
```

### 5.7 Panorama Import — `.set` File

`ipdataset_objects_v{DATE}.set` contains static address group definitions for any objects small enough to embed directly, and EDL references for the larger ones. Import to the appropriate device group before referencing in policy.

### 5.8 Current Scale (v20260624)

810 EDL files written, 229,630 total CIDRs across all providers.

### 5.9 Generating

```bash
python3 build_ipdataset_objects.py --dry-run
python3 build_ipdataset_objects.py

# Pipeline stage 2.5
```

---

## 6. Geo-Block EDLs

### 6.1 Purpose

Geo-Block EDLs contain all CIDR ranges for a given country per the IP2Location LITE DB1 database. They are used for blanket country-based deny policy at the perimeter.

### 6.2 Source Database

IP2Location LITE DB1 CIDR (`IP2LOCATION-LITE-DB1.CIDR.CSV`) — 381,545 rows. Lives at `IP_Lookup/ipdatasets/`. `build_geo_block_objects.py` discovers it via a candidate path list; the current working path is `base_dir / 'ipdatasets' / 'IP2LOCATION-LITE-DB1.CIDR.CSV'`.

### 6.3 Country Set (v20260623)

13 countries blocked: NG (Nigeria), GH (Ghana), KZ (Kazakhstan), SN (Senegal), PK (Pakistan), UZ (Uzbekistan), KG (Kyrgyzstan), AF (Afghanistan), TJ (Tajikistan), TM (Turkmenistan), RU (Russia), IR (Iran), CN (China).

Special handling: Azure China CIDRs (`GEO-BLOCK-CN` carve-out) — 2 CIDRs removed from the CN block list to avoid breaking Azure China connectivity.

### 6.4 EDL File Naming

```
GEO-BLOCK-{ISO2}.txt     # Per-country
GEO-BLOCK-ALL.txt        # Union of all 13 countries (22,137 CIDRs)
```

### 6.5 EDL File Format

```
# GEO-BLOCK-CN — China
# Generated by build_geo_block_objects.py v1.0.2
# Generated at: 2026-06-24T01:29:41Z
# CIDRs: 6064
# Source: IP2Location LITE DB1 CIDR
1.0.1.0/24
1.0.2.0/23
...
```

### 6.6 Manifest File

`geo_block_manifest_v{DATE}.csv` catalogs the 14 objects:

```
OBJECT_NAME,OBJECT_TYPE,CIDR_COUNT,SOURCE
GEO-BLOCK-NG,EDL,592,geo_block/NG/Nigeria
GEO-BLOCK-CN,EDL,6064,geo_block/CN/China
GEO-BLOCK-ALL,EDL,22137,geo_block/ALL/combined
...
```

### 6.7 Generating

```bash
python3 build_geo_block_objects.py --dry-run
python3 build_geo_block_objects.py

# Pipeline stage 2.6
```

---

## 7. The Object Pipeline

### 7.1 Pipeline Script

`build_object_pipeline.py` is the master orchestrator. It runs all four dataset families in sequence, then optionally bundles outputs and serves the catalog.

```bash
# Full pipeline run
python3 build_object_pipeline.py

# With EDL bundle collection
python3 build_object_pipeline.py --collect

# With catalog web server
python3 build_object_pipeline.py --serve
```

### 7.2 Stage Sequence

| Stage | Script | Output |
|-------|--------|--------|
| 0 | `build_cpc_service_catalog.py` → `build_canonical_app_objects.py` → `build_user_access_objects.py` | CPC-CORE-SERVICES, canonical_app_objects, canonical_user_access_objects → ipam-db import (in that order; each is a prerequisite for Stage 3) |
| 1 | `build_network_groups.py` | `Net_Group/NG-{DATE}_v{N}/` |
| 1.5 | `build_external_ng.py` | `External_NG/NG-{DATE}_v{N}/` — populates the External-NG catalog tab |
| 1.6 | `build_partner_ng.py` | `Partner_NG/NG-{DATE}_v{N}/` — populates the Partner-NG catalog tab |
| 2 | `build_ng_report.py` | NG breakdown HTML/CSV |
| 2.5 | `build_ipdataset_objects.py` | `Net_Object/IPDATASET-v{DATE}/` |
| 2.6 | `build_geo_block_objects.py` | `Net_Object/IPDATASET-v{DATE}/` (merged) |
| 3 | `build_service_objects.py` | `Net_Object/SO-{DATE}_v{N}/` |
| 4 | `build_svc_report.py` | SO breakdown HTML/CSV |
| 5 | `build_edl_catalog.py` | `edl_catalog.html` |
| 6 | `generate_csna_hostgroups.py` | CSNA Stealthwatch export |
| 7 | `collect-edl_bundle.sh` | Only with `--collect` flag |
| 8 | `object-viewer-web-service.sh` | Only with `--serve` flag |

**Silent stage skip:** Stages 1.5, 1.6, 2.5, and 2.6 check `os.path.exists(scripts[key])` before running. If the corresponding script is missing from disk, the stage silently skips. Verify the relevant script is installed if External-NG, Partner-NG, Cloud Services, or Geo-Block tabs are empty in the catalog. Stages 1.5/1.6 can also be explicitly skipped with `--skip-external-ng`/`--skip-partner-ng`.

### 7.3 The EDL Catalog

`edl_catalog.html` is a self-contained interactive browser for all four families. It is rebuilt by Stage 5 using the existing HTML file as its template — `build_edl_catalog.py` strips the embedded catalog data and injects fresh data, so any fixes to the HTML template propagate automatically to future catalog builds.

**Catalog tabs (9 total, per `build_edl_catalog.py` `DATASET_SLOTS`):**

| Tab | slot_id | required | EDL base dir |
|-----|---------|----------|-------------|
| Internal-NG | `internal_ng` | Yes | `Net_Group/NG-{DATE}_v{N}/EDL/` (uppercase) |
| External-NG | `external_ng` | No | `External_NG/NG-{DATE}_v{N}/EDL/` — see §3.7 |
| Partner-NG | `partner_ng` | No | `Partner_NG/NG-{DATE}_v{N}/EDL/` — see §3.7 |
| Internal-NO | `internal_no` | Yes | `Net_Object/SO-{DATE}_v{N}/EDL/` (uppercase) |
| External-NO | `external_no` | No | `External_NO/` — lifecycle-managed placeholder, not built by this pipeline |
| Partner-NO | `partner_no` | No | `Partner_NO/` — lifecycle-managed placeholder, not built by this pipeline |
| User-Access | `user_access` | No | `Net_Object/UA-{DATE}_v{N}/EDL/` — from `build_user_access_objects.py`, not covered by this doc |
| Cloud Services | `cloud_services` | No | `Net_Object/IPDATASET-v{DATE}/edl/` (lowercase) |
| Geo-Block | `geo_block` | No | `Net_Object/IPDATASET-v{DATE}/edl/` (lowercase) |

`_SLOT_PREFIX` in `build_edl_catalog.py` dispatches each slot to its own directory-name prefix (`NG` for the three NG slots, `SO` for the three NO slots, `UA` for User-Access) so that one slot's directory can never be picked up by mistake for another — each slot only scans for its own dedicated prefix. The catalog identifies the active dataset by taking the latest-modified directory matching each slot's pattern.

**Serving the catalog:**

```bash
./object-viewer-web-service.sh
# or
python3 build_object_pipeline.py --serve
```

Starts a Python HTTP server on port 8080. Browser opens automatically to `http://localhost:8080/edl_catalog.html`.

### 7.4 EDL Bundle Collection

`collect-edl_bundle.sh` copies the current NG, SO, Cloud Services, and Geo-Block EDL files into a single timestamped bundle for delivery or archival.

It reads NG/SO version strings from the HTML comment in `edl_catalog.html` and uses `edl/` (lowercase) for IPDATASET directories and `EDL/` (uppercase) for NG/SO directories. This aligns with the actual directory structure.

---

## 8. Pipeline Run Checklist

Use this sequence for a clean daily pipeline run:

```bash
cd ~/Documents/IP_Lookup

# 1. Dry run to verify inputs
python3 build_object_pipeline.py --dry-run

# 2. Full pipeline
python3 build_object_pipeline.py

# 3. Verify catalog counts
#    Internal-NG: ~727 EDL files
#    External-NG: check against ent-ipdataset-INTERNET-FACING row count (~138 CIDRs, 6 sites as of 2026-07-08)
#    Partner-NG: check against VPN-PROTECTED-SUBNETS non-LOCAL rows (~99 CIDRs, 4 sites as of 2026-07-08;
#                NG-P2P-PARTNERS will be 0 until a subnet-level P2P export exists — see §3.7)
#    SO: ~3,213 EDL files
#    Cloud Services: ~810 EDL files
#    Geo-Block: 14 EDL files (13 countries + ALL)

# 4. Serve and inspect
./object-viewer-web-service.sh

# 5. Collect bundle (when ready for delivery)
python3 build_object_pipeline.py --collect
```

**If Cloud Services, Geo-Block, External-NG, or Partner-NG tabs are empty:** verify
`build_ipdataset_objects.py`, `build_geo_block_objects.py`, `build_external_ng.py`, and
`build_partner_ng.py` (respectively) are present in the base IP_Lookup directory. The
pipeline silently skips stages when the scripts aren't found on disk.

---

## 11. Revision Notes

**v2 — 2026-07-08.** This document previously described a 4-family/4-tab EDL model
(NG, SO, Cloud Services, Geo-Block) that had drifted out of sync with
`build_edl_catalog.py`, which had already moved to a 9-slot `DATASET_SLOTS` layout
(Internal/External/Partner-NG, Internal/External/Partner-NO, User-Access, Cloud
Services, Geo-Block) as of its v1.2.0/v1.3.0 changes. This revision:

- Documents External-NG and Partner-NG (§3.7) and the two new scripts that populate
  them, `build_external_ng.py` and `build_partner_ng.py` (both v1.0.0, standalone,
  independent of `build_network_groups.py`'s internal computation of the same Tier-1
  classes).
- Wires both into `build_object_pipeline.py` as Stage 1.5 / Stage 1.6
  (`build_object_pipeline.py` bumped v1.6.1 → v1.7.0).
- Corrects the Stage 0 script list (was showing only `build_canonical_app_objects.py`;
  actually three scripts run in sequence) and the full script version table (§9).
- Documents the 9-tab catalog slot table (§7.3) including the still-unbuilt
  lifecycle-managed placeholders (External-NO, Partner-NO) and the undocumented
  User-Access tab (flagged, not fully documented — out of scope for this revision).
- Flags a known upstream data gap: no subnet-level P2P dataset exists in the current
  `ipam-db/` collect, so `NG-P2P-PARTNERS` cannot be populated by any script until one
  is generated.

**Not addressed in this revision:** full documentation of the User-Access tab
(`build_user_access_objects.py`), External-NO/Partner-NO (still placeholders pending
the FW Rule Lifecycle framework), and the P2P subnet-level export gap itself (tracked
as a follow-up, not fixed here).

---

## 9. Script Version Reference

| Script | Current version | Role |
|--------|----------------|------|
| `build_cpc_service_catalog.py` | v1.2.2 | Stage 0 — CPC core services prerequisite |
| `build_canonical_app_objects.py` | v1.9.1 | Stage 0 — canonical app objects prerequisite |
| `build_user_access_objects.py` | v1.7.0 | Stage 0 — canonical user-access objects prerequisite; also feeds User-Access catalog tab |
| `build_network_groups.py` | v1.8.6 | Stage 1 — Internal-NG generation |
| `build_external_ng.py` | v1.0.0 | Stage 1.5 — External-NG generation (new 2026-07-08, see §3.7) |
| `build_partner_ng.py` | v1.0.0 | Stage 1.6 — Partner-NG generation (new 2026-07-08, see §3.7) |
| `build_ng_report.py` | v1.3.2 | Stage 2 — NG breakdown report |
| `build_ipdataset_objects.py` | v1.1.1 | Stage 2.5 — Cloud Services EDLs |
| `build_geo_block_objects.py` | v1.0.2 | Stage 2.6 — Geo-Block EDLs |
| `build_service_objects.py` | v1.2.1 | Stage 3 — SO generation |
| `build_svc_report.py` | v1.0.5 | Stage 4 — SO breakdown report |
| `build_edl_catalog.py` | v1.5.1 | Stage 5 — Catalog HTML assembly, 9-slot `DATASET_SLOTS` |
| `generate_csna_hostgroups.py` | v4.0.3 | Stage 6 — CSNA Stealthwatch export |
| `build_object_pipeline.py` | v1.7.0 | Master orchestrator |
| `object-viewer-web-service.sh` | v1.0.0 | HTTP catalog server |
| `collect-edl_bundle.sh` | — | Bundle collector |

Versions above reflect the 2026-07-08 upload/reconciliation session. Re-verify with
`--version` on Yggdrasil before relying on this table for anything version-sensitive.

---

## 10. Key Architectural Rules

**IPAM-first:** No subnet enters any NG or SO object without a verified `CANONICAL_LOCATION` in `location_master`. The pipeline inherits the IPAM hard gate.

**No hardcoded filenames in IPDATASET:** `build_ipdataset_objects.py` reads all filenames from `ip_dataset.json`. Adding a new provider dataset to the registry is sufficient — no script changes needed.

**Run date vs. data date:** IPDATASET output directories use the run date (`IPDATASET-v{TODAY}`), not the dataset's data date. This ensures the catalog's latest-directory sort always resolves to the current run.

**Case sensitivity matters:** NG/SO EDL directories are `EDL/` (uppercase). IPDATASET EDL directories are `edl/` (lowercase). The catalog JavaScript, `collect-edl_bundle.sh`, and all path construction in the scripts must respect this distinction.

**Template propagation:** Because `build_edl_catalog.py` uses the existing `edl_catalog.html` as its template, fixing a bug in the HTML (JavaScript logic, CSS, etc.) automatically propagates to all subsequent catalog rebuilds. There is no separate template file to keep in sync.

**Geo-Block DB path:** The IP2Location LITE database must be present at `IP_Lookup/ipdatasets/IP2LOCATION-LITE-DB1.CIDR.CSV`. The script searches a candidate path list and fails cleanly if no candidate is found.
