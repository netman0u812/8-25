# Skyhigh / McAfee Web Gateway (SK Proxy) Structural Reference

Confirmed facts from direct reads of gwrs.xml this engagement.

## Architecture: implicit-permit forward proxy

SK forwards traffic by default; rules carve out exceptions (block, or `stopcycle`/`stoprulegroup` early exits). This is the structural opposite of Palo Alto's explicit-permit inline model. **There is no global/default block rule** -- confirmed by checking the last rules in the ruleset (all logging, not a catch-all deny) and searching for any rule named Global Block/Default Block/Deny All/Catch-all (none found). Traffic reaching the end of the ruleset without being explicitly blocked by a specific rule simply passes through. Do not assume a PAN-OS-style default-deny fallback exists here; its absence is the defining architectural trait, not a gap.

Entry to the proxy is via active redirection only, never transparent interception -- WCCP (network-infrastructure-based redirection) or explicit `proxy.pac` (client-side). In this environment: **WCCP for CVS, proxy.pac specifically for Aetna** -- these are platform-specific, not interchangeable mechanisms both used everywhere; confirm which applies before describing entry mechanism generically.

## Rule group evaluation order is determined by byte offset in the raw XML, not by section headers

Rule groups execute in the order they appear in the file. To determine which stage a specific rule belongs to, find its byte offset and compare against the confirmed offsets of named rule groups -- don't assume a rule belongs to the nearest-named group without checking. This engagement found a real, previously-uncatalogued rule group (web/URL category- and reputation-based blocking) sitting between two already-named stages (`Global Allow Rule` and `DLP Precheck`) purely by offset comparison -- it had no clean `ruleGroup name=` wrapper findable by the obvious search pattern, and had gone completely uncatalogued until the byte-offset check was done.

## stopcycle vs. stoprulegroup -- materially different, confirm which one a rule uses

`stopcycle`: terminates the **entire remaining rule-processing cycle** for that transaction -- skips every downstream rule group (Content Inspection, DLP, AV, everything). `stoprulegroup`: exits only the **current rule group**, downstream groups still evaluate normally. A rule that looks like a broad "allow and skip everything" rule based on its name needs its actual terminal action checked -- confirmed this engagement that `Global Allow Rule` uses `stoprulegroup` (narrow: category-block override only, does NOT bypass DLP/AV/file-blocking), while several Housekeeping bypass rules use `stopcycle` (broad: genuinely skip all downstream inspection).

## McAfee TrustedSource engine -- category and reputation matching

Real rules use `com.scur.engine.trustedsource.url.categories` (category-based) and a separate reputation-scoring mechanism, matched against a list ID (e.g., `<listValue id="17066"/>`). **The actual category names in the referenced list are frequently not present in the same export as the rule that references it** -- confirmed this engagement (searched all occurrences of a specific list ID, found only the rule's own reference to it, no separate list-definition block anywhere in the file). This is architecturally the same pattern as PA's category `block[]` lists (a local selection from a fixed taxonomy, not a fetched external list) -- don't expect a URL/fetch mechanism to explain the missing content; it's a local selection whose human-readable mapping isn't in this particular export.

## Header manipulation rules (remove/check/add pattern)

Real rules exist using `removeheaders`, `hasheader`, and `addheader` procedure actions on named HTTP headers -- confirmed for Azure Tenant Restrictions specifically (`Restrict-Access-To-Tenants`, the TRv1 header). **Check the actual configured header value, not just whether the rule/infrastructure exists** -- a rule can have entirely correct, real remove/check/add scaffolding while its configured value is an obvious placeholder (e.g., `"ABCD1234567890abcdef"`, not a valid GUID format), making it non-functional despite looking complete.

## Terminology traps confirmed this engagement -- verify before repeating

- **"Denied Categories" does not mean blocked.** On both SK and PA, a category list with "denied" or "deny" in its name can still result in a non-blocking action (SK: some denied-category rules result in tag/log only; PA: `ALL-TO-INTERNET-DECRYPT-DENIED-CATEGORIES` results in `action=decrypt`). Always check the rule's actual terminal action, never infer it from the rule/list name.
- **"DLP" is SK's own correct terminology** (their rule groups are literally named `DLP Precheck`, `DLP in Request Cycle`, etc.) -- but is NOT Palo Alto's terminology. On PA, the equivalent capability is called **Data Filtering**; PA reserves "DLP" for a separate, more advanced licensed product (Enterprise DLP). Don't carry SK's "DLP" label over to describe PA's Data Filtering profiles -- confirmed this was a real mislabeling error made and corrected this engagement.
- **X-Forwarded-For removal (SK) and PAN-OS's XFF-related setting are not the same function.** SK's rule strips the header (privacy/hygiene, since SK as a forward proxy would otherwise leak internal client IPs to external destinations it's supposedly masking). PAN-OS's XFF-related setting (found nested in a URL Filtering profile as HTTP Header Logging) *adds/logs* the header for visibility, since PA as an inline device doesn't substitute its own IP the way a proxy does and so never creates the leak SK's rule exists to prevent. Confirm which direction (add vs. remove) a header-related finding actually is before comparing it across platforms.
