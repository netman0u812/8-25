# Cross-Platform Comparison Methodology

How to structure a parity/gap analysis between two architecturally different security platforms (this engagement: SK proxy vs. Palo Alto NGFW) without producing false equivalencies in either direction.

## Describe outcomes first, mechanisms second

Don't build the comparison as a rule-by-rule or object-by-object mapping -- the platforms are different enough (implicit-permit forward proxy vs. explicit-permit inline firewall) that forcing a 1:1 mapping produces false equivalencies. Structure each functional area as: what security outcome does this achieve, then how does each platform achieve it (which may be structurally unrelated mechanisms, or may not exist at all on one platform).

When one platform genuinely has no equivalent to a function the other platform performs, state that plainly as **"N/A -- structurally unnecessary"** or similar, with the architectural reason given directly (e.g., PA doesn't need SK's fast-path/bypass rules because PA's explicit-permit-by-default model already denies unmatched traffic without a separate stage). This is different from and should not be confused with a genuine gap -- don't let "no equivalent found" default to reading as "missing capability" when the reason is structural.

## Positional/structural analogies must be labeled as analogies

When describing one platform's stage as occupying "the same relative position" as a stage on the other platform, say so explicitly as a positional/structural analogy -- not as a claim about confirmed identical behavior or confirmed evaluation order. If the actual evaluation-order relationship between a specific mechanism and neighboring stages isn't independently confirmed on the platform being described, say that directly rather than let the analogy imply more certainty than exists.

## "SH Delivery" / functional-delivery-status framing

At one point in this engagement, every stage of a platform's pipeline diagram was annotated with an explicit delivery verdict (DELIVERED / NOT DELIVERED / PARTIALLY DELIVERED / NOT LIVE / N/A) stating directly whether that stage actually delivers the other platform's equivalent function today. This is a genuinely useful framing for a parity-focused deliverable, but it was later explicitly reverted at user request -- **it is not a default the user necessarily wants applied**, even though it was requested once. Offer it as an option when building a parity-framed pipeline diagram; don't assume it should be there, and don't re-add it after an explicit removal without being asked again.

## Don't conflate structurally independent estates within one platform

The same platform (Palo Alto in this engagement) can have multiple structurally independent deployments (separate Panorama instances, separate device-group/profile-group naming conventions, zero shared configuration) that should never be presented as one combined posture. State which specific cluster/estate every finding applies to, every time, and periodically re-check that a document's own stated scope still matches what's actually been added to it -- scope tends to silently expand as more material gets folded in during a long engagement, and the document's own Purpose/scope statement needs to be updated to match, not left describing an earlier, narrower state.

## When asked to "reconfirm" or answer a binary question about a nuanced finding, resist collapsing the nuance

A recurring pattern this engagement: being asked "is there any content-inspection anywhere" or "is X blocked" as if the answer were a clean yes/no, when the actual, defensible answer is "absent in the dominant path, present in a narrow confirmed exception." Give the precise, complete distribution rather than picking the side of the binary that's closer to true on average -- both "yes, plenty of inspection exists" and "no, none exists anywhere" would be defensible-sounding but wrong statements built from an accurate underlying finding. State the real distribution, even when a shorter binary answer was what was asked for.
