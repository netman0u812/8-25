# Palo Alto / Panorama Structural Reference

Confirmed facts from direct config reads this engagement. Where something is stated as a general PAN-OS fact rather than something read in a specific config, it's marked as such.

## Device Group vs. Profile Group -- do not conflate these

**Device Group**: a Panorama-level construct that groups physical firewalls together so a shared set of policies/objects/profiles can be pushed to all of them. Confirmed real device groups this engagement: `HCB-DMZ`, `MID-WIN-GLR`, `Officeext`, `AWS` (Aetna Cluster B); `DG_LV_Egress`, `DG_RI_Egress`, `DG_AZ_Egress`, `DG_HOL_PCI`, and related `_EXT_DMZ`/`_3rd_Party`/`_EXT_APP` variants (CVS Cluster A).

**Profile Group** (aka Security Profile Group, "SPG" in this environment's naming): a bundle of individual security profiles (virus, spyware, vulnerability, url-filtering, file-blocking, data-filtering, wildfire-analysis) that a security rule attaches by referencing the bundle's name. Confirmed 27 unique profile groups across both clusters checked this engagement -- do not assume a short list is exhaustive; enumerate via every object followed by `virus X;`.

A device group typically has ONE profile-group assignment in its own Panorama config block, but individual profile groups (especially on CVS Cluster A) are referenced by rules across MULTIPLE device groups -- confirm actual usage per profile group with a reference count (`group NAME;` occurrences), don't assume 1:1.

**Physical firewall identity (hostname, management IP) lives in a third, separate place**: individual firewall config exports (not Panorama). These typically have an EMPTY local security rulebase (`security { rules; }`) because rules are pushed from Panorama -- don't expect to find security policy in an individual firewall's own config file. What you can find there: the device's own management IP (`ip-address X;` near `hostname Y;`), HA-pair role, and sometimes a `show running security-policy` CLI-output dump that reveals the *effective* pushed ruleset (a different, flatter format than the Panorama XML structure -- rule blocks like `"NAME; index: N" { from X; source [...]; action Y; }`, with no `profile-setting` field visible in that output format at all -- absence of that field in this output does not mean no profile is attached, it means this CLI command doesn't display it).

## The 7 real Content-ID profile types

Virus (Antivirus), Spyware (Anti-Spyware), Vulnerability (Vulnerability Protection), File Blocking, URL Filtering, WildFire Analysis, Data Filtering. Check every one of these 7 fields individually for every profile group being characterized -- "ABSENT" (field not present at all) is a distinct, common, important state, different from "ALERT" (present but log-only) and "BLOCK" (present and enforcing).

## Decryption Policy's real action set -- it cannot block or permit

The decryption rulebase has exactly three valid actions: `no-decrypt` (default), `decrypt`, `decrypt-and-forward`. **There is no block or deny action.** A rule named with "Denied" or "Deny" in it that lives in the decryption rulebase almost certainly still results in `action=decrypt` -- confirmed directly this engagement (`ALL-TO-INTERNET-DECRYPT-DENIED-CATEGORIES` results in decrypt, for closer inspection, not exclusion). Category names in decrypt rules describe decrypt-scoping only, never content inspection or traffic control.

The one real exception: a **Decryption Profile** attached to a no-decrypt rule can block based on **certificate validity** (expired cert, untrusted issuer, unsupported version/cipher) -- but that's triggered by the certificate itself failing validation, not by the URL category that got the session there. Certificate-validity blocking and content-category matching are architecturally unconnected axes.

The actual permit/deny decision for traffic happens entirely in the separate **Security Policy** rulebase, confirmed to share zero match criteria with Decryption Policy. A session's decrypt outcome has no structural link to its eventual permit/deny outcome.

## Interzone / Intrazone defaults

PAN-OS factory default: `interzone-default=deny`, `intrazone-default=allow`. Both are overridable per device group. Check both explicitly per device group -- don't assume factory defaults hold, and don't assume a hardening pattern found on one device group extends to others in the same cluster (this engagement found Aetna had explicitly hardened `intrazone-default` to `drop` on nearly every device group except one; CVS Cluster A largely still ran the permissive factory default across every device group checked).

## URL Filtering profile structure

Each profile has `block [...]` and `alert [...]` category lists (space-separated category names, both standard PAN-DB categories and custom-defined categories). **Read the actual `block[]` list, not just whether a `url-filtering` field is present** -- a profile can be attached and still have an empty or near-empty block list (pure alert-only), or can have a real 34-44 category block list. Custom category names that don't match the standard ~89-category PAN-DB taxonomy are locally-defined "Custom URL Category" objects (`type "URL List"`), typically a static domain list -- these function as SNI-matchable categories the same as built-in ones, but their content doesn't update from any external feed unless the object itself is later converted to an EDL.

**SNI mechanism**: category matching works without decryption via the SNI field (sent in cleartext during the TLS handshake). Once a session is decrypted, category matching switches to the actual HTTP Host header/URL path instead. A documented platform behavior (CVE-2020-2035) means SNI is not separately re-checked for category enforcement once a session is configured for decryption -- enforcement in that case relies entirely on the post-decrypt HTTP data.

## File Blocking's multi-rule, catch-all structure

A single File Blocking profile object commonly contains **multiple ordered rules**, not one flat list. Confirmed pattern this engagement: explicit block rules for specific high-risk extensions and encrypted archive/document formats, followed by a final catch-all rule (`file-type=any`, `action=alert`) that anything not matching the earlier rules falls through to. Read every rule within the profile, not just the first -- the profile's real enforcement coverage is exactly as complete as its explicit block rules; everything else defaults to whatever the catch-all does.

**Profile variants are a real, used exception mechanism**: differently-named File Blocking (and other) profile objects that are near-identical except for one rule's presence/absence get assigned to different profile groups to carve out specific exceptions (e.g., a variant missing the "block encrypted Office/PDF" rule, assigned specifically to a profile group that needs that exception). Confirming an exception exists requires diffing the suspect variant against the baseline profile it's presumably derived from.

## Data Filtering profile structure

Each rule within a Data Filtering profile can reference multiple named patterns (both PAN-OS Predefined Data Patterns -- confirmed to exist for SSN, Credit Card, banking identifiers, tax IDs, national IDs across many countries, and healthcare identifiers, referenced by name with no local definition needed -- and custom regex patterns). **Each pattern within a rule has its own independently-delimited match/occurrence/confidence block, even when multiple patterns share one rule** -- meaning a rule bundling 22 patterns together still has each pattern individually addressable; the constraint is that action applies at the rule level, so all patterns sharing one rule share one action.

**Data Filtering rules have no source-user, user-group, destination, or domain fields of their own** -- confirmed directly. AD-group or domain-based Data Filtering exceptions require two things working together: (1) a security rule matching the specific group/domain (source-user/destination fields live at the security-rule layer only), attached to (2) a specific Data Filtering profile variant carrying the appropriate pattern set. Splitting bundled patterns into one-pattern-per-rule is a precondition that makes building such variants clean, not something that by itself creates the AD-group/domain targeting capability.

## HTTP Header Insertion (Azure Tenant Restrictions and similar)

A real PAN-OS feature, structurally nested inside a URL Filtering profile object (found as `http-header-insertion { PolicyName { ... } }` inside a named url-filtering profile). Distinguish TRv1 header (`Restrict-Access-To-Tenants`) from TRv2 header (`sec-Restrict-Tenant-Access-Policy`) -- these are different feature versions, not naming variants; check which one is actually present rather than assuming. This mechanism requires the session to be decrypted to function (header insertion only operates on traffic the platform can read/modify) -- check for a corresponding active decrypt rule before treating the header-insertion policy as functional.
