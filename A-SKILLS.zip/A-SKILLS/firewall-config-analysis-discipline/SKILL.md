---
name: firewall-config-analysis-discipline
description: Verification discipline and structural knowledge for analyzing Palo Alto NGFW and Skyhigh/McAfee SWG (SK proxy) configurations -- Panorama exports, individual firewall configs, and gwrs.xml rule dumps. Use this whenever the user asks about PA or SK security policy, profile groups, device groups, decrypt rules, DLP/data-filtering, URL filtering, file blocking, or any claim about what a firewall "does" or "blocks." Trigger on mentions of Panorama, profile-group, device-group, security profile, url-filtering, data-filtering, gwrs.xml, McAfee, Skyhigh, SK proxy, or any request to characterize firewall coverage, enforcement, or parity between platforms. This skill exists specifically because naming conventions and partial searches produced real, repeated wrong answers this engagement -- read it before asserting any claim about these platforms' actual behavior.
---

# Firewall Configuration Analysis Discipline

This skill captures verification discipline earned the hard way across an extended CVS Health / Aetna PA + SK config analysis engagement. Every principle below corresponds to a real, specific mistake that was made and caught -- not hypothetical caution. Read `references/` files as indicated; they contain the structural facts, this file contains the discipline for using them correctly.

## The core failure mode this skill exists to prevent

**A profile group's name, or one component's behavior, is not evidence for the rest of the profile group's behavior.** The single most expensive mistake this engagement: `Vulnerability_Best_Practice_SP` was assumed to be enforcing because it shares the `_Best_Practice_SP` naming convention with `AV_Best_Practice_SP` (confirmed enforcing, action=reset-both) and `File_Blocking_Best_Practice_SP` (confirmed enforcing). Individually checking it found **14 of 14 severity/category rules set to alert, zero blocking** -- the name was misleading. This had already been written into a delivered document before the individual check caught it.

**The rule this produces: check every component of every profile group individually. Never infer one component's action from another's, and never infer a profile's action from its name.**

## Enumeration discipline

**Partial search results are not complete results until you have explicitly enumerated everything and can state a total count.** This engagement repeatedly found more objects than an initial targeted search returned:

- A targeted check found 2 URL-filtering profiles worth examining on the Aetna side. A full enumeration (`grep` for every `url-filtering X;` reference) found **16**. The same full enumeration on the CVS side found **21** where only a handful had been individually checked.
- A targeted check found 6-7 security profile groups. A full enumeration (every object followed by `virus X;`) found **27**.
- Asking "is there a set of SPG in Panorama" (a direct nudge, not a self-generated check) is what triggered the enumeration that found the 27. Don't wait for that nudge -- when characterizing "what profile groups/lists/rules exist," always run the full-enumeration query first, before any targeted spot-check.

**Practical pattern**: for any config object type (profile group, url-filtering profile, decrypt rule, device group), first count *how many exist total* with a broad structural regex (e.g., `NAME { \s*\n\s*virus `), then decide how many need individual verification. Report the total count explicitly ("31 profile groups confirmed to exist, X individually verified") rather than presenting a partial list as if it were exhaustive.

## Verification discipline

**Every specific factual claim (a count, a category name, an IP address, an action) must be traced to a direct read of the raw config, not recalled, not inferred from a similar-looking object, and not assumed from documentation of the general product.** Concretely:

- When told a fact by the user that you have not independently verified (e.g., an operator describing a rule from memory), say so explicitly in whatever you produce -- "operator-provided, not independently verified against any config checked" -- rather than silently absorbing it as confirmed.
- When a claim can be corroborated by a mechanism found in the raw config, say so; when it cannot (searched and found nothing), say that precisely too. Don't let an unconfirmable claim sit un-flagged next to confirmed ones.
- Re-verify claims that predate this specific check, even your own. A prior response in the same engagement having said something is not evidence -- if it becomes relevant again, check it again against the raw config, not against what was said before.
- Distinguish sourcing precisely in writing: CONFIRMED (read directly), INFERRED (pattern match, not verified -- e.g. a hostname suggesting a device-group membership), NOT CONFIRMED (checked, found nothing), OPERATOR-PROVIDED (stated by the user, not independently checked). Never blur these into one undifferentiated claim.

## Don't conflate scopes

**Palo Alto Panorama environments in this engagement span multiple structurally independent clusters** (e.g., "Aetna Cluster B" vs "CVS Cluster A" -- separate Panorama instances, separate device groups, separate profile-group naming conventions, zero shared configuration). A finding from one cluster's config is not evidence about the other cluster. State which cluster every finding applies to, explicitly, every time -- do not let a document's stated scope ("this section covers Cluster B") silently go stale as material from a different cluster gets added to it later. Check the document's own scope statement against what's actually in it periodically.

**Similarly, don't let one platform's terminology or architecture bleed into how you describe the other.** SK and PA are architecturally different (implicit-permit forward proxy vs. explicit-permit inline firewall). A rule-by-rule comparison between them produces false equivalencies. Describe what security outcome each function achieves, then how each platform achieves it -- which may be a structurally different mechanism entirely, or may not exist on one platform at all (state "N/A -- structurally unnecessary," not "missing").

## Build/tooling discipline (when producing a document from this analysis)

Several real bugs were introduced and caught during document production, not just during config analysis:

- **A file-reference edit can silently do nothing.** `content.replace(old_string, new_string)` on a string that doesn't exist in the target returns the input unchanged with no error. After any find-and-replace targeting a file path or generated content reference, grep the result to confirm the new reference is actually present -- don't trust that the script ran without error.
- **After any structural edit (splicing content, reordering sections), actually render the output (PDF or equivalent) and view the affected pages.** A docx that validates as well-formed XML can still have silently misaligned tables, a blank page from a duplicated page-break, or a truncated diagram from an indent value that overflowed the page width. Validation confirms the file opens; it does not confirm it looks right.
- **When computing a display column position (e.g., aligning a label column across many rows), compute it programmatically from the actual longest string, don't guess a fixed width.** A hand-typed padding value will be wrong the moment any row's content changes length.
- **CSV/structured text with unescaped delimiters inside a field breaks naive parsing.** A regex quantifier like `{1,8}` inside a CSV cell contains a comma that a naive `.split(',')` will treat as a field boundary, silently shifting every subsequent column. If a parsed field's content looks truncated or misplaced, check whether the source delimiter appears unescaped inside the data itself before assuming the source is simply wrong.

## Reference files

- `references/palo-alto-structure.md` -- PAN-OS/Panorama object model: device groups vs. profile groups, the 7 real Content-ID profile types, decryption rulebase's real action set, interzone/intrazone defaults, URL filtering block[]/alert[] structure, File Blocking's multi-rule-with-catch-all pattern, Data Filtering's per-pattern structure and exception mechanisms.
- `references/sk-mcafee-structure.md` -- SK/MWG (gwrs.xml) object model: rule group evaluation order via byte offset, stopcycle vs. stoprulegroup, implicit-permit architecture, McAfee TrustedSource category/reputation engine, common terminology traps (e.g., "Denied Categories" that still result in decrypt, not block).
- `references/cross-platform-comparison.md` -- How to structure a parity/gap analysis between two architecturally different platforms without producing false equivalencies; the "SH Delivery status" framing pattern and when it was and wasn't wanted.
