# Technical Specification: FW Class Tagging and Home/Not-Home Traffic Modeling

**Audience:** an engineer (human or AI) implementing this from scratch, with access to the real
`fwlookup.py`, `fw_rule_db.sqlite`, `fw_group_db.sqlite`, `fw_route_db.sqlite`, and the
`fw-policy-classification` skill, but no other context.
**Status:** design spec, not yet implemented.
**Builds on:** `fw-policy-classification` (the classification methodology this implements) and
`fwlookup_plugin_architecture_spec.md` (the mechanism this is delivered through -- new plugins
under that contract, not a new extension mechanism).

---

## 1. Background — why this exists

The `fw-policy-classification` skill establishes that most firewall rules on this estate are best
read as **Home Net (Trust) to Not-Home (Untrust)**, and that an `ANY` match is not literally
unbounded -- it means "whatever traffic naturally arrives here, because this device is the gateway
of last resort for its source population." Two real, already-built pieces of infrastructure exist
toward contextualizing that specifically:

- `HERITAGE` (`fw_config_manifest.py`, sourced from `fw_location_topology.py`)
- `EGRESS_FIREWALL_CLUSTER`/`ASSIGNED_FW` (`fw_location_topology.py`, scoped to internet egress only)

Neither is complete, and neither is derived from the most authoritative source available:
**`fw_route_db.sqlite`'s own `fw_interfaces` (directly-connected subnets per device) and
`fw_routes` (full routing table per device) tables — real, already-built, already-registered data
(13,501 rows, confirmed) that has never been used for classification at all.** This spec is about
using that data properly, not collecting anything new.

With hundreds of FW configs and more being added continuously, classification has to scale --
manual, per-device reasoning (the way the real Vegas/Semafone investigation was done, by hand,
against a Panorama export) does not scale to the full estate. **The goal of this spec is to make
that same kind of reasoning computable and repeatable**, exposed through `fwlookup.py` plugins.

---

## 2. Goals

- **G1.** Compute, from real data (not zone names, not hostnames), the Home/Not-Home boundary for
  any device: which subnets are directly connected or internally routed (Home), and which
  routes represent the gateway-of-last-resort path toward Not-Home (Internet, Cloud, a specific
  Partner, etc.).
- **G2.** Tag each device (or, for Shea/Vegas-pattern consolidated hardware, each zone-pair --
  see `fw-policy-classification`'s "one device, multiple classes" section) with the Firewall
  Class(es) it actually supports, from the 10-class taxonomy already defined in the skill.
- **G3.** Determine real traffic direction (client→server vs. server→client) per Home↔Not-Home
  zone-pair, from actual `fw_rule_db` ALLOW rules -- not inferred from zone naming.
- **G4.** Deliver all of this as `fwlookup.py` plugins under the existing plugin contract, with a
  concrete, fully worked example: model a PCI firewall's Trust/Home→Untrust traffic, using
  directly-connected and routing-table subnet mapping as the Home determination mechanism.
- **G5.** Extend the existing `HERITAGE`/`EGRESS_FIREWALL_CLUSTER` mechanism rather than duplicate
  or replace it -- cross-check against it, and where it's more specific (e.g. it names a
  particular assigned egress cluster), prefer it as a secondary confirming signal alongside the
  route-table-derived answer, not instead of it.

## 3. Non-goals

- Do not attempt Cross-Cloud-Provider, P2P-Partner-Transit, VPN-Partner-Transit, or
  Cross-Company classification in the first pass -- start with the classes directly computable
  from Home/Not-Home + routing-domain data (Internet Egress/Ingress, Cloud Egress/Ingress, PCI),
  and the ones already partially covered (`FW_ROLE`'s `MPLS-EDGE`, `FW_SEGMENT`'s `B2B-MPLS`/
  `B2B-VPN`/`INTERCOMPANY`). Extending to the rest is a natural second pass once the mechanism is
  proven on the classes with the most existing data support.
- Do not attempt to resolve the switch-level redirect problem (the `Semafone_DMZ` hairpin
  example in the skill, where a hop happens on infrastructure outside any FW config). That's a
  confirmed, standing gap this spec doesn't try to close.
- Do not build a new database from scratch for `fw_interfaces`/`fw_routes` data -- it already
  exists in `fw_route_db.sqlite`. If a new table is needed for the *computed* Home/Not-Home
  boundary and class tags, it can live alongside the existing ones in the same database, or in a
  new one -- state which choice was made and why (see ss6).

---

## 4. Home/Not-Home determination algorithm

For a given device, using `fw_route_db.sqlite`'s real schema (`fw_interfaces`: `device, nameif,
ip_address, netmask, cidr, source_file`; `fw_routes`: `device, nameif, dest_cidr, dest_lo,
dest_hi, prefix_len, next_hop, metric, source_file`):

1. **Home (directly connected)**: every `cidr` in `fw_interfaces` for this device is
   unconditionally Home -- these are the device's own local networks.
2. **Home (routed, internal)**: a route in `fw_routes` whose `next_hop` is itself an address
   within one of the device's own directly-connected interfaces (i.e. routing to a neighbor on a
   local segment, not out through an edge interface) extends Home transitively. Cap the
   transitive extension depth explicitly (recommend depth 1 for the first pass -- don't chase an
   arbitrarily long chain of internal hops without validating against real data first) and state
   whatever depth was actually used.
3. **Not-Home (gateway of last resort)**: the route with the broadest `prefix_len` (lowest
   specificity -- typically but not necessarily `0.0.0.0/0`) whose `next_hop` is **not** on a
   directly-connected local segment is the gateway-of-last-resort candidate. This is the route
   that answers "what does `ANY` mean when it matches via this device."
4. **Not-Home (classified)**: cross-reference the gateway-of-last-resort's destination scope and
   the device's own `FW_SEGMENT`/`FW_ROLE`/`HERITAGE`/`EGRESS_FIREWALL_CLUSTER` to classify *which*
   Not-Home domain this represents -- Internet, a specific Cloud provider, a specific Partner.
   Where `EGRESS_FIREWALL_CLUSTER` names a specific assigned cluster, treat that as a confirming
   secondary signal (per G5), not the primary one -- the primary signal is the real route data.

**Real edge case to handle explicitly, not silently**: a device with multiple default-ish broad
routes (e.g. one gateway-of-last-resort per VRF/routing-instance, or genuinely multiple equal-cost
paths) needs a defined tie-breaking rule -- don't just take the first one found. State whatever
rule is chosen (e.g. lowest `metric`, or flag as ambiguous and require manual resolution) and why.

**Verification requirement before trusting this algorithm at scale**: run it against the real
Vegas/Semafone devices already investigated by hand in this session and confirm the computed
Home/Not-Home boundary matches what was found manually (Trust as Home, `Semafone_DMZ` correctly
excluded from Home, the gateway-of-last-resort correctly identified as the Untrust-facing route).
If it doesn't reproduce that known-correct result, the algorithm is wrong before it's applied to
anything else.

---

## 5. FW Class tagging

For each device (or zone-pair, per the skill's multi-class guidance), compute:

1. **Connectivity** — which domains does this device/zone-pair actually touch. Combine: (a) the
   Home/Not-Home boundary from ss4, (b) `FW_ROLE`'s routing-domain-derived classification
   (`INTERNET-EDGE`, `CLOUD-EDGE`, `MPLS-EDGE`, `INTERNAL`, `MGMT`), (c) `FW_SEGMENT`'s naming-based
   classification as a lower-trust cross-check per the skill's signal hierarchy. Where these
   disagree, trust (a) and (b) over (c), and log the disagreement rather than silently picking one
   -- a disagreement is itself useful signal that the device's naming doesn't match its real
   function (exactly the pattern the skill documents repeatedly).
2. **Direction** — for the Home↔Not-Home zone-pair identified in ss4, query `fw_rule_db`'s real
   ALLOW rules and determine which side predominantly appears as `src_zone` vs `dst_zone`. Home
   predominantly as source = client→server = Egress-shaped. Home predominantly as destination =
   server→client = Ingress-shaped. Both present in meaningful volume = bidirectional (expected
   for classes like PCI, Cross-Company, Segment FW per the taxonomy).
3. **Class assignment** — combine connectivity + direction per the 10-class table in the skill.
   For the classes explicitly in scope for this pass (ss3): Internet Egress/Ingress, Cloud
   Egress/Ingress, PCI.

**Multi-class devices** (Shea/Vegas-pattern, per the skill): run this per zone-pair, not once per
device. A single device may produce multiple (zone-pair, class) tags.

---

## 6. Storage

Store computed tags in a new table -- **decide and state explicitly** whether this lives in
`fw_route_db.sqlite` (co-located with the data it's derived from) or a new dedicated database
(cleaner separation, but another file to register/auto-discover). Recommend the former unless a
concrete reason favors the latter -- there's no need to add a fifth `fw-db/` database if the
existing one can hold this without confusion.

Minimum real fields needed, regardless of which choice is made:
```
device, zone_pair (home_zone, not_home_zone), fw_class, direction,
home_subnets (the actual computed CIDR list, not just a boolean), not_home_domain,
gateway_of_last_resort_route, confidence/evidence_notes, computed_at, computed_by_version
```
`evidence_notes` matters -- when this disagrees with `FW_SEGMENT`/`FW_ROLE`, or when a tie-break
rule from ss4 had to fire, record *why* the tag was assigned, not just the final answer. This is
exactly the kind of thing that made the manual Vegas investigation valuable -- don't lose that
when it becomes automated.

---

## 7. Plugins to build

Following the plugin contract in `fwlookup_plugin_architecture_spec.md` exactly (`PLUGIN_NAME`,
`PLUGIN_VERSION`, `PLUGIN_FLAG`, `PLUGIN_DB_REQUIRED`, `run(dbs, value, args)`):

- **`plugin_fw_class_tag.py`** (`--fw-class DEVICE_OR_SEGMENT`) — show the computed Home/Not-Home
  boundary and Firewall Class(es) for a device, or list all devices carrying a given class.
  `PLUGIN_DB_REQUIRED = ['fw_route_db', 'fw_rule_db']` at minimum (add `fw_group_db` if resolving
  address-objects is needed for the direction analysis in ss5.2).
- **`plugin_pci_traffic_model.py`** (`--pci-traffic-model FW_NAME`) — the concrete worked example
  from G4: given a PCI-tagged device, show its computed Home subnets (from `fw_interfaces`/
  `fw_routes`), then the real Trust/Home→Untrust ALLOW rules for that device with objects resolved
  (reusing `fw_group_lookup.py`'s resolution logic, not reimplementing it), presented as a
  traffic model -- real services, real resolved destinations, correctly attributed as PCI-scoped
  egress. This is the acceptance-test plugin: if it can't produce a coherent, correct model for a
  real PCI device, the underlying mechanism (ss4/ss5) isn't ready yet, regardless of how clean the
  code is.

Both plugins should reuse `fw_group_lookup.py`'s object-resolution logic and
`ha_stem_and_role()`'s device-grouping logic rather than reimplementing either -- this is exactly
the kind of shared-logic case the plugin architecture spec's migration requirement (G6 there) was
meant to prevent from happening twice.

---

## 8. Retooling required per component

- **`fw_route_db.sqlite`**: no schema change needed for `fw_interfaces`/`fw_routes` themselves
  (ss4 reads them as-is). Add the new tag-storage table from ss6.
- **`fw_rule_db.sqlite`**: no schema change needed -- ss5.2's direction analysis reads existing
  `src_zone`/`dst_zone` and `rule_ips` as-is.
- **`fw_group_db.sqlite`**: no schema change needed -- consumed read-only via
  `fw_group_lookup.py`'s existing resolution functions for object-content lookups in ss7.
- **`fwlookup.py`**: no direct changes required beyond what the plugin architecture spec already
  covers -- both new plugins register through the existing discovery mechanism, zero edits to
  `fwlookup.py`'s own source for the common case (that's the entire point of that spec).

---

## 9. Testing and verification requirements

Follow this codebase's established discipline throughout, not a lighter bar because this is a
new, larger piece of work:

- Verify the Home/Not-Home algorithm (ss4) against the real Vegas/Semafone devices already
  investigated by hand in this session, as stated in ss4 -- this is the load-bearing test.
- Verify `plugin_pci_traffic_model.py` against at least one real PCI-tagged device end to end,
  and confirm the output is coherent enough that someone who *doesn't* already know that device's
  topology could understand its real Trust→Untrust traffic shape from the plugin's output alone.
- Verify the multi-class-device path (ss5) against a real Shea/Vegas-pattern device confirmed to
  carry more than one class, and confirm it's NOT collapsed into a single-class tag.
- Verify the single-class-device path against a real Aetna/Cloud-pattern device (e.g. one of the
  `eclawseast-shubegress-ftd-*` quad) and confirm it correctly resolves to one class, not several.
- Real synthetic edge cases per ss4's "real edge case" note (multiple broad routes, tie-breaking).
- A negative control: confirm a device with a clearly wrong/absent route table produces an
  explicit "insufficient data" result, not a silently wrong class tag.

---

## 10. Deliverables checklist

- [ ] Home/Not-Home algorithm (ss4) implemented against real `fw_interfaces`/`fw_routes` data
- [ ] Verified against the real Vegas/Semafone devices, reproducing the known-correct manual result
- [ ] FW Class tagging (ss5) implemented for the in-scope classes (ss3)
- [ ] Tag storage (ss6) implemented, with the co-location-vs-new-database decision stated explicitly
- [ ] `plugin_fw_class_tag.py` built per the existing plugin contract
- [ ] `plugin_pci_traffic_model.py` built and verified against a real PCI device end to end
- [ ] Both plugins reuse `fw_group_lookup.py`/`ha_stem_and_role()` rather than reimplementing them
- [ ] Multi-class (Shea/Vegas-pattern) and single-class (Aetna/Cloud-pattern) paths both verified
      against real devices, each producing the correct shape of result
- [ ] `fw-policy-classification` skill updated with a pointer to this mechanism once it exists,
      the same way it currently points to `HERITAGE`/`EGRESS_FIREWALL_CLUSTER` as the existing
      partial attempt -- this spec's output should become the *next* thing that skill points to
