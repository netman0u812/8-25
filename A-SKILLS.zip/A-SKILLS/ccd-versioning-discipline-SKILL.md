---
name: ccd-versioning-discipline
description: >
  CCD Platform versioning, changelog, and session documentation discipline for
  CVS Health Information Security. Use this skill for EVERY script modification,
  dataset update, or pipeline change in the CCD Platform. Triggers on: any
  request to patch, update, fix, or modify a CCD Platform script; any version
  bump; any end-of-session handoff; any documentation update request. This skill
  is NON-NEGOTIABLE — apply it before delivering any file. Failure to follow
  this discipline has caused production issues and lost functionality in the past.
---

# CCD Platform — Versioning & Documentation Discipline

## The Problem This Skill Solves

Scripts in the CCD Platform have MULTIPLE version string variables. Updating only
one while leaving others stale causes the deployed script to display the wrong version,
making it impossible to verify that the correct version is running. This has caused
repeated confusion and wasted sessions.

Additionally, changelog entries must be written at the time of change — not reconstructed
later. And pipeline documentation must be updated before the end of every session.

---

## Rule 1: Find ALL Version Variables Before Touching Anything

Every CCD script may have multiple version variables. Before making any change:

```bash
grep -n "version\|VERSION\|__version__\|SCRIPT_VERSION" <script.py> | grep -v "#"
```

Common patterns in the CCD Platform:

| Script | Version Variables |
|--------|------------------|
| preprocess_p1.py | `SCRIPT_VERSION = '...'` (line ~3) AND `__version__ = '...'` (line ~200) — BOTH must be updated |
| build_*.py | `__version__ = '...'` — usually one |
| ipam-db.py | `__version__ = '...'` |
| iplookup.sh | `VERSION=...` in the shell header |
| update_app.py | `__version__ = '...'` |

**NEVER update only one version variable. Find them all. Update them all.**

After patching, always verify:

```python
import re
with open('script.py') as f:
    content = f.read()
# Find ALL version strings
for m in re.finditer(r'(?:__version__|SCRIPT_VERSION|VERSION)\s*=\s*["\']([^"\']+)["\']', content):
    print(f"Line {content[:m.start()].count(chr(10))+1}: {m.group(0)}")
```

All must show the new version. If any still show the old version — fix before delivery.

---

## Rule 2: Write the Changelog at the Time of Change

Every script has a changelog section. Update it BEFORE delivering the file.

### Changelog location patterns

**Python scripts — look for:**
```python
# v1.2.3 — description of change
# v1.2.2 — previous change
```
Or in the module docstring:
```
preprocess_p1.py  v2.9.3  2026-06-15
  Description of what changed in this version.
preprocess_p1.py  v2.9.2  2026-06-15
  Previous version description.
```

### Changelog entry format

```
# vX.Y.Z  YYYY-MM-DD  One-line summary.
#          Detail line 1: what changed and why.
#          Detail line 2: any architectural implications.
#          New fields added: FIELD_A, FIELD_B (if applicable).
#          Downstream impact: which scripts consume this output.
```

### What must be documented

- What changed (the actual code change)
- Why it changed (the business reason)
- New fields added to any output schema
- New input files required
- Downstream scripts affected
- Any deprecations (e.g. DELIVERY_CONTAINER_HOST retired → DELIVERY_SHARED_PLATFORM)

### What is NOT acceptable

- Empty changelog for a version bump
- "Minor fixes" with no detail
- Updating `__version__` without updating the changelog text
- Changelog that only says what changed, not why

---

## Rule 3: Version Bump Rules

```
MAJOR.MINOR.PATCH

PATCH (+0.0.1): Bug fix, no schema change, no behavior change
MINOR (+0.1.0): New feature, new field, new input source, behavior change
MAJOR (+1.0.0): Breaking change, schema incompatibility, complete rewrite
```

### Dataset versioning (non-script files)

```
vYYYYMMDD       — date-versioned datasets (first version on that date)
vYYYYMMDDrN     — revision N on date YYYYMMDD (e.g. v20260615r3)
```

Three stamps required on every dataset file:
1. Versioned filename: `all_IP_networks_v20260611r4.csv`
2. `#VERSION=v20260611r4` header comment in the file
3. `DATASET_VERSION` column in every data row

**`vbare` = hard stop.** A dataset file with no version stamp must not be imported.

---

## Rule 4: Complete File Delivery Only

**Never deliver:**
- Patches or diffs to apply manually
- `sed` commands to run
- "Change line X to Y" instructions
- Partial file sections

**Always deliver:**
- The complete file, ready to deploy
- Verified with `ast.parse()` (Python) or `bash -n` (shell) before delivery
- With `present_files()` called so the user can download it

### Pre-delivery checklist (run before every present_files call)

```python
# 1. Syntax check
import ast
ast.parse(content)  # must not raise

# 2. Version check — ALL version strings updated
import re
versions = re.findall(r'(?:__version__|SCRIPT_VERSION|VERSION)\s*=\s*["\']([^"\']+)["\']', content)
assert all(v == NEW_VERSION for v in versions), f"Stale version strings: {versions}"

# 3. Changelog present
assert f'# v{NEW_VERSION}' in content or f'v{NEW_VERSION}' in content[:5000], "No changelog entry"

# 4. No unresolved TODO/FIXME left by the patch
assert 'TODO: UPDATE VERSION' not in content
```

---

## Rule 5: End-of-Session Documentation Update

Before ending ANY session, the following documents must be updated:

### Always update
1. **Session handoff prompt** (`ccd_session_handoff_YYYYMMDD.md`) — current dataset versions, script versions, completed work, next session objectives
2. **Pipeline command tree** (`CCD_Pipeline_Command_Tree_vX.Y.txt`) — if any stage changed

### Update if affected
3. **`CCD_Canonical_Objects_Pipeline_vX.Y.docx`** — if preprocess, EHM, or canonical objects changed
4. **SKILL.md files** — if a new pattern, dataset, or architectural rule was established
5. **`check_toolset.py`** — if a script version changed (update expected version string)

### Session handoff template

```markdown
# CCD Platform — Session Handoff YYYY-MM-DD

## Completed This Session
- Script: <name> <old_version> → <new_version>
  Change: <what and why>
- Dataset: <name> <old_version> → <new_version>
  Change: <what and why>

## Verified Baseline (EOD)
| Dataset | Version | Rows | Status |
| Script  | Version | — | Status |

## Next Session Objectives
1. Primary: <objective>
2. Secondary: <objective>

## Carry-Forward Open Items
- <item>
```

---

## Rule 6: check_toolset.py Must Stay Current

Every time a script version changes, `check_toolset.py` must be updated:

```python
# Find the relevant test entry
grep -n "script_name\|expected_version" check_toolset.py

# Update the expected version string
# Example: 'v1.4' → 'v1.5' for build_canonical_app_objects
('build', 'build_canonical_app_objects.py',
 ['--version'],
 'v2.9',   # ← must match the new __version__ prefix
 'build_canonical_app_objects version'),
```

The expected string is a PREFIX match — `'v2.9'` matches `v2.9.3`. Keep it at MAJOR.MINOR only so PATCH bumps don't require a check_toolset update.

---

## Common Mistakes to Avoid

| Mistake | Consequence | Fix |
|---------|-------------|-----|
| Updating `SCRIPT_VERSION` but not `__version__` | Script displays wrong version in header | Always grep for ALL version vars |
| Writing changelog after the fact | Inaccurate documentation | Write changelog as part of the patch |
| Not updating check_toolset.py | Health check fails on valid script | Update immediately after version bump |
| Delivering a patch instead of a full file | User can't deploy, session wasted | Always deliver complete files |
| Ending session without updating handoff prompt | Next session starts blind | Update handoff before session ends |
| Bumping version without changelog entry | No audit trail | Changelog is mandatory |
| Not documenting new EHM fields | Downstream scripts miss the fields | Document in pipeline doc AND changelog |

---

## Quick Reference — CCD Script Version Map

| Script | Current Version | Version Variable(s) |
|--------|----------------|---------------------|
| preprocess_p1.py | 2.9.3 | `SCRIPT_VERSION` AND `__version__` |
| update_app.py | 1.9 | `__version__` |
| build_canonical_app_objects.py | 1.8.4 | `VERSION` |
| build_shared_server_registry.py | 1.1.0 | `__version__` |
| build_network_groups.py | 1.8.4 | `__version__` |
| build_ng_report.py | 1.3.2 | `__version__` |
| build_service_objects.py | 1.0.5 | `__version__` |
| build_object_pipeline.py | 1.3.1 | `__version__` |
| build_edl_catalog.py | 1.1.2 | `__version__` |
| ipam-db.py | 3.15.8 | `__version__` |
| check_toolset.py | 1.1.0 | `__version__` |
| iplookup.sh | 3.23 | `VERSION=` |

Update this table in the SKILL whenever a script version changes.

---

*CCD Platform | CVS Health Information Security | June 2026*

---

## Rule 7: Terminal Output Discipline — Before → After → Next Step

Every CCD script must follow the same output pattern at completion.
This is NON-NEGOTIABLE and carries the same weight as versioning.

### The pattern

```
──────────────────────────────────────────────────────────────
  Before  :  <prior state — filename, version, row count>
  After   :  <new state — filename, version, row count>
──────────────────────────────────────────────────────────────

  Next step: python3 <next_script>
```

### Rules

**Before/After must show state change.** The operator must be able to
see immediately what changed without reading back through the log.
Include filename and version at minimum. Row counts where meaningful.

**Next step is a single command.** No explanation, no parentheticals,
no "once all reviews are done". Just the command. Explanations belong
in `--help` and `--verbose`.

**Breakdown tables and verbose detail belong behind `--verbose`.**
The IoT device class breakdown, the IPAM candidate list, the
enhancement field counts — these are all `--verbose` output. The
normal run shows only the state change and the next command.

**`--verbose` / `--debug` flags gate expanded output.** When adding
diagnostic or explanatory output to a script, it must be gated behind
a flag — never printed in the default run. This keeps the operational
output clean and consistent across all scripts.

### Per-script state change examples

| Script | Before | After |
|--------|--------|-------|
| `build_nms_db.py` | registered NDM version + RMAC counts | new NDM file + new RMAC counts |
| `commit_nms.py` | (registered) | new NDM + IoT filenames |
| `update_ipam.py` | old all_IP_networks filename | new all_IP_networks filename |
| `update_app.py` | old EHM filename | new EHM filename |
| `preprocess_p1.py` | N/A (reads live data) | matched / enhanced / new counts |

### What is NOT acceptable

- A "Done." line with no state change shown
- Next step with parenthetical explanation: `python3 foo.py  (does X and Y)`
- Breakdown tables printed in normal (non-verbose) output
- Multiple "Next step" lines at different points in the output
- The word "successfully" anywhere in output

### Enforcement

Before delivering any script modification, verify the terminal output
follows this pattern. Apply the same pre-delivery checklist as versioning:
1. Does the script show Before → After state?
2. Is the Next step a single clean command?
3. Is verbose/debug output gated behind a flag?
4. Is there exactly one Next step, printed at the very end?

---

## Rule 8: Skill Documentation Discipline — Every Change Updates the Skill

Documentation is part of the work, not an afterthought. This rule carries
the same weight as versioning and terminal output discipline.

### The rule

**Every script modification must identify and update the relevant skill.**

A script change that ships without a corresponding skill update is incomplete.
The skill is the only persistent record a future developer or future session
has of why the code works the way it does. Without it, the work has to be
re-discovered from scratch.

### Skill-to-script mapping

| Script(s) | Skill |
|-----------|-------|
| `build_nms_db.py`, `commit_nms.py`, `diff_nms_export.py` | `nms-ndm-rebuild` |
| `preprocess_p1.py`, `preprocess_p2.py`, `update_app.py`, `update_infrastructure.py`, `update_platform.py`, `update_network.py`, `update_ipam.py`, `ccd_host_enrichment.py` | `ccd-host-ingest-pipeline` |
| `build_object_pipeline.py`, `build_canonical_app_objects.py`, `build_network_groups.py`, `build_service_objects.py`, `build_custom_objects.py`, `build_partner_ng.py`, `build_edl_catalog.py` | `ccd-edl-object-pipeline` (to be created) |
| `setup_fw_configs.sh`, `build_fw_config_manifest.py`, `build_fw_interface_inventory.py`, `build_fw_location_topology.py`, `build_fw_route_db.py`, `build_fw_group_db.py`, `build_fw_rule_db.py`, `build_fw_snat_pools.py`, `build_vpn_registry.py`, `build_ftd_p2p_registry.py`, `collect_fw_bundle.sh`, `asa_ftd_identity.py` | `ccd-fw-pipeline` |
| `build_IP_Network_Egress_FW_topology.py`, `build_known_unknown_ip_resolver.py` | `ccd-fw-pipeline` + `ccd-review-pipeline` |
| `ipam-db.py`, `build_all_ip_networks.py`, `build_mgmt_ip_index.py` | `ccd-platform-data-model`, `create-update-ipam-dataset` |
| `build_external_ip_registry.py` | `external-ip-registry-internals` |
| `fwlookup.py`, `generate_fw_rule_report.py` | `ccd-fw-rule-database` (to be created) |

### Pre-delivery checklist (all 8 rules)

Before delivering any modified script:

1. **Version** — all version strings updated (see Rule 1-6)
2. **Changelog** — entry written at time of change, not after (see Rule 1-6)
3. **Before→After→Next step** — terminal output follows pattern (see Rule 7)
4. **Verbose gate** — diagnostic output behind `--verbose` (see Rule 7)
5. **Skill identified** — which skill covers this script? (Rule 8)
6. **Skill updated** — does the skill reflect the change just made? (Rule 8)

### What counts as a skill update

A skill update is required when the change affects:
- Run order or pipeline sequence
- A bug fix that changes observable behavior
- A new flag or mode
- A classification rule or threshold
- A confirmed data quality finding or root cause
- A new output file or registered dataset

A skill update is NOT required for:
- Pure internal refactor with no behavior change
- Whitespace or comment-only edits
- Version bump with no logic change

### Reality check

Consistent skill maintenance requires discipline across sessions. The platform
owner has confirmed that even with this skill loaded, versioning and documentation
have been missed repeatedly. The mechanical fix is `pre_delivery_verify.py` —
a script that checks all 8 rules before any file is accepted. Until that exists,
the pre-delivery checklist above is the control.
