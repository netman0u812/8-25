# fwlookup.py — FW Rule Database CLI

**Version:** v1.10.0 (2026-07-17)
**Part of:** CCD Platform — CVS Health Information Security
**Purpose:** Query `fw_rule_db.sqlite` (built by `build_fw_rule_db.py`) to find which firewall rules affect a given IP/CIDR, rule name, policy, or service — without opening Panorama, FMC, or ASDM.

---

## Setup / requirements

Run from a directory where these are reachable (or point at them explicitly):

| Path | Flag to override | Default |
|---|---|---|
| Rule database | `--db` | `./fw-db/fw_rule_db.sqlite` |
| IPAM directory (for EIR/location context) | `--ipam-db` | `./ipam-db` |
| Geo-IP datasets root | `--dataset-dir` | script's own directory |
| FW inventory CSVs (`fw-inv-*.csv`) | `--inv-dir` | `./IP_Datasets_Raw/FW_Invintories` |

Check you're on the current version before relying on any of this:

```bash
python3 fwlookup.py -V
# should print: fwlookup.py v1.10.0
```

---

## Query modes

`fwlookup.py` has five distinct modes, chosen by which arguments you pass:

| Mode | How to trigger | What it answers |
|---|---|---|
| **IP/CIDR lookup** | positional `ip` arg, or `--ip`/`-i` | "What rules match this IP or subnet?" |
| **Rule/policy lookup** | `--rule`/`-r` (optionally + `--policy`) | "Find this named rule or policy across all firewalls" |
| **Combined** | `--rule` **and** an IP | "Show this rule, plus observed CrowdStrike flows for that IP" |
| **Service lookup** | `--service`/`-s` | "What rules permit this port/service?" |
| **IP context only** | `--context`/`-c` | "What do we know about this IP?" (IPAM/VIP/SNAT/GeoIP/EIR) — no rule search |

Plus standalone utility modes: `--profile` (full public-IP intel), `--dns` (quick PTR/NS lookup), `--egress-map` (FW topology for a site), `--inv` (FW estate inventory from the manifest).

---

## IP/CIDR lookup — the core mode

```bash
python3 fwlookup.py 10.93.48.0/24
python3 fwlookup.py 198.187.88.73
```

By default this returns every rule where the queried IP/CIDR overlaps the rule's source or destination — including rules scoped far broader than your query (a `/8` supernet, or `any`), up to `--limit` (default 200) results.

### Narrowing the direction

```bash
python3 fwlookup.py 10.93.48.0/24 --direction dst    # only where it's the destination
python3 fwlookup.py 10.93.48.0/24 --direction src    # only where it's the source
```

### Narrowing by firewall, action, or result count

```bash
python3 fwlookup.py 10.93.48.0/24 --fw mid-fw-vpn1     # substring match on FW name
python3 fwlookup.py 10.93.48.0/24 --action permit      # substring match on action
python3 fwlookup.py 10.93.48.0/24 --limit 5000         # default is 200 -- raise for dense subnets
```

**If you're seeing `[!] hit --limit N — TRUNCATED`, you're not seeing the full picture.** Either raise `--limit`, or (usually better) use `--only-targeted` below to filter out the noise causing the flood in the first place.

---

## Scope filtering — separating real policy from incidental catch-alls

This is the most important thing to understand if you're doing bulk analysis (e.g. sweeping many subnets). A single broad rule (`10.0.0.0/8 → any`) can technically "match" almost every internal subnet you query, burying the handful of rules actually written for that subnet — and doing so *without* triggering a truncation warning, because the flood happens before `--limit` even matters.

```bash
python3 fwlookup.py 10.157.89.64/26 --only-targeted
python3 fwlookup.py 10.157.89.64/26 --only-broad
```

- **`--only-targeted`** — only rules whose matched network is **`/20` or narrower** (configurable via `--broad-threshold`). This is "is there a reasonably specific rule for this," filtering out corpnet-wide catch-alls.
- **`--only-broad`** — the inverse: only the broad/catch-all matches. Useful for building a deduplicated reference of which supernet rules exist across many subnets, separate from the real per-subnet policy.
- **`--broad-threshold PREFIX`** (default `20`) — the cutoff. A matched network at or narrower than `/PREFIX` counts as targeted; wider (and `any`) counts as broad.

```bash
python3 fwlookup.py 10.157.89.64/26 --only-targeted --broad-threshold 24
```

Both flags filter **in SQL, before `--limit` is applied** — so a subnet buried under thousands of broad-rule matches will still surface its targeted rules even at a low `--limit`, instead of the broad noise crowding them out.

---

## Exact-match modes — is this rule written for *this specific* subnet?

`--only-targeted` guarantees "reasonably narrow," not "the same subnet." A `/24` supernet containing your queried `/26` still counts as targeted. If you need to know whether a rule exists for the **exact** subnet — no broader, no narrower — use one of these three (mutually exclusive) flags instead:

```bash
python3 fwlookup.py 10.247.67.64/26 --exact          # ONLY the exact /26 — nothing broader, nothing narrower
python3 fwlookup.py 10.247.67.64/26 --more-exact      # the /26, PLUS anything narrower inside it (/27 .. /32)
python3 fwlookup.py 10.247.67.64/26 --less-exact      # the /26, PLUS anything broader containing it (/25 .. /8)
```

| Flag | Matches | Use it to ask |
|---|---|---|
| `--exact` | Network == query, exactly | "Is there a rule written for exactly this subnet?" |
| `--more-exact` | Network ⊆ query (query or narrower) | "Is there anything more specific scoped *inside* this subnet?" — e.g. a host-level rule for one IP within it |
| `--less-exact` | Network ⊇ query (query or broader) | "What's the chain of supernets that contain this subnet, from the subnet itself up to /8?" |

**Important:** `--more-exact` can surface rules that **no other mode — including a plain unfiltered lookup — can ever find.** The default containment logic only matches networks broad enough to span your *entire* queried range; a rule scoped to a single host inside your subnet is invisible to it. If you need to confirm "nothing more specific than this subnet-wide rule exists," `--more-exact` is the only mode that actually checks.

All three exclude `ip_type='any'` — `any` is never "exact" to a specific subnet by definition. If you want `any` included, don't use these flags (a plain lookup and `--only-broad` both include it).

---

## Reading the output

Each matched rule prints a block like this:

```
  MID-FMC-PCI-1                                 FMC   BLOCK
  Policy/ACL:    MID-FMC-PCI-1/win-fw-pciprod-sysadm-policy
  Rule:          corpnet_#1  #45
  Zones:         corpnet → any
  Protocol:      any
  Scope:         BROAD  (matched via /8 supernet)
  Direction:     SOURCE  (query IP matched as rule source)
  Source:        10.112.0.0/12, 10.113.0.0/16, ... (+5 more)
  Destination:   0.0.0.0/0, ::/0
  Dst ports:     443
  Comment:       CM8135 CM8229 - block wifi network from pci enclaves
```

| Line | Meaning |
|---|---|
| `Scope:` | `TARGETED`/`BROAD`/`ANY` classification of the **matched entry** (not the full rule text) — see scope filtering above |
| `Direction:` | Whether your query matched as the rule's **SOURCE** or **DESTINATION** — ground truth from the SQL match, not reconstructed from (possibly truncated) displayed text |
| `Source:` / `Destination:` | Full rule text, may show `(+N more)` if the list is long — this is a **display truncation**; the actual match may be an entry not shown here. Use `Direction:` for certainty on which side matched, not text-scanning these lines. |

**Note on `Source:`/`Destination:` truncation:** these lines are for human review, not machine parsing. If you're scripting against `fwlookup.py`'s output, rely on `Scope:` and `Direction:` (both computed from the actual SQL match) rather than trying to parse which CIDR in a truncated list caused the match.

---

## Rule / policy / service lookup

```bash
python3 fwlookup.py --rule "Tufin-4945"                    # find by rule/policy name (substring)
python3 fwlookup.py --rule "Tufin-4945" --ip 10.92.14.0/24  # + show observed flows for that IP
python3 fwlookup.py --policy "Alorica"                      # policy name filter, standalone or combined
python3 fwlookup.py --policy "Alorica" --fw RRICMCP          # + firewall filter
python3 fwlookup.py --service 443
python3 fwlookup.py --service ssh --action permit
```

`--rule` and `--policy` both do substring matching against `rule_name`/`policy_name`/`comment`. `--service` substring-matches `dst_ports`/`src_ports`/`protocol`.

---

## IP context and intel (no rule search)

```bash
python3 fwlookup.py --context 10.223.252.110    # IPAM / VIP / SNAT / GeoIP / EIR context only
python3 fwlookup.py --profile 8.8.8.8            # full security/provider/ASN/DNS profile (public IPs)
python3 fwlookup.py --dns 8.8.8.8                # quick PTR/NS lookup only
```

`--context` is also run automatically as a header block before every IP/CIDR rule lookup — these flags are for when you want *just* that, without a rule search.

---

## Egress topology and FW inventory

```bash
python3 fwlookup.py --egress-map "Shea"           # FW topology for a location (substring)
python3 fwlookup.py --egress-map "US_SHE_AZ_DC"   # or by SITE_CODE

python3 fwlookup.py --inv                          # full FW estate inventory from the manifest
python3 fwlookup.py --inv EGRESS                   # filter to one segment (EGRESS/PCI/CLOUD/RA-VPN/
                                                     # B2B-VPN/B2B-MPLS/INTERCOMPANY/AFFILIATE/
                                                     # INTERNAL-DC/RETAIL-SDWAN/MGMT)
python3 fwlookup.py --inv --fw ASA                  # combine with --fw to filter by platform type
python3 fwlookup.py --inv --missing                 # only devices with MISSING/MISMATCH hostname
```

---

## Full flag reference

| Flag | Short | Applies to | Description |
|---|---|---|---|
| `ip` (positional) | | IP lookup | IP or CIDR to look up |
| `--ip` | `-i` | IP lookup | Same as positional, explicit form |
| `--rule` | `-r` | Rule lookup | Rule/policy name, substring match |
| `--policy` | `-p` | Rule lookup | Policy/ACL name filter |
| `--service` | `-s` | Service lookup | Substring match on ports/protocol |
| `--context` | `-c` | Context mode | IP context only, no rule search |
| `--direction` | `-d` | IP lookup | `src` / `dst` / `both` (default `both`) |
| `--fw` | `-f` | any | Firewall name, substring match |
| `--action` | `-a` | any | Action, substring match |
| `--limit` | `-l` | any | Max rules returned (default 200) |
| `--broad-threshold` | | IP lookup | Prefix cutoff for TARGETED vs BROAD (default 20) |
| `--only-targeted` | | IP lookup | Only `/20`-or-narrower matches |
| `--only-broad` | | IP lookup | Only broad/`any` matches |
| `--exact` | | IP lookup | Only the exact queried network |
| `--more-exact` | | IP lookup | Query network or narrower (subset) |
| `--less-exact` | | IP lookup | Query network or broader (superset) |
| `--no-flows` | | any | Skip CrowdStrike flow output |
| `--db` | | any | Path to `fw_rule_db.sqlite` |
| `--dataset-dir` | | any | Root dir for geo-IP datasets |
| `--ipam-db` | | any | IPAM directory for EIR context |
| `--profile` | | Utility | Full public-IP intel profile |
| `--dns` | | Utility | Quick DNS/PTR/NS lookup |
| `--egress-map` | | Utility | FW topology for a site |
| `--inv-dir` | | `--inv` | Directory of `fw-inv-*.csv` files |
| `--inv` | | Utility | FW estate inventory; optional segment name |
| `--missing` | | `--inv` | Only MISSING/MISMATCH hostname devices |
| `-V` / `--version` | | any | Print version and exit |

**Mutually exclusive groups:** `--only-targeted` / `--only-broad`. Separately, `--exact` / `--more-exact` / `--less-exact`. (You can combine one from each group, e.g. `--exact --only-targeted`, though an exact match is normally also targeted unless it happens to be wider than `--broad-threshold`.)

---

## Common workflows

**"What actually enforces traffic for this subnet, ignoring corpnate noise?"**
```bash
python3 fwlookup.py 10.157.89.64/26 --only-targeted --limit 5000
```

**"Is there a rule written specifically for this subnet, or only broader coverage?"**
```bash
python3 fwlookup.py 10.157.89.64/26 --exact
```

**"Is there anything more specific than a subnet-wide rule hiding inside it?"**
```bash
python3 fwlookup.py 10.157.89.64/26 --more-exact
```

**"What's the full supernet chain that would also affect this subnet?"**
```bash
python3 fwlookup.py 10.157.89.64/26 --less-exact
```

**"I only want the catch-all rules, to build a dedup'd reference across many subnets."**
```bash
python3 fwlookup.py 10.157.89.64/26 --only-broad --limit 5000
```

**Bulk sweeps across many subnets:** see `run_composer2_fwlookup.sh` / `parse_composer2_results.py`, which wrap `--only-targeted` and `--only-broad` into a two-pass sweep across a subnet list, with per-subnet result files and consolidated CSVs.

---

## Version history (recent)

| Version | Date | What changed |
|---|---|---|
| v1.10.0 | 2026-07-17 | `--exact` generalized into `--exact`/`--more-exact`/`--less-exact` |
| v1.9.0 | 2026-07-17 | Added `--exact` |
| v1.8.0 | 2026-07-17 | Added `Direction:` line to output (SOURCE/DESTINATION, ground truth from SQL match) |
| v1.7.0 | 2026-07-16 | Added `Scope:` classification (`--only-targeted`/`--only-broad`/`--broad-threshold`), SQL-level filtering before `--limit` |
| v1.6.1 | 2026-07-08 | (baseline at start of this session) |

Full changelog with detailed rationale for each change is in the script's own docstring header (top of `fwlookup.py`).
