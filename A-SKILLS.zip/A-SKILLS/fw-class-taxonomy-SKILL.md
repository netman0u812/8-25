---
name: fw-class-taxonomy
description: The authoritative definition of CVS Health's 10 Firewall Classes (Internet Egress/Ingress, Cloud Egress/Ingress, Cross-Cloud-Provider, P2P/VPN-Partner-Transit, PCI, Cross-Company, Segment FW) and how to determine which class(es) a given firewall actually supports. Use whenever tagging or classifying a firewall by function, deciding whether a device is single-class or multi-class, mapping a class to the real data source that computes it (FW_ROLE, FW_SEGMENT, Home/Not-Home boundary), or building/reviewing the FW Class tagging mechanism itself (fw_class_tagging_retooling_spec.md, the fw_route_db.sqlite-derived Home/Not-Home algorithm, plugin_fw_class_tag.py). This is the companion skill to fw-policy-classification: use fw-class-taxonomy to determine WHAT class a firewall is, then fw-policy-classification to correctly INTERPRET that firewall's specific rules once you know its class.
---

# FW Class Taxonomy

The authoritative definition of the 10 Firewall Classes and how to determine which one(s) apply to a real device. For the broader methodology on reading firewall rules correctly once you know a device's class (zone reliability, what `ANY` means, object-vs-zone portability, Home/Not-Home), see the companion skill `fw-policy-classification`.

## The 10 classes

| Class | Connects | Direction |
|---|---|---|
| **Internet Egress** | Internal ↔ External | Client→Server (internal client → external server) |
| **Internet Ingress** | Internal ↔ External | Server→Client (external client → internal-hosted server) |
| **Cloud Egress** | Internal → Cloud | Client→Server |
| **Cloud Ingress** | Cloud → Internal | Server→Client (cloud-side client → internal-hosted server) |
| **Cross-Cloud-Provider** | Cloud ↔ Cloud | Both |
| **P2P-Partner-Transit** | Internal ↔ Partner (MPLS) | Both |
| **VPN-Partner-Transit** | Internal ↔ Partner (VPN) | Both |
| **PCI** | Internal-PCI ↔ Internal (non-PCI) | Both |
| **Cross-Company** | Business Unit ↔ Business Unit (Retail, MinuteClinic, Distro, Mail-order, etc.) | Both |
| **Segment FW** | Corporate ↔ IOT/OT | Unconfirmed -- verify before assuming bidirectional |

A class is defined by two independent properties: **connectivity** (which two domains does the
firewall sit between) and **direction** (which side initiates -- client, or server). The
egress/ingress pairs (Internet, Cloud) are the same connectivity with opposite direction; the
"both" classes (P2P/VPN-Partner-Transit, PCI, Cross-Company) are domains where traffic
legitimately flows both ways and a single direction label wouldn't be accurate.

## Every class maps to a real, specific data source -- don't invent a new signal per class

| Class | Connectivity signal | Direction signal |
|---|---|---|
| Internet Egress/Ingress | `FW_ROLE = INTERNET-EDGE`, or Home/Not-Home boundary (see below) with Not-Home resolving to public internet | `fw_rule_db` ALLOW-rule direction analysis on the Home↔Not-Home zone-pair |
| Cloud Egress/Ingress | `FW_ROLE = CLOUD-EDGE` | same, direction analysis on Home↔Cloud zone-pair |
| PCI | `FW_SEGMENT = PCI` (naming-based, lower trust) cross-checked against Home/Not-Home showing Not-Home resolving to non-PCI internal space | both directions expected; verify not surprising for a specific device |
| Cross-Company | no dedicated existing signal -- likely needs Home/Not-Home cross-referenced against a business-unit-aware IPAM lookup, not yet defined precisely | both |
| P2P-Partner-Transit | `FW_SEGMENT = B2B-MPLS` | both |
| VPN-Partner-Transit | `FW_SEGMENT = B2B-VPN` or `RA-VPN` | both |
| Cross-Cloud-Provider | no dedicated existing signal -- likely needs two Cloud-Edge-classified zones on the same device with different cloud providers on each side, not yet defined precisely | both |
| Segment FW | no dedicated existing signal at all | unconfirmed |

**Only Internet Egress/Ingress, Cloud Egress/Ingress, and PCI have a clear, direct path to
real data today.** The rest either reuse an existing but lower-confidence signal (`FW_SEGMENT`'s
naming-based `B2B-MPLS`/`B2B-VPN`/`RA-VPN`) or have no defined computation path at all
(Cross-Company, Cross-Cloud-Provider, Segment FW). `fw_class_tagging_retooling_spec.md`
deliberately scopes its first implementation pass to the classes with real data support --
don't attempt to compute the undefined ones without designing their signal first.

## Determining "which class(es)" -- one device is not always one class

**A firewall can support more than one class simultaneously, and whether it does depends on how
it was actually deployed, not on the platform it runs.** Two confirmed real patterns, from actual
production evidence:

- **Shea and Las Vegas** (`PAZSHDC-SEC-PAN-PROD-01`, `lgs1501`/`lgs1502`): purpose-built
  multi-tenant-capable PA-5400/7K hardware, confirmed running only `vsys1` (never `vsys2`+)
  across all real exported devices -- deployed as a straight HA-pair replacement for legacy
  ASA/FMC clusters, meaning everything that used to be functionally separate clusters is now
  consolidated onto one physical/logical firewall. **Assume multi-class for devices matching this
  pattern**, and tag at the zone-pair level, not the device level.
- **Aetna and Cloud** (confirmed via real `--inv` output, the `CLOUD` segment): proper
  one-function-per-device disaggregation -- dedicated device quads per function
  (`eclawseast-shubegress-ftd-01..04` vs `-shubingress-ftd-01..04`, separately again for DR, ZTNA,
  and prod/non-prod). **These are genuinely single-class**, and device-level tagging is accurate.

**A third, structural signal exists independent of either team's discipline**: cloud/SDN
integration via AWS Gateway Load Balancer (`GWLB-outside`, a real confirmed zone name) forces
ingress and egress onto structurally separate paths -- a device with this integration pattern can
be trusted as single-class with high confidence, without zone-pair-level inspection. A device
without it needs that inspection, because on-prem hardware never had the platform-level
constraint and evidently didn't self-impose one.

**Decision procedure for a real device**:
1. Check for GWLB (or equivalent structural cloud-SDN) integration -- if present, single-class,
   device-level tagging is safe.
2. Otherwise, check whether the device is genuinely one-function-per-device (Aetna/Cloud pattern:
   dedicated device quads, function encoded in the hostname/naming, `--inv` shows it isolated in
   its own small device group) -- if so, single-class, device-level tagging is safe.
3. Otherwise (Shea/Vegas pattern: consolidated hardware, `vsys1`-only, HA-pair-replacing-cluster
   history) -- assume multi-class, tag per zone-pair, not per device.

## Home/Not-Home: the connectivity foundation every class ultimately depends on

Every class in the table above is fundamentally a statement about which two domains a device sits
between -- and "Home" vs. "Not-Home" is the base distinction all of them are built on top of.
**This is computed from `fw_route_db.sqlite`'s real `fw_interfaces` (directly-connected subnets)
and `fw_routes` (full routing table) data** -- not from zone names, not from hostnames. See
`fw_class_tagging_retooling_spec.md` ss4 for the precise algorithm, and `fw-policy-classification`
for why zone names and hostnames aren't trustworthy enough to use instead.

**Status as of this skill's writing: the Home/Not-Home algorithm and the class-tagging mechanism
built on top of it are specified but not yet implemented**, and implementation is currently
blocked on a real, unresolved data-completeness question -- see
`fw_data_pipeline_integrity_prompt.md` for the full, current blocking issue (whether production's
real PA config collection is per-device files or bulk Panorama exports, which determines whether
`fw_interfaces`/`fw_routes` can be trusted as complete before this taxonomy can be applied at
scale).

## Related tools, files, and skills

- `fw-policy-classification` skill -- companion skill, the broader interpretive methodology for
  reading a firewall's actual rules correctly once its class is known
- `fw_class_tagging_retooling_spec.md` -- the implementation design for computing and storing
  these class tags
- `fw_data_pipeline_integrity_prompt.md` -- the current blocking data-completeness question that
  must be resolved before the tagging mechanism can be trusted
- `fw_route_db.sqlite` (`fw_interfaces`, `fw_routes`) -- the real data source for Home/Not-Home
- `fwlookup.py --inv [SEGMENT]` -- `FW_SEGMENT`-based inventory, useful for spotting the
  single-class vs. multi-class pattern in a device group at a glance (Aetna/Cloud's dedicated
  quads are visually obvious in `--inv CLOUD`'s output; Shea/Vegas's consolidation is visible as
  fewer, denser device entries per segment)
