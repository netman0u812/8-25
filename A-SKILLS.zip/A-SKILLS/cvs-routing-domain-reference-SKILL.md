# CVS Health CCD Platform — Routing Domain & Network Topology Reference

## CRITICAL — Read before any IPAM, LM, or topology work

This skill documents the authoritative routing domain taxonomy, site classification
rules, cloud FW topology, and IPAM correction rules established through systematic
analysis of FW configs, FMC ACP exports, Zscaler traffic data, and HR location data.

---

## 1. ROUTING_DOMAIN Taxonomy

Valid ROUTING_DOMAIN values and their meaning:

| ROUTING_DOMAIN | Description |
|---|---|
| `Internal-PBM` | CVS/Caremark enterprise routing fabric |
| `Internal-HCB` | Aetna enterprise routing fabric |
| `Internal-Retail` | CVS retail store network — physical stores ONLY |
| `Cloud-Azure` | Azure cloud subnets (both CVS and Aetna heritage) |
| `Cloud-GCP` | GCP cloud subnets (both CVS and Aetna heritage) |
| `Cloud-AWS` | AWS cloud subnets (both CVS and Aetna heritage) |
| `Internet-Facing` | Publicly BGP-advertised space — actual edge blocks only |
| `Partner` | Third-party partner connectivity |
| `P2P-WAN` | Point-to-point WAN links |
| `Offshore` | NOT VALID — correct to `Partner` |
| `COLO` | NOT VALID for workload subnets — Switch/DC-COLO subnets must be `Internal-PBM` or `Internal-HCB` based on HERITAGE. Only valid for Switch-owned backbone (`HERITAGE=SWITCH`). |

---

## 2. SITE_CODE Suffix Convention

| Suffix | Meaning |
|---|---|
| `_DC` | Data Center |
| `_CO` | Corporate office |
| `_RT` | Retail store |
| `_SP` | Specialty pharmacy |
| `_HP` | CarePlus Health Plan clinic |
| `_MO` | Mail Order / distribution |
| `_RD` | Distribution center |
| `_CC` | Call Center |
| `_TP` | Third Party / Partner |
| `_CI` | COLO Infrastructure (Switch LVG, Switch ATL) |
| `_CX` | COLO Exchange (Equinix peering — ONE per city) |
| `_DR` | Disaster Recovery |
| `_IS` | Infrastructure Services (cloud) |
| `_VH` | VoIP Hub |

---

## 3. LOCATION_TYPE Classification

| LOCATION_TYPE | Description | Example Sites |
|---|---|---|
| `DataCenter` | CVS/Aetna owned/leased DC | US_SCO_AZ_DC (Shea), US_MIC_CT_DC (MDC), US_WIN_CT_DC (WDC), US_WOR_RI_DC, US_CUR_RI_DC |
| `COLO` | Network/cloud exchange peering ONLY | US_DFW_TX_CX (Equinix Dallas), US_IAD_VA_CX (Equinix Ashburn) |
| `DC-COLO` | Data center COLO — hosts CVS/Aetna workloads | US_LVG_NV_CI (Switch LVG), US_ATL_GA_CI (Switch ATL) |
| `DR` | Disaster recovery facility | US_SPK_NV_CI (Switch TRE/Sparks), US_WDB_NJ_CI (Iron Mountain Woodbridge), US_EDW_IL_CI (WWT Edwardsville), US_CDT_NJ_DR (SunGard Carlstadt), US_PHL_PA_DR (SunGard Philadelphia) |
| `Cloud` | Cloud provider subnets | US_AZR_UE2_IS, US_GCP_USE4_IS, US_AWS_USE1_IS |
| `Corporate` | Corporate office | Various US_xxx_CO sites |
| `Retail` | CVS retail stores | US_xx_xxxxx_RT |
| `CarePlus` | CarePlus Health Plan clinics | US_xxx_HP sites |
| `Partner` | Third-party partner | US_xxx_TP, IN_GGN_HR_TP |
| `Specialty` | CVS Specialty pharmacy | US_xxx_SP (non-Omnicare) |
| `Omnicare` | Omnicare pharmacy sites | US_xxx_SP (HERITAGE=OMNICARE) |
| `Distribution` | Distribution/fulfillment centers | US_xxx_RD |
| `Mail-Order` | Mail order pharmacy | US_xxx_MO |
| `Call-Center` | Call centers | US_xxx_CC |

---

## 4. ROUTING_DOMAIN Rules by LOCATION_TYPE + HERITAGE

### Non-negotiable rules:

**Retail plane:**
- `LOCATION_TYPE=Retail` → MUST be `Internal-Retail`
- All other LOCATION_TYPEs → MUST NOT be `Internal-Retail`

**CarePlus:**
- All CarePlus HP sites → `Internal-HCB` regardless of HERITAGE field
- CarePlus is Aetna HMO — always on HCB fabric

**Heritage-driven rules (for DC, Corporate, Specialty, Distribution, Mail-Order, Call-Center, Omnicare):**
- `HERITAGE=CVS` or `HERITAGE=OMNICARE` or `HERITAGE=Caremark/CVS` → `Internal-PBM`
- `HERITAGE=AETNA` → `Internal-HCB`
- `HERITAGE=Mixed` → investigate, split by subnet owner

**Cloud:**
- `LOCATION_TYPE=Cloud` + `US_AZR_*` → `Cloud-Azure`
- `LOCATION_TYPE=Cloud` + `US_GCP_*` → `Cloud-GCP`
- `LOCATION_TYPE=Cloud` + `US_AWS_*` → `Cloud-AWS`
- `HERITAGE` does NOT determine cloud RD — both CVS and Aetna use same cloud FW paths
- ExpressRoute peering subnets at DC sites (NET_TYPE=Cloud-Azure) → `Cloud-Azure` not `Internal-HCB`

**Partner:**
- `LOCATION_TYPE=Partner` → `Partner` regardless of HERITAGE
- `Offshore` is not a valid RD — correct to `Partner`

**COLO/DC-COLO:**
- `HERITAGE=SWITCH` at Switch facilities → `COLO` RD is valid for Switch-owned backbone only
- `HERITAGE=CVS` at DC-COLO → `Internal-PBM`
- `HERITAGE=AETNA` at DC-COLO → `Internal-HCB`
- `HERITAGE=PARTNER` at DC-COLO → `Partner`
- `LOCATION_TYPE=COLO` (Equinix peering) → subnets are `Internal-PBM` (CVS) or `Internal-HCB` (Aetna) based on HERITAGE — NOT `COLO` RD

**Internet-Facing:**
- Only valid for publicly BGP-advertised edge blocks
- NEVER overwrite `Internet-Facing` based on SITE_CODE alone
- Aetna public BGP space: `157.121/16`, `167.69/16`, `206.213/16`
- CVS public space at WOR/RI DC: `12.x.x.x`, `23.x.x.x`, `156.78.x.x`, `199.42.x.x`, `204.122.x.x` — these are internally routed, NOT `Internet-Facing`

---

## 5. Cloud FW Topology

### Aetna cloud path (Internal-HCB → Cloud):
```
Aetna DC (MDC/WDC)
  → MID-FW-EQUINIX-FTD (mid-fw-equinix-ftd-1/2/3/4)
    inside: 10.10.14.120/29 (MDC fabric)
    outside: 10.10.14.112/29 (Equinix)
  → WIN-FW-EQUINIX-FTD (win-fw-equinix-ftd-1-1/1-2/2-1/2-2)
    inside: 10.10.15.208/29 (WDC fabric)
    outside: 10.10.15.200/29 (Equinix)
  → CME-HUB-PRODGLR (Cisco Managed Equinix hub)
  → Azure ExpressRoute / GCP Interconnect
```
FMC Policy: `Internal_Networks = Aetna_Networks (157.121/16, 167.69/16, 206.213.x.x, 10.x.x.x)`
EIGRP distribute-list filters summary route back to inside.

### CVS cloud path (Internal-PBM → Cloud):
```
CVS DC (RI-ONE / Shea)
  → RRIWSDC-SEC-EXXTFTD (RI to Equinix)
    Policy: retail-equinix_Cloud-Policy
  → PAZSHDC-SEC-EXXTFTD (Shea to Equinix)
    Policy: shea-equinix_Cloud-Policy
    inside: 10.218.32.x (Shea DC fabric)
  → CME-HUB-PRODGLR (same Cisco Managed hub)
  → Azure ExpressRoute / GCP Interconnect
```

### Key finding: Both CVS and Aetna use the SAME CME-HUB cluster
- Azure traffic: CVS 3.9B connections, Aetna 462M — identical FW path
- No separate routing domain needed for cloud — HERITAGE distinguishes, not RD
- `Cloud-Azure` is correct for both CVS and Aetna Azure subnets

### GCP environments:
- `GCP-SecureHub_PROD` — Aetna GCP hub, also handles PSS_RETAIL traffic. Subnets: `10.236.x.x`, `10.149.x.x`
- `GCP-RxCon-Prod` — CVS Caremark RxConnect GCP. Subnets: `10.149.0.0/16`
- `GCP-CaaS-PCI` — CVS GCP PCI environment. Subnets: `10.117.0.0/21`, `10.117.32.0/21`. On-prem peer: RI-ONE (`12.46.119.234`)

### AWS environments:
- `AWS-Egress` — CVS Mac VDI AWS. Subnets: `10.174.0.0/16`. Egresses via Zscaler.
- `AWS-DR-Egress/Ingress` — CVS AWS DR. Subnets: `10.174.x.x` hosts.
- AWS subnets at `US_AWS_USE1_IS` → `Cloud-AWS`

---

## 6. Equinix Topology

### ONE Equinix per city — use CX suffix only:
- `US_DFW_TX_CX` — Dallas TX Equinix (peering only)
- `US_IAD_VA_CX` — Ashburn VA Equinix (peering only)
- `US_DFW_TX_CI` and `US_IAD_VA_CI` — STALE LM entries, retire

### What lives at Equinix:
- CME-HUB FW cluster (Cisco Managed) — Azure/GCP cloud egress for both CVS and Aetna
- MID/WIN-FW-EQUINIX-FTD — Aetna DC to cloud path
- RRIWSDC/PAZSHDC-EXXTFTD — CVS DC to cloud path
- BGP peering with Azure, GCP, AWS

### Equinix subnets in IPAM:
- `US_DFW_TX_CX` — 335 rows, `Internal-PBM` (CVS peering segments)
- `US_IAD_VA_CX` — 238 rows, `Internal-PBM` (CVS peering segments)
- These are CORRECT — CVS-heritage peering subnets at Equinix route on Internal-PBM fabric

---

## 7. Wireless Tunnel Topology

`SHEA-DC-WIRELESS` FW zone = Cisco WLC termination point at Shea DC.
- Remote site SSIDs (CarePlus HP, Specialty) tunnel back to Shea WLCs via CAPWAP/LWAPP
- `11.1.x.x/25` subnets = wireless tunnel endpoints, correctly assigned to SHEA-DC-WIRELESS
- Routing table shows RI-ONE route for `11.1.x.x` — this is a summary route, not the actual traffic path
- These are NOT route mismatches — topology is correct

---

## 8. Pending IPAM Workstreams

### Completed (r13):
- Patch 1: ROUTING_DOMAIN corrections (468 rows) — r12
- Patch 2: Systematic RD corrections F1-F14 (460 rows) — r13

### In Progress:
- LM patch: LOCATION_TYPE corrections (5 rows) — COLO→DC-COLO/DR
- CX13 fix: NET_TYPE corrections at Cloud/Partner sites (275 rows)
- CX4 fix: CSNA SITE_CLASS sync (13 rows)
- CX7 fix: Orphaned CSNA entries (4 rows)

### Pending (future sessions):
- Patch 3: SITE_CODE/LOCATION_TYPE corrections for misattributed cloud subnets
  - `10.149.x.x` at US_SCO_AZ_DC (53 rows) → US_GCP_USE4_IS, Cloud-GCP
  - `10.236.x.x` at US_SCO_AZ_DC (21 rows) → US_GCP_USE4_IS, Cloud-GCP
- ACP ingestion pipeline: build_cloud_fw_topology.py
  - Ingest FMC ACP JSON exports
  - Extract source/dest subnet pairs with policy context
  - Map to IPAM CIDRs via LPM
  - Produce ent-ipdataset-CLOUD-FW-TOPOLOGY
  - Feed app context into app_subnet_index

---

## 9. LM Patch — COLO/DR Corrections

File: `lm_colo_dr_patch_20260618.csv`

| SITE_CODE | CANONICAL_NAME | BEFORE | AFTER |
|---|---|---|---|
| `US_ATL_GA_CI` | Atlanta GA - Switch COLO | `COLO` | `DC-COLO` |
| `US_LVG_NV_CI` | Las Vegas NV - Switch Colo | `COLO` | `DC-COLO` |
| `US_SPK_NV_CI` | Sparks NV - Switch TRE | `COLO` | `DR` |
| `US_WDB_NJ_CI` | Woodbridge NJ - Iron Mountain | `COLO` | `DR` |
| `US_EDW_IL_CI` | Edwardsville IL - WWT COLO | `COLO` | `DR` |

Apply order:
```bash
python3 ipam-db.py --update-patch lm_colo_dr_patch_20260618.csv --type location_master --dry-run
python3 ipam-db.py --update-patch lm_colo_dr_patch_20260618.csv --type location_master
python3 ipam-db.py --cross-check
```
Cascades LOCATION_TYPE into all_IP_networks. Does NOT change ROUTING_DOMAIN.
Current IPAM is r13 — cascade writes r14. All 460 RD corrections in r13 are preserved.

---

## 10. Session State (2026-06-18 EOD)

| Dataset | Version | Rows | Notes |
|---|---|---|---|
| `location_master` | v5.24 | 11,598 | LM patch pending |
| `all_IP_networks` | v20260611r13 | 24,944 | 0 HIGH, 292 MEDIUM (pre-existing) |
| `EGRESS-FW-TOPOLOGY` | v20260617 | 71,559 | Needs rebuild against r13 |
| `build_IP_Network_Egress_FW_topology.py` | v1.1.4 | — | Ready |
