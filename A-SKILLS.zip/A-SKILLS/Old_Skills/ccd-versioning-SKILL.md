---
name: ccd-versioning
description: >
  CVS Health CCD Platform versioning rules and script delivery discipline.
  ALWAYS load this skill before writing, modifying, patching, or delivering
  any Python script in the CCD platform (build_location_master.py,
  process_ip_report.py, apply_ehm_enrichment.py, apply_ndm_gaps.py,
  build_all_ip_networks.py, build_network_device_master.py,
  build_ent_host_dataset.py, build_app_subnet_index.py, ipam-db.py,
  generate_fw_rule_report.py, build_qualys_pipeline.py, pipeline.py,
  and any other CCD tool). Triggers: any mention of versioning, script
  updates, patches, "bump the version", "what version is", delivering a
  script, modifying a script, version mismatch, wrong script, "give me
  the script", "update the script", version string, changelog.
---

# CCD Platform — Versioning Rules & Script Delivery Discipline

## The Core Problem This Skill Solves

Scripts have been delivered with wrong versions, patches applied in
multiple places (live machine, sandbox, download) with no canonical
source, and version strings not bumped after changes. This causes the
user to unknowingly run stale code. This skill enforces rules that
prevent that.

---

## Rule 1 — Every Change = Version Bump

**No exceptions.** If a script is modified in any way — bug fix, new
feature, default path, formatting — the version must be incremented
before delivery.

CCD scripts use **three-part semantic versioning: `MAJOR.MINOR.PATCH`**

| Change type | Increment | Example |
|---|---|---|
| Bug fix / minor tweak | PATCH | v1.2.0 → v1.2.1 |
| New feature / flag | MINOR | v1.2.1 → v1.3.0 |
| Breaking change / redesign | MAJOR | v1.3.0 → v2.0.0 |

**Why three parts matter:** Bug fix increments create a traceable trail.
When something breaks, you can bisect exactly which fix introduced the
regression. Without PATCH, every bug fix looks like a feature change
and the history is unreadable.

**Existing scripts** at two-part versions (e.g. `v1.8`, `v3.10`) are
treated as `v1.8.0` / `v3.10.0` — the next change starts the PATCH
counter from there.

**PATCH is never reflected in filenames.** It lives in the version
string, `--version` output, and changelog only. Filenames stay
`MAJOR.MINOR` (datasets) or unversioned (scripts). See Rule 8.

---

## Rule 2 — Version Strings Are in Three Places

Every script must have:

1. **`__version__` or `SCRIPT_VERSION` constant** at the top of the file
2. **`-V` / `--version` argparse flag** that prints the version and exits
3. **First line of stdout** when the script runs normally

```python
__version__ = "1.2.1"

parser.add_argument('-V', '--version', action='version',
                    version=f'script_name.py v{__version__}')

# In main():
print(f"=== script_name.py  v{__version__}  {date.today()} ===")
```

All three must agree. A mismatch between `__version__` and `--version`
output means the argparse wiring is broken — fix before delivery.

---

## Rule 3 — DATASET_VERSION Is Never Hardcoded

Scripts that produce versioned CCD dataset files must **auto-derive**
the next version from `ipam-db.json`, not hardcode it.

Dataset files use `MAJOR.MINOR` versioning only — PATCH does not apply
to dataset filenames or `DATASET_VERSION` values. The auto-derive
function bumps MINOR:

```python
def _next_version(ipam_dir: str, stem: str) -> str:
    """Read current registered version and increment minor.
    
    Dataset versioning is MAJOR.MINOR only — PATCH level does not
    apply to dataset files. Script versioning is MAJOR.MINOR.PATCH.
    """
    import json, re
    db_path = os.path.join(ipam_dir, 'ipam-db.json')
    if os.path.exists(db_path):
        with open(db_path) as f:
            db = json.load(f)
        ver = db.get(stem, {}).get('version', '')
        # Match MAJOR.MINOR (datasets never carry a patch segment)
        m = re.match(r'v?(\d+)\.(\d+)', str(ver))
        if m:
            return f'{m.group(1)}.{int(m.group(2))+1}'
    return '1.0'  # fallback for first run
```

Scripts affected: `build_location_master.py`, `build_all_ip_networks.py`,
`build_app_subnet_index.py`, `build_ent_host_dataset.py`,
`build_network_device_master.py`.

---

## Rule 4 — Complete File Delivery Only

**Never deliver a script as a patch, sed command, or Python snippet.**

Every script change must result in a **complete file download** via
`present_files`. The download IS the canonical version.

Workflow:
1. Make changes in sandbox (`/home/claude/`)
2. Bump `__version__` / `SCRIPT_VERSION` (correct increment level)
3. Update changelog in docstring
4. Run syntax check: `python3 -c "import ast; ast.parse(open('script.py').read())"`
5. Run `--version` check: `python3 script.py --version`
6. Copy to `/mnt/user-data/outputs/`
7. Call `present_files` to deliver the download

Do NOT say "run this sed command to patch it" or "add this block to
your script." Always deliver the whole file.

---

## Rule 5 — Changelog in Docstring

Every script must have a full version history in its module docstring.
**Every version entry must be present** — including PATCH increments.
This is the primary record of what changed and when.

```python
"""
script_name.py  v1.3.0
======================
Brief description.

Changelog:
    v1.3.0 — Added --hr-loc flag for HR validation; auto-find latest ip_report
    v1.2.2 — Fixed KeyError on missing VENDOR column in SolarWinds input
    v1.2.1 — Fixed off-by-one in CIDR prefix length check
    v1.2.0 — Added --dry-run flag; versioned output filenames
    v1.1.0 — Expanded SNMP normalizer; added --out-dir flag
    v1.0.0 — Initial build
"""
```

PATCH entries are especially important — they identify exactly which
bug fix introduced or resolved a regression.

---

## Rule 6 — Default Paths for Standard Source Files

Scripts must not require arguments for files at known standard locations.
All standard CCD source file paths must be defaults, overridable by flags.

Standard path layout (relative to `IP_Lookup/`):
```
IP_Lookup/
├── ipam-db/                          # --ipam-dir default
├── IP_Datasets_Raw/
│   ├── NMS-Source/                   # --out-dir default for NMS scripts
│   │   └── ip_report_*.csv           # auto-find latest
│   ├── Location-data/
│   │   ├── CVS-Location-Data-11-25.csv   # --cvs-loc default
│   │   └── CVS-Location-HR_LOC.xlsx      # --hr-loc default
│   ├── Retail-Network-Data/
│   │   └── Store_IP_and_Address_Info.xlsx  # --store-ip default
│   └── Risk-Reg_Files/               # Qualys VAE files
└── processed_outputs/                # pipeline output default
```

Pattern for auto-deriving defaults:
```python
_BASE = os.path.dirname(os.path.abspath(__file__))
_RAW  = os.path.join(_BASE, 'IP_Datasets_Raw')

parser.add_argument('--ipam-dir',
    default=os.path.join(_BASE, 'ipam-db'),
    help='ipam-db directory (default: ./ipam-db/)')
```

---

## Rule 7 — Version Verification Checklist

Before delivering any script, verify:

```
[ ] __version__ or SCRIPT_VERSION bumped (correct level: PATCH/MINOR/MAJOR)
[ ] Version string is three-part (MAJOR.MINOR.PATCH)
[ ] Version appears in --version output
[ ] Version appears in first line of normal run output
[ ] All three version locations agree
[ ] Syntax check passes (ast.parse)
[ ] --version flag works
[ ] Complete file delivered via present_files (never a patch)
[ ] Changelog updated in docstring (new entry at top)
[ ] DATASET_VERSION auto-derived (if script produces datasets)
[ ] All standard source file paths have defaults
```

---

## Rule 8 — Version in Filenames

**Scripts:** Script filenames are never versioned (`build_app_subnet_index.py`,
not `build_app_subnet_index_v1.8.0.py`). The version lives inside the file.

**Datasets:** Dataset filenames carry `MAJOR.MINOR` only — PATCH level is
not included. The `#VERSION=` header and `DATASET_VERSION` column are the
authoritative version record inside the file.

```
# Correct
all_IP_networks_v3.71.csv        # MAJOR.MINOR only
location_master_v4.8.csv

# Wrong
all_IP_networks_v3.71.2.csv      # No patch in dataset filenames
build_app_subnet_index_v1.8.0.py # No version in script filenames
```

---

## CCD Script Version Registry

**Always verify with `python3 <script> --version` before running.**
This table is a baseline reference — it will lag behind the live versions.
The canonical version is always what `--version` reports on the installed
script. Existing two-part versions are shown as `vX.Y.0` — the PATCH
counter starts from the next change.

| Script | Baseline Version | Key Flags |
|---|---|---|
| `build_location_candidates.py` | v2.7.0 | `-p1`, `-p2`, `-rp`, `--ipam-dir`, `-V` |
| `build_location_master.py` | v3.3.0 | `--work-dir`, `--nms`, `--cvs-loc`, `--store-ip`, `--hr-loc`, `-V` |
| `preprocess_p1.py` | v1.4.0 | `--module`, `--sw-file`, `--dry-run`, `-V` |
| `preprocess_p2.py` | v1.2.0 | `--dry-run`, `-V` |
| `update_location.py` | v1.1.0 | `--candidates`, `--dry-run`, `-V` |
| `update_ipam.py` | v1.6.0 | `--dry-run`, `-V` |
| `update_app.py` | v1.2.0 | `--dry-run`, `-V` |
| `update_network.py` | v1.1.0 | `--dry-run`, `-V` |
| `update_infrastructure.py` | v1.0.0 | `--dry-run`, `-V` |
| `update_platform.py` | v1.0.0 | `--dry-run`, `-V` |
| `ipam-db.py` | v3.10.0 | `--import`, `--list`, `--cross-check`, `--diff`, `--backup`, `--restore`, `--force`, `-V` |
| `build_app_subnet_index.py` | v1.8.0 | `--ipam-dir`, `-V` |
| `build_ent_host_dataset.py` | v3.1.0 | `--app-data`, `--ipam-dir`, `-V` |
| `build_network_device_master.py` | v2.0.0 | `--netbrain`, `--ipam-dir`, `-V` |
| `build_all_ip_networks.py` | v1.1.0 | `--nms-sub`, `--nms-32`, `--ipam-dir`, `-V` |
| `build_csna_site_registry.py` | v1.0.0 | `--ipam-dir`, `-V` |
| `generate_csna_hostgroups.py` | v3.3.0 | `--host-master`, `--ipam-dir`, `-V` |
| `generate_fw_rule_report.py` | v2.0.0 | `--ipam-dir`, `-V` |
| `generate_fw_app_matrix.py` | v1.1.0 | `--ipam-dir`, `-V` |
| `build_ipam_promotion_candidates.py` | v1.1.0 | `--review`, `--ipam-dir`, `-V` |
| `hostname_translate.py` | v1.0.0 | `--add-prefix`, `--batch`, `-V` |
| `iplookup.sh` | v3.11.0 | `--loc-list`, `--loc-lookup`, `-V` |
| `parse_vpn_configs.py` | v1.4.0 | `--ipam-dir`, `-V` |
| `process_ip_report.py` | v1.2.1 | `--ip-report`, `--ipam-dir`, `--out-dir`, `--hr-loc`, `-V` |
| `apply_ehm_enrichment.py` | v1.0.0 | `--ehm`, `--patch`, `--out-dir`, `--pci-only`, `--dry-run`, `-V` |
| `apply_ndm_gaps.py` | v1.1.0 | `--ndm`, `--gaps`, `--ipam-dir`, `--out-dir`, `--review`, `--dry-run`, `-V` |
| `build_qualys_pipeline.py` | v1.1.0 | `--input-dir`, `--out-dir`, `--dry-run`, `-V` |

---

## What To Do When a Version Mismatch Is Found

If the user reports the wrong version ran:

1. **Do not patch** — deliver a complete new file
2. Check the version registry above (then verify with `--version`)
3. Verify the sandbox copy has the correct version before delivery
4. Run the checklist (Rule 7) before calling `present_files`
5. Tell the user explicitly: "Install this by copying to `./script_name.py`"

---

## CCD Dataset Versioning Rules (Reference)

Scripts use `MAJOR.MINOR.PATCH`. Datasets use `MAJOR.MINOR` only —
PATCH does not apply to dataset files.

| Dataset | Versioning scheme | Filename example | Notes |
|---|---|---|---|
| `all_IP_networks` | `vMAJOR.MINOR` | `all_IP_networks_v3.71.csv` | PATCH not in filename |
| `location_master` | `vMAJOR.MINOR` | `location_master_v4.8.csv` | PATCH not in filename |
| `retail_networks` | `vMAJOR.MINOR` | `retail_networks_v2.5.csv` | PATCH not in filename |
| `csna_site_registry` | `vMAJOR.MINOR` | `csna_site_registry_v2.13.csv` | PATCH not in filename |
| `ent_host_master` | `vYYYYMMDDrN` | `ent_host_master_v20260427r13.csv` | Date + revision |
| `ent_network_device_master` | `vYYYYMMDD` | `ent_network_device_master_v20260504.csv` | Date only |
| `app_subnet_index` | `vYYYYMMDD` | `app_subnet_index_v20260509.csv` | Date only |
| `delivery_infrastructure` | `vYYYYMMDDrN` | `delivery_infrastructure_v20260504r4.csv` | Date + revision |
| `delivery_platform` | `vYYYYMMDDrN` | `delivery_platform_v20260504r2.csv` | Date + revision |

Every dataset file must have:
- Versioned filename (`MAJOR.MINOR` or date-based — no PATCH segment)
- `#VERSION=` header line
- `DATASET_VERSION` column on every row
- `LOC_MASTER_VERSION` column on every row (for IPAM files)
