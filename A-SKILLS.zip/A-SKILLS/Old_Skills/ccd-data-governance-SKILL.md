---
name: ccd-data-governance
description: >
  CCD Platform master data governance rules — location canonical names,
  cloud zone taxonomy, IPAM update discipline, EHM update discipline.
  ALWAYS load this skill before: building any location patch, updating
  all_IP_networks, updating ent_host_master, adding cloud subnets,
  resolving CANONICAL_LOCATION mismatches, or any script that writes
  CANONICAL_LOCATION values into any CCD dataset. Triggers: location
  master update, IPAM patch, EHM patch, cloud subnet, canonical name,
  CANONICAL_LOCATION, routing domain, cloud zone, location mismatch,
  stale location, wrong location.
---

# CCD Platform — Master Data Governance Rules

## Why This Skill Exists

Every data quality problem in CCD location, IPAM, and EHM traces to
the same root cause: source data was used to REBUILD masters from
scratch instead of MERGING into the registered master. Each rebuild
lost canonical name discipline because source systems (NMS, Qualys,
ADL, SNOW) use their own naming conventions — not CCD canonical names.

These rules prevent that from happening again.

---

## Rule 1 — Never Rebuild From Scratch

**The registered master is always the base. Always.**

| Operation | Correct | Wrong |
|---|---|---|
| Location update | Export registered LM → patch → new version | Build new LM from NMS export |
| IPAM update | Merge promoter output into registered IPAM | Rebuild all_IP_networks from SourceFire/NMS |
| EHM update | Apply patch to registered EHM | Rebuild EHM from ADL/SNOW export |

If a script produces a full dataset file, it must start from the
registered master and merge — not generate from source data alone.

Violation symptom: row count drops unexpectedly, canonical names
revert to source-system strings, location fields go blank.

---

## Rule 2 — CANONICAL_LOCATION Must Always Resolve

Every row in every CCD dataset that has a CANONICAL_LOCATION field
must contain a value that exists in the current registered
location_master CANONICAL_NAME column.

**The column in location_master is `CANONICAL_NAME` — not
`CANONICAL_LOCATION`.** Scripts that load location_master to validate
must use `CANONICAL_NAME` as the lookup key.

Validation check (required before any import):
```python
lm_names = set()
with open(lm_path) as f:
    for line in f:
        if not line.startswith('#'): break
    for row in csv.DictReader([line] + f.readlines()):
        n = row.get('CANONICAL_NAME','').strip()
        if n: lm_names.add(n)

# Every CANONICAL_LOCATION in the dataset must be in lm_names
stale = [r for r in dataset if r['CANONICAL_LOCATION'] not in lm_names]
# stale must be empty before import is permitted
```

---

## Rule 3 — Location Is Derived From Network, Not From Application

**CANONICAL_LOCATION = where the host's subnet is anchored in the
network topology. Not where the application owner says the server is.
Not what the server name suggests. Not what the source system says.**

Derivation priority:
1. CIDR-based LPM lookup against all_IP_networks
2. Hostname-based site code translation (hostname_translate.py)
3. NMS SNMP location string (normalized via build_snmp_location_map.py)
4. Manual override (documented in KNOWN_SUBNET_OVERRIDES)

Never use:
- SERVER_SITE field from ADL/SNOW (application owner location)
- Source system location strings without normalization
- Free-text location from Qualys or any scanner

---

## Rule 4 — Cloud Location Is Zone-Based, Not BU-Based

Cloud deployments are multi-tenant. A single cloud /16 block carries
CVS, Aetna, PBM, Retail, and other workloads simultaneously. The
CANONICAL_LOCATION for a cloud host identifies the **network zone**
(which hub, which region, which security boundary) — not the business
unit that owns the application running on that host.

### Architecture Context

CVS Health cloud connects to the enterprise via Equinix peering from
five fixed points: Las Vegas Switch Colo, Cumberland RI, Scottsdale
Shea DC, Middletown CT (MID), Windsor CT (WDC). The cloud is a third
routing domain tier (`Cloud-Azure`, `Cloud-GCP`, `Cloud-AWS`) that
sits above the CVS (`Internal-CVS`) / Aetna (`Internal-HCB`) split.

### Authoritative Cloud CIDR → Canonical Location Map

**Azure:**
| CIDR Block(s) | Canonical Name | Zone |
|---|---|---|
| 10.68, 10.74, 10.82, 10.83, 10.85, 10.86, 10.98, 10.141, 10.142, 10.159, 10.175, 10.209, 10.210, 10.223, 10.229, 10.242 (all /16) | `Cloud - Azure SecureHub UE1` | SecureHub East US1/West US3 — contain mode |
| 10.152.0.0/16 | `Cloud - Azure SecureHub UE2` | SecureHub East US2 — active growth |
| 10.155.0.0/16 | `Cloud - Azure East US 2` | CVS Digital/PBM/MinuteClinic AKS platform |
| 10.243.0.0/16 | `SPLIT - Azure/GCP` | Split block — needs /24 resolution |

**GCP:**
| CIDR Block(s) | Canonical Name | Zone |
|---|---|---|
| 10.114.0.0/16, 10.236.0.0/16 | `Cloud - GCP East4 SecureHub` | GCP East4 SecureHub hub |
| 10.117.0.0/16 | `Cloud - GCP East4 PCI` | GCP East4 PCI/shared hub expansion |
| 10.112.0.0/16, 10.143.0.0/16, 10.149.0.0/16, 10.157.0.0/16, 10.247.0.0/16, 10.252.0.0/16 | `Cloud - GCP East4` | GCP East4 general |
| 10.158.0.0/16 | `Cloud - GCP West2` | GCP West2 |

**AWS:**
| CIDR Block(s) | Canonical Name | Zone |
|---|---|---|
| 10.207.0.0/18, 10.207.64.0/19 | `Cloud - AWS East1 Prod` | AWS East1 production |
| 10.207.96.0/19, 10.207.128.0/18 | `Cloud - AWS East1 NonProd` | AWS East1 non-prod |
| 10.207.192.0/19 | `Cloud - AWS East2 Prod` | AWS East2 production |
| 10.207.224.0/19 | `Cloud - AWS East2 NonProd` | AWS East2 non-prod |
| 10.208.0.0/16 | `Cloud - AWS East1 Aetna` | Aetna AWS East1 |

### Stale Cloud Names — Never Use These

These names existed in LM v4.4 and are being retired in v4.5.
Any script that produces one of these values has a bug:

```
Cloud - Azure CVS East US 2       → Cloud - Azure SecureHub UE1 (if in UE1 CIDRs)
                                    or Cloud - Azure East US 2 (if in 10.155)
Cloud - Azure CVS Central US      → Cloud - Azure SecureHub UE1 (mislabel — no Central US zone)
Cloud - Azure CVS                 → Cloud - Azure SecureHub UE1
Cloud - Azure Aetna East US 2     → Cloud - Azure SecureHub UE1
Cloud - Azure HCB - Aetna         → Cloud - Azure SecureHub UE1
Cloud - Azure CVS West US         → Cloud - Azure SecureHub UE1
Azure - Central US                → Cloud - Azure SecureHub UE1
Azure - East US 2                 → Cloud - Azure SecureHub UE1
West US Azure                     → Cloud - Azure SecureHub UE1
Cloud - GCP US-East4 - CVS        → Cloud - GCP East4 (zone-based, no BU suffix)
Cloud - GCP US-East4 - Aetna      → Cloud - GCP East4 (zone-based, no BU suffix)
Cloud - GCP US-East4 - Aetna 2    → Cloud - GCP East4
Cloud - GCP US-East4 - SecureHub  → Cloud - GCP East4 SecureHub
Cloud - GCP US-East4 - RxConnect  → Cloud - GCP East4
Cloud - GCP US-East4 - PCI        → Cloud - GCP East4 PCI
Cloud - GCP US-West2 - CVS        → Cloud - GCP West2
Cloud - GCP CVS West US 2         → Cloud - GCP West2
Cloud - GCP US-East4              → Cloud - GCP East4
Cloud - GCP US-West2              → Cloud - GCP West2
GCP - US East 4                   → Cloud - GCP East4
GCP - US West 2                   → Cloud - GCP West2
Cloud - GCP                       → resolve via CIDR lookup
AWS - US East 1                   → resolve via CIDR lookup
Cloud - AWS CVS East US           → resolve via CIDR lookup
Cloud - AWS                       → resolve via CIDR lookup
```

---

## Rule 5 — Physical DC Canonical Names Are Fixed

These names are authoritative for on-premises locations.
Never create variants, abbreviations, or BU-suffixed versions.

**CVS Primary:**
- `Las Vegas NV - Switch Colo` — core backbone, Switch NAP14 colo
- `Cumberland RI - 2100 Highland` — RI datacenter (RI-One)
- `Scottsdale AZ - Shea DC` — Shea DC

**Aetna Primary:**
- `Middletown CT - MID` — Aetna primary DC
- `Windsor CT - WDC` — Aetna DR DC

**Switch COLO variants that are WRONG (never use):**
- `Las Vegas NV - Switch DC` → `Las Vegas NV - Switch Colo`
- `Las Vegas NV - Switch COLO` → `Las Vegas NV - Switch Colo`

---

## Rule 6 — Update Sequence Is Non-Negotiable

When any master dataset changes, downstream datasets must be updated
in dependency order. Never skip a layer.

```
Layer 1 (Foundation):
  location_master → must be stable before anything else moves
  all_IP_networks → depends on location_master
  retail_networks → depends on location_master

Layer 2 (Identity):
  ent_host_master         → depends on all_IP_networks + location_master
  ent_network_device_master → depends on all_IP_networks

Layer 3 (Application):
  app_subnet_index        → depends on ent_host_master + all_IP_networks
  csna_site_registry      → depends on location_master

Layer 4 (Output):
  CSNA hostgroups         → depends on all Layer 1-3
  FW enrichment report    → depends on all Layer 1-3
```

**For the current cloud location remediation the sequence is:**
1. Patch location_master v4.4 → v4.5 (retire stale, add new canonicals)
2. Patch all_IP_networks v3.67 → v3.68 (update cloud CIDR CANONICAL_LOCATION)
3. Patch ent_host_master r4 → r5 (CIDR-LPM location correction for 14,451 hosts)
4. Apply Qualys EHM enrichment r5 → r6
5. Rebuild app_subnet_index
6. Run ipam-db.py --cross-check — expect 0 HIGH, 0 stale location violations

---

## Rule 7 — 100.64.x.x and Other Special Ranges Are Never Host IPs

If any of these appear as IP_ADDRESS in EHM or IPAM they are data errors:
- `100.64.x.x` — RFC 6598 CGNAT, carrier-grade NAT translation addresses
- `127.x.x.x` — loopback
- `169.254.x.x` — link-local
- `0.x.x.x` — unassigned
- Any hostname string appearing in an IP field

Tag these as `DATA_QUALITY=Error` and do not promote to IPAM.

---

## Rule 8 — Source System Names Are Never Canonical Names

Source systems use their own location strings. They must ALWAYS be
normalized through the CCD location resolver before writing to any
CCD dataset. Common source-system strings that look plausible but
are not canonical:

| Source string | What to do |
|---|---|
| `Rack:wVD13` | Skip — vSphere virtual rack, not a physical site |
| `3600 Mansell Road` | → `ActiveHealth GA` |
| `Cumberland RI` (bare) | → determine which building, do not use bare city |
| `Las Vegas` (bare) | → determine facility, do not use bare city |
| Any street address | → normalize via build_snmp_location_map.py |
| Any `Cloud - *` not in Rule 4 table | → CIDR lookup, then apply Rule 4 |

---

## Validation Checklist Before Any Master Import

Run before `ipam-db.py --import` for any dataset:

```
[ ] All CANONICAL_LOCATION values exist in current location_master CANONICAL_NAME
[ ] No stale cloud names from Rule 4 stale list
[ ] No bare city names (Cumberland RI, Las Vegas, etc.)
[ ] No 100.64.x.x, 127.x.x.x, or hostname strings in IP fields
[ ] Row count >= previous version (drops > 1% require explanation)
[ ] DATASET_VERSION and LOC_MASTER_VERSION stamped on every row
[ ] preflight_lm_check.py passes
[ ] ipam-db.py --cross-check shows 0 HIGH violations after import
```

---

## Rule 9 — Work From Home Locations Are NEVER Server Locations

**CRITICAL: Work From Home, Remote, and Offshore/Offsite locations from
SNOW/CMDB are the HR work location of the APPLICATION OWNER — not the
physical location of the server.**

These location values MUST be excluded from any EHM, IPAM, or NDM import:

```
Work At Home-*          (any state variant)
Remote - *
Remotes
Offshore/Offsite CW
CVS-Default Location
Field-*                 (HR field employee work locations)
```

When any of these appear in a source CMDB/SNOW export:
- Do NOT use them as CANONICAL_LOCATION
- Derive location from IP address via CIDR-LPM lookup instead
- If CIDR lookup fails, set LOCATION_SOURCE=LOCATION_NEEDS_REVIEW
- Log these rows to a separate review file for manual resolution

This applies to ALL pipeline scripts that process SNOW/CMDB exports:
build_ent_host_dataset.py, build_cmdb_enrichment.py, and any future
scripts that consume ServiceNow CI exports.

The same rule applies to any location string that resolves to a
residential address, home office, or personal work location.
