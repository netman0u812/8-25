# CCD Platform — Data Governance & Ingestion Skill

## Overview
This skill governs all data ingestion, dataset management, and quality
enforcement for the CVS Health CCD (Cyber and Compliance/Cloud Defense)
Platform. It encodes the rules, pipeline stages, tool inventory, and
decision logic Claude must apply when working on any CCD platform task.

---

## Trigger Conditions
Use this skill when the user:
- Asks about ingesting, processing, or onboarding a new dataset
- Asks about location mapping, CANONICAL_LOCATION, or location_master
- Asks about running preprocess_p1, preprocess_p2, or any update script
- Asks about versioning, importing, or cross-checking a dataset
- Asks "what do I do with this file?" in the context of network/IP data
- Asks about the pipeline gate, build_location_candidates, or exclusions
- Asks about dataset state, registry, or ipam-db
- Asks about any CCD script, dataset, or governance rule

---

## Core Mission

Accurate IP subnet → location mapping, with context about how that IP
space is used. This is the foundation for all security policy, CSNA host
group generation, and firewall enrichment. Without accurate IP-to-location,
nothing downstream is trustworthy.

---

## The Fundamental Challenge

The CVS Health estate spans 15+ acquisitions with massive RFC1918 overlap:

| Space | Heritage | Nature |
|---|---|---|
| 10.0.0.0/8 | CVS + Aetna overlap | Largest conflict zone |
| 172.16.0.0–172.31.0.0 | Retail dominant | 9,100+ stores, /26 per function |
| 100.64.0.0/10 | GKE pod networking | CGNAT overlap |

An IP address alone does not identify location. Disambiguation requires
CANONICAL_LOCATION + ROUTING_DOMAIN + HERITAGE together.

---

## The Non-Negotiable Rule

> No IP enters any master dataset without a verified CANONICAL_LOCATION
> that exists in location_master.

This is not a quality check. It is the hard entry condition for the
entire pipeline. Every other governance rule flows from this one.

---

## Context Layers

Location alone is insufficient for security policy. The platform builds
context across six layers:

| Layer | Dataset | Answers |
|---|---|---|
| Location | all_IP_networks, location_master | Where is this subnet? |
| Network device | ent_network_device_master | What device owns this space? |
| Server/host | ent_host_master | What server lives here? |
| Application | app_subnet_index | What app uses this subnet? |
| Delivery platform | delivery_infrastructure, delivery_platform | K8s, Docker, bare metal? |
| Retail | retail_networks | Which store, which function? |

---

## Dataset Registry

| Dataset | Current Ver | Notes |
|---|---|---|
| location_master | v4.5 | 10,181 rows |
| all_IP_networks | v3.70 | 20,177 rows — Observed→Inferred patch pending |
| ent_host_master | v20260427r11 | 66,948 rows |
| ent_network_device_master | v20260504 | 10,849 rows |
| app_subnet_index | v20260504 | 2,608 rows |
| retail_networks | v2.5 | 294,463 rows — never import retail /26s into all_IP_networks |
| hr_location_index | v20260507 | 4,445 rows |
| delivery_infrastructure | v20260504r3 | 5,755 rows |
| delivery_platform | v20260504r2 | 1,870 rows |
| csna_site_registry | v2.13 | 348 rows |
| mgmt_ip_index | v1.2 | 21 rows |
| pipeline_exclusions | pending | IPs excluded from pipeline with audit trail |

Registry must show all entries clean. Always verify with:
  python3 ipam-db.py --list
  python3 ipam-db.py --cross-check   # must show 0 HIGH

---

## Script Inventory

### Stage 0 — Dataset Builders
| Script | Ver | Source → Output |
|---|---|---|
| build_ent_host_dataset.py | v3.1 | ADL App + ADL Ent + SNOW → ent_host_master |
| build_network_device_master.py | v2.0 | NMS exports → ent_network_device_master |
| build_all_ip_networks.py | v1.1 | Nautobot/SolarWinds → all_IP_networks |
| build_location_master.py | v3.0 | Site reference → location_master |
| build_app_inventory.py | v1.3 | ent_host_master → app intermediates |
| build_app_subnet_index.py | v1.8 | App intermediates → app_subnet_index |
| build_hr_location_index.py | v1.0 | HR XLSX → hr_location_index |
| build_csna_site_registry.py | v1.0 | all_IP_networks + LM → csna_site_registry |
| crosscheck_solarwinds.py | v1.0 | SolarWinds XLSX + NDM → gap CSV |
| triage_gap.py | v1.0 | Gap CSV → buckets B–E + IPAM candidates |

### Pre-Pipeline Gate
| Script | Ver | Purpose |
|---|---|---|
| build_location_candidates.py | v1.2 | Location normalization + gate |
| manage_exclusions.py | v1.0 | T5 unmapped disposition → pipeline_exclusions |

### Pipeline
| Script | Ver | Stage |
|---|---|---|
| preprocess_p1.py | v1.3 | Stage 1 — classify |
| preprocess_p2.py | v1.0 | Stage 3 — normalize new hosts |
| update_location.py | v1.1 | Stage 4 |
| update_ipam.py | v1.5 | Stage 2 + 4 |
| update_network.py | v1.1 | Stage 2 + 4 |
| update_app.py | v1.0 | Stage 2 + 4 |
| update_infrastructure.py | v1.0 | Stage 2 + 4 |
| update_platform.py | v1.0 | Stage 2 + 4 |

### IPAM Management
| Script | Ver | Purpose |
|---|---|---|
| ipam-db.py | v3.10 | Registry manager |
| build_ipam_promotion_candidates.py | v1.1 | Manual IPAM candidate review |

### Lookup / Inventory
| Script | Ver | Purpose |
|---|---|---|
| iplookup.sh | v3.10 | IP lookup + device/app inventory |
| hostname_translate.py | current | Five-tier hostname → location |
| ip_dataset.py | v1.9 | External IP feed manager |

### Reporting
| Script | Ver | Purpose |
|---|---|---|
| generate_csna_hostgroups.py | v3.3 | CSNA XML for Stealthwatch |
| generate_fw_rule_report.py | v2.0 | FW rule analysis — 6-tab HTML |
| generate_fw_enrichment.py | v1.4 | Enrich FW logs |
| generate_fw_app_matrix.py | v1.1 | FW app traffic matrix |
| parse_vpn_configs.py | v1.4 | ASA VPN → vpn_protected_subnets |

---

## Data Ingestion Pipeline

### Pre-condition
Masters must be current. Run ipam-db.py --cross-check first.
Must show 0 HIGH before any pipeline run begins.

---

### Pre-Pipeline — Location Normalization (Hard Gate)

build_location_candidates.py MUST show CLEAR before preprocess_p1 runs.

The location mapping exercise resolves every IP in the candidate dataset.
Three outcomes — in order of frequency:

1. NORMALIZED — mangled string fuzzy-matched to existing LM entry.
   This is the expected outcome for the vast majority of records.
   The exercise is normalization, not location creation.

2. EXCLUDED — unresolvable or irrelevant (public IP, retired device,
   retail subnet). Documented in pipeline_exclusions with reason.

3. NEW LOCATION — genuinely new site with no LM entry (rare).
   Frequent new location entries = dirty source dataset, investigate first.

Five-tier resolution stack:
  Pre-T0  ip_dataset public IP check → auto-REJECT
  T1      CIDR-LPM vs all_IP_networks
  T1.5    retail_networks LPM → RETAIL_SKIP
  T2      hostname_translate five-tier resolver
  T3      HR index cross-validation
  T4      location_master fuzzy match → normalization
  T5      Unmapped → explicit disposition required

Gate sequence:
  python3 build_location_candidates.py --source <file> \
      --source-type <type> --dry-run
  python3 build_location_candidates.py --source <file> \
      --source-type <type>
  python3 manage_exclusions.py
  python3 ipam-db.py --import ./ipam-db/pipeline_exclusions.csv \
      --type pipeline_exclusions
  python3 update_location.py \
      --candidates ./processed_outputs/loc_candidates_DATE.csv
  python3 ipam-db.py --cross-check        # 0 HIGH required
  python3 build_location_candidates.py --source <file> \
      --source-type <type> --dry-run      # must show: CLEAR

---

### Stage 1 — Classify: preprocess_p1.py v1.3

Never touches location_master. Two modes:

  # Standard (CMDB + Qualys — default)
  python3 preprocess_p1.py --dry-run
  python3 preprocess_p1.py

  # SolarWinds onboarding
  python3 preprocess_p1.py --module solarwinds \
      --sw-file <path> --dry-run

p1 outputs:
  p1_matched             Already in NDM — no action
  p1_ndm_enhancement     Gap-fill NDM
  p1_ehm_enhancement     Gap-fill EHM
  p1_infra_enhancement   Gap-fill delivery_infrastructure
  p1_platform_enhancement Gap-fill delivery_platform
  p1_ipam_candidates     Missing subnets → Stage 2 + p2 *
  p1_new_hosts           Not in any master → p2
  p1_excluded            On pipeline_exclusions → skipped

* BACKLOG: p1_ipam_candidates should split LOCATED (parent prefix
  in LPM → Stage 2) vs UNLOCATED (no parent → p2). Not in v1.3.
  Currently all candidates flow to p2.

---

### Stage 2 — Enhancement Pass

Must commit before p2 runs. p2 does LPM lookups against all_IP_networks —
stale masters produce wrong locations that cascade silently.

  python3 update_ipam.py --dry-run
  python3 update_network.py --dry-run
  python3 update_app.py --dry-run
  python3 update_infrastructure.py --dry-run
  python3 update_platform.py --dry-run
  # Each: dry-run → run → --cross-check → 0 HIGH → next

---

### Stage 3 — Normalize New Hosts: preprocess_p2.py v1.0

--dry-run is a required gate. Must show acceptable location coverage
on new hosts before proceeding. Location failures cascade silently
into all six candidate streams — there is no hard gate on those masters.

  python3 preprocess_p2.py --dry-run
  python3 preprocess_p2.py

p2 outputs:
  location_candidates / ipam_candidates / network_candidates /
  app_candidates / infra_candidates / platform_candidates /
  unmapped (never silently dropped — always review queue)

---

### Stage 4 — New Data Pass

Strict order. Each script: dry-run → run → --cross-check → 0 HIGH → next.

  python3 update_location.py --dry-run
  python3 update_ipam.py --dry-run
  python3 update_network.py --dry-run
  python3 update_app.py --dry-run
  python3 update_infrastructure.py --dry-run
  python3 update_platform.py --dry-run

---

### Stage 5 — IPAM Promotion

Most careful step. Review every CANONICAL_LOCATION before approving.

  python3 build_ipam_promotion_candidates.py --review
  # Interactive [A/R/O/D/S/Q] per row
  # Output is delta patch — merge into full all_IP_networks before import
  python3 ipam-db.py --import ./promoter-output/all_IP_networks_vNEW.csv \
      --type all_IP_networks
  python3 ipam-db.py --cross-check        # 0 HIGH required

---

### Stage 6 — Post-Import Validation

- --cross-check after every import — CX1–CX9 + R13-UNMAPPED-LOCATION
- Rebuild app_subnet_index after any all_IP_networks change
- Check stale warnings — Qualys and preprocess candidates flagged
  if EHM version advanced since last run
- On HIGH violation: ipam-db.py --restore to last clean state immediately

---

## Versioning Rules

1. Every import = new version number. Never re-import under same version.
2. Curated datasets: vMAJOR.MINOR (e.g. v4.6)
3. Rebuilt/date-stamped: vYYYYMMDD (revisions: vYYYYMMDDrN)
4. Three required stamps on every file:
     - Versioned filename (e.g. all_IP_networks_v3.71.csv)
     - #VERSION= header row
     - DATASET_VERSION + LOC_MASTER_VERSION columns on every data row
5. vbare (no version prefix) = hard stop, do not import.

---

## Update Order (Non-Negotiable)

  LM → IPAM → NDM → EHM → Infra → Platform

---

## Safety Rules

1. Gate CLEAR before preprocess_p1 runs — no exceptions
2. --dry-run every script before writing files
3. --cross-check after every import — 0 HIGH required before continuing
4. Enhancement = gap fill only — existing data never overwritten
5. p2 --dry-run location coverage must be acceptable before Stage 3
6. On HIGH violation: ipam-db.py --restore immediately
7. No IP enters any master without a verified CANONICAL_LOCATION
8. Retail /26 subnets → retail_networks only, never all_IP_networks

---

## Location Derivation Rules

1. Location derived from network (CIDR-LPM), never from server owner
2. Hostname translation is the correct method for cloud/DC hosts
3. Subnet ownership = hub device location, not spoke
4. Cloud location = zone-based (hub + region), not BU-based
5. Physical DC canonical names are fixed — do not create variants
6. Retail store location = store /24 in retail_networks, not LM entry

---

## DC Topology Reference

Legacy CVS:    Shea DC, RI-One (Woonsocket), RI-2100 (Cumberland)
Legacy Aetna:  Middletown CT, Windsor CT, Phoenix AZ (Internal-HCB)
Switch COLO:   Las Vegas (Core Campus), Tahoe Reno (Citadel/TRE), Atlanta (Keep)
Other COLO:    Woodbridge (Iron Mountain), Carlstadt/Philadelphia (SunGard DR)
Retiring:      Richardson TX / Dallas Caremark
Cloud:         GCP (CVS + Aetna — 100.64.0.0/10 GKE), Azure (Zerto DR),
               AWS. IP derives location from hostname, not server owner.

---

## Known Open Items (Backlog)

1. all_IP_networks v3.70 → v3.71 — Observed→Inferred DATA_QUALITY patch
2. 1,270 app candidates with unmapped locations from Qualys run
3. vv double-version bug in ipam-db.py — cosmetic, registry shows vv4.5
4. 550 unreviewed location module candidates
5. Qualys pipeline re-run — stale since EHM r11 update
6. p1_ipam_candidates LOCATED/UNLOCATED split — not in v1.3

---

## Key File Paths (Yggdrasil — mj0u812)

Work dir:    ~/Documents/IP_Lookup/
ipam-db:     ~/Documents/IP_Lookup/ipam-db/
ipdatasets:  ~/Documents/IP_Lookup/ipdatasets/
Raw sources: ~/Documents/IP_Lookup/IP_Datasets_Raw/
Outputs:     ~/Documents/IP_Lookup/processed_outputs/