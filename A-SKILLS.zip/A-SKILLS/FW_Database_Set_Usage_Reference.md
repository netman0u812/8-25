# CCD Platform — FW Database Set: Usage Reference
**Covers:** `fwlookup.py` (rule/flow interface) and the 2026-07-17 expansion (`fw_route_db.py`, `fw_group_lookup.py`)

---

## 1. The FW Database Set — Overview

Three separate SQLite databases, each answering a genuinely different question about the firewall estate. They share one integration model (`ipam-db.py` registration, auto-discovery via `ipam_db_registry.py`) but are not interchangeable — picking the right one matters.

| Database | Built by | Queried by | Answers |
|---|---|---|---|
| `fw_rule_db.sqlite` | `build_fw_rule_db.py` v1.6.6 | `fwlookup.py` v1.10.0 | *"What rules exist, and what do they permit/deny?"* — the actual ACL/policy rule content, with observed flow correlation |
| `fw_route_db.sqlite` | `build_fw_route_db.py` v0.3.1 | `fw_route_db.py` v0.4.0 | *"Which firewalls sit on the path between this source and destination?"* / *"Which firewalls know how to route this prefix?"* — topology, not rule content |
| `fw_group_db.sqlite` | `build_fw_group_db.py` v0.2.1 | `fw_group_lookup.py` v0.2.0 | *"What IP addresses actually make up this named object-group, on this device?"* — resolved group membership, following nested references |

**A concrete example of why the distinction matters:** `fwlookup.py` can tell you a rule references `object-group yard_jockey_ips`. It does *not* expand that into the four real IP addresses inside it — that's `fw_group_lookup.py`'s job. Similarly, `fwlookup.py` can show you a rule permitting traffic from `10.247.67.64/26`, but it won't tell you whether that traffic would actually reach its destination through a *different* firewall entirely — that's what `fw_route_db.py` answers.

All three registered through the same model:
```
python3 ipam-db.py --import <file> --type fw_rule_db      # or fw_route_db / fw_group_db
```

---

## 2. `fwlookup.py` — the FW Rule Interface

### 2.1 What it queries

`fw_rule_db.sqlite` has three tables:
- **`rules`** — one row per ACL/policy rule (fw_name, policy_name, rule_name, action, protocol, zones, ports, comment, source config file)
- **`rule_ips`** — one row per src/dst IP entry a rule references (direction, type — host/network/any/fqdn/range/object —, CIDR, and packed integer bounds for longest-prefix-match sorting)
- **`ip_context`** — IPAM/F5-VIP/SNAT/GeoIP/EIR enrichment, keyed by IP value

Sources it's built from: ASA CLI configs, FTD CLI configs, PA Panorama XML, FMC ACP CSV exports, CrowdStrike observed-flow telemetry, and IPAM datasets (all_IP_networks, F5 VIP/Pool, SNAT pools, EHM).

### 2.2 Five query modes

**IP / network lookup** — find every rule where the IP/CIDR matches src or dst:
```
python3 fwlookup.py 10.93.48.0/24 --action permit
python3 fwlookup.py --ip 10.93.48.0/24        # equivalent, explicit flag form
```

**Rule name lookup** — find a named rule across every firewall:
```
python3 fwlookup.py --rule "some-rule-name"
```

**Policy lookup** — find every rule in a named policy/ACL:
```
python3 fwlookup.py --policy "Alorica"
python3 fwlookup.py --policy "Alorica" --fw RRICMCP    # narrow to one firewall
```

**Combined (rule + IP)** — rule name plus an IP together shows the rule *and* observed flows for that specific IP.

**Service lookup** — find rules permitting a specific port/service:
```
python3 fwlookup.py --service 443
python3 fwlookup.py --service ssh --action permit
```

**Context-only lookup** — skip rule matching entirely, just show what's known about an IP (IPAM/VIP/SNAT/GeoIP/EIR):
```
python3 fwlookup.py --context 10.223.252.110
```

### 2.3 Scope-filtering flags — the ones that matter most for signal vs. noise

This is the same "specific match vs. broad catch-all" problem this whole session ran into repeatedly with the newer tools — `fwlookup.py` already solved it, worth understanding these three flags well:

| Flag | Meaning |
|---|---|
| `--broad-threshold PREFIX` (default `20`) | The cutoff. Matches at/narrower than `/PREFIX` count as **TARGETED**; wider matches (and `any`) count as **BROAD**. |
| `--only-targeted` | Only show TARGETED matches. Filtered in SQL *before* `--limit`, so targeted rules aren't pushed out of the result set by broad-rule noise. |
| `--only-broad` | The inverse — only the catch-all/supernet rules. Useful for building a deduplicated reference of broad rules across many subnets. |

```
python3 fwlookup.py 10.157.89.64/26 --only-targeted
python3 fwlookup.py 10.157.89.64/26 --only-broad
python3 fwlookup.py 10.157.89.64/26 --only-targeted --broad-threshold 24
```

| Flag | Meaning |
|---|---|
| `--exact` | Only the **exact** queried network — same network address *and* same prefix length. A `/24` supernet containing your queried `/26`, or a `/32` inside it, both pass `--only-targeted` but fail `--exact`. |
| `--more-exact` | The query network **or narrower** (subset) — catches anything scoped *inside* the queried range, including single-host rules a plain lookup or `--exact` can't see. |
| `--less-exact` | The query network **or broader** (superset) — the full supernet chain that would also affect this subnet, from the subnet itself up to `/8`. |

**Generalized at v1.10.0** from a single v1.9.0 `--exact` flag into this three-flag family, once it became clear "is there a rule for exactly this subnet" and "is there anything more specific hiding inside it" are genuinely different questions — `--only-targeted` alone can't distinguish either from "a reasonably narrow supernet happens to cover this." **`--more-exact` matters specifically because no other mode, including a plain unfiltered lookup, can find a rule scoped to a single host inside your queried range** — the default containment logic only matches networks broad enough to span the *entire* queried range. All three exclude `ip_type='any'` (never "exact" to a specific subnet by definition) — a plain lookup or `--only-broad` still includes `any`.

```
python3 fwlookup.py 10.157.89.64/26 --exact          # only the exact /26
python3 fwlookup.py 10.157.89.64/26 --more-exact      # the /26 plus anything narrower inside it
python3 fwlookup.py 10.157.89.64/26 --less-exact      # the /26 plus anything broader containing it
python3 fwlookup.py 10.157.89.64/26 --exact --only-targeted    # combinable across the two flag families
```

`--only-targeted`/`--only-broad` are mutually exclusive with each other; separately, `--exact`/`--more-exact`/`--less-exact` are mutually exclusive with each other. One flag from each family can be combined (an exact match is normally also targeted unless it's wider than `--broad-threshold`).

### 2.4 Reading the output

`Scope:` (TARGETED/BROAD/ANY, of the matched entry specifically) and `Direction:` (SOURCE/DESTINATION) are both computed directly from the SQL match — trust these over the displayed `Source:`/`Destination:` text lines, which can show `(+N more)` and are for human review only, not machine parsing. If scripting against output, use `Scope:`/`Direction:`, not text-scanning the CIDR list.

### 2.5 Filter flags (combinable with any query mode)

| Flag | Purpose |
|---|---|
| `--direction {src,dst,both}` | Which side of the rule to match against (default: `both`) |
| `--fw` | Filter by firewall name (substring) |
| `--action` | Filter by action (`permit`/`deny`/`allow`/`block`) |
| `--limit N` | Max rules returned (default `200`) |
| `--no-flows` | Skip CrowdStrike observed-flow output |

### 2.6 IP intelligence flags — independent of rule lookup

These don't query `fw_rule_db.sqlite` at all — they're standalone IP intelligence tools bundled into the same CLI:

```
python3 fwlookup.py --profile 8.8.8.8      # full security/provider/ASN/DNS profile for a public IP
python3 fwlookup.py --dns 104.244.72.132   # quick DNS/PTR/NS lookup
python3 fwlookup.py --egress-map "Shea"    # FW egress topology for a SITE_CODE or location name
```

### 2.7 Inventory-manifest mode

```
python3 fwlookup.py --inv                          # full FW estate inventory
python3 fwlookup.py --inv EGRESS                    # one segment only
python3 fwlookup.py --inv PCI --fw PA               # segment + device-type filter
python3 fwlookup.py --inv --missing                 # only devices with hostname problems
```

Valid segments: `EGRESS`, `PCI`, `CLOUD`, `RA-VPN`, `B2B-VPN`, `B2B-MPLS`, `INTERCOMPANY`, `AFFILIATE`, `INTERNAL-DC`, `RETAIL-SDWAN`, `MGMT`.

### 2.8 Path/location overrides

| Flag | Default |
|---|---|
| `--db` | `./fw-db/fw_rule_db.sqlite` — **not yet on the auto-discovery model** (see §4) |
| `--ipam-db` | `./ipam-db` |
| `--dataset-dir` | script directory |
| `--inv-dir` | `./IP_Datasets_Raw/FW_Invintories` |

---

## 3. `build_fw_rule_db.py` — building the rule database

```
python3 build_fw_rule_db.py
```

Defaults (all overridable):
- `--config-dir ./IP_Datasets_Raw/FW_CONFIGS` — expects `ASA/`, `FTD/`, `PA/` subdirs
- `--policy-dir ./IP_Datasets_Raw/FW_POLICIES` — FMC ACP CSV exports
- `--ipam-dir ./ipam-db`
- `--ipdatasets ./ipdatasets` — for F5/SNAT registered datasets
- `--out ./fw-db/fw_rule_db.sqlite`
- `--compare` (on by default) — compares old DB vs. new after rebuild; `--no-compare` to skip
- `--dry-run` — parse and report without writing

---

## 4. The 2026-07-17 expansion: `fw_route_db` and `fw_group_db`

These two are architecturally newer and follow a different, more automated integration pattern than `fw_rule_db`/`fwlookup.py` — worth knowing the difference so you use the right workflow for each.

### 4.1 `fw_route_db.py` — routing topology

```
python3 build_fw_route_db.py                        # defaults to ~/Documents/IP_Lookup/IP_Datasets_Raw/FW_CONFIGS
python3 ipam-db.py --import fw_route_db_v<date>.sqlite --type fw_route_db
python3 fw_route_db.py -s <src> -d <dst>             # path-finding: who sits between these two
python3 fw_route_db.py --prefix <cidr>               # knowledge lookup: who has a route to this network
python3 fw_route_db.py -s <src> -d <dst> --ipam <all_IP_networks CSV>   # enrich with real IPAM context
```

`-s`/`-d` are **range-aware** — a full CIDR is evaluated across its whole range, not collapsed to a single address. If the range genuinely spans a routing boundary on some device (part of it goes one way, part another), that's surfaced explicitly as a flagged split, never silently resolved to one answer.

`--db` and `--ipam` **auto-discover** the currently registered file from `ipam-db/ipam-db.json` — no path needed in normal use. Explicit `--db`/`--ipam` still override.

### 4.2 `fw_group_lookup.py` — address-group membership

```
python3 build_fw_group_db.py                        # same default config-dir as above
python3 ipam-db.py --import fw_group_db_v<date>.sqlite --type fw_group_db
python3 fw_group_lookup.py --ip <ip>                                        # every group containing this IP, any device
python3 fw_group_lookup.py --fw_name <device>                              # every group on one device
python3 fw_group_lookup.py --fw_name <device> --address-group_name <name>  # exact membership of one group
python3 fw_group_lookup.py --ip <ip> --fw_name <device>                    # combine both filters
```

Membership is **fully resolved** — nested references (`network-object object <ref>`, `group-object <ref>` on ASA; static/dynamic groups on PA) are followed recursively to the real underlying CIDRs, the same way the device itself would evaluate the group at rule-match time. PA `dynamic` (tag-filter) groups are flagged as unresolvable from static config rather than guessed at.

`--db` also auto-discovers from the registry, same as `fw_route_db.py`.

### 4.3 Registration status, across all three

```
python3 check_fw_db_registration.py --base-dir ~/Documents/IP_Lookup
```

Reports every FW database's registration state in one place — including `fw_rule_db.sqlite`, which still lives at its own separate `./fw-db/` location. Never registers anything automatically; prints the exact `ipam-db.py --import` command for anything found unregistered.

---

## 5. A note on `fwlookup.py`/`fw_rule_db` integration status

`fwlookup.py --db` still defaults to a hardcoded `./fw-db/fw_rule_db.sqlite` — it does **not** auto-discover from `ipam-db/ipam-db.json` the way `fw_route_db.py`/`fw_group_lookup.py` do. This was a deliberate choice, not an oversight: `fwlookup.py` and `build_fw_rule_db.py` are large, established production tools (2,223 and 1,951 lines) with unknown downstream dependents, and changing their core path-resolution behavior wasn't done without a dedicated, carefully-scoped pass. `check_fw_db_registration.py` (§4.3) is how `fw_rule_db.sqlite` gets brought into the registration model today — via collection and explicit `ipam-db.py --import`, not by changing `fwlookup.py` itself.

If unifying this fully (auto-discovery for all three query tools, one consistent pattern) is wanted, that's a real, scoped follow-up — see the outstanding-work list in `CCD_Next_Session_Prompt_v20260717.md`, §3i.
