---
name: ccd-versioning-discipline
description: >
  CCD Platform versioning, changelog, and session documentation discipline for
  CVS Health Information Security. Use this skill for EVERY script modification,
  dataset update, or pipeline change in the CCD Platform. Triggers on: any
  request to patch, update, fix, or modify a CCD Platform script; any version
  bump; any end-of-session handoff; any documentation update request. This skill
  is NON-NEGOTIABLE — apply it before delivering any file. Failure to follow
  this discipline has caused production issues and lost functionality in the past.
---

# CCD Platform — Versioning & Documentation Discipline

## The Problem This Skill Solves

Scripts in the CCD Platform have MULTIPLE version string variables. Updating only
one while leaving others stale causes the deployed script to display the wrong version,
making it impossible to verify that the correct version is running. This has caused
repeated confusion and wasted sessions.

Additionally, changelog entries must be written at the time of change — not reconstructed
later. And pipeline documentation must be updated before the end of every session.

---

## Rule 1: Find ALL Version Variables Before Touching Anything

Every CCD script may have multiple version variables. Before making any change:

```bash
grep -n "version\|VERSION\|__version__\|SCRIPT_VERSION" <script.py> | grep -v "#"
```

Common patterns in the CCD Platform:

| Script | Version Variables |
|--------|------------------|
| preprocess_p1.py | `SCRIPT_VERSION = '...'` (line ~3) AND `__version__ = '...'` (line ~200) — BOTH must be updated |
| build_*.py | `__version__ = '...'` — usually one |
| ipam-db.py | `__version__ = '...'` |
| iplookup.sh | `VERSION=...` in the shell header |
| update_app.py | `__version__ = '...'` |

**NEVER update only one version variable. Find them all. Update them all.**

After patching, always verify:

```python
import re
with open('script.py') as f:
    content = f.read()
# Find ALL version strings
for m in re.finditer(r'(?:__version__|SCRIPT_VERSION|VERSION)\s*=\s*["\']([^"\']+)["\']', content):
    print(f"Line {content[:m.start()].count(chr(10))+1}: {m.group(0)}")
```

All must show the new version. If any still show the old version — fix before delivery.

---

## Rule 2: Write the Changelog at the Time of Change

Every script has a changelog section. Update it BEFORE delivering the file.

### Changelog location patterns

**Python scripts — look for:**
```python
# v1.2.3 — description of change
# v1.2.2 — previous change
```
Or in the module docstring:
```
preprocess_p1.py  v2.9.3  2026-06-15
  Description of what changed in this version.
preprocess_p1.py  v2.9.2  2026-06-15
  Previous version description.
```

### Changelog entry format

```
# vX.Y.Z  YYYY-MM-DD  One-line summary.
#          Detail line 1: what changed and why.
#          Detail line 2: any architectural implications.
#          New fields added: FIELD_A, FIELD_B (if applicable).
#          Downstream impact: which scripts consume this output.
```

### What must be documented

- What changed (the actual code change)
- Why it changed (the business reason)
- New fields added to any output schema
- New input files required
- Downstream scripts affected
- Any deprecations (e.g. DELIVERY_CONTAINER_HOST retired → DELIVERY_SHARED_PLATFORM)

### What is NOT acceptable

- Empty changelog for a version bump
- "Minor fixes" with no detail
- Updating `__version__` without updating the changelog text
- Changelog that only says what changed, not why

---

## Rule 3: Version Bump Rules

```
MAJOR.MINOR.PATCH

PATCH (+0.0.1): Bug fix, no schema change, no behavior change
MINOR (+0.1.0): New feature, new field, new input source, behavior change
MAJOR (+1.0.0): Breaking change, schema incompatibility, complete rewrite
```

### Dataset versioning (non-script files)

```
vYYYYMMDD       — date-versioned datasets (first version on that date)
vYYYYMMDDrN     — revision N on date YYYYMMDD (e.g. v20260615r3)
```

Three stamps required on every dataset file:
1. Versioned filename: `all_IP_networks_v20260611r4.csv`
2. `#VERSION=v20260611r4` header comment in the file
3. `DATASET_VERSION` column in every data row

**`vbare` = hard stop.** A dataset file with no version stamp must not be imported.

---

## Rule 4: Complete File Delivery Only

**Never deliver:**
- Patches or diffs to apply manually
- `sed` commands to run
- "Change line X to Y" instructions
- Partial file sections

**Always deliver:**
- The complete file, ready to deploy
- Verified with `ast.parse()` (Python) or `bash -n` (shell) before delivery
- With `present_files()` called so the user can download it

### Pre-delivery checklist (run before every present_files call)

```python
# 1. Syntax check
import ast
ast.parse(content)  # must not raise

# 2. Version check — ALL version strings updated
import re
versions = re.findall(r'(?:__version__|SCRIPT_VERSION|VERSION)\s*=\s*["\']([^"\']+)["\']', content)
assert all(v == NEW_VERSION for v in versions), f"Stale version strings: {versions}"

# 3. Changelog present
assert f'# v{NEW_VERSION}' in content or f'v{NEW_VERSION}' in content[:5000], "No changelog entry"

# 4. No unresolved TODO/FIXME left by the patch
assert 'TODO: UPDATE VERSION' not in content
```

---

## Rule 5: End-of-Session Documentation Update

Before ending ANY session, the following documents must be updated:

### Always update
1. **Session handoff prompt** (`ccd_session_handoff_YYYYMMDD.md`) — current dataset versions, script versions, completed work, next session objectives
2. **Pipeline command tree** (`CCD_Pipeline_Command_Tree_vX.Y.txt`) — if any stage changed

### Update if affected
3. **`CCD_Canonical_Objects_Pipeline_vX.Y.docx`** — if preprocess, EHM, or canonical objects changed
4. **SKILL.md files** — if a new pattern, dataset, or architectural rule was established
5. **`check_toolset.py`** — if a script version changed (update expected version string)

### Session handoff template

```markdown
# CCD Platform — Session Handoff YYYY-MM-DD

## Completed This Session
- Script: <name> <old_version> → <new_version>
  Change: <what and why>
- Dataset: <name> <old_version> → <new_version>
  Change: <what and why>

## Verified Baseline (EOD)
| Dataset | Version | Rows | Status |
| Script  | Version | — | Status |

## Next Session Objectives
1. Primary: <objective>
2. Secondary: <objective>

## Carry-Forward Open Items
- <item>
```

---

## Rule 6: check_toolset.py Must Stay Current

Every time a script version changes, `check_toolset.py` must be updated:

```python
# Find the relevant test entry
grep -n "script_name\|expected_version" check_toolset.py

# Update the expected version string
# Example: 'v1.4' → 'v1.5' for build_canonical_app_objects
('build', 'build_canonical_app_objects.py',
 ['--version'],
 'v2.9',   # ← must match the new __version__ prefix
 'build_canonical_app_objects version'),
```

The expected string is a PREFIX match — `'v2.9'` matches `v2.9.3`. Keep it at MAJOR.MINOR only so PATCH bumps don't require a check_toolset update.

---

## Common Mistakes to Avoid

| Mistake | Consequence | Fix |
|---------|-------------|-----|
| Updating `SCRIPT_VERSION` but not `__version__` | Script displays wrong version in header | Always grep for ALL version vars |
| Writing changelog after the fact | Inaccurate documentation | Write changelog as part of the patch |
| Not updating check_toolset.py | Health check fails on valid script | Update immediately after version bump |
| Delivering a patch instead of a full file | User can't deploy, session wasted | Always deliver complete files |
| Ending session without updating handoff prompt | Next session starts blind | Update handoff before session ends |
| Bumping version without changelog entry | No audit trail | Changelog is mandatory |
| Not documenting new EHM fields | Downstream scripts miss the fields | Document in pipeline doc AND changelog |

---

## Quick Reference — CCD Script Version Map

| Script | Current Version | Version Variable(s) |
|--------|----------------|---------------------|
| preprocess_p1.py | 2.9.3 | `SCRIPT_VERSION` AND `__version__` |
| update_app.py | 1.9 | `__version__` |
| build_canonical_app_objects.py | 1.8.4 | `VERSION` |
| build_shared_server_registry.py | 1.1.0 | `__version__` |
| build_network_groups.py | 1.8.4 | `__version__` |
| build_ng_report.py | 1.3.2 | `__version__` |
| build_service_objects.py | 1.0.5 | `__version__` |
| build_object_pipeline.py | 1.3.1 | `__version__` |
| build_edl_catalog.py | 1.1.2 | `__version__` |
| ipam-db.py | 3.15.8 | `__version__` |
| check_toolset.py | 1.1.0 | `__version__` |
| iplookup.sh | 3.23 | `VERSION=` |

Update this table in the SKILL whenever a script version changes.

---

*CCD Platform | CVS Health Information Security | June 2026*
