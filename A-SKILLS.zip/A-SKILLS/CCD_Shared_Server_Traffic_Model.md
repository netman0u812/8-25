# CCD Platform — Shared Server & Traffic Flow Model
**CVS Health Information Security | M. J. Martin, Lead Director**  
**June 15, 2026 | Reference Document**

---

## Why This Exists

This document captures the shared server traffic flow model that underpins the CCD
firewall object pipeline. It was nearly lost when `build_shared_server_registry.py` was
incorrectly deleted. This must be maintained as a SKILL reference and pipeline document.

---

## The Core Problem

In the CVS/Aetna enterprise, a single physical or virtual server frequently hosts multiple
applications. This creates an attribution problem:

- EHM records one row per IP per APM ID
- The same IP appears under multiple APM IDs (APP_COUNT >= 2)
- `build_canonical_app_objects.py` would incorrectly assign that IP to multiple APP_Objects

**The shared server registry resolves this** — it identifies shared servers, excludes their
IPs from APP_Objects, and creates DELIVERY_* objects that correctly model the hosting topology.

---

## Traffic Flow Models by Hosting Platform

### On-Premises (CVS DC / Aetna DC / COLO)

```
INBOUND:
  Internet / Partner
    → Extranet FW (public VIP IP is on the FW interface)
      → FW SNATs to F5 internal VIP IP
        → F5 load balances to MEMBER_IP:MEMBER_PORT (server backend)

OUTBOUND (server-originated):
  Server private IP (MEMBER_IP)
    → F5 SNAT pool IP (post-SNAT source)
      → Egress FW (INET_SEG_* address range)
        → Internet or cross-domain (via extranet FW)
```

**Key IP addresses:**
| Role | IP Source | Dataset |
|------|-----------|---------|
| Public-facing address | FW interface IP | ent-ipdataset-INTERNET-FACING |
| F5 internal VIP | VIP_IP | ent-ipdataset-F5-VIP-REGISTRY |
| Backend server | MEMBER_IP:MEMBER_PORT | ent-ipdataset-F5-POOL-MEMBERS |
| Outbound SNAT source | SNAT_MEMBER_IPS or automap | ent-ipdataset-FW-SNAT-POOLS |
| Egress address (post-FW) | INET_SEG_* | internet_segments_vDATE.csv |

**SNAT modes:**
- `automap` (majority) — F5 uses its own self-IP as outbound source
- `snat` (explicit pool) — F5 uses a defined SNAT pool IP as outbound source
- `none` — pass-through, server sees real client IP (rare)

---

### Cloud (Azure / GCP)

```
INBOUND public:
  Internet
    → F5 public VIP (Azure public IP — F5 IS the edge, no separate FW)
      → Server private IP:PORT

INBOUND private (cross-domain from on-prem):
  CVS/Aetna on-prem (via ExpressRoute)
    → Cloud Ingress FW
      → F5 private VIP (Azure private IP)
        → Server private IP:PORT

OUTBOUND (server-originated):
  Server private IP
    → Cloud Egress FW
      → Azure NAT Gateway public IP
        → Internet or back to on-prem via ExpressRoute
```

**Key IP addresses:**
| Role | IP Source | Dataset |
|------|-----------|---------|
| Public VIP (internet-facing) | Azure public IP on F5 | ent-ipdataset-F5-VIP-REGISTRY (204.x.x.x) |
| Private VIP (cross-domain) | Azure private IP on F5 | ent-ipdataset-F5-VIP-REGISTRY (10.x.x.x) |
| Backend server | MEMBER_IP:MEMBER_PORT | ent-ipdataset-F5-POOL-MEMBERS |
| Outbound NAT address | Azure NAT Gateway IP | ent-ipdataset-AZURE-PUBLIC-ENDPOINTS |

**Critical difference from on-prem:**
- On-prem: extranet FW owns the public IP, SNATs to F5 internal VIP
- Cloud: F5 directly owns the public IP — no separate FW in front for public inbound
- Cloud egress: Azure NAT Gateway handles outbound SNAT — separate from F5

---

## Shared Server Object Structure

A shared server is any host where:
1. `APP_COUNT >= 2` in EHM (multiple APM IDs on one server)
2. `PLATFORM_TYPE = SHARED-SERVER` in EHM (dedicated shared role)
3. `PLATFORM_TYPE = SHARED-PLATFORM` or `SHARED_PLATFORM = Yes` (shared VM/LPAR platform)
4. Same `MEMBER_IP` serves 2+ F5 VIPs (F5-derived detection)

### Complete Object Model (target state)

```
DELIVERY_SHARED_APP_{HOSTNAME}
  ├── SERVER_IP          — MEMBER_IP from F5 pool / IP_ADDRESS from EHM
  ├── APPS               — APP_ACRONYMS (pipe-delimited)
  ├── OBJECT_CLASS       — DELIVERY_SHARED_APP / DELIVERY_EDH / DELIVERY_IIB etc.
  │
  ├── INBOUND_VIPS       — VIP_IP:VIP_PORT:MEMBER_PORT per serving VIP
  │     e.g. 10.217.234.14:443:443     (internal VIP)
  │          204.99.16.71:443:443      (public/internet VIP)
  │          10.217.234.15:8080:8080   (internal VIP, different port)
  │
  └── OUTBOUND
        Pre-SNAT:  SERVER_IP (the MEMBER_IP — what the server originates from)
        Post-SNAT: SNAT_POOL_IP (on-prem F5) or AZURE_NAT_IP (cloud)
        Egress:    INET_SEG_{SITE} (on-prem) or AZURE-PUBLIC-ENDPOINTS (cloud)
```

### OBJECT_CLASS Taxonomy

| Class | Description | Hostname Pattern |
|-------|-------------|-----------------|
| DELIVERY_SHARED_APP | Linux/AIX server hosting 2+ apps | any, APP_COUNT >= 2 |
| DELIVERY_SHARED_PLATFORM | IBM Power LPARs, Aetna VM farm, Azure VMs | mvmp*, SHARED_PLATFORM=Yes |
| DELIVERY_EDH | Aetna Enterprise Data Hub nodes | xmld*, xmle*, xmlh*, xmli* |
| DELIVERY_IIB | IBM Integration Bus nodes | xiib* |
| DELIVERY_ACE | IBM App Connect Enterprise nodes | xace* |
| DELIVERY_WAS | WebSphere Application Server nodes | xwas* |
| DELIVERY_DB | Shared DB2/Oracle database servers | xcir*, xjaz*, xbwl*, xfp8d* etc. |
| DELIVERY_DB_COLO | DB2 servers at colo sites | pac4* |
| DELIVERY_MQ | IBM MQ cluster nodes | xmqcls* |
| DELIVERY_SAP | SAP/IFS application servers | xifsa* |
| DELIVERY_WEB | Aetna web/EDI platform nodes | xiweb* |
| DELIVERY_SHARED_SERVER | CVS Linux multi-app servers (catch-all) | paz1*, rri*, raz1* |

**Note:** `DELIVERY_CONTAINER_HOST` was a CMDB misclassification — IBM Power LPARs and
Azure VMs were tagged `PLATFORM_TYPE=CONTAINER-BRIDGE` due to virtual NIC bridge topology.
These are correctly classified as `DELIVERY_SHARED_PLATFORM`.

---

## Pipeline Position

```
Stage 0: build_f5_vip_registry.py        → F5-VIP-REGISTRY (VIP_IP:PORT → POOL)
         build_f5_datasets.py            → F5-POOL-MEMBERS (POOL → MEMBER_IP:PORT)

Stage 1: preprocess_p1.py               → routes hosts to EHM / delivery_* masters

Stage 2: update_app.py                  → builds ent_host_master with APP_COUNT,
                                          PLATFORM_TYPE, SHARED_PLATFORM fields

Stage 3: build_shared_server_registry.py → detects shared servers from EHM + F5
                                          output: ent-ipdataset-SHARED-SERVER-REGISTRY
                                          *** MUST RUN BEFORE build_canonical_app_objects ***

Stage 4: build_canonical_app_objects.py  → reads registry, excludes shared IPs from
                                          APP_Objects, builds DELIVERY_* objects
                                          *** REGISTRY IS A REQUIRED INPUT ***

Stage 5: build_object_pipeline.py        → network groups + service objects + EDL
```

**Run sequence:**
```bash
python3 build_shared_server_registry.py
python3 ipam-db.py --import ipam-db/ent-ipdataset-SHARED-SERVER-REGISTRY-vDATE.csv \
    --type shared_server_registry
python3 build_canonical_app_objects.py
```

---

## What Is Currently Missing (Gap)

The registry currently captures the server IP and app list but NOT the complete
traffic flow model. The following needs to be added to `build_shared_server_registry.py`:

1. **VIP → port mapping** — join F5-POOL-MEMBERS to F5-VIP-REGISTRY to add
   `INBOUND_VIPS` column: pipe-delimited `VIP_IP:VIP_PORT:MEMBER_PORT` per server

2. **Public vs private VIP classification** — tag each VIP as PUBLIC (internet-facing,
   204.x.x.x or public IP range) or PRIVATE (internal, 10.x.x.x)

3. **Outbound SNAT attribution** — for on-prem: join to FW-SNAT-POOLS;
   for cloud: join to AZURE-PUBLIC-ENDPOINTS / CLOUD-SUBNETS

4. **F5 device attribution** — `F5_HOSTNAME` and `F5_LOCATION` from pool members
   tells you which FW domain the server is in

Until these gaps are filled, the shared server registry is a server inventory with
app attribution — not a complete traffic flow model. WS-10
(generate_fw_consolidation_report.py) requires the complete model.

---

## Firewall Rule Implications

Given a shared server `DELIVERY_SHARED_APP_PAZ1ANSAPL10V` hosting apps A and B:

**You CANNOT write:**
```
src=any  dst=APP_A  port=443  action=allow   ← wrong, IP also serves APP_B
src=any  dst=APP_B  port=8080 action=allow   ← wrong, same IP
```

**You MUST write:**
```
# Inbound via F5 VIP
src=NG-USER-ACCESS  dst=VIP_IP_1:443   action=allow  ← hits APP_A
src=NG-USER-ACCESS  dst=VIP_IP_2:8080  action=allow  ← hits APP_B

# Server-originated outbound
src=DELIVERY_SHARED_APP_PAZ1ANSAPL10V  dst=SVC-AD  port=389  action=allow
src=INET_SEG_SHEA                      dst=internet port=443  action=allow
```

**The VIP is the correct firewall destination for inbound — not the server IP.**
**The server IP is the correct firewall source for outbound — not the VIP.**

---

*CCD Platform | CVS Health Information Security | June 15, 2026*
