# FW Rule Request Tool — Separation from CCD Platform
**Working handoff doc — 2026-07-22**

## Purpose

The FW Rule Request Tool is being peeled off from the CCD Platform as its own tooling effort. This doc captures the scope boundary, current inventory, the interface contract between the two, and the open items being carried forward — so the split has a clear starting reference rather than an implicit one.

**One-line split:** CCD Platform continues to own and produce IPAM and firewall/network data (the source of truth). The FW Rule Request Tool becomes its own effort that *consumes* that data to do one job — object-first PA firewall rule request construction — and owns everything downstream of that consumption.

---

## Why split it out

- The FW Rule Request Tool has outgrown "a script in the CCD Platform folder." It's now a real client-server application: a Flask API (`ccd_api.py`), two SQLite databases it owns and writes to (`ccd_objects.sqlite`, `ccd_groups.sqlite`), its own build/ingest scripts, and a web frontend — none of which follow the CCD Platform's versioning discipline, pipeline stage model, or toolset registration today.
- It solves a different problem than CCD Platform's core mandate (IPAM governance, firewall estate visibility, network group/object generation for the EDL pipeline). CCD Platform tells you *what exists and where*; the FW Rule Request Tool is a human-facing workflow tool for *requesting a new rule* — object-first, replacing the Cisco ACL mental model the PA estate inherited.
- Per the FPMS problem framing this tool exists to address:
  1. The PA estate runs ported Cisco FP policy with Alert-All-SPG on ~98% of rules.
  2. The rule request process itself is built around a Cisco ACL mental model.
  3. Tufin SecureChange/SecureTrack is broken and needs replacing.
- Keeping it inside CCD Platform's toolset model was starting to cause real gaps rather than shared discipline — see "Known Issues Carried Forward" below. Splitting it out lets it get its own versioning, its own toolset registration, and its own review cadence without CCD Platform's pipeline changes accidentally leaving it behind (or vice versa).

---

## Scope boundary

### Stays with CCD Platform (unchanged)
- IPAM datasets: `all_IP_networks`, `location_master`, `ent_host_master`, `ent_network_device_master`, `delivery_infrastructure`, `delivery_platform`, `retail_networks`, `app_subnet_index`, `csna_site_registry`, `placeholder_networks`.
- Firewall estate data: config collection, `fw_rule_db.sqlite`, `fwlookup.py`, network intelligence/topology tooling.
- The Object/EDL pipeline (`build_object_pipeline.py` Stages 0–8): canonical app/user-access objects → network groups → External-NG/Partner-NG → NG report → Cloud Services/Geo-Block objects → service objects → SVC report → EDL catalog → CSNA host groups.
- `build_og_toolset_bundle.py` — the versioned bundler/change-tracker for that Object/EDL pipeline toolset (v1.1.0, in active use).

**CCD Platform's job relative to the FW Rule Request Tool going forward: publish IPAM and FW/network data. Nothing more.**

### Moves to the FW Rule Request Tool (separate effort)
- `ccd_api.py` — Flask backend, 10 endpoints (2 currently wired to the UI: `/api/catalog/picker`, `/api/objects/location`; 8 exist and work but have no UI path yet).
- `ccd_objects.sqlite` / `ccd_objects_local.sqlite`, `ccd_groups.sqlite` / `ccd_groups_local.sqlite`.
- `build_ccd_object_db.py`, `build_ccd_group_db.py`, `build_fw_rule_catalog.py` — ingest CCD Platform's EDL output into the two databases above.
- `query_ccd.py`, `validate_ip.py`, `start_ccd_api.sh`, `stop_ccd_api.sh`.
- Frontend: `fw_rule_request.html`, `fw_rule_requestv5.html`, and `old_fw_rule/` (archived prior versions). **Note:** per the tool's own Next Steps doc, a `fw_rule_request_v6.html` is referenced as the current live, API-integrated frontend — it was not found in the top-level listing of the archive reviewed for this doc and needs to be located (see Open Items).
- `ipam_master/` — a local, point-in-time copy of `all_IP_networks` and `placeholder_networks` used for IPAM validation inside the tool. This is a consumed snapshot, not a source the tool produces.
- Documentation: `FW_Rule_Request_Tool_Next_Steps.md`, `fpms_continuation_prompt.md`, `catalog_build_report.txt`.

---

## Interface contract (the actual seam)

This is the boundary that has to stay stable across the split:

| From CCD Platform | To FW Rule Request Tool | Format |
|---|---|---|
| Net_Group output (NG-*, External-NG, Partner-NG) | Source for network/location objects | EDL `.txt` files + `network_object_catalog_*.csv/.yaml` |
| Net_Object output (SO-*, UA-*, IPDATASET-*) | Source for service/app/user-access objects | EDL `.txt` files + `service_object_catalog_*.csv` |
| `all_IP_networks` (IPAM) | Real-IPAM validation for object creation (`force=true` bypasses this) | CSV, versioned |
| `edl_catalog.html` | Not consumed directly today, but is the human-readable index of the same data | HTML (regenerated in place, not versioned per-snapshot) |

The FW Rule Request Tool's own build scripts (`build_ccd_object_db.py`, `build_ccd_group_db.py`) are the ingestion point — they read the above and populate `ccd_objects.sqlite` / `ccd_groups.sqlite`. As of the last catalog build: **369 NG objects, 477 AO objects, 824 EXT objects**, with 3 flagged for manual review (`INTERNET-FACING`, `P2P-PARTNERS`, `VPN-PARTNERS` — zone/hard-constraint classification needs confirming).

Anything CCD Platform changes about the *shape* of its EDL/IPAM output (new file naming, new columns, new object categories) is now a cross-project compatibility question, not an internal refactor. Worth deciding who owns flagging that.

---

## Known issues carried forward

Pulled directly from `FW_Rule_Request_Tool_Next_Steps.md` (dated 2026-07-17, written from direct code inspection — these are verified, not guesses):

**P0 — fix first**
- `fw_rule_request.html` (the unversioned "canonical" name) has zero API integration. `fw_rule_request_v6.html` is described as the real, live, API-wired tool. Whatever currently references "`fw_rule_request.html`" is pointing at the wrong file. Needs a decision: rename v6 to canonical and archive the stale file explicitly, or adopt real versioning for the HTML frontend matching CCD Platform's discipline (versioned filename + changelog).
- The whole subsystem (`ccd_api.py`, the frontend, `query_ccd.py`, `validate_ip.py`, the two build scripts, the two shell scripts) is invisible to any toolset inventory or version check today — this doc/split is the first step in giving it its own equivalent.

**P1 — real backend capability with no UI**
- Application/Service object creation (`POST /api/objects/application`, `/api/objects/service`) — exists, works, no UI.
- Custom group creation (`POST /api/groups/custom`) — exists, works, no UI.
- Group resolve/validate (`GET /api/groups/<n>/resolve`, `/validate`) — exists, would be a low-effort UI win.
- IP lookup (`GET /api/lookup_ip/<ip>`) — exists, natural fit for a "does this already exist" utility panel.
- Search — **confirmed not a gap.** Client-side filtering already works against the full loaded catalog; don't build a server-side search endpoint unless catalog size becomes the actual bottleneck.

**P2 — integration ideas (design proposals, not started)**
- Cross-check new objects against Partner-IP-Map conflict data at creation time.
- Cross-check against `fw_group_db` for existing device-level address-group membership.
- Show routing/reachability context via `fw_route_db` (`-s`/`-d` path-finding) when creating an Intent-policy rule request — most speculative item, depends on `fw_route_db` coverage completeness.

**P3 — object model gaps**
- No service/port binding schema in `ccd_objects.sqlite` — objects have zone/hard_constraint/PCI but nothing for TCP/UDP service data.
- No Policies DB — an object with an address (and eventually a service) still isn't a *policy* (source, dest, service, action, justification, approver). This tool is the natural place to eventually read/write a real Policies DB once one exists.

**P4 — security/audit posture**
- No authentication anywhere. `ccd_api.py` binds `127.0.0.1` only — that's the actual safeguard today, fine for a single-operator local tool, but an explicit decision (not default-by-omission) is needed if this ever needs multi-user access.
- `force=true` bypasses IPAM validation with no distinct audit trail — a force-created object isn't currently distinguishable from a cleanly-validated one after the fact.

---

## Open items from this review

- **`FW Rule Request.zip`** (61.9 MB, nested inside the reviewed archive) has not been opened. `fw_rule_request_v6.html` may be inside it — needs checking before the naming-collision fix above can actually be executed.
- No versioning discipline currently applied to `ccd_api.py`, the build scripts, or the frontend — first real task for this effort once split is to decide what that looks like (CCD Platform's MAJOR.MINOR.PATCH-in-`__version__` + changelog convention is the obvious default, but the frontend HTML versioning question from P0 needs resolving alongside it).
- No decision yet on where this effort lives going forward (own directory outside `IP_Lookup/`? own repo?) — out of scope for this doc, flagged for next session.

---

## Next session objectives (suggested)

1. Open `FW Rule Request.zip` and resolve the `fw_rule_request.html` / `v6` naming collision (P0 above).
2. Decide and apply a versioning convention for the FW Rule Request Tool's own files, independent of CCD Platform's.
3. Stand up whatever the equivalent of `check_toolset.py` / `build_og_toolset_bundle.py` looks like for this tool's own file set, now that it's explicitly out of CCD Platform's toolset registry.
4. Revisit the P1 UI gaps (App/Service object creation, custom groups, group resolve/validate, IP lookup) and pick one based on actual near-term workflow need.
