# FW_Rule_Request_Tool — Architecture & Usage
**Covers:** the web-server conversion of the firewall rule-request tool — from a static, embedded-JSON HTML file to a live-backed tool talking to a real Flask API and real SQLite databases.

---

## ⚠️ Read this first — a real naming landmine in the current files

Two files exist side by side:

| File | Lines | API-wired? |
|---|---|---|
| `fw_rule_request.html` (unversioned "canonical" name) | 1,004 | **No — zero `fetch()` calls, zero `API_BASE` reference** |
| `fw_rule_request_v6.html` | 1,448 | **Yes — this is the real, live tool** |

The file with the "canonical," unversioned name is the **stale one**. It has no API integration at all — no duplicate-detection panels, no policy-type cards, no catalog-status indicator, none of the features described below. Whoever deploys or serves this tool needs to make sure `fw_rule_request_v6.html` is what's actually in use, not the unversioned file. This is worth fixing at the source (either rename `v6` to the canonical name and retire the stale copy, or make the naming convention unambiguous) rather than something to just remember by hand each time.

Everything below documents `fw_rule_request_v6.html` specifically.

---

## 1. What the conversion actually solved

Before this conversion, the HTML tool embedded its object/group catalog as static JSON constants (`CAT`, `APP_OBJECTS`, `SVC_OBJECTS`) baked directly into the page — a snapshot, frozen at whatever moment someone last regenerated the file. Any object created "through" the tool went nowhere real; there was no persistence.

`ccd_api.py`'s own docstring states the problem precisely:

> *"This is what closes the 'no persistence' gap: objects created through the tool now write to `ccd_objects.sqlite` / `ccd_groups.sqlite` for real, with the same validation (IPAM check, ownership gate, criticality requirement) as the CLI paths in `build_ccd_object_db.py` — because this module imports and calls those same functions rather than reimplementing them."*

That last clause matters: the API doesn't reimplement validation logic — it directly calls the same `build_ccd_object_db.py`/`build_ccd_group_db.py` functions the CLI tools use. There's one validation path, not two that could drift apart.

---

## 2. Architecture

```
┌─────────────────────────┐         ┌──────────────────┐         ┌────────────────────────┐
│ fw_rule_request_v6.html │  fetch  │   ccd_api.py      │  calls  │ build_ccd_object_db.py │
│ (browser, file:// or    │────────>│  Flask, port 5000 │────────>│ build_ccd_group_db.py  │
│  served separately)     │<────────│  127.0.0.1 only   │<────────│ query_ccd.py           │
└─────────────────────────┘  JSON   └──────────────────┘         │ validate_ip.py         │
                                              │                    └────────────────────────┘
                                              ▼
                                    ┌──────────────────────┐
                                    │ ccd_objects.sqlite    │
                                    │ ccd_groups.sqlite      │
                                    │ (real persistence)     │
                                    └──────────────────────┘
```

**Local-only by design.** `ccd_api.py` binds `127.0.0.1:5000` explicitly and its own startup message says so directly: *"This serves localhost only. Do not expose this port outside the host machine."* CORS is wide open (`Access-Control-Allow-Origin: *`) specifically because the HTML file may be opened via `file://` (a null origin) rather than served — that's a deliberate choice for a same-host tool, not something to carry over if this were ever exposed beyond localhost.

---

## 3. Running it

```
./start_ccd_api.sh
```

What it actually does, in order:
1. Checks for an existing PID file (`.ccd_api.pid`) — refuses to start a second instance if one's already running; cleans up a stale PID file if the process is gone.
2. Checks port 5000 directly via `lsof`, in case something's listening without a matching PID file.
3. **Preflight** — refuses to start unless all of these exist in the same directory: `ccd_api.py`, `query_ccd.py`, `validate_ip.py`, `build_ccd_object_db.py`, `build_ccd_group_db.py`, `ccd_objects.sqlite`, `ccd_groups.sqlite`.
4. Uses `./venv/bin/python3` if a venv directory exists, else falls back to bare `python3`; checks Flask is actually importable before proceeding, with the exact install command printed if not.
5. Starts the process with `nohup`, backgrounded, logging to `ccd_api.log`.
6. Waits 2 seconds, confirms the process didn't die immediately (prints the last 20 log lines if it did).
7. Curls `/api/health` and confirms a `200` before declaring success.

```
./stop_ccd_api.sh
```
PID-file-based; SIGTERM first, waits up to 5 seconds, escalates to SIGKILL if needed. Falls back to finding whatever's listening on port 5000 by `lsof` if the PID file is missing, and asks for confirmation before killing an untracked process.

**Environment variable overrides** (all optional, real defaults shown):
```
CCD_OBJECTS_DB=ccd_objects.sqlite
CCD_GROUPS_DB=ccd_groups.sqlite
CCD_IPAM_PATH=ipam_master/all_IP_networks_v20260611r58.csv
CCD_PLACEHOLDER_PATH=ipam_master/placeholder_networks_v20260605.csv
CCD_FW_RULE_DB=db/fw_rule_db.sqlite
```

---

## 4. Full API reference

All 10 real endpoints, straight from `ccd_api.py`. **Only 2 are currently called by the frontend** — see §5 for exactly which, and what the other 8 are for.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/health` | `{"status":"ok","objects":N,"groups":N}` — live counts from the actual DB, not cached |
| `GET` | `/api/search?q=<term>&limit=15` | Free-text search across objects and groups |
| `GET` | `/api/catalog/picker?policy_type=INTENT\|APP2APP\|USER2APP&side=src\|dst` | The object picker — see §4.1 |
| `GET` | `/api/groups/<name>/resolve` | Expands a group to its real CIDRs and leaf objects |
| `GET` | `/api/groups/<name>/validate` | Group-level validation check |
| `GET` | `/api/lookup_ip/<ip>` | Reverse lookup — what object(s) contain this IP |
| `POST` | `/api/objects/application` | Create an Application-class object (`{name, owner, criticality, pci_scope, heritage, routing_domain, app_acronym}`) |
| `POST` | `/api/objects/service` | Create a Service-class object (`{name, category, owner, parent_group}`) |
| `POST` | `/api/objects/location` | Create a Location/network object — the one the current UI actually uses (`{name, workload_class, owner, cidrs, force}`) |
| `POST` | `/api/groups/custom` | Create a custom group (`{name, owner, members}`) |

### 4.1 `/api/catalog/picker` — the core read endpoint

This replaced the embedded `CAT`/`APP_OBJECTS`/`SVC_OBJECTS` JSON constants directly — same role, live instead of frozen.

- **`policy_type=INTENT&side=src`** → objects where `workload_class='APP'`
- **`policy_type=INTENT&side=dst`** → objects where `workload_class IN ('SERVICE','INFRA','DELIVERY','CPC','VPN')`
- **`policy_type=APP2APP`** (or `USER2APP`) → everything *except* `APP`/`SVC` zone objects, each annotated with its live member count (`SELECT COUNT(*) FROM object_members ... WHERE removed_date IS NULL`)

All three only return `status='ACTIVE'` objects.

### 4.2 `/api/objects/location` — the create endpoint, with real server-side validation

This is where "closes the no-persistence gap" actually happens end to end:

1. Loads the real IPAM CSV, placeholder-networks CSV, and public-range data fresh on every call (`validate_ip.load_ipam()`, etc. — not cached at startup, so it reflects the current files on disk).
2. Validates every submitted CIDR against all three sources plus the FW rule DB.
3. If any CIDR fails validation and `force` wasn't set, returns **HTTP 400** with the specific blocking reasons per CIDR — the object is *not* created.
4. If `force=true` was passed, or nothing blocked, calls `build_ccd_object_db.py`'s real `add_location_object()` — the same function the CLI path uses.

### 4.3 Endpoints not currently called by the frontend

`/api/health` (only used manually via `curl` for the startup check, not called by the page itself), `/api/search`, `/api/groups/<name>/resolve`, `/api/groups/<name>/validate`, `/api/lookup_ip/<ip>`, `/api/objects/application`, `/api/objects/service`, `/api/groups/custom` all exist, work, and follow the same real-validation pattern — they're just not wired into any UI element in `fw_rule_request_v6.html` yet. Available for other tooling to call directly, or as the natural next additions to the frontend if application/service/custom-group creation ever needs a UI path the way location-object creation already has one.

---

## 5. Frontend integration — exactly what's wired in

Confirmed directly from the only `API_BASE` references that exist in the file (grep, not assumption):

**On page load**, `loadCatalogs()` fires three parallel requests:
```javascript
const [app2app, intentSrc, intentDst] = await Promise.all([
  fetch(`${API_BASE}/api/catalog/picker?policy_type=APP2APP`).then(r => r.json()),
  fetch(`${API_BASE}/api/catalog/picker?policy_type=INTENT&side=src`).then(r => r.json()),
  fetch(`${API_BASE}/api/catalog/picker?policy_type=INTENT&side=dst`).then(r => r.json()),
]);
```
populating `CAT_FLAT` (App-to-App / User-to-App picker), `APP_OBJECTS` (Intent-policy source picker), `SVC_OBJECTS` (Intent-policy destination picker). A status line shows live counts on success (`"Live: N NG/AO/EXT, N Application, N Service objects (ccd_api.py)"`) or a clear, actionable error if the backend isn't reachable (*"Run `python3 ccd_api.py` in the CCD Platform folder, then reload this page"*).

**On new-object submission**, client-side checks run first — name required, owner required (*"the backend will refuse creation without one"*, telling the user up front rather than letting the server reject it), at least one CIDR, CIDR syntax regex, and a duplicate-name check against the already-loaded catalog — before the request ever reaches the server. Only after those pass does it POST to `/api/objects/location`. A failed server-side validation surfaces the real per-CIDR blocking reasons in an alert (*"Refused by backend (real IPAM check, not just syntax)"*), distinguishing a real IPAM rejection from a client-side syntax problem.

**Everything else in the tool** — the policy-type cards, duplicate-match panels, zone badges — is UI/display logic built on top of the catalog data fetched above; it doesn't make additional server calls of its own.

---

## 6. Required files, all in one directory

For `start_ccd_api.sh`'s preflight to pass and the tool to actually work end to end:

```
ccd_api.py
query_ccd.py
validate_ip.py
build_ccd_object_db.py
build_ccd_group_db.py
ccd_objects.sqlite
ccd_groups.sqlite
fw_rule_request_v6.html   ← NOT fw_rule_request.html, see warning at top
start_ccd_api.sh
stop_ccd_api.sh
```

Plus, referenced via environment variables (§3), the IPAM CSVs and `fw_rule_db.sqlite` — the latter of which is the same database `fwlookup.py` queries (see the separate `FW_Database_Set_Usage_Reference.md`), giving `ccd_api.py`'s validation path visibility into real, current rule data during CIDR validation.
