---
name: ipam-patch-safety
description: >
  Non-negotiable discipline for any ipam-db.py --update-patch, --apply-patch,
  or --remove-patch operation that changes existing rows (not pure net-new
  additions). Use this skill whenever modifying a field on existing
  all_IP_networks, location_master, retail_networks, or mgmt_ip_index rows --
  e.g. correcting a NET_TYPE, LOCATION_TYPE, CANONICAL_LOCATION, or STATUS
  value. Trigger on: "fix this NET_TYPE", "correct the LOCATION_TYPE",
  "update these existing rows", "patch IPAM", "modify existing SITE_CODE/CIDR
  entries", or any request to change data that already exists in a
  registered IPAM dataset. Do NOT bundle a REMOVE and its corresponding ADD
  into a single patch file or a single import -- this skill exists
  specifically to prevent that mistake. Also covers a required-but-easy-to-
  skip detail: REMOVE rows must carry complete field data (every column,
  not just the CIDR key) so the patch file itself remains a usable audit
  record -- see "REMOVE rows need complete field data" below.
---

# IPAM Patch Safety: One Restorable Step at a Time

## The rule

**Every ipam-db.py patch operation that changes existing data must be split into
separate, independently-registered steps.** Never combine a REMOVE and its
corresponding ADD into one patch file, and never batch a REMOVE+ADD pair into
one `--update-patch` invocation followed by one `--import`, even though the
tool technically supports a `PATCH_ACTION` column that allows this in a single
file.

## Why this matters (not just a style preference)

`ipam-db.py --restore <STEM>` rolls back to the **most recently registered prior
version** of a dataset. Registration happens at `--import` time. This means the
restore granularity is exactly as fine as the number of separate imports you
did.

- **Two separate imports** (REMOVE registered, then ADD registered) gives you
  two restore points. If the ADD step turns out wrong, `--restore
  all_IP_networks` cleanly returns you to the state right after the REMOVE —
  the correction is undone, the removal stands, nothing else is touched.
- **One combined REMOVE+ADD import** gives you exactly one restore point. If
  anything about the combined change is wrong, the only rollback available is
  the *entire* combined operation — you cannot separate "undo the correction"
  from "undo the removal," because from the registry's point of view they were
  one atomic change.

Cross-check (`--cross-check`, which also runs automatically after every
`--import` of a managed stem) is the other reason to separate the steps: it
gives you a genuine checkpoint to verify the REMOVE landed clean *before* the
ADD goes in, rather than discovering a problem only after both changes are
already bundled together.

## The correct workflow

For any correction to existing rows (e.g. fixing a wrong `NET_TYPE`):

1. Build a patch CSV containing **only the REMOVE rows** (`PATCH_ACTION=REMOVE`,
   matching the exact CIDR/SITE_CODE of the rows being corrected).
2. `ipam-db.py --update-patch <remove_patch.csv>`
3. `ipam-db.py --import <resulting_versioned_file>` — this registers the
   removal as its own restore point.
4. `ipam-db.py --cross-check` — confirm the removal didn't introduce new
   violations (e.g. orphaned children, broken LPM parents) before proceeding.
5. Build a **separate** patch CSV containing only the ADD rows
   (`PATCH_ACTION=ADD`, same CIDRs, corrected field values).
6. `ipam-db.py --update-patch <add_patch.csv>`
7. `ipam-db.py --import <resulting_versioned_file>` — registers the correction
   as its own, independent restore point.
8. `ipam-db.py --cross-check` — confirm the correction is clean.

This is more commands than doing it in one shot. That's the point — each
command is a checkpoint, not overhead to be optimized away.

## REMOVE rows need complete field data, not just the key

A `PATCH_ACTION=REMOVE` row must carry the row's **full current values across
every column** — CIDR, SITE_CODE, CANONICAL_LOCATION, SOURCE, everything —
not just the CIDR plus `PATCH_ACTION=REMOVE` with the rest blank. The
underlying `--update-patch` code only technically *needs* the CIDR to know
which row to exclude, so a bare-key REMOVE row will pass validation and run
— but passing validation is not the bar here.

**Why this matters:** `--restore` rolls back via whole-file snapshots
registered at `--import` time (`_txn_log` records `file_before`/
`sha256_before` at the file level, not per-row). That means the patch file
itself — not the registry, not the diff — is the only human-readable record
of exactly what was removed and why, at the moment it was removed. A bare
`10.102.9.0/24,REMOVE` line with 19 blank columns tells a future reader
(including a future instance of yourself) nothing. A complete line — every
field populated with the value that was actually in the row at removal time
— makes the patch file self-documenting: reviewable on its own, without
needing to cross-reference the exact prior version of all_IP_networks to
know what was there.

Pull the row's real current values before building the REMOVE patch — don't
leave columns blank because the tool doesn't strictly require them.

## What NOT to do

- Do not build a REMOVE row with only CIDR and PATCH_ACTION populated and
  every other column left blank. The tool will accept it, but the patch
  file stops being a usable audit record of what was actually removed —
  fill in the row's real current values for every column.
- Do not build one patch CSV with both `PATCH_ACTION=REMOVE` and
  `PATCH_ACTION=ADD` rows for the same correction, even though the
  underlying `--update-patch` code accepts this in a single file.
- Do not skip the `--import` + `--cross-check` step between REMOVE and ADD "to
  save time" — the intermediate registered state is the entire value of doing
  this in two steps.
- Do not reach for an external/ad-hoc script (e.g. hand-rolling a "stripped
  baseline file" plus a separate add-only tool) when `ipam-db.py
  --update-patch` already does this natively, with proper versioning,
  archiving, and audit. Use the platform's own patch mechanism, not a
  workaround built around it.

## Applies beyond all_IP_networks

The same discipline applies to `--type location_master` patches
(`_do_update_patch_lm`) and any other managed stem: separate the destructive
half from the corrective half, register each independently, cross-check
between them.

## EGR_* ROUTING_DOMAIN propagation patch pattern (confirmed 2026-08-21)

For bulk ROUTING_DOMAIN updates (Internet-Facing or Internal-* → EGR_*-TC or -TI):

**Always two separate patch files:**
- `remove_egress_{fw}_{batch}.csv` — PATCH_ACTION=REMOVE rows
- `add_egress_{fw}_{batch}.csv` — same rows with new ROUTING_DOMAIN

**Orphan-risk screen BEFORE building patches:**
For each candidate CIDR: check children, confirm 0 orphans (children have own covering block).
Held rows (orphan risk) go into a separate `held_*.csv` — never force-apply them.

**Run order:**
1. `ipam-db.py --update-patch remove_*.csv --dry-run` — verify 0 errors
2. `ipam-db.py --update-patch remove_*.csv` — apply REMOVE
3. `ipam-db.py --import all_IP_networks_vDATE_rN.csv --type all_IP_networks`
4. `ipam-db.py --update-patch add_*.csv --dry-run` — verify 0 errors
5. `ipam-db.py --update-patch add_*.csv` — apply ADD
6. `ipam-db.py --import all_IP_networks_vDATE_rN+1.csv --type all_IP_networks`
7. `ipam-db.py --cross-check` — must show 0 HIGH before proceeding

**CX11 exemption:** EGR_*-TC and EGR_*-TI satisfy CX11-INTERNET-FACING.
Do NOT revert EGR_* rows back to Internet-Facing.

**Blank SITE_CODE in ADD patches:** Pre-flight will fail if SITE_CODE is blank.
Derive from CANONICAL_LOCATION via the LM SITE_CODE column before building the patch.
`US_WOR_RI_DC` = Woonsocket RI One; check LM for all others.

**Scale reference from 2026-08-21 session:**
- 6,525 rows propagated across 10 firewalls in ~8 batches
- 102 rows held for orphan risk (children needed their own EGR_* codes first)
- CX11 batch corrections: 204.99.110.x (3 rows), 198.187.114.x (2 rows),
  204.99.3.x (1 row), others
