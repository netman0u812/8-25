---
name: ccd-fw-pipeline
description: CCD Platform FW toolset build order, dependency graph, and orchestration signal for CVS Health Information Security. Use whenever asked about running, ordering, automating, or debugging the firewall pipeline (setup_fw_configs.sh through collect_fw_bundle.sh) -- e.g. "what order do I run the FW scripts", "what needs to run after X", "do I need to rebuild Y", "is this pipeline step gated correctly", or writing/modifying an FW pipeline orchestrator. Also trigger when debugging why a downstream FW script (route_db, group_db, rule_db, interface_inventory, location_topology, topology_report, vpn_registry, ftd_p2p_registry, snat_pools, app_egress_topology) has stale, missing, or duplicated data -- root cause is often a build-order/dependency issue, not a bug in that script. Check this before proposing a new run order, gating mechanism, or orchestrator -- don't reconstruct the dependency graph from memory, the tiers and known gaps below are confirmed against real runs. Also trigger on: "build_fw_location_topology", "fw_location_topology", "FW_ROLE", "PCI-ENFORCEMENT", "VPN-EDGE", "B2B-EDGE", "EGR_CODE", "ADJACENT_EGR_CODE", "egress_fw_mgmt_ips", "cvs_pci_fw_mgmt_ips", "four FW tier registries".
---

# CCD FW Pipeline

Build-order dependency graph for the CCD Platform's firewall (FW) toolset. This is CVS Health Information Security's pipeline for turning raw collected firewall configs into queryable topology, route, rule, and group databases.

**Read this before proposing any run order, orchestrator script, or gating logic for the FW toolset.** The tier structure below reflects what has actually been confirmed by tracing real script code and real production runs (not assumed from filenames) — see "Confirmed vs. inferred" per tier.

## The pipeline at a glance

```
Tier 0   setup_fw_configs.sh
           │
           ▼
Tier 1   build_fw_config_manifest.py  ──►  fw_pipeline_signals.json
           │                                (needs_interface_inventory,
           │                                 needs_location_topology)
           ▼
Tier 2   build_fw_interface_inventory.py
           │
           ▼
         build_fw_location_topology.py  v2.0.4
           │  (consumes: egress_fw_mgmt_ips, cvs_pci_fw_mgmt_ips,
           │   vpn_fw_mgmt_ips [optional], b2b_fw_mgmt_ips [optional],
           │   all_IP_networks, fw_interface_inventory)
           │
           ▼
         build_fw_topology_report.py  v1.3.0
           │  (new tabs: PCI Enforcement, VPN/B2B)
           │
           ▼
         build_app_egress_topology.py  v1.5.0
           │  (post-FW-pipeline, post-IPAM — standalone, not gated by
           │   Tier 1 signal; run after both pipelines are current)
           │  outputs: egress_topology_registry, app_egress_topology,
           │           ip_resolution_index → ipam-db.py --import each

Tier 3   build_fw_route_db.py         ┐
         build_fw_group_db.py         │  independent of each other,
         build_ftd_p2p_registry.py    │  NOT currently gated by the
         build_fw_snat_pools.py       │  Tier 1 signal -- always run
         build_fw_rule_db.py          ┘  in full (see Known Gaps)

Tier 4   build_vpn_registry.py --dry-run  →  build_vpn_registry.py
         (self-caching by checksum, safe/cheap to run every time)

Tier 5   collect_fw_bundle.sh  v2.7.0
         (packages whatever is on disk -- always last)

Tier 6   scan_ip_datasets_all.py / build_fw_accounting.py / cross_reference_missing.py
         (read-only coverage audit -- run any time, not part of the build chain)

Validation: check_toolset.py  (run any time, ideally after a full cycle)
```

## Tier 0 — Estate refresh (always first)

`setup_fw_configs.sh` populates `IP_Datasets_Raw/FW_CONFIGS/{ASA,FTD,PA}/` and `FW_POLICIES/` from the raw zip drops in `IP_Datasets_Raw/`. Every other script in the pipeline reads from what this produces — nothing downstream should ever run against a stale or partial estate.

Key behaviors to know:
- Classification into ASA/FTD/PA is done by `classify_config()` — filename-pattern-first, with a content-sniffing fallback (added v2.3.0) for files that don't match any filename pattern. See "Known gaps" below for what this does and doesn't catch.
- `--reset` wipes and fully re-extracts `FW_CONFIGS/{ASA,FTD,PA}/` from scratch. **Use `--reset` after any change to `classify_config()`'s logic** — a normal (non-reset) run never deletes files, so previously-misclassified copies persist alongside newly-correct ones until a reset cleans them out.
- Its own printed "Next steps" defers to Tier 1's signal rather than guessing (see below) — do not have it try to predict whether downstream steps are needed, since it runs before the manifest and cannot know.
- **v2.10.0+ adds an ASA/FTD device identity registration sweep** (`asa_ftd_identity.py --register`, once per real file, run automatically after all ASA/FTD ingestion paths finish) — confirmed real and working in production: 1,047 real files registered, 118 real hostname collisions surfaced in a single run. **v2.11.0+ also auto-runs `asa_ftd_identity.py --resolve` immediately afterward** — closes an earlier real gap (registration alone left `merged_id` data absent until a separate manual step). No manual intervention needed between Tier 0 and Tier 3 for this anymore.

## Tier 1 — Manifest & orchestration signal (always second)

`build_fw_config_manifest.py` reads the fresh estate and produces:
- `ipam-db/fw_config_manifest_v<date>.csv` — the manifest itself (NEW/CHANGED/UNCHANGED/DROPPED per file)
- `ipam-db/fw_hostname_inventory_v<date>.html` — hostname mismatch/missing report
- `FW_Setup_Log/fw_checksum_history.json` — the running checksum history used to detect changes
- `FW_Setup_Log/fw_pipeline_signals.json` — **the definitive orchestration signal** (v2.6.0+)

The signal file is the mechanism to key off of for automation:
```json
{
  "new_count": 2, "changed_count": 0, "unchanged_count": 1150,
  "dropped_count": 0, "reconciled_count": 1, "actionable_count": 2,
  "needs_interface_inventory": true, "needs_location_topology": true
}
```
`actionable_count` = NEW + CHANGED (a brand-new device's interfaces/topology are just as absent downstream as a changed device's are stale — both are actionable, UNCHANGED and DROPPED are not).

**DROPPED reconciliation (v2.5.0+):** before flagging a device as dropped, this script checks whether the same `fw_name` still appears elsewhere in the current run's staged files (e.g. after a `classify_config()` reclassification moved it to a different bucket). If found, it's counted as `reconciled`, not `dropped` — a real DROPPED means the device's config is genuinely gone from disk, not just relocated.

## Tier 2 — Interface & topology (gated by the Tier 1 signal)

Run only when `needs_interface_inventory` / `needs_location_topology` are `true`:

1. `build_fw_interface_inventory.py` — v1.9.1+ (2026-08-05) has cross-file device-level dedup
   (`FW_NAME`+`INTERFACE`+`IP_ADDRESS` keyed), confirmed real and needed: the same physical
   device can be independently resolved and expanded from more than one bulk Panorama export
   (e.g. a device present in both `MID-PAN-PROD-01` and `WIN-PAN-PROD-01`'s device-group scope),
   producing exact duplicate interface rows that the file-level `by_device` dedup (keyed by
   filename stem) has no visibility into. Confirmed on a real run: 283 → 193 total interfaces,
   90 genuine cross-file duplicates dropped. Also inherits `pa_config_parser.py` v1.2.2's
   `extract_interfaces()` fix (a real, separate, three-nesting-level bug in the shared parser
   itself — interface TYPE labels/`units` VLAN sub-interface wrappers were being returned as if
   they were real interface names) — confirmed on the same real dataset: 6 → 147 total interfaces
   across a 46-device test set, all 46 devices getting real data instead of only 6.
2. `build_fw_location_topology.py` **v2.0.4** — major rewrite from v1.x. Now consumes four
   FW tier registries (all auto-discovered from `ipam-db/`, all same schema):
   - `egress_fw_mgmt_ips_v*.csv` — internet egress FWs (38 FWs, 17 clusters) — **required**
   - `cvs_pci_fw_mgmt_ips_v*.csv` — CVS PBM PCI zone enforcement FWs (22 FWs, 8 clusters)
   - `vpn_fw_mgmt_ips_v*.csv` — MPLS/NET4 VPN partner ASAs (optional, not yet built)
   - `b2b_fw_mgmt_ips_v*.csv` — Equinix B2B circuit FWs (optional, not yet built)

   Also consumes `all_IP_networks` for IPAM LPM enrichment of routing domains.

   **New FW_ROLE values:** `PCI-ENFORCEMENT`, `VPN-EDGE`, `B2B-EDGE` (in addition to existing
   `INTERNET-EDGE`, `CLOUD-EDGE`, `RETAIL-SDWAN-HUB`, `MPLS-EDGE`, `INTERNAL`, `MGMT`).

   **New output columns:** `EGR_CODE`, `EGRESS_LOGICAL`, `MGMT_PLANE`, `ADJACENT_EGR_CODE`,
   `FW_TIER`, `ROUTING_FABRIC`, `PARTNER_NAMES`.

   **`ADJACENT_EGR_CODE`** — for non-egress FWs, which egress cluster their traffic exits through.
   Derived from registry when present, otherwise from hostname pattern + CANONICAL_LOCATION:
   ```
   PAZSHDC-*/MPLSWEST-*  → EGR_SHEAW
   RRICMCP-*/MPLSEAST-*  → EGR_RI1
   B2B/Equinix FWs       → EGR_SHEAE
   GCP PCI FWs           → EGR_CMEP
   PCI at Shea           → EGR_SHEAW
   PCI at RI/HOL/PIH/SA  → EGR_RI1
   ```

   **Hard guard:** refuses to write to `ipam-db/` directly — output goes to `IP_Lookup/` root,
   then registered via `ipam-db.py --import fw_location_topology_vDATE.csv --type fw_location_topology`.

   **FW_ROLE fix (v1.3.1, retained):** `EGR_*` routing domain alone does NOT qualify a FW as
   `INTERNET-EDGE` — PCI CDE enforcement FWs have `EGR_*` routing domains because their
   management IPs sit in egress subnets, not because they carry internet egress traffic.
   `inet_cidrs` (confirmed public CIDRs) must be non-empty. Aetna PCI FWs correctly stay
   `INTERNET-EDGE` (have real 167.69.x `inet_cidrs`); CVS PBM PCI FWs correctly become
   `PCI-ENFORCEMENT` (empty `inet_cidrs`).

3. `build_fw_topology_report.py` **v1.3.0** — renders `fw_location_topology.csv` as HTML.
   New tabs: **PCI Enforcement** (rose), **VPN/B2B** (orange/fuchsia). New role colors for
   all new FW_ROLE values.

4. `build_app_egress_topology.py` **v1.5.0** — standalone, runs AFTER both FW pipeline and
   IPAM pipeline are current. Not gated by Tier 1 signal. Produces three datasets:
   - `egress_topology_registry_vDATE.csv` — 17 EGR_CODEs, cluster master map
   - `app_egress_topology_vDATE.csv` — 9,114 rows, CIDR_24 × EGR_CODE
   - `ip_resolution_index_vDATE.csv` — 96,078 rows, any IP → full egress context

   All three registered via `ipam-db.py --import ... --type <stem>`.

**Confirmed vs. inferred:** the *order* (interface inventory before location topology) matches every real run's "Next steps" text and has never been seen run the other way — treat it as the correct order. `build_fw_location_topology.py` v2.0.4 reads `ent-ipdataset-FW-INTERFACE-INVENTORY-v*.csv` directly from `ipam-db/` — this IS a hard data dependency, confirmed by tracing the code.

## Tier 3 — Independent config-derived databases

Each of these parses `FW_CONFIGS/`/`FW_POLICIES/` directly and does not consume another Tier 3 script's output, so they can run in any order or in parallel:

- `build_fw_route_db.py` — interfaces + routes, PA/ASA/FTD. v0.4.0+ has device-level dedup (newest-by-mtime wins on duplicate timestamped configs) and a full-rebuild-per-run table clear (fixes a same-day-rerun crash).
- `build_fw_group_db.py` — address objects/groups, PA/ASA/FTD. v0.2.3+ has `is_pa_config()` parity with route_db (catches PA files whose merged config has `static-route {` but no `address {`). **v0.8.0+ adds a real, second, new cross-tier dependency**: after building its own tables, it separately populates a new `fw_device_identity` table (device, fw_id, merged_id, hostname) by reading Tier 0's identity registry (`asa_ftd_identity.py`'s `--register`/`--resolve` output) — purely additive, zero changes to any existing table, and a graceful no-op if the registry isn't present. `merged_id` is only ever populated for the registry's `LIKELY_DUPLICATE_SPELLING` collision category specifically (see below) — never for genuinely distinct hardware.
- `build_ftd_p2p_registry.py` — P2P/MPLS partner circuit registry.
- `build_fw_snat_pools.py` — CVS-owned SNAT pool extraction.
- `build_fw_rule_db.py` — the unified rule database backing `fwlookup.py`. Has one confirmed **real** cross-tier dependency: its `ip_context` enrichment step loads `build_fw_interface_inventory.py`'s (Tier 2) output to resolve management IPs to location/heritage (per its own v1.4.0 GAP-10 changelog). Core rule extraction works without Tier 2 having run first, but enrichment quality is degraded until it has.
  - **v1.21.0 (2026-08-22) adds FMC REST API JSON parser** (`parse_fmc_acp_json`) — reads `*_acp.json` files alongside the existing CSV parser in step [4/5]. Format is FMC iControlREST accessrules export. Handles both `objects` (named network groups) and `literals` (raw IP/CIDR) in source/destination fields. Tested against 6 real production files (GCP-SecureHub_PROD, AWS-DR-Egress/Ingress, GCP-RxCon-Prod, GCP-CaaS-PCI, AWS-Egress) — 1,021 rules confirmed parsed correctly. Known Gap 4 below is now resolved.
  - v1.7.0+ adds `parse_pa_cli_flat_policy()` — a second PA parser for the flat `show running security-policy` CLI format (no wrapping `rules {` container), used as a fallback only when the nested-brace parser finds zero rules. Real devices exist where the nested form is genuinely empty (Panorama-managed, no locally-stored rulebase) but the flat form has hundreds of real rules.
  - v1.7.1+ adds device-level dedup to the PA loop specifically (same newest-by-mtime pattern as route_db). **The ASA and FTD loops do NOT have this dedup yet** — see Known Gaps.
  - v1.19.2+ adds the same `fw_device_identity` cross-tier dependency as `build_fw_group_db.py` v0.8.0 above — same table shape, same Tier 0 dependency, same additive/graceful-no-op behavior. **A real, confirmed subtlety specific to this script**: the lookup key used for the identity-registry join is deliberately the *raw filename*, resolved through the registry's own `device_key_from_filename()` — not this script's own internal `device_key`/`fw_name`, which can be transformed by the NET4WIR/MPLEAST multi-context naming special-case (e.g. `fw_name` becomes `'MPLEAST/omnicare'`). Using the internal, transformed key here silently produced zero identity matches on real production data before this was traced and fixed — if this cross-tier join ever regresses to reading the internal key again, expect the same silent failure.

### ASA/FTD device identity registry (`asa_ftd_identity.py`) — real classification detail Tier 3 depends on

`asa_ftd_identity.py --register` assigns a stable `FWID_NNNNNN` per real device_key (filename-derived) and records every real hostname collision (multiple device_keys sharing one real in-config hostname) without ever auto-resolving them. `--resolve` then classifies each real collision into one of four categories and assigns a shared `merged_id` **only** for the one category confirmed safe to treat as probably-the-same-device:

- `HA_PAIR` — genuinely distinct hardware (real, unambiguous suffix words: `xaact`/`xastby`/`-primary`/`-secondary`/`-fo`) — never merged.
- `NUMERIC_SUFFIX_AMBIGUOUS` — a trailing-digit-only difference (e.g. `win-fw-equinix-ftd-1-1` vs `...-1-2`). **Deliberately never merged, on purpose, not by omission**: this exact pattern is the real device group that caused a severe production regression (251,418 real rules silently dropped) when an earlier attempt used hostname as a merge key directly. A classifier bug that nearly repeated this same mistake was caught and fixed before shipping — see the script's own v1.1.0 changelog for the full account.
- `LIKELY_DUPLICATE_SPELLING` — high textual similarity not explained by the two patterns above (e.g. `pazshdc-sec-ext-aet-01` vs `pazshdc-sec-exxt-aet-01`, a one-character typo). **This is the only category that ever receives a `merged_id`.**
- `SHARED_GENERIC_LABEL` — structurally unrelated devices reusing a generic partner-context name (e.g. `omnicare` shared across otherwise-unrelated device families) — never merged.

Confirmed real scale from a full production run (2026-08-07): 709 real distinct device_keys, 118 real hostname collisions — 43 `HA_PAIR`, 18 `NUMERIC_SUFFIX_AMBIGUOUS`, 56 `LIKELY_DUPLICATE_SPELLING` (135 real device_keys received a `merged_id`), 1 `SHARED_GENERIC_LABEL`.

## Tier 4 — VPN registry

`build_vpn_registry.py --dry-run` then `build_vpn_registry.py`. Self-caching by checksum — safe and cheap to run every time regardless of the Tier 1 signal, no need to gate it.

## Tier 5 — Distribution (always last)

`collect_fw_bundle.sh` packages whatever is currently on disk: the raw estate (`FW_CONFIGS/`, `FW_POLICIES/`, required) plus whichever Tier 2/3/4 build artifacts exist (all optional/non-fatal, resolved by latest-mtime glob). Run this after a full pipeline cycle, not mid-cycle, or the bundle will contain stale artifacts from before the refresh.

## Tier 6 — Coverage & completeness audit (run any time, ideally after a full Tier 0-5 cycle; NOT part of the build chain itself)

These are read-only audit tools, not build steps — nothing downstream depends on their output the way Tier 3 depends on Tier 0/2. They exist to answer a different, real question the rest of this pipeline was never built to answer: **does what we have actually reflect what exists?** Every Tier 0-5 script above only ever processes files that are already sitting in `FW_CONFIGS/` — none of them can tell you about a real device that was never captured into that directory in the first place.

- `scan_ip_datasets_all.py` — recursively scans a raw root directory (not just `FW_CONFIGS/`) for every real config file, regardless of current classification or location, including inside `.zip` archives (real, established input format for this estate — matches Tier 0's own baseline/PCI/`FW_CONF_UPDATES` zip handling). Uses the identical, already-tested `classify_config()` logic Tier 0 itself uses, so its findings never disagree with what `setup_fw_configs.sh` would decide. **Two real fixes worth knowing before trusting its output**: v1.2.0 excludes `__MACOSX`/`._`-prefixed macOS zip artifacts (confirmed the dominant source of false "missing" hits in a real production run — thousands of `device_key='.'` noise rows before the fix); F5 load balancer and L3 switch configs still misclassify as ASA (no F5/switch-aware detection exists yet in `classify_config()`, inherited from Tier 0 — a real, open gap, not fixed by this tool).
- `build_fw_accounting.py` — the real, three-way cross-reference: an authoritative external device inventory (see below) vs. what's actually present in `FW_CONFIGS/` vs. what's been identity-registered (Tier 0's `asa_ftd_identity.py` registry). Auto-detects two real authoritative-inventory formats: the original CDO/FMC/Panorama export (~479 real devices, 6% with Excel-scientific-notation-corrupted serials — all showing the identical fake value, confirmed not independently corrupted per-device) and a richer CMDB-style device export (~1,522 real firewall rows once filtered from a ~53,000-row full estate dump) with a real, working `Status` (Online/Offline) field the original export doesn't have. Also classifies every device's real `FW_TYPE` against CVS Network Security's own authoritative naming taxonomy, preserving genuine overlaps in that taxonomy (e.g. `aws`/`azhub`/`cae` legitimately match both `CLOUD` and `PERIMETER`) rather than silently resolving them.
- `cross_reference_missing.py` — takes `build_fw_accounting.py`'s missing-device list and checks it against `scan_ip_datasets_all.py`'s raw-pool scan, splitting into `FOUND_IN_RAW_POOL` (real file exists, just never classified into `FW_CONFIGS/` — a fixable classification gap) vs. `TRULY_MISSING` (no trace anywhere — a genuine capture gap, needs pulling from the source system directly).

**Real, severe finding from a full production run of this tier (2026-08-13), not a hypothetical**: against the richer ~1,522-device inventory, only 24% (363) have any config in `FW_CONFIGS/` at all — 1,143 real devices are missing, of which 645 are confirmed `Offline` (a real, legitimate explanation — nothing to capture), but **154 are confirmed `Online`**, i.e. real, active, production firewalls this entire pipeline has zero visibility into. This means every Tier 0-5 output (route_db, group_db, rule_db, the whole `fwlookup.py` surface) reflects, at best, a real minority of the actual estate — not a rounding error. Independently cross-referencing a sample of these against the raw config pool, multiple zip archives by content, and Panorama bulk exports by hostname all confirmed zero trace — this is a genuine device-capture gap upstream of Tier 0, not a classification or naming-mismatch problem this pipeline's existing tools can fix. Treat any Tier 3+ output as describing "the ~25% of the estate we have data for," not "the estate," until this gap is meaningfully closed.

## Validation

`check_toolset.py` exercises the whole platform's `--version`/`--dry-run`/`--help` surface, FW toolset included. Run any time; most useful right after a full pipeline cycle to confirm nothing regressed. Version floors for FW scripts need bumping in lockstep with real script version bumps — this has been missed more than once (see changelog discipline in `ccd-versioning-discipline`).

## Known gaps (do not silently "fix" these without flagging them to the user first — they may be intentional scope boundaries, not bugs)

1. **Tier 3 is not gated by the Tier 1 signal.** All five Tier 3 scripts always run in full, every time, regardless of `actionable_count`. If a fully signal-driven pipeline is wanted, this needs either per-database flags added to `fw_pipeline_signals.json`, or each Tier 3 script doing its own internal checksum-based skip (the way `build_vpn_registry.py` already does).
2. **`classify_config()`'s content-sniffing fallback only fires when the filename regex would default to ASA.** It does not re-check files that already matched a filename-based PA or FTD pattern, and it does not attempt to disambiguate PA vs. FTD content — only "would-be-ASA vs. actually-PA".
3. ~~`build_fw_rule_db.py`'s ASA and FTD loops lack the device-level dedup that the PA loop has.~~
   **FIXED in v1.10.0 (2026-07-30)** — confirmed directly against the real current loop code
   (v1.17.2, 2026-08-05), not just the changelog text: `seen_asa_devices`/`seen_ftd_devices` sets,
   same skip-before-open, newest-by-mtime pattern as the PA loop, with `asa_skipped_duplicate`/
   `ftd_skipped_duplicate` counters printed in the summary lines. This skill entry was stale —
   the fix shipped and was verified in production (previous baseline 930,385 rules / 16,053,699
   rule_ips confirmed to shrink on the next real run per that changelog entry) but this skill was
   never updated to reflect it. Corrected 2026-08-05.
4. ~~**No FMC REST API JSON rule parser** in `build_fw_rule_db.py`~~
   **FIXED in v1.21.0 (2026-08-22)** — `parse_fmc_acp_json()` added. Reads `*_acp.json` FMC iControlREST accessrules exports from `FW_POLICIES/`. Runs alongside the CSV parser in step [4/5]. Confirmed against 6 real production files (1,021 rules). This skill was stale — the gap is now closed.

   **No CheckPoint rule parser exists in `build_fw_rule_db.py`** — 11 CheckPoint firewalls in the estate have never had their rules extracted; `fwlookup.py` is silently blind to them. Blocked on Management API/SmartConsole access to the SmartCenter server, per longer-standing project notes.
5. **`build_fw_group_db.py`'s v0.2.3 fix recovered zero additional objects** in the estate as it stood at fix time — worth re-checking after any large new PA device set lands, since the fix closes a real false-negative detection gap even though it happened to find nothing new immediately.
6. **`classify_config()` has no F5 or L3-switch awareness.** Real F5 load balancer and L3 switch configs sitting in the raw pool (confirmed via Tier 6's `scan_ip_datasets_all.py`) silently default to ASA classification, the same failure shape as the historical PA-defaulting-to-ASA bug that motivated the v2.3.0 content-sniffing fallback — except F5/switch configs don't trigger that fallback either, since their content doesn't match any PA signature. These are correctly *not* real ASA firewalls and don't belong in `FW_CONFIGS/ASA/` at all, but Tier 6's raw-pool scan currently reports them as "missing ASA configs" without distinguishing this from a genuine gap — read Tier 6 output with this in mind until `classify_config()` (or a Tier 6-side filter) gains real F5/switch detection.
7. ~~`setup_fw_configs.sh` v2.10.0 registers ASA/FTD identity but does not auto-run `--resolve`.~~
   **FIXED in v2.11.0** — `--resolve` now runs automatically, once, immediately after the
   registration sweep, confirmed via direct test (a real `LIKELY_DUPLICATE_SPELLING` pair
   correctly produced `2 real device_keys assigned a merged_id` through the exact call path the
   script itself uses). Tier 3's `fw_device_identity.merged_id` column is now populated as soon
   as Tier 0 finishes, with no separate manual step required.

## When debugging a downstream FW script's data quality

Before assuming a bug in the script itself, check in this order:
1. Did Tier 0 run recently, and did it run with `--reset` if `classify_config()` logic changed since the last reset?
2. Did Tier 1 run *after* Tier 0's most recent run? (Its signal is only as fresh as the last time it read the estate.)
3. For anything reading Tier 2 output (topology report, rule_db's `ip_context` enrichment): did Tier 2 actually run, or was it skipped because the signal said `false` on a run where it shouldn't have?
4. For duplicate/inflated counts specifically: is this Tier 3, and does the affected script's loop have device-level dedup yet? (Confirmed present as of 2026-08-05: PA/ASA/FTD route_db, PA group_db, and all three of PA/ASA/FTD rule_db — Known Gap 3 above was stale, fixed in v1.10.0. Also confirmed present: `build_fw_interface_inventory.py`'s cross-file dedup, v1.9.1 — see Tier 2 above.)

---

## build_IP_Network_Egress_FW_topology.py — Daily Bridge Script

**Version:** v1.17.1 (2026-08-20)
**Cadence:** Daily (scheduled) — runs every weekday
**Role:** Bridges the FW pipeline to the host ingest pipeline

This script is the daily auto-runner that:
1. Analyzes firewall egress traffic against IPAM to find unregistered subnets
2. Produces `unknown_ip_subnets_v{date}.csv` — consumed by `preprocess_p1.py`
3. Produces `ent-ipdataset-EGRESS-FW-TOPOLOGY-v{date}.csv`
4. Auto-runs the full EDL object pipeline chain (Stages 0-6) after topology rebuild

**Critical dependency:** `preprocess_p1.py` auto-discovers the latest
`unknown_ip_subnets_v*.csv` from `FW-Egress_Out/`. If this script hasn't run
recently, p1 uses a stale egress snapshot. Confirmed real (2026-08-23): script
hadn't run since Friday, p1 used 2-day-old file. Not blocking but worth tracking.

**Registered outputs:**
```
EGRESS-FW-TOPOLOGY   ent-ipdataset-EGRESS-FW-TOPOLOGY-v20260820.csv   371,821 rows
EGRESS-FW-UNMATCHED  ent-ipdataset-EGRESS-FW-UNMATCHED-v20260613.csv  861 rows
```

**Relationship to 10 egress domains:**
The script's `ROUTING_DOMAIN` output maps directly to the 10 egress FW enforcement
boundaries (EGR_RI1-TC, EGR_MDC-TC, EGR_SHEAW-TC, EGR_WDC-TC, EGR_LV-TC, etc.)
plus Retail (172.16.0.0/12 aggregate). These are the same domains used in
`all_IP_networks.ROUTING_DOMAIN` and the EDL object zone tags (`APP_{ACRONYM}_{ZONE}`).

---

## Current Registered Dataset Versions (2026-08-23)

| Dataset | Version | Rows |
|---------|---------|------|
| `fw_rule_db` | v20260822 | 21,783,215 (1,085,211 rules) |
| `fw_route_db` | v20260821r2 | 78,956 |
| `fw_group_db` | v20260821 | 2,967,913 |
| `fw_config_manifest` | v20260822 | 2,190 |
| `fw_location_topology` | v20260822 | 768 |
| `fw_device_master` | v20260803 | 852 |
| `EGRESS-FW-TOPOLOGY` | v20260820 | 371,821 |
| `EGRESS-FW-UNMATCHED` | v20260613 | 861 |

**Rule DB coverage:** ~70% of the estate has configs collected as of 2026-08-23.
The rule DB contains 1,085,211 rules but these reflect ~70% of real production FWs.
Treat all Tier 3+ output as describing the collected subset, not the full estate.

**Rule quality baseline (2026-08-23):**
```
802,911 (74%)  src=named, dst=named   — already using address objects
205,272 (19%)  src=raw,   dst=raw     — explicit IPs, need abstraction
 41,435  (4%)  src=named, dst=raw     — half-normalized
 35,593  (3%)  src=raw,   dst=named   — half-normalized
 54,046  (5%)  ANY on either side     — need traffic evidence
  3,426  (0.3%) true any/any          — highest risk rules
```

**fw_rule_db schema (rules table key columns):**
```
rule_id, fw_name, fw_type, policy_name, rule_name, rule_seq
action, protocol, src_zone, dst_zone
src_raw, dst_raw          — raw config string ('any', IP, or group name)
src_group_ref, dst_group_ref — named address object reference (null if raw)
src_ports, dst_ports, application
enabled, log_setting, comment, config_file
```

**ip_context table (179,823 rows) — enrichment layer:**
```
ip_value → ipam_cidr, site_code, canonical_loc, routing_domain, heritage, net_type
         → vip_vs_name, vip_pool, vip_members, vip_f5  (F5 VIP context)
         → snat_platform, snat_rule, snat_type          (NAT context)
         → ehm_hostname, ehm_app_id                     (application context)
```
This is the bridge between `rule_ips` and the EDL address object model.
Join: `rule_ips.ip_value → ip_context.ip_value → routing_domain + heritage → EDL zone`

**Panorama vs cluster rules:**
The largest rule set is `POLICIES` (41,849 rules) — the Panorama shared policy
pushed to all FTD clusters. Per-cluster counts (~19-25k) are subsets of this.
The real unique rule universe for normalization is:
1. Panorama shared policy (~41,849) — applies everywhere
2. Per-site device-group policies — what differs per egress domain
3. Local cluster overrides — unique to a single FTD

**Zone naming inconsistency (known gap):**
Zone names are not normalized across clusters:
- `outside / Outside / OUTSIDE / Outside_Equinix` — all mean egress zone
- 159,332 rules have blank zones — must be assigned from `fw_name → fw_location_topology`
- `asminside / asmoutside` — ASM-specific naming
Cross-referencing `fw_name` against `fw_location_topology` is required to assign
topology-correct zones before any normalization work can proceed.

---

## Egress Topology → FW Rule Translation (2026-08-23)

The complete chain from any IP to the physical FW enforcing rules on it:

```
Any IP (app server / VIP / SNAT / FW interface)
  ↓ ip_resolution_index (91,956 entries)
ROUTING_DOMAIN
  ↓ egress_topology_registry (STATIC_RD_TO_EGR seeded first)
EGR_CODE + FW_HOSTNAMES
  ↓ fw_rule_db WHERE fw_name IN hostnames
RULES to normalize / translate / push
```

**egress_topology_registry** — 17 EGR_CODEs, registered in ipam-db:

| EGR_CODE | ROUTING_FABRIC | MGMT_PLANE | BREAKOUT_TYPES |
|----------|---------------|------------|----------------|
| EGR_MDC  | HCB | Panorama | Internet\|Cloud\|VPN-Partner\|COLO |
| EGR_WDC  | HCB | Panorama | Internet\|Cloud\|VPN-Partner\|COLO |
| EGR_CMEP | HCB | Panorama | Cloud\|VPN-Partner |
| EGR_CMEN | HCB | Panorama | Cloud\|VPN-Partner |
| EGR_MDCO | HCB | Panorama | Internet |
| EGR_RI1  | PBM | Panorama | Internet\|Cloud\|VPN-Partner\|COLO |
| EGR_RIRETAIL | PBM\|RETAIL | FMC | Retail-Egress\|Store-VPN |
| EGR_SHEAW | PBM | Panorama | Internet\|VPN-Partner\|COLO |
| EGR_CMC  | PBM | Panorama | Internet\|Cloud |
| EGR_LV   | HCB\|PBM | Panorama | Internet\|COLO |
| EGR_SHEAE | INTERNET | Panorama | Internet\|VPN-Partner |
| EGR_PCIMDCAPP/SYS/WEB | PCI-HCB | FMC | PCI-Internet |
| EGR_PCIWDCAPP/SYS/WEB | PCI-HCB | FMC | PCI-Internet\|PCI-DR |

**Three routing fabrics — discrete paths, no crossover:**
```
HCB (Aetna):   Internet→EGR_MDC/WDC, Cloud→EGR_CMEP/MDC/WDC,
               VPN→EGR_MDC/WDC/SHEAE, COLO→EGR_LV(HCB context)
               PCI→EGR_PCIMDCAPP/SYS/WEB + EGR_PCIWDCAPP/SYS/WEB
               (Aetna PCI FWs are INTERNET-EDGE — have real 167.69.x inet_cidrs)

PBM (CVS):     Internet→EGR_RI1, Cloud→EGR_RI1/CMEP,
               VPN→EGR_RI1/SHEAW, COLO→EGR_LV(PBM context)
               Retail→EGR_RIRETAIL
               PCI zone enforcement→EGR_PCISHEA/RIWSDC/CUMBER/HOL/PIH/PTXSNMO/GCP_USE4/USW2
               (CVS PBM PCI FWs are PCI-ENFORCEMENT — CDE boundary, NOT internet egress;
                internet egress for PCI traffic still via main PBM path ADJACENT_EGR_CODE)

RETAIL:        Egress→EGR_RIRETAIL only; no direct cloud/VPN
```

EGR_LV serves HCB (EGR_MDC-TC) AND PBM (EGR_SHEAW-TC) in separate routing
contexts on the same physical FWs. A rule affecting EGR_LV must account for
both fabrics.

**STATIC_RD_TO_EGR** (in build_app_egress_topology.py) — seeds the routing
domain → EGR_CODE map before dynamic topology lookup. Essential because
fw_location_topology hostname matching misses Internal-HCB and Internal-PBM.
Read this before modifying the rd_to_egr logic.

**FW config inventory (build_fw_accounting.py v2.1.0):**
- Join key: fw_config_manifest.HOSTNAME + CHANGE_STATUS (not STATUS)
- CHANGE_STATUS values: NEW/CHANGED/UNCHANGED/DROPPED
- PA egress FWs absent from CMDB/CDO inventory — Panorama-managed by design
- CMDB status suppressed from output — unreliable for all device types
