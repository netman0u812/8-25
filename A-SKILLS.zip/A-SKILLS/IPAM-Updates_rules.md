---
name: ipam-patch-safety
description: Non-negotiable discipline for any ipam-db.py --update-patch, --apply-patch, or --remove-patch operation that changes existing rows (not pure net-new additions). Use this skill whenever modifying a field on existing all_IP_networks, location_master, retail_networks, or mgmt_ip_index rows -- e.g. correcting a NET_TYPE, LOCATION_TYPE, CANONICAL_LOCATION, or STATUS value. Trigger on: "fix this NET_TYPE", "correct the LOCATION_TYPE", "update these existing rows", "patch IPAM", "modify existing SITE_CODE/CIDR entries", or any request to change data that already exists in a registered IPAM dataset. Do NOT bundle a REMOVE and its corresponding ADD into a single patch file or a single import -- this skill exists specifically to prevent that mistake.
---

# IPAM Patch Safety: One Restorable Step at a Time

## The rule

**Every ipam-db.py patch operation that changes existing data must be split into
separate, independently-registered steps.** Never combine a REMOVE and its
corresponding ADD into one patch file, and never batch a REMOVE+ADD pair into
one `--update-patch` invocation followed by one `--import`, even though the
tool technically supports a `PATCH_ACTION` column that allows this in a single
file.

## Why this matters (not just a style preference)

`ipam-db.py --restore <STEM>` rolls back to the **most recently registered prior
version** of a dataset. Registration happens at `--import` time. This means the
restore granularity is exactly as fine as the number of separate imports you
did.

- **Two separate imports** (REMOVE registered, then ADD registered) gives you
  two restore points. If the ADD step turns out wrong, `--restore
  all_IP_networks` cleanly returns you to the state right after the REMOVE —
  the correction is undone, the removal stands, nothing else is touched.
- **One combined REMOVE+ADD import** gives you exactly one restore point. If
  anything about the combined change is wrong, the only rollback available is
  the *entire* combined operation — you cannot separate "undo the correction"
  from "undo the removal," because from the registry's point of view they were
  one atomic change.

Cross-check (`--cross-check`, which also runs automatically after every
`--import` of a managed stem) is the other reason to separate the steps: it
gives you a genuine checkpoint to verify the REMOVE landed clean *before* the
ADD goes in, rather than discovering a problem only after both changes are
already bundled together.

## The correct workflow

For any correction to existing rows (e.g. fixing a wrong `NET_TYPE`):

1. Build a patch CSV containing **only the REMOVE rows** (`PATCH_ACTION=REMOVE`,
   matching the exact CIDR/SITE_CODE of the rows being corrected).
2. `ipam-db.py --update-patch <remove_patch.csv>`
3. `ipam-db.py --import <resulting_versioned_file>` — this registers the
   removal as its own restore point.
4. `ipam-db.py --cross-check` — confirm the removal didn't introduce new
   violations (e.g. orphaned children, broken LPM parents) before proceeding.
5. Build a **separate** patch CSV containing only the ADD rows
   (`PATCH_ACTION=ADD`, same CIDRs, corrected field values).
6. `ipam-db.py --update-patch <add_patch.csv>`
7. `ipam-db.py --import <resulting_versioned_file>` — registers the correction
   as its own, independent restore point.
8. `ipam-db.py --cross-check` — confirm the correction is clean.

This is more commands than doing it in one shot. That's the point — each
command is a checkpoint, not overhead to be optimized away.

## What NOT to do

- Do not build one patch CSV with both `PATCH_ACTION=REMOVE` and
  `PATCH_ACTION=ADD` rows for the same correction, even though the
  underlying `--update-patch` code accepts this in a single file.
- Do not skip the `--import` + `--cross-check` step between REMOVE and ADD "to
  save time" — the intermediate registered state is the entire value of doing
  this in two steps.
- Do not reach for an external/ad-hoc script (e.g. hand-rolling a "stripped
  baseline file" plus a separate add-only tool) when `ipam-db.py
  --update-patch` already does this natively, with proper versioning,
  archiving, and audit. Use the platform's own patch mechanism, not a
  workaround built around it.

## Applies beyond all_IP_networks

The same discipline applies to `--type location_master` patches
(`_do_update_patch_lm`) and any other managed stem: separate the destructive
half from the corrective half, register each independently, cross-check
between them.
