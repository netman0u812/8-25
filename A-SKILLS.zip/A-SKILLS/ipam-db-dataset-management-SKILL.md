---
name: ipam-db-dataset-management
description: >
  ipam-db.py dataset lifecycle management for the CCD Platform — CVS Health
  Information Security. Use this skill for any task involving registering,
  updating, importing, diffing, archiving, restoring, or removing datasets in
  ipam-db/. Covers both core IPAM datasets (all_IP_networks, location_master,
  ent_host_master, etc.) and ENT ipdatasets (F5-VIP-REGISTRY, COMPUTE-SUBSTRATE,
  etc.). Trigger on: "register a dataset", "import into ipam-db", "add a new
  dataset", "ENT_DESCRIPTORS", "ipam-db.json", "archive", "restore", "diff",
  "--import", "--type", "STEM", "compute_substrate", "checksum", "txn.log",
  "version manifest", "ipam-db-archive", "_DIFF_CONFIG", "RAW_DISPATCH".
---

# ipam-db.py — Dataset Lifecycle Management

## 1. Two Categories of Datasets

**Core IPAM datasets** — live in `ipam-db/`, managed by `ipam-db.py` directly,
have cross-check (CX) rules:

| Stem | Purpose |
|---|---|
| `all_IP_networks` | Enterprise subnet registry — primary IPAM source of truth |
| `location_master` | Physical and logical site registry — root FK for everything |
| `ent_host_master` | Per-host enrichment layer |
| `ent_network_device_master` | Network device inventory |
| `app_subnet_index` | App-to-subnet mapping at /24 level |
| `retail_networks` | Retail store /26 allocations (separate routing plane) |
| `delivery_infrastructure` | ESXi, HMC, LPAR, DataPower hosts |
| `delivery_platform` | Kubernetes, OpenShift, container hosts |
| `placeholder_networks` | Synthetic entries for LM sites with no subnets |
| `external_ip_registry` | External cloud/provider IP ranges |
| `compute_substrate` | Compute substrate attribution (VMWARE/CLOUD_IAAS/etc.) |

**ENT ipdatasets** — also live in `ipam-db/`, registered via `ipam-db.py --import`,
but produced by separate build/update scripts, no CX rules:

| Descriptor | Stem | Produced by |
|---|---|---|
| `F5-VIP-REGISTRY` | `ent_f5_vip_registry` | `build_f5_vip_registry.py` |
| `F5-POOL-MEMBERS` | `ent_f5_pool_members` | `build_f5_vip_registry.py` |
| `CPC-CORE-SERVICES` | `ent_cpc_core_services` | CPC template import |
| `EGRESS-FW-TOPOLOGY` | `ent-ipdataset-EGRESS-FW-TOPOLOGY` | `build_egress_fw_topology.py` |
| `EGRESS-FW-UNMATCHED` | `ent-ipdataset-EGRESS-FW-UNMATCHED` | `build_egress_fw_topology.py` |
| `COMPUTE-SUBSTRATE` | `compute_substrate` | `update_compute_substrate.py` |

---

## 2. Adding a New Dataset — Full Procedure

### Step 1 — Decide: Core IPAM or ENT ipdataset?

**Core IPAM** — if the dataset:
- Is a primary data source (not derived from other CCD datasets)
- Needs CX cross-check rules
- Has LM or IPAM as a hard FK dependency

**ENT ipdataset** — if the dataset:
- Is produced by a CCD build/update script from existing datasets
- Has no independent CX rules
- Is a derived attribution, registry, or enrichment output

### Step 2 — Register in ENT_DESCRIPTORS (ENT datasets only)

In `ipam-db.py`, find `ENT_DESCRIPTORS` (currently around line 577) and add the
new descriptor string:

```python
ENT_DESCRIPTORS = [
    'F5-VIP-REGISTRY',
    'F5-POOL-MEMBERS',
    'CPC-CORE-SERVICES',
    'EGRESS-FW-TOPOLOGY',
    'EGRESS-FW-UNMATCHED',
    'COMPUTE-SUBSTRATE',      # ← add new descriptor here
    'YOUR-NEW-DESCRIPTOR',    # ← your addition
]
```

The descriptor is the ALL-CAPS hyphenated name. It drives:
- `--list` display under ENT ipdatasets section
- `ent_` stem key derivation in registry (`COMPUTE-SUBSTRATE` → `compute_substrate`)
- `ent-ipdataset-YOUR-DESCRIPTOR-vDATE.csv` filename pattern recognition

### Step 3 — Add _DIFF_CONFIG entry

In `ipam-db.py`, find `_DIFF_CONFIG` (around line 6139) and add entries. Always
add both the normalized stem AND the legacy ent-ipdataset- form:

```python
# ── Your new dataset ──────────────────────────────────────────────────────
'your_stem_name': {
    'key':     'IP_ADDRESS',          # primary key column for row matching
    'display': ['FIELD1', 'FIELD2', 'FIELD3', 'FIELD4'],  # shown in diff output
    'label':   'your_stem_name (Human Readable Description)',
},
'ent-ipdataset-YOUR-DESCRIPTOR': {
    'key':     'IP_ADDRESS',
    'display': ['FIELD1', 'FIELD2', 'FIELD3', 'FIELD4'],
    'label':   'ent-ipdataset-YOUR-DESCRIPTOR (Human Readable Description legacy)',
},
```

**Key column rules:**
- Use `IP_ADDRESS` for per-host datasets
- Use `CIDR` for per-subnet datasets
- Use `VIP_IP` / `MEMBER_IP` for F5-style datasets
- Use `SITE_CODE` for location datasets
- Use `OBJECT_NAME` / `FLOW_ID` for object catalog datasets

**Display field rules:**
- 3-5 fields only — shown inline in the diff report
- Choose fields that make a changed row immediately identifiable
- For substrate datasets: substrate type + source + confidence + site

### Step 4 — Bump ipam-db.py version

`SCRIPT_VERSION` is a single variable (not `__version__`). Always PATCH bump
for descriptor/diff config additions:

```python
SCRIPT_VERSION = '3.15.14'   # → '3.15.15' for your addition
```

Add changelog entry at the top of the file:
```python
# v3.15.15 2026-MM-DD  Added YOUR-DESCRIPTOR to ENT_DESCRIPTORS and _DIFF_CONFIG.
#                      key=YOUR_KEY, display fields: FIELD1/FIELD2/FIELD3.
#                      Produced by your_build_script.py. Import via:
#                      ipam-db.py --import <file> --type your_stem
```

### Step 5 — Verify with check_toolset.py

After bumping `ipam-db.py`, update `check_toolset.py`:
```python
('platform', 'ipam-db.py',
 ['--version'],
 'v3.15.15',   # ← bump to match new SCRIPT_VERSION prefix
 'Registry version check'),
```

---

## 3. Importing a Dataset File

### Standard import command

```bash
# Always dry-run first
python3 ipam-db.py \
    --import ./ipam-db/compute_substrate_v20260616.csv \
    --type compute_substrate \
    --description "Compute substrate attribution — three-tier derivation from EHM+IPAM" \
    --dry-run

# Write when dry-run looks correct
python3 ipam-db.py \
    --import ./ipam-db/compute_substrate_v20260616.csv \
    --type compute_substrate \
    --description "Compute substrate attribution — three-tier derivation from EHM+IPAM"
```

### What --import does automatically

1. **Copies** the file into `ipam-db/` (overwrites if same filename exists)
2. **Archives** the previously registered version to `ipam-db-archive/`
3. **Sweeps** for stray versioned files of the same stem and archives them
4. **Runs inline diff** against the previously registered version — shows
   added/removed/modified rows using the `_DIFF_CONFIG` display fields
5. **Computes SHA-256** of the new file and stores in registry entry
6. **Writes registry entry** to `ipam-db.json` with filename, version,
   row_count, size_kb, description, imported_at, sha256
7. **Appends version manifest snapshot** — full checksum of all registered
   files at this point in time
8. **Writes txn.log record** — JSONL transaction audit trail
9. **Backs up ipam-db.json** to `ipam-db.json.bak` before every write
10. **Prints next steps** — downstream pipeline commands to run

For `all_IP_networks` imports only: also runs IPAM audit (CX rules) against
new/modified rows. HIGH violations block import unless `--force` is passed.

### The --type flag

`--type` specifies the registry stem key. Rules:
- For core IPAM datasets: use the exact stem name (`all_IP_networks`, `location_master`, etc.)
- For ENT ipdatasets: use the lowercase stem (`compute_substrate`, `f5_vip_registry`, etc.)
- The filename pattern (`ent-ipdataset-DESCRIPTOR-vDATE.csv`) is auto-detected from the filename

### Output file must have CCD headers

Every file imported into ipam-db must have the standard comment headers:
```
#STEM=compute_substrate
#VERSION=v20260616
#ROWS=61492
#CREATED=2026-06-16T14:00:00Z
#TOOL=update_compute_substrate.py v1.0.0
#END_HEADER
COLUMN1,COLUMN2,...
```

Files missing `#VERSION=` are rejected (`vbare` = hard stop).

---

## 4. Dataset Lifecycle Commands

### List all registered datasets
```bash
python3 ipam-db.py --list
```
Shows all stems with version, row count, size, last import date, and status.
Sections: Core IPAM → ENT ipdatasets → Other registered.

### Resolve current file path for a stem
```bash
python3 ipam-db.py --resolve compute_substrate
# Output: /path/to/ipam-db/compute_substrate_v20260616.csv
```
Used by downstream scripts to find the current registered version without
hardcoding a filename. Always use `best_versioned()` or `--resolve` — never
hardcode versioned filenames in scripts.

### Check version and integrity of all datasets
```bash
python3 ipam-db.py --checksums
```
Prints version, SHA-256, and last-verified date for every registered dataset.
Use after any manual file operation to confirm nothing was corrupted.

### Show JSON status (used by iplookup.sh)
```bash
python3 ipam-db.py --status
```

### Diff a dataset against its prior version
```bash
# Diff current vs most recent prior version
python3 ipam-db.py --diff-dataset compute_substrate

# Diff against a specific prior timestamp
python3 ipam-db.py --diff-dataset compute_substrate --timestamp 20260615T140000
```
Uses `_DIFF_CONFIG` display fields. Shows added rows, removed rows, and
modified rows (key field unchanged, display fields changed).

### Remove a registry entry
```bash
# Dry run first
python3 ipam-db.py --remove compute_substrate --dry-run

# Write (prompts for confirmation)
python3 ipam-db.py --remove compute_substrate

# Skip confirmation prompt
python3 ipam-db.py --remove compute_substrate --force
```
**Critical:** `--remove` only deletes the `ipam-db.json` entry. The CSV file
on disk is untouched. The file must be manually deleted or archived if desired.
Registry is backed up to `ipam-db.json.bak` before removal.

### Restore a dataset to its prior version
```bash
# Restore most recent prior version of a single stem
python3 ipam-db.py --restore compute_substrate

# Skip confirmation
python3 ipam-db.py --restore compute_substrate --force

# Restore entire ipam-db/ to a prior timestamp (full rollback)
python3 ipam-db.py --restore 20260615T140000
```
`--restore <STEM>` is surgical — only that dataset is touched. Scans backup
snapshots newest→oldest, finds the most recent version with a different SHA-256,
copies it back into `ipam-db/`, updates the registry entry and txn.log.

---

## 5. Update Cycle — Existing Dataset

When a build/update script produces a new version of an existing dataset:

```bash
# 1. Run the build script (produces new versioned file in ipam-db/)
python3 update_compute_substrate.py --dry-run
python3 update_compute_substrate.py

# 2. Import: checksums, diffs, archives old version, registers new
python3 ipam-db.py --import ./ipam-db/compute_substrate_v20260617.csv \
    --type compute_substrate \
    --description "Compute substrate attribution v2 — EHM r24"

# 3. Review the inline diff output before continuing downstream
# 4. Continue pipeline
python3 update_asi.py
python3 build_object_pipeline.py --edl
```

The inline diff on import is the primary review gate — inspect it for:
- Unexpected substrate changes (host type flipping without a CMDB update)
- New DATA_QUALITY flags appearing
- Significant UNKNOWN count changes
- Sites with large delta counts (could indicate SITE_CODE attribution drift)

---

## 6. Patching Existing Rows — --apply-patch

Use `--apply-patch` to correct field values on existing rows in `all_IP_networks`
(e.g. ROUTING_DOMAIN, FACILITY_TYPE, NET_TYPE, HERITAGE corrections).

**This is the ONLY correct way to make field-level corrections to existing IPAM rows.**
Never modify the source CSV outside of `ipam-db.py`. Never regenerate a versioned
file by hand and import it as a correction. Both approaches corrupt the checksum
chain and bypass the audit trail.

### Patch file schema

Plain CSV — **no comment headers**. Columns:

```
action,cidr,field,old_value,new_value,rule
SET,10.68.63.0/24,ROUTING_DOMAIN,Internal-PBM,Cloud-Azure,SITE_CODE-US_AZR_UE2_IS-RD-CORRECTION
SET,10.47.248.0/24,FACILITY_TYPE,,Datacenter,R10-REQUIRED-FIX
```

- `action`: `SET` (change a field) or `DROP` (remove the row entirely)
- `cidr`: must match `CIDR` column exactly in `all_IP_networks`
- `field`: column name to change
- `old_value`: prior value (informational only — not validated by the handler)
- `new_value`: value to set
- `rule`: free-text label for audit trail

**Critical:** No `#STEM=` / `#VERSION=` comment headers. The handler uses
`csv.DictReader` directly — comment headers will cause 0 patches to be read.

### Workflow

```bash
# 1. Build patch file (plain CSV, no comment headers)
# 2. Dry run first — always
python3 ipam-db.py --apply-patch ipam_rd_correction_patch_20260618.csv --dry-run

# 3. Verify: "SET patches: N field changes across M CIDRs"
# 4. Apply
python3 ipam-db.py --apply-patch ipam_rd_correction_patch_20260618.csv

# 5. Cross-check
python3 ipam-db.py --cross-check
```

`--apply-patch` reads the current registered `all_IP_networks`, applies all SET/DROP
actions, writes the next versioned file (`r11` → `r12`), archives the prior version,
updates the registry and SHA-256, and appends to txn.log. The patch file itself is
not imported or registered — it is a transient input only.

### When to use --apply-patch vs --update-patch vs --import

| Need | Command |
|---|---|
| Correct field values on existing rows (ROUTING_DOMAIN, NET_TYPE, etc.) | `--apply-patch` |
| Add or remove subnet rows | `--update-patch` |
| Replace entire dataset with new build script output | `--import` |
| Cascade CANONICAL_LOCATION fixes from LM into all_IP_networks | `--update-patch --type location_master` |

---

## 7. RAW_DISPATCH (auto-import from raw files)

For datasets that come from raw file drops (not CCD build scripts), add an
entry to `RAW_DISPATCH` in `ipam-db.py`. The `--import-update` command scans
`IP_Datasets_Raw/`, checksums files, and processes new/changed ones:

```python
# In RAW_DISPATCH list:
(r'YourRawFilePattern.*\.csv$',
 {'handler': 'ip_dataset_enterprise',
  'descriptor': 'YOUR-DESCRIPTOR',
  'name': 'your-dataset-name',
  'provider': 'Enterprise_Data',
  'description': 'Human readable description',
  'outputs': ['ent_your_stem_name']}),
```

For CCD build/update script outputs (not raw file drops), RAW_DISPATCH is NOT
used — the build script writes directly to `ipam-db/` and manual `--import`
registers it. `update_compute_substrate.py` follows this pattern.

---

## 8. ipam-db.json Registry Structure

The registry file lives at `ipam-db/ipam-db.json`. Each dataset entry:

```json
{
  "files": {
    "compute_substrate": {
      "filename":         "compute_substrate_v20260616.csv",
      "version":          "20260616",
      "row_count":        61492,
      "size_kb":          4821,
      "description":      "Compute substrate attribution...",
      "imported_at":      "2026-06-16T14:00:00Z",
      "source":           "/path/to/original/file",
      "imported_by":      "3.15.14",
      "audit_status":     "passed",
      "sha256":           "abc123...",
      "sha256_verified":  "2026-06-16T14:00:01Z"
    }
  },
  "schema_version":   "1.0",
  "ipam_db_version":  "3.15.14",
  "last_updated":     "2026-06-16T14:00:01Z",
  "version_manifest": [...],
  "stage2_required":  {...}
}
```

**Never edit `ipam-db.json` by hand.** Always use `ipam-db.py` commands.
If the registry is corrupted, restore from `ipam-db.json.bak`.

---

## 9. File Naming and Versioning Rules

Every dataset file must follow:
- **Versioned filename:** `stem_vYYYYMMDD.csv` or `stem_vYYYYMMDDrN.csv`
- **`#VERSION=` header:** must match filename version
- **`DATASET_VERSION` column:** in every data row
- **`LOC_MASTER_VERSION` column:** in every data row (where applicable)

**Version bump rules:**
- First version on a date: `v20260616`
- Second version same date: `v20260616r1`, third: `v20260616r2`, etc.
- Never skip version numbers — always use `bump_ehm_version()` or equivalent

**`vbare` = hard stop.** A file with no version stamp is never imported.

---

## 10. Archive and Backup Structure

```
IP_Lookup/
├── ipam-db/                    ← current registered versions only
│   ├── ipam-db.json            ← registry
│   ├── ipam-db.json.bak        ← auto-backup before every write
│   ├── txn.log                 ← JSONL transaction audit trail
│   ├── all_IP_networks_v20260611r11.csv
│   ├── compute_substrate_v20260616.csv
│   └── ...
├── ipam-db-archive/            ← superseded versions (auto-archived on import)
│   ├── all_IP_networks_v20260611r10.csv
│   ├── compute_substrate_v20260615.csv
│   └── ...
└── ipam-db-backups/            ← full point-in-time snapshots
    ├── 20260616T140000/
    │   ├── manifest.json
    │   └── ipam-db/
    │       └── ...all files...
    └── ...
```

`ipam-db/` holds only the current registered version of each stem.
`ipam-db-archive/` holds all prior versions — never deleted.
`ipam-db-backups/` holds full point-in-time snapshots for `--restore <TIMESTAMP>`.

---

## 11. Common Errors and Fixes

| Error | Cause | Fix |
|---|---|---|
| `vbare — hard stop` | File has no `#VERSION=` header | Add `#VERSION=vYYYYMMDD` header to the file |
| `stem not registered` | `--type` stem doesn't match any known stem | Check `--list` output for correct stem name |
| `HIGH audit violations` | all_IP_networks import has CX rule violations | Fix violations, then re-import; or `--force` if intentional |
| `ipam-db.json.bak` out of date | Concurrent modification | Restore from backup: `cp ipam-db.json.bak ipam-db.json` |
| Stray versioned files in ipam-db/ | Partial/failed prior import | Run `--import` again — stray sweep runs automatically |
| Diff shows unexpected mass changes | Wrong file imported under wrong stem | `--remove` the entry, restore prior version, re-import correct file |
| `best_versioned()` returns wrong file | Two versioned files for same stem in ipam-db/ | Run `--import` to trigger stray sweep; or manually move old version to archive |
| `⚠ TAMPERED` warning on `--list` | File in `ipam-db/` was modified outside `ipam-db.py` | Re-import the original file to re-register checksum: `--import ipam-db/STEM_vN.csv --type STEM` |
| `--apply-patch` reports 0 patches | Patch file has `#STEM=`/`#VERSION=` comment headers | Remove all comment headers — patch file must be plain CSV with header row only |
| `--update-patch` ADD rows fail as duplicates | REMOVE+ADD pairs for same CIDR in one file | Use `--apply-patch` for field corrections instead; `--update-patch` is ADD/REMOVE only |

---

## 12. Quick Reference — Dataset Management Commands

```bash
# Apply field-level corrections to existing all_IP_networks rows
python3 ipam-db.py --apply-patch PATCH_CSV --dry-run
python3 ipam-db.py --apply-patch PATCH_CSV

# Add or remove subnet rows in all_IP_networks
python3 ipam-db.py --update-patch PATCH_CSV --dry-run
python3 ipam-db.py --update-patch PATCH_CSV

# Import new dataset
python3 ipam-db.py --import FILE --type STEM --description "TEXT" --dry-run
python3 ipam-db.py --import FILE --type STEM --description "TEXT"

# List all registered datasets
python3 ipam-db.py --list

# Resolve current file path for a stem
python3 ipam-db.py --resolve STEM

# Check integrity
python3 ipam-db.py --checksums

# Diff dataset against prior version
python3 ipam-db.py --diff-dataset STEM

# Remove registry entry (file untouched)
python3 ipam-db.py --remove STEM --dry-run
python3 ipam-db.py --remove STEM

# Restore prior version of a dataset
python3 ipam-db.py --restore STEM
python3 ipam-db.py --restore TIMESTAMP  # full rollback

# List available restore points
python3 ipam-db.py --list-backups

# Scan raw files and auto-import changed datasets
python3 ipam-db.py --import-update --dry-run
python3 ipam-db.py --import-update
```

---

*CCD Platform | CVS Health Information Security | June 2026*
