---
name: fw-unified-object-model
description: The model, method, and architecture for building a universal, content-based
  canonical object and identity graph across the entire real firewall estate (~800 devices,
  ASA/FTD/PA). Use whenever the goal is cross-firewall address-group/object deduplication,
  determining real (not name-matched) traffic permit coverage across a business context, answering
  abstracted queries like "what protects app-X" or "which firewalls/subnets support PCI for Aetna
  vs. CVS Retail", or building/reviewing any of the three phases this skill defines. Status: design
  only, nothing in this skill has been implemented yet -- see "Current real state" below for
  exactly what related, narrower tools already exist and what this skill still requires building.
---

# FW Unified Object & Identity Model

## 1. The real problem

Roughly 800 real firewalls (ASA, FTD, PA) each maintain their own private, disconnected set of
address objects and groups. The same real IP content gets defined independently, over and over,
under different bespoke names, on different devices, sometimes on different platforms -- e.g.
`company_all_src` on one ASA containing `10.0.0.0/8, 172.16.0.0/…`, and `all_src_ip` on a
completely different firewall containing the identical real IP set. Nothing today has a concept
of "these are the same real thing" -- each is just a locally-scoped name with no relationship to
any other device's equivalent object, even when the content is byte-for-byte identical.

**This breaks two real, different capabilities that depend on cross-firewall consistency:**

1. **Object management.** Updating "all company IP space" today means finding and separately
   editing every bespoke alias of that same real content, one device at a time, with no
   guarantee every alias has even been found.
2. **Traffic-coverage analysis.** Topology/path-analysis tools (Tufin and others work this way)
   try to match rules by exact object/name correspondence across a traffic path. When firewall B
   doesn't have an *exactly matching* rule to firewall A's, these tools either flag a false gap
   or add a redundant rule -- because they can't see that firewall B may already permit the exact
   same real traffic through a completely different, broader, unrelated rule that shares no name
   or object with firewall A's. Exact-match tooling cannot distinguish a genuine gap from
   traffic that's already covered by different real means.

Both failures have the same root cause: **no universal, content-based identity for what a rule's
source/destination actually *is*, only what it's locally *called*.**

## 2. The three-phase model

### Phase 1 — Universal extraction and canonicalization (no rule rewriting)

1. From every real firewall, extract every rule and every object/address-group it references,
   including the real, resolved IP content of each object. Assign a unique ID to every element
   extracted -- both rules and objects get real identity at this stage.
2. Across *all* firewalls together, cluster objects whose real, resolved IP content is identical
   -- regardless of what any individual device calls it -- into one canonical **master object**
   with a permanent ID (e.g. `MAG_S0001` for a master source-address-group, following the
   platform's `MAG_S<n>`/`MAG_D<n>` convention for src/dst respectively).
3. **The bespoke, device-local name is never rewritten and never removed.** The real, on-device
   rule configuration is untouched. What gets built is a mapping layer: *this rule, on this
   device, uses bespoke name X; bespoke name X consumes canonical master object `MAG_S0001`.*
   This is deliberate and load-bearing -- it means the entire model is non-disruptive (nothing on
   any real device changes) while still making "everything that consumes `MAG_S0001` needs
   updating" a real, directly answerable question for the first time.
4. Dedup is by **exact, real resolved content**, not by name, and applies universally -- to every
   rule's src/dst, whether it came from a named group, a bare host IP, a literal CIDR, or
   anything else that resolves to a real address list. A rule that never used a named group at
   all still gets folded into the master set if its content matches something else's.

### Phase 2 — Real, content-based coverage analysis

Phase 1 alone answers "which objects are the same." It does not yet answer "is this traffic
actually permitted, and where." Phase 2 is the analysis layer built on top of Phase 1's canonical
objects: for a given real traffic context (e.g. "app-0002's traffic, which touches three
firewalls"), determine **actual, effective permit coverage** per firewall using real IP-content
matching against canonical objects -- never name matching, never exact-rule matching.

This is what correctly distinguishes:
- Traffic genuinely **not** permitted on a firewall where it should be (a real gap, worth fixing)
- Traffic **already permitted** via some broader, structurally unrelated rule that just doesn't
  share a name or object with the others (not a gap -- flagging it as one is the exact false
  positive this whole model exists to eliminate)

Only once this true, content-based state is known per firewall does any downstream migration or
rule-standardization become a safe, well-informed operation rather than blind rule-sprawl on top
of coverage that may already exist.

### Phase 3 — The query interface

The practical, business-facing capability built on Phases 1 and 2. Two real, confirmed shapes:

**Forward query** ("does X already reach Y"): given an IP or app-ID and a target (a named service,
an IP, another app), resolve where the source actually lives, determine via Phase 2 whether that
traffic is already permitted and by which real rule, identify every firewall in the real path that
already permits it, and -- only if genuinely not covered -- determine how to support the request
correctly through the canonical object model, not a new bespoke one-off rule.

**Reverse/partial-knowledge update** (the `MAG_S000341` example): a business owner knows their
canonical object needs 5 more `/26` blocks added, but typically only knows 1-2 of their own
object's current real member blocks -- not its full membership, and not everywhere it's
referenced. The system must take that partial input, correctly identify which canonical master
object it actually belongs to from just the known fragment, and apply the change there -- so it
propagates automatically to every bespoke-named alias on every firewall that truly consumes it,
without the requester needing full visibility into their own object's real footprint.

**Abstracted queries** (the real acceptance test, ss5 below): answering questions like "what PCI
subnets and firewalls support Aetna vs. CVS vs. CVS Retail" -- which cannot be answered by any
single existing tool today, only by traversing the full identity graph in ss3.

## 3. The identity graph -- the structural model underneath all three phases

Every layer below is a real, unique ID, and every arrow is a typed, real relationship backed by
an actual dataset -- not a set of independent name-keyed lookups that happen to correlate. This
is what makes the graph traversable in *both* directions on the same structure:

```
LOCATION_ID          (e.g. Shea DC)
    │  contains
    ▼
FW_ID                (a specific real firewall -- universal across ASA/FTD/PA; see ss4)
    │  tagged_as
    ▼
FW_CLASS              (from the 10-class taxonomy -- fw-class-taxonomy skill)
    │  supports
    ▼
CONTEXT_ID            (a specific traffic context, e.g. "app-0002" or "PCI")
    │  protects
    ▼
SUBNET_ID              (real, directly-connected or adjacent CIDR(s) -- fw_interfaces/fw_routes)
    │  hosts
    ▼
APP_ID                 (the real application(s) living in that subnet)
    │  confirmed_by
    ▼
{ INFRA_ID, F5_VIP_ID, FW_SNAT_ID }   (independent cross-verification, not a single-source trust)
```

**Top-down traversal** answers "Shea DC → which PCI firewalls → which contexts → which apps."
**Bottom-up traversal** (the original, harder question) answers "app-Q → which subnet → which
firewall → which class → is it PCI-protected." Same graph, same IDs, either direction -- not two
separate query paths that happen to arrive at similar answers.

**Canonical objects (Phase 1's `MAG_S<n>`/`MAG_D<n>`) are a parallel, cross-cutting layer**,
referenced by rules at any point in this graph -- an object doesn't belong to one context or one
firewall, it's consumed by many nodes across the graph simultaneously.

## 4. FW Identity, Class, and Adjacency -- the substrate this graph requires

Three real prerequisites underneath the graph in ss3, needed before Phase 2/3 can work correctly:

1. **FW Identity** -- every real firewall gets one universal, unique `FW_ID`. Partially exists
   today only for PA (serial-based device identity via `pa_config_parser.py`'s registry,
   confirmed real and working this session). ASA/FTD have no equivalent universal identity yet --
   a real, necessary extension, not yet built.
2. **FW Class(es)** -- each firewall's real function tag(s) from the 10-class taxonomy. Partially
   built: `plugin_fw_class_tag.py` computes `INTERNET_EGRESS`/`INTERNET_INGRESS` with real
   confidence; `CLOUD_EGRESS`/`CLOUD_INGRESS` and `PCI` are not yet wired in (see
   `fw-class-taxonomy` skill for the exact real signal each needs).
3. **FW Adjacency** -- a real, directed topology: which firewall's egress zone actually connects
   to which *other* firewall's ingress, based on real traffic path, not assumed from naming or
   location proximity. **Not built at all yet.** This is what a multi-hop path query (Phase 3's
   forward-query shape) fundamentally depends on -- without it, "which firewalls are in app-X's
   real path" cannot be answered beyond a single device.

You cannot correctly run Phase 2's coverage analysis, or answer a multi-hop Phase 3 query,
without all three of these being real and populated -- they are prerequisites, not a parallel,
independent effort.

## 5. The real acceptance test

The concrete, fully-worked query the finished system must be able to answer correctly, end to
end, using real cross-confirmation, not a single-source guess:

> **What are the CVS vs. Aetna PCI apps, and which PCI firewalls protect them?**

Methodology, confirmed correct and mapped to real (partially existing) data sources:

| Step | Real data source |
|---|---|
| PCI FW inventory + real location | `FW_SEGMENT = PCI` (`fw_config_manifest.py`) + `fw_location_topology.py` |
| Directly-connected subnets per PCI firewall | `fw_interfaces.cidr` in `fw_route_db.sqlite` -- `plugin_fw_class_tag.py`'s existing Home computation |
| PCI-to-Corporate real traffic flow | Not-Home domain classification + direction analysis (same plugin -- PCI-specific class logic is the real, stated gap, not yet wired in) |
| Real app IPs mapped to those subnets | `app_subnet_index.csv` cross-referenced against the real Home subnet list |
| **Cross-confirmation** (not optional) | Independently verified against `ent_host_master` (app attribution), `ent_network_device_master` (infra identity), `F5-VIP-REGISTRY`/`F5-POOL-MEMBERS`, and `ent_fw_snat_pools` -- four independent real sources, not one |

A correct answer must cite agreement (or flag disagreement) across all four cross-confirmation
sources, not just the primary chain -- this mirrors the exact discipline `fw_class_tagging_
retooling_spec.md`'s own storage design already requires (`evidence_notes`, "record *why*", not
just the final answer).

## 6. Current real state -- what exists today vs. what this skill still requires

**Real, built, tested, directly relevant (2026-08-05/06):**
- `build_fw_group_canonical.py` -- deduplicates *named address-groups* by real resolved content
  across ASA/FTD/PA, writes `fw_group_canonical`/`fw_group_canonical_map` into `fw_group_db.sqlite`.
  **Verified against the real, live estate (2026-08-05)**: 131,861 raw group definitions → 36,016
  canonical groups (73% real duplication rate). 8,919 canonical groups genuinely span more than
  one platform (later refined to ~6,790 after correcting a platform-counting bug that treated an
  unresolved device as if it were a real second platform -- see the same naming-mismatch note
  below, which explains *why* devices were unresolved). **Scope note: only covers rules that used
  a named group** -- a bare-IP rule's content is not yet folded into the same canonical set.
  Extending dedup to *every* rule's resolved src/dst, regardless of whether it came from a named
  group, is real, required, not-yet-done work for Phase 1 to be complete as specified in ss2 above.
- `build_fw_rule_db.py` v1.18.2 -- `rules.src_group_ref`/`dst_group_ref` preserve the real bespoke
  group name a rule referenced, before resolution -- **ASA/FTD only**; PA/FMC parsing paths still
  flatten the name on resolution, a real, separate, scoped-out follow-up. Two real bugs found and
  fixed after the initial v1.18.0 build, both via direct verification against the actual live
  database, not assumed correct from a diff:
    - v1.18.1: `src_group_ref`/`dst_group_ref` were defaulting to empty string `''` instead of real
      SQL `NULL` for PA/FMC rules (whose parsing paths never set these keys at all) -- made every
      single PA/FMC rule falsely match `WHERE src_group_ref IS NOT NULL`. Fixed with a targeted
      default; every other column's existing behavior is unchanged.
    - v1.18.2: a real device-naming mismatch against `build_fw_group_db.py` -- this script's ASA/FTD
      loops used only the filename prefix for device identity, while `build_fw_group_db.py` already
      preferred the real in-config `hostname` command. Confirmed real, large-scale impact via direct
      cross-database verification: **151,235 of 442,073 real group references (34.2%) resolved
      correctly before the fix; the remaining 290,838 broke down as 183,160 naming-mismatch failures
      (the group genuinely exists, just under a different device-name string) and 107,678 references
      to single named *objects* (not groups -- `fw_group_db.sqlite` was never built to catalog those,
      a real, separate, structural scope gap, not a data-loss bug -- the underlying IP content for
      those was confirmed present and correctly resolved in the rule's own data 99.9% of the time).**
      Fixed by preferring the real hostname the same way `build_fw_group_db.py` already does,
      scoped to preserve the existing `NET4WIR`/`MPLEAST` multi-context special case (v1.6.6)
      untouched. **PA confirmed to need no equivalent fix** -- all three scripts (`build_fw_group_
      db.py`, `build_fw_route_db.py`, `build_fw_rule_db.py`) already share one canonical PA device
      identity source (`pa_config_parser.py`'s registry, `dev.display_name`), so no independent
      name-derivation exists there to drift. **Post-fix resolution rate not yet re-verified** -- a
      rebuild with v1.18.2 was in progress as of this skill's last update; re-run the same real
      cross-database verification query once it completes and update this note with the real result.
- `plugin_fw_class_tag.py` v1.1.0 -- real Home/Not-Home boundary computation from
  `fw_route_db.sqlite`; `INTERNET_EGRESS`/`INTERNET_INGRESS` implemented and verified;
  `CLOUD_EGRESS`/`CLOUD_INGRESS`/`PCI` not yet.
- PA device identity via `pa_config_parser.py`'s registry (serial-based, real, working).

**Not built at all yet, required for this skill's model to function:**
- The join between `rules.src_group_ref`/`dst_group_ref` and `fw_group_canonical_map` (a rule →
  canonical-object lookup) -- discussed, not yet implemented as either a `fwlookup.py` plugin or a
  report script.
- Universal `FW_ID` for ASA/FTD (PA-only today).
- `FW_CLASS = PCI`/`CLOUD_*` signal wiring.
- **FW Adjacency** -- the directed firewall-to-firewall topology graph. No existing tool computes
  this at all.
- Phase 1's rule-level (not just named-group) canonicalization.
- All of Phase 2 (content-based coverage analysis) -- does not exist in any form yet.
- All of Phase 3 (the query interface, both directions) -- does not exist in any form yet.
- `CONTEXT_ID` as a real, populated concept (e.g. "this is app-0002's context") -- not defined
  anywhere yet; Cross-Company classification (needed to distinguish "CVS" from "CVS Retail"
  specifically) has **no defined computation path at all** per `fw-class-taxonomy`.

## 7. Non-goals for the first real implementation pass

- Do not attempt full Cross-Company disambiguation (CVS vs. CVS Retail vs. MinuteClinic, etc.) in
  the first pass -- `fw-class-taxonomy` already states this has no defined signal yet; designing
  that signal is real, separate work, not a byproduct of this skill.
- Do not attempt automatic rule *rewriting* or *rule generation* as part of Phase 1 or Phase 2 --
  both phases are read/analysis-only against real, unmodified device configs. Rule
  standardization/migration (briefly mentioned as a possible future step) is explicitly out of
  scope until Phases 1-3 are real and verified; do not build toward it prematurely.
- Do not assume FW Adjacency from location proximity or naming convention -- it must be derived
  from real routing/interface data (egress zone → next-hop firewall's real ingress), the same
  standard `plugin_fw_class_tag.py`'s Home/Not-Home algorithm already holds itself to.

## 8. Deliverables checklist

- [ ] Phase 1a: rule-level (not just named-group) canonicalization -- every rule's resolved
      src/dst gets a real object identity, dedup applies universally
- [ ] Phase 1b: the rule → bespoke-name → canonical-object join, queryable (plugin or report)
- [ ] Universal `FW_ID` extended to ASA/FTD (PA-only today)
- [ ] `FW_CLASS` completed for `CLOUD_EGRESS`/`CLOUD_INGRESS`/`PCI`
- [ ] FW Adjacency graph -- real, derived from routing/interface data, not assumed
- [ ] `CONTEXT_ID` defined and populated for at least one real business context (recommend
      starting with PCI, given ss5's acceptance test and the most real existing signal support)
- [ ] Phase 2: real, content-based coverage analysis, verified against a real multi-firewall
      context, explicitly tested against the "covered by an unrelated broader rule" false-negative
      case described in ss1
- [ ] Phase 3 forward query, verified end to end against a real app/IP
- [ ] Phase 3 partial-knowledge update, verified against a real canonical object with intentionally
      incomplete input (matching the `MAG_S000341` example's real shape)
- [ ] ss5's acceptance test answered correctly, with real cross-confirmation across all four
      independent sources, not just the primary chain
- [ ] This skill's "Current real state" (ss6) kept honestly updated as each piece ships -- matching
      this session's own established discipline of correcting stale documentation rather than
      leaving it to drift (see `ccd-fw-pipeline`'s corrected Known Gap 3 as the precedent)

## 9. Related tools and skills

- `fw-class-taxonomy` -- the 10-class definition and real signal mapping this skill's FW_CLASS
  layer depends on
- `fw-policy-classification` -- the broader rule-interpretation methodology; also where
  `plugin_fw_class_tag.py` is pointed to as the current Home/Not-Home mechanism
- `ccd-fw-pipeline` -- the real build-order/dependency graph for every script this skill's data
  layer depends on
- `fw_class_tagging_retooling_spec.md` -- the Home/Not-Home algorithm and its own storage-design
  precedent (`evidence_notes`, explicit tie-break/ambiguity handling) this skill's Phase 2 should
  match
- `fwlookup_plugin_architecture_spec.md` -- the mechanism any new Phase 2/3 query tooling should
  be delivered through, per this codebase's established convention
- `build_fw_group_canonical.py`, `build_fw_rule_db.py` -- the real, current Phase 1 groundwork
