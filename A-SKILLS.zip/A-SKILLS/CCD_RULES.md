# CCD Platform — Session Rules
# Upload this file at the start of every session.

## Before doing ANYTHING
Read the skill: /mnt/skills/user/ccd-platform-data-model/SKILL.md
No exceptions. Read it first, then proceed.

## Hard Rules

### Files
- Complete files only — no patches, diffs, or sed commands
- --dry-run before every write
- --cross-check after every IPAM import — 0 HIGH required to continue
- If HIGH violation: stop, run --restore immediately
- Confirm deployed version with --version before running any script
- Files download to ~/Documents/IP_Lookup/ — never ~/Downloads/

### Location Master
- NEVER delete, move, or archive location_master_table.csv or location_master_v*.csv
- NEVER modify LM without explicit confirmation AND verified backup
- LM changes cascade to IPAM → canonical objects → CSNA — treat as high risk
- Both files must always exist in ipam-db/: location_master_v5_11.csv AND location_master_table.csv

### Data Model
- HERITAGE = IP block ownership — NOT physical location
- Routing domain is the stronger signal for HERITAGE than location
- Never infer HERITAGE from LM location alone — co-located facilities have mixed ownership
- Internal-HCB = Aetna routing → HERITAGE typically AETNA
- Internal-PBM = CVS enterprise → HERITAGE typically CVS
- Retail /26 subnets live in retail_networks ONLY — never in all_IP_networks
- CANONICAL_LOCATION must exist in LM before any subnet or host row is committed

### Versioning (§12 of skill)
- Scripts: MAJOR.MINOR.PATCH — one variable only
- __version__ is canonical — SCRIPT_VERSION must equal __version__ if used at all
- Never have two version variables with different values
- Datasets: vYYYYMMDD or vYYYYMMDDrN — three stamps required on every dataset:
  1. Versioned filename
  2. #VERSION= header
  3. DATASET_VERSION column
- vbare is a hard stop — never use bare filename in production

### Pipeline
- Update order non-negotiable: LM → IPAM → NDM → EHM → Infra → Platform
- Heritage patch requires line-by-line review — never apply blindly
- fix-interactive patch is NOT auto-applied — explicit --apply-patch required
- When fix-interactive prompts for a field value — show valid options, validate input

### Data Source Registry
- Register source files with dsr.py before processing
- Register output files after writing
- Never process an unregistered source file
