---
name: external-ip-registry-internals
description: >
  Real, confirmed internals, known-fixed bugs, and data-source dependencies
  of build_external_ip_registry.py (the EIR tool for CVS Health
  InfoSec/CCD Platform). Use before modifying this script, debugging its
  output, or explaining what a specific EIR field means. Covers: the real
  GROUP BY fragmentation bug and its fix (v2.4.2), the EIP-side vs
  internal-counterpart enrichment asymmetry and its fix (v2.4.3/v3.0.0),
  and the deprecated ent-ipdataset-INTERNET-FACING file's replacement by
  ip_classification_ref. Trigger on: "external ip registry", "EIR",
  "build_external_ip_registry.py", "CVS_OWNED", "EIP_HERITAGE",
  "INTERNAL_COUNTERPART", "FW_PLATFORM", "why does this external IP show
  up twice", or any request to change or debug this script. Confirmed
  real production bugs and fixes as of 2026-08-20 -- read before assuming
  a symptom is new.
---

# External IP Registry (`build_external_ip_registry.py`) Internals

## What this tool actually does

Queries `fw_rule_db.sqlite` for every real external IP referenced in a
`permit`/`allow`/`trust` rule, excludes CVS/Aetna's own administratively-
relevant address space (via `ip_classification_ref`), enriches each real
external IP with threat intel/GeoIP/provider ownership, and computes a
risk score. One row per real external IP per direction -- not one row
per rule, not one row per firewall.

## Real, confirmed bug #1: GROUP BY fragmentation (fixed v2.4.2)

**Symptom**: the same real external IP, referenced across firewalls of
*different platform types* (some ASA, some FTD), appeared as multiple
separate records with different `EXT_ID`s instead of one unified record.

**Root cause**: the real SQL `GROUP BY` included `r.fw_type` and
`r.action` alongside `ip_value`/`direction` -- so a real external IP
seen on both an ASA and an FTD firewall got split into two SQL rows,
each aggregating only its own platform's rules.

**Fix**: `GROUP BY` narrowed to `(ip_value, direction)` only. Six other
bare (non-aggregated) SELECT columns had to be audited and fixed for the
SAME class of bug once the wider grouping could expose them:
`fw_type`/`action` (now `GROUP_CONCAT`'d, pipe-joined in output),
`enabled` (now `MAX(r.enabled)` -- if ANY real rule referencing this IP
is active, the real exposure exists), `src_raw`/`dst_raw` (now
`GROUP_CONCAT`'d and re-split on both the inter-rule `,` boundary and
the existing intra-rule `|` member boundary before feeding
`INTERNAL_COUNTERPART`), `dst_ports`.

**Real, confirmed production impact**: a live run before the fix showed
341,086 raw rows / 104,892 final rows; the same real data after the fix
showed 186,316 raw rows / 56,768 final rows -- roughly 45% fewer rows,
with 100% `EXT_ID` preservation confirming this was fragmentation being
corrected, not real data loss.

**If debugging "why does this external IP appear more than once" or
`FW_COUNT`/`RULE_COUNT` look wrong**: check the real `GROUP BY` clause
first. This exact bug class (a bare SELECT column not covered by the
`GROUP BY` or wrapped in an aggregate) can reappear if a new column is
added to the query without checking whether it needs the same treatment.

## Real, confirmed bug #2: asymmetric EIP-side vs internal-side enrichment (fixed v2.4.3)

**Symptom**: the internal counterpart of a rule got full context
(`INTERNAL_ROUTING_DOMAIN`, `INTERNAL_APP`, real location data) via
`ipam_entries`/`asi_entries` lookups. The EXTERNAL IP itself -- even when
it was genuinely CVS/Aetna-owned space -- only got a boolean `CVS_OWNED`
flag, no location/app/heritage context, despite the exact same lookup
data being available.

**Fix**: `EIP_HERITAGE`, `EIP_LOCATION`, `EIP_MATCHED_SUBNET`, `EIP_APP`
added -- same real `ipam_entries`/`asi_entries` sources, same lookup
pattern already used for the internal side, applied symmetrically to the
external side. No extra lookup cost (reuses the same `lpm()` call that
already ran for the `cvs_owned` boolean).

## Real, confirmed architectural finding: the deprecated INTERNET-FACING file (removed v3.0.0)

`ent-ipdataset-INTERNET-FACING-v20260610.csv` was a real, hand-maintained
reference file (`PUB-IP-DOC` source) that had gone 76 days stale by the
time this was found, and was confirmed by the platform owner to be a
majorly deprecated dataset/function. It was used in TWO real, separate
places in this script -- fixing one without checking the other was
itself a real gap in an earlier pass:

1. The `CVS_OWNED`/`EIP_*` check (checked `inet_entries` first).
2. The internal counterpart's `lpm_tiered()` fallback chain (`inet_entries`
   was one of the tiers).

**Real replacement**: `ip_classification_ref` -- built through actual
cross-validation (real firewall rule zones, SNAT pools, F5 VIPs, host/
device master), not hand-maintained documentation. For (1), it's now the
authoritative check (`PUBLIC` or `PRIVATE` classification = CVS/Aetna-
owned); `ipam_entries` still supplies the separate location/app CONTEXT
fields, which `ip_classification_ref` doesn't carry. For (2),
`ip_classification_ref` can't structurally replace `inet_entries` (no
`ROUTING_DOMAIN`/location data, just a classification label + evidence)
-- it was removed from that fallback chain entirely rather than forced
into a role it can't fill; `ipam_entries`/`retail_entries` remain the
real sources there.

**As of this writing, `ent-ipdataset-INTERNET-FACING-*.csv` has been
formally retired from the ipam-db.py registry** (`--remove
ent_internet_facing`, confirmed real removal 2026-08-20). The file
itself is untouched on disk (removal only clears the registry entry) --
if any other script outside this session's real audit still references
it directly by file path rather than through the registry, that
reference is now pointing at a permanently-stale, unregistered file and
should be found and redirected to `ip_classification_ref` the same way.

**If a fix or feature seems to need `INTERNET-FACING`-style public/CVS-
owned classification**: use `ip_classification_ref` from the start. Do
not reintroduce the deprecated file as an input to any script.

## Real, confirmed operational gap: Ctrl-C handling and progress feedback (fixed v2.4.4)

This script (and `build_IP_Network_Egress_FW_topology.py`, a sibling
tool) had zero live progress feedback for any phase except
`enrich_records()`, and zero Ctrl-C handling -- an interrupt mid-run
produced a raw Python traceback with no indication of which phase it
died in. Real production impact: a live run of the topology script went
silent for 8+ minutes mid-loop after a later fix (retail_networks merge)
made that loop 12.6x larger, and was interrupted, reasonably assumed
hung.

Both scripts now share the same real pattern: a `_Heartbeat` class
(wall-clock "still running" messages every N seconds, for phases with no
natural iteration point) and a `_progress_bar()` helper (percent-based,
for loops with a known total), plus a top-level
`try/except KeyboardInterrupt` around the real entry point (clean
message, exit code 130, never a raw traceback). **If adding a new
long-running loop or phase to either script, apply this same pattern --
don't ship a silent phase.**

## Category-2-vs-3 blind spot — fixed across entire toolset (2026-08-21)

The core issue: `addr.is_private` returns False for CVS/Aetna-owned IANA
public blocks (167.69, 157.121, 204.99, 206.213, 198.187, 152.145) used
as PRIVATE space internally. Every tool using `is_private()`/`net.is_private`
to decide public vs private was misclassifying these as "public" — some
critically (validate_ip.py gates object creation; plugin_audit_patterns.py
gates audit findings).

**Real fix pattern (same across all tools fixed this session):**
1. Load `ip_classification_ref` via LPM (`load_ip_classification_ref()`)
2. Check real evidence FIRST — PRIVATE evidence → treat as private, PUBLIC → public
3. Fall back to `net.is_private` ONLY when no real evidence exists for that CIDR

**Tools fixed (2026-08-21):**
- `build_fw_location_topology.py` v1.3.0 — `is_public_ip()`
- `build_fw_snat_pools.py` v2.6.0 — `is_public()`
- `fwlookup.py` v1.20.0 — `show_ip_profile()` is_pub check
- `build_p2p_policy_map.py` v1.3.0 — `is_cvs_side()`
- `validate_ip.py` v0.2.0 — `route_as_private()` (gates object creation — most consequential)
- `plugin_audit_patterns.py` v1.1.0 — `is_public()` (gates audit findings)
- `preprocess_p1.py` v2.12.0 — `is_unowned_public_ip()` + 198.187/16 and 152.145/16
  added to KNOWN_PUBLIC_RANGES (were missing from the hardcoded allowlist)

**Also fixed in `build_ip_classification_ref.py` itself:**
- v1.6.0: WAN_EDGE removed from NDM evidence tier — SD-WAN routers have 11.0.0.0/8
  (CVS private SD-WAN platform space) in CONNECTED_SUBNETS → false PUBLIC
- v1.7.0: Evidence priority ordering fixed — INTERNAL_CIDRS was overriding confirmed
  positive FW-SNAT evidence. Real fix: collect all positive PUBLIC evidence first;
  PRIVATE-forcing signals only apply when NO positive evidence found.
