---
name: ipam-db
description: >
  CCD Platform — ipam-db.py operational reference. Use this skill for any task
  involving ipam-db.py: importing datasets, running cross-checks, applying patches,
  restoring backups, diffing versions, managing ENT ipdatasets, or interpreting
  cross-check violations. Covers all CLI flags, the full CX1–CX13 rule set with
  severities, the update-patch PATCH_ACTION model, and the mandatory operational
  gates. Trigger on: "ipam-db", "--import", "--cross-check", "--restore", "--update-patch",
  "--apply-patch", "--fix-interactive", "--diff", "CX violation", "HIGH violation",
  "cross-check failed", "import IPAM", "register dataset", "--sync", "--checksums",
  "txn_log", "dataset version", "ipam-db.json".
---

# ipam-db.py — Operational Reference

**Current version:** v3.15.10
**Location:** `~/Documents/IP_Lookup/ipam-db.py`
**Registry:** `~/Documents/IP_Lookup/ipam-db/ipam-db.json`

---

## 1. Non-Negotiable Operational Gates

These rules apply to every session. No exceptions.

| Gate | Rule |
|------|------|
| **--dry-run first** | Run `--dry-run` before every `--import`, `--update-patch`, or `--apply-patch` write |
| **0 HIGH required** | After every `--import`: run `--cross-check` and confirm 0 HIGH violations before any downstream work |
| **On HIGH violation** | Stop immediately — run `python3 ipam-db.py --restore <stem>` before touching anything else |
| **--version before running** | Confirm deployed version matches expected before executing any script |
| **Never delete manually** | Files are only removed via `PATCH_ACTION=REMOVE` or `--archive` — never `rm` |
| **Versioned filenames always** | `vbare` is a hard stop. Every dataset needs `vYYYYMMDD` or `vYYYYMMDDrN` |
| **Update order** | LM → IPAM → NDM → EHM → Infra → Platform — non-negotiable pipeline sequence |

---

## 2. Complete CLI Reference

### Core operations

```bash
# Version check — always run first
python3 ipam-db.py --version

# List all managed datasets and their current versions
python3 ipam-db.py --list

# Status summary — versions, row counts, stale flags
python3 ipam-db.py --status

# Dry-run an import (no writes)
python3 ipam-db.py --import <FILE> --type <STEM> --dry-run

# Import a dataset
python3 ipam-db.py --import <FILE> --type <STEM>

# Import with description note
python3 ipam-db.py --import <FILE> --type <STEM> --description "15 /16 blocks removed"

# Force overwrite (skip version-sequence guard — use with care)
python3 ipam-db.py --import <FILE> --type <STEM> --force
```

### Cross-check

```bash
# Full cross-check against registered datasets
python3 ipam-db.py --cross-check

# Cross-check against specific files (override auto-discovery)
python3 ipam-db.py --cross-check \
    --ain-path ./ipam-db/all_IP_networks_v20260611r2.csv \
    --lm-path  ./ipam-db/location_master_v5.22.csv

# Cross-check with retail and CSNA inputs
python3 ipam-db.py --cross-check --retail-path <FILE> --csna-path <FILE>
```

### Patching

```bash
# Apply a fix-interactive patch (requires --apply-patch to execute)
python3 ipam-db.py --apply-patch <PATCH_CSV>

# Update-patch with ADD/REMOVE actions (dry-run first)
python3 ipam-db.py --update-patch <PATCH_CSV> --dry-run
python3 ipam-db.py --update-patch <PATCH_CSV>

# Patch-ext-refs: full-replace EIR external CIDR references
python3 ipam-db.py --patch-ext-refs <EIR_CSV>

# Interactive fix session for CX violations
python3 ipam-db.py --fix-interactive
python3 ipam-db.py --fix-interactive --skip-audit   # skip pre-flight audit
```

### Backup and restore

```bash
# Manual backup snapshot
python3 ipam-db.py --backup

# List all backup snapshots
python3 ipam-db.py --list-backups

# Restore a single dataset to most recent prior version
python3 ipam-db.py --restore all_IP_networks
python3 ipam-db.py --restore all_IP_networks --force   # skip confirmation

# Restore full snapshot (ipam-db/ + ipdatasets/) by timestamp
python3 ipam-db.py --restore 20260611T142300
```

### Diff and audit

```bash
# Diff current vs prior version of a dataset
python3 ipam-db.py --diff all_IP_networks

# Diff two specific timestamps
python3 ipam-db.py --diff 20260610T090000 20260611T142300

# Dataset-level diff (row changes between versions)
python3 ipam-db.py --diff-dataset all_IP_networks

# Checksum verification
python3 ipam-db.py --checksums

# Initialize checksums (first-time setup)
python3 ipam-db.py --checksum-init
```

### Registry management

```bash
# Sync registry with actual files on disk (reconcile ipam-db.json)
python3 ipam-db.py --sync

# Resolve a stem — show current registered path
python3 ipam-db.py --resolve all_IP_networks

# Remove a stem from registry (does not delete file)
python3 ipam-db.py --remove <STEM>

# Deregister a stem
python3 ipam-db.py --deregister <STEM>

# Archive superseded versions
python3 ipam-db.py --archive

# Clear stale flag for a block
python3 ipam-db.py --clear-stale <BLOCK>

# Plan next import (show what version number would be assigned)
python3 ipam-db.py --plan
```

### ENT ipdataset operations

```bash
# Import an ENT ipdataset
python3 ipam-db.py --import ./ipdatasets/ent-ipdataset-NAME-vDATE.csv --type ent-ipdataset

# Refresh cloud range feeds (Zscaler, Imperva, AWS, GCP, etc.)
python3 ipam-db.py --refresh-feeds

# Update cloud CIDR ranges from a specific file
python3 ipam-db.py --update-cloud-ranges <FILE>

# Cleanup superseded ipdatasets
python3 ipam-db.py --cleanup-datasets
```

---

## 3. Dataset Types (--type STEM values)

| STEM | Dataset | Pipeline position |
|------|---------|-------------------|
| `all_IP_networks` | Enterprise IPAM (non-retail subnets) | 2nd (after LM) |
| `location_master` | Site/location registry | 1st — root of model |
| `retail_networks` | Retail store /26 subnets | Parallel to IPAM |
| `ent_host_master` | Application server /32 hosts | 4th |
| `delivery_infrastructure` | ESXi/HMC/iSeries hosts | 5th |
| `delivery_platform` | K8s/Docker/OCP nodes | 5th |
| `app_subnet_index` | /24 → app context mapping | Derived; rebuild after EHM update |
| `csna_site_registry` | Stealthwatch host group registry | Derived |
| `ent_qualys_scanners` | Qualys scanner IPs | ENT ipdataset |
| `ent-ipdataset` | Generic ENT ipdataset import | Registered in ip_dataset.json |
| `placeholder_networks` | LM locations with no subnets yet | Supplementary |
| `mgmt_ip_index` | OOB/management-plane subnets | Supplementary |

---

## 4. Cross-Check Rules (CX1–CX13)

Run after every import. 0 HIGH is the gate. MEDIUMs are tracked; LOWs are informational.

| Rule | Severity | What it checks |
|------|----------|----------------|
| **CX1-AIN-LM-COVERAGE** | HIGH | Every CIDR in all_IP_networks must have a SITE_CODE that exists in location_master |
| **CX2-RETAIL-LM-COVERAGE** | HIGH | Every retail_networks entry must resolve to an LM SITE_CODE |
| **CX3-LM-REGISTRY** | MEDIUM | Infrastructure LM entries (DC/CI/etc.) must have at least one subnet registered |
| **CX4-TYPE-SYNC** | MEDIUM | csna_site_registry SITE_CLASS must match LM LOCATION_TYPE for the same site |
| **CX5-RETAIL-ISOLATION** | HIGH | 172.16/12 subnets with retail store coverage must not appear in all_IP_networks |
| **CX6-LM-ORPHAN** | LOW | LM entries with no subnets in IPAM or retail_networks |
| **CX7-REGISTRY-LM-BACK** | MEDIUM | csna_site_registry entries that have no matching LM entry (orphaned) |
| **CX8-HMR-REVIEW** | LOW | LM entries with LOCATION_TYPE=HMR flagged for human review |
| **CX10-LM-SC-UNIQUE** | HIGH | SITE_CODE must be unique within location_master |
| **CX11-INTERNET-FACING** | HIGH | Known CVS/Aetna public blocks (157.121/16, 167.69/16, 206.213/16, 204.99/16) must have ROUTING_DOMAIN=Internet-Facing |
| **CX12-CONTESTED-MISSING** | MEDIUM | 172.16.0.0/12 entries with overlap between routing domains missing explicit contest resolution |
| **CX13-NET-TYPE-SC-MISMATCH** | MEDIUM | NET_TYPE in all_IP_networks must be consistent with the LOCATION_TYPE of its SITE_CODE FK in LM |

### CX13 note — known MEDIUM pre-conditions (275 as of v20260611r2)
- 258 × CX13-NET-TYPE-SC-MISMATCH: Corporate subnets at Partner/Cloud/NAAS sites — architectural; not errors
- 13 × CX4-TYPE-SYNC: CSNA SITE_CLASS vs LM LOCATION_TYPE delta (pre-existing)
- 4 × CX7-REGISTRY-LM-BACK: orphaned CSNA entries (pre-existing)

These 275 MEDIUMs are the **known clean baseline**. Any new violations introduced by an import indicate a real problem.

---

## 5. update-patch PATCH_ACTION Model (v3.15.10+)

The `--update-patch` mechanism is the **only** approved path for adding or removing rows from all_IP_networks. Never edit the CSV directly.

### Patch CSV format

```
CIDR,CANONICAL_LOCATION,SITE_CODE,ROUTING_DOMAIN,NET_TYPE,HERITAGE,PATCH_ACTION
10.232.0.0/16,Glasgow KY - Distribution Center,US_GLA_KY_DC,Internal-PBM,DataCenter,CVS,REMOVE
10.232.5.0/24,Glasgow KY - Distribution Center,US_GLA_KY_DC,Internal-PBM,Application,CVS,ADD
```

| PATCH_ACTION | Behavior |
|---|---|
| `ADD` | Validates against LM, checks for overlaps, runs parent-safety check, adds row |
| `REMOVE` | Runs parent-safety check: blocks removal if children exist without their own SITE_CODE at /29 or larger; self-anchored children (/28+) are safe |

### Self-anchor rule
A child subnet is self-anchored (safe to remove its /16 parent) when it either:
- Has its own SITE_CODE AND prefix ≥ /28, OR
- Is a registered IPAM entry at /24 or larger

P2P links (/29–/31) without a SITE_CODE require a covering /24 parent.

### Execution sequence
```bash
python3 ipam-db.py --update-patch patch.csv --dry-run   # always first
python3 ipam-db.py --update-patch patch.csv             # execute
python3 ipam-db.py --cross-check                        # confirm 0 HIGH
```

---

## 6. Auto-behavior on Import (v3.15.x)

| Behavior | Triggered by |
|----------|-------------|
| Auto-backup | Every non-dry-run `--import` (v3.15.6+) |
| Auto-diff | Every `--import`: calls `do_diff_dataset` inline and shows row delta (v3.15.0+) |
| Auto-cross-check | Every `--import` of `all_IP_networks` (even with `--dry-run`, uses temp file) |
| Version bump | `--import` auto-assigns next `vYYYYMMDDrN` if same-day |
| txn_log entry | Every write operation — SHA-256 hash recorded in transaction log |
| extrasaction='ignore' | Extra columns in patch CSV are silently ignored (v3.15.10 crash fix) |

---

## 7. Managed Stems — Known Current State (EOD June 11, 2026)

| Dataset | Version | Rows | Status |
|---------|---------|------|--------|
| all_IP_networks | v20260611r2 | 24,935 | Clean — 0 HIGH |
| location_master | v5.22 | 11,570 | Current |
| ent_host_master | v20260525r11 | 51,100 | Current |
| delivery_infrastructure | v20260504r9 | 5,763 | Current |
| delivery_platform | v20260504r6 | 1,875 | Current |
| app_subnet_index | v20260610r2 | 2,608 | **STALE** — rebuild from EHM r11 required |
| ent_qualys_scanners | v20260608 | 93 | Current |
| retail_networks | v2.9 | — | Current |
| csna_site_registry | v2.30 | 102,560 rows / 5,906 host groups | Current |

---

## 8. Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| HIGH violation after import | Wrong SITE_CODE, missing LM entry, retail subnet in IPAM | `--restore <stem>`, investigate, fix source, reimport |
| `extrasaction` crash on `--update-patch` | Extra columns in patch CSV | Fixed in v3.15.10 — confirm version |
| `_DIFF_CONFIG` key error | Mismatched diff key column | Fixed for `ent_qualys_scanners` in v3.15.9 (key = IP_NETWORK not IP_ADDRESS) |
| `vbare` rejection | Missing version stamp | Rename file to include `vYYYYMMDD` before import |
| Registry out of sync with disk | Manual file moves / session interruption | `python3 ipam-db.py --sync` |
| Stale flag blocking downstream | Prior session wrote dataset but downstream not rebuilt | `--clear-stale <BLOCK>` after rebuilding downstream |
| Cross-check fires on dry-run | Expected — uses temp file for validation (v3.14.1 fix) | Normal behavior; verify violations are pre-existing MEDIUMs only |
