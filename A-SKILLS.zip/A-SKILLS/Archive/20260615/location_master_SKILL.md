---
name: location-master
description: >
  CVS Health CCD Platform — Location Master (LM) reference. Use this skill
  for any task involving location_master data: adding or updating LM entries,
  deriving SITE_CODEs, resolving CANONICAL_NAME values, validating locations
  against the LM, understanding SITE_CODE suffix conventions, or debugging
  CX1/CX2/CX6 location integrity violations. Trigger on: "location_master",
  "SITE_CODE", "CANONICAL_LOCATION", "CANONICAL_NAME", "location not in LM",
  "CX2 violation", "what site code", "LM entry", "add a location".
---

# Location Master — Complete Reference

## 1. What the LM Is

The Location Master is the root of the entire CCD Platform data model. Every
physical and logical site in CVS Health's enterprise. **Nothing enters any
downstream dataset (IPAM, EHM, NDM, retail_networks) without a
CANONICAL_LOCATION that resolves exactly to an active LM entry.**

**Current version:** v5.11  **Rows:** 11,527

Hard gate: `CANONICAL_LOCATION` must exist in LM before any subnet or host
row is committed. Blank or unresolvable = CX1/CX2 HIGH violation, import blocked.

---

## 2. Key Fields

| Field | Purpose |
|-------|---------|
| `SITE_CODE` | Primary key. Format: `CC_CCC_ST_SUFFIX[N]` |
| `CANONICAL_NAME` | Human-readable name. Used as `CANONICAL_LOCATION` in all downstream datasets |
| `LOCATION_TYPE` | Controlled vocabulary — see §4 |
| `HERITAGE` | CVS / AETNA / OMNICARE / OSH / CAREMARK / SWITCH / PARTNER |
| `STATUS` | Active / Retired / Decom-Candidate |
| `CITY` | City name |
| `STATE` | 2-letter state code |
| `COUNTRY` | 2-letter country code (US, IE, PH) |
| `NET_TYPE` | Operational network type (see §5) |
| `HOSTNAME_PREFIX` | Used by hostname_translate.py T5 resolver |
| `FACILITY_OWNER` | Physical facility operator (Switch, Iron Mountain, Equinix, etc.) |
| `CSNA_SITE_NAME` | Stealthwatch site name |
| `NMS_PATH_FRAGMENT` | NetBrain/NMS path fragment for device discovery |
| `BASE_IP` | Representative IP for NMS-based location derivation |

---

## 3. SITE_CODE Format

```
CC_CCC_ST_TYPE[N]
│   │   │  │   └─ Optional disambiguator (1, 2, 3... or HP1, CO3, etc.)
│   │   │  └──── Location type suffix (see §3.1)
│   │   └─────── State/region code (2 chars)
│   └─────────── City abbreviation (3–5 chars)
└─────────────── Country code (US, IE, PH)
```

**Examples:**
```
US_WIN_CT_DC     Windsor CT - Aetna WDC          (Datacenter)
US_MIC_CT_DC     Middletown CT - Aetna MDC        (Datacenter)
US_SCO_AZ_DC     Scottsdale AZ - Shea DC          (Datacenter)
US_LVG_NV_CI     Las Vegas NV - Switch Colo       (COLO)
US_HFD_CT_CO1    Hartford CT - Aetna HQ           (Corporate)
US_TX_06752_RT   Houston TX - Store 06752         (Retail)
US_AZR_UE2_IS    Cloud - Azure East US 2          (IaaS cloud)
```

### 3.1 Type Suffix Taxonomy

**CRITICAL: Use the exact suffix from the table below. Wrong suffix = CX2 violation.**

| Suffix | Meaning | Used for | Example |
|--------|---------|----------|---------|
| `_DC` | On-premises Datacenter | DC/server rooms with network infrastructure | `US_SCO_AZ_DC` |
| `_CI` | COLO Infrastructure | Co-location vendor facilities (Switch, Equinix, Iron Mountain) | `US_LVG_NV_CI` |
| `_CO` | Corporate office (single) | Office/campus locations | `US_HPT_NC_CO` |
| `_CO1`, `_CO2`... | Corporate (multiple at city) | When a city has >1 corporate location | `US_CUR_RI_CO4` |
| `_IS` | IaaS cloud site | **Azure, GCP, AWS ONLY** — never for on-prem | `US_AZR_UE2_IS` |
| `_RT` | Retail store | CVS retail stores (with store number) | `US_TX_06752_RT` |
| `_MC` | MinuteClinic | MinuteClinic locations (with store number) | `US_AL_04372_MC` |
| `_OPT` | Optical | CVS Optical locations | `US_CA_00550_OPT` |
| `_HP` | CarePlus/HealthPlan | CarePlus field sites | `US_ALL_PA_HP` |
| `_HP1`, `_HP2`... | CarePlus (multiple at city) | | `US_CHD_AZ_HP1` |
| `_SP` | Specialty/Coram | Coram infusion/specialty pharmacy | `US_COM_MD_SP` |
| `_RD` | Distribution Center | CVS distribution centers | `US_AUG_GA_RD` |
| `_MO` | Mail Order | Mail order pharmacy facilities | `US_MPR_IL_MO` |
| `_DR` | Disaster Recovery | DR sites (SunGard, etc.) | `US_PHL_PA_DR` |
| `_CVS-CC` | CVS Call Center | CVS-operated call centers | `US_CHD_AZ_CVS-CC` |
| `_INS-CC` | Insurance Call Center | Aetna-operated call centers | `US_ANC_AK_INS-CC` |
| `_TP` | Third-Party/Partner | Offshore and external partner sites | `US_BEA_AR_TP` |
| `_F9-NH` | Five9 NAAS Hub | Five9 VoIP hub (Network-as-a-Service) | `US_SCA_CA_F9-NH` |
| `_AZU-NH` | Azure ExpressRoute NH | Azure NAAS/ExpressRoute hubs | `US_NKC_MO_AZU-NH` |

### 3.2 Retail Store SITE_CODE Format

Retail stores use state code + zero-padded store number (not city abbreviation):

```
US_[STATE]_[STORE_NUM]_RT      e.g.  US_TX_06752_RT
US_[STATE]_[STORE_NUM]_MC      e.g.  US_AL_04372_MC
US_[STATE]_[STORE_NUM]_OPT     e.g.  US_CA_00550_OPT
```

---

## 4. CANONICAL_NAME Format

Format: `{City} {State} - {Description}`

The CANONICAL_NAME is used verbatim as `CANONICAL_LOCATION` in all downstream
datasets. Case and punctuation must match exactly.

```
Windsor CT - Aetna WDC
Middletown CT - Aetna MDC
Scottsdale AZ - Shea DC
Las Vegas NV - Switch Colo          ← not "Switch DC" or "Switch COLO"
Hartford CT - Aetna HQ              ← not "Hartford CT - Corporate" (that's a different entry)
Cumberland RI - 2100 Highland
Woonsocket RI - RI One
Ashburn VA - Equinix                ← not "Ashburn VA - Equinix PSS"
```

**Common wrong names that will fail CX2:**
```
❌ "Hartford CT - Corporate"        → ✓ "Hartford CT - Aetna HQ"
❌ "Cumberland RI - Highland Lab"   → ✓ "Cumberland RI - 2100 Highland"
❌ "Las Vegas NV - Switch DC"       → ✓ "Las Vegas NV - Switch Colo"
❌ "Las Vegas NV - Switch COLO"     → ✓ "Las Vegas NV - Switch Colo"
❌ "Raleigh NC - Omnicare"          → ✓ "Raleigh NC - Specialty"
❌ "Wilkes Barre PA - Mail Order"   → ✓ "Wilkes-Barre PA - Mail Order"
❌ "Wellesley MA - Corporate"       → ✓ "Wellesley MA - Aetna Corporate"
❌ "Ashburn VA - Equinix PSS"       → ✓ "Ashburn VA - Equinix"
```

---

## 5. All Active DC and COLO Entries

### On-Premises Datacenters (_DC)

| SITE_CODE | CANONICAL_NAME | Heritage |
|-----------|----------------|----------|
| `US_SCO_AZ_DC` | Scottsdale AZ - Shea DC | CVS |
| `US_WOR_RI_DC` | Woonsocket RI - RI One | CVS |
| `US_CUR_RI_DC` | Cumberland RI - 2100 Highland | CVS |
| `US_MIC_CT_DC` | Middletown CT - Aetna MDC | AETNA |
| `US_WIN_CT_DC` | Windsor CT - Aetna WDC | AETNA |
| `US_PHX_AZ_DC` | Phoenix AZ - Aetna DC | AETNA |
| `US_ATL_GA_DC` | Atlanta GA - Aetna DC | SWITCH |
| `US_WOI_IL_DC` | Wood Dale IL - CVS DC | CVS |

### COLO Facilities (_CI)

| SITE_CODE | CANONICAL_NAME | Heritage |
|-----------|----------------|----------|
| `US_LVG_NV_CI` | Las Vegas NV - Switch Colo | SWITCH |
| `US_ATL_GA_CI` | Atlanta GA - Switch COLO | PARTNER |
| `US_SPK_NV_CI` | Sparks NV - Switch TRE | SWITCH |
| `US_IAD_VA_CI` | Ashburn VA - Equinix | CVS |
| `US_DFW_TX_CI` | Dallas TX - Equinix | CVS |
| `US_WDB_NJ_CI` | Woodbridge NJ - Iron Mountain | AETNA |
| `US_CAR_NJ_CI` | Carlstadt NJ - DC | CVS |
| `US_EDW_IL_CI` | Edwardsville IL - WWT COLO | CVS |

### Key Corporate/HQ Sites

| SITE_CODE | CANONICAL_NAME | Note |
|-----------|----------------|------|
| `US_HFD_CT_CO1` | Hartford CT - Aetna HQ | Aetna HQ — Corporate, NOT Datacenter |
| `US_WEL_MA_CO1` | Wellesley MA - Aetna Corporate | Aetna corporate |
| `US_SCO_AZ_CO3` | Scottsdale AZ - Shea Campus | Campus offices near Shea DC |

---

## 6. Cloud / IaaS Entries (_IS suffix)

`_IS` suffix is **only** for cloud provider virtual sites:

| SITE_CODE | CANONICAL_NAME |
|-----------|----------------|
| `US_AZR_UE2_IS` | Cloud - Azure East US 2 |
| `US_AZR_UEC_IS` | Cloud - Azure Central US |
| `US_AZR_USW_IS` | Cloud - Azure West US |
| `US_GCP_USE4_IS` | Cloud - GCP US-East4 |
| `US_GCP_USW2_IS` | Cloud - GCP US-West2 |
| `US_GCP_USE1_IS` | Cloud - GCP US-East1 |
| `US_GCP_UEC1_IS` | Cloud - GCP US-Central1 |
| `US_AWS_USE1_IS` | Cloud - AWS US-East1 |
| `US_AWS_USE2_IS` | Cloud - AWS US-East2 |

**Never use `_IS` for on-premises or COLO sites.** On-prem DCs use `_DC`. COLO uses `_CI`.

---

## 7. LOCATION_TYPE Controlled Vocabulary

| Value | Description |
|-------|-------------|
| `Retail` | CVS retail store |
| `MinuteClinic` | MinuteClinic location |
| `Optical` | CVS Optical |
| `Corporate` | Corporate office / campus |
| `Datacenter` | On-premises datacenter |
| `CI` | COLO / co-location facility |
| `IS` | IaaS cloud (Azure/GCP/AWS) |
| `CarePlus` | CarePlus HMO field site |
| `Omnicare` | Omnicare pharmacy operations |
| `Specialty` | Specialty pharmacy / Coram |
| `Distribution` | Distribution center |
| `Field-Office` | Small field office |
| `Field-Clinic` | Oak Street Health / clinical |
| `Call-Center` | Call center |
| `Mail-Order` | Mail order pharmacy |
| `DR` | Disaster recovery site |
| `Partner` | Third-party / offshore partner |
| `NH` | NAAS-Hub (Five9, Azure ExpressRoute) |

---

## 8. HERITAGE Values

| Value | Meaning |
|-------|---------|
| `CVS` | CVS Health / Caremark heritage (10,000+ locations — mostly retail) |
| `AETNA` | Aetna heritage |
| `OMNICARE` | Omnicare |
| `OSH` | Oak Street Health |
| `CAREMARK` | Caremark legacy (pre-merger) |
| `SWITCH` | Switch network/COLO provider |
| `PARTNER` | External partner / third-party |
| `CVS\|AETNA` | Dual-heritage (shared campus) |

---

## 9. Update Rules

1. **Never edit CANONICAL_NAME once downstream data references it.** Rename
   requires a sweep of all_IP_networks, EHM, NDM, retail_networks to update
   CANONICAL_LOCATION. Run `ehm_enhancement_patch` after any rename.

2. **SITE_CODE is immutable once assigned.** Never reuse a SITE_CODE.

3. **STATUS transitions:** Active → Retired requires verifying zero active
   IPAM entries at that location. Retired → Decom-Candidate requires 90-day
   hold. Never hard-delete — set STATUS=Retired.

4. **New LM entry required before:** adding a subnet in IPAM, adding a host
   in EHM, or adding a retail store in retail_networks. CX6 fires HIGH if
   an IPAM entry references a location with no LM entry.

5. **LM is updated first in the pipeline:**
   `LM → IPAM → NDM → EHM → Infra → Platform → CSNA`

---

## 10. Common Lookup Patterns

### Find the SITE_CODE for a location name
```bash
iplookup.sh --sc-list | grep -i "Windsor"
iplookup.sh --sc 'US_WIN_CT_DC'
```

### Verify a location exists in LM before adding to IPAM
```python
lm_names = {r['CANONICAL_NAME'] for r in lm_rows}
assert loc in lm_names, f"CX2: {loc} not in LM"
```

### Find all IPAM entries for a location
```bash
iplookup.sh --sc-subnets US_MIC_CT_DC
iplookup.sh -loc 'Middletown CT - Aetna MDC'
```

---

## 11. Frequent Mistakes

| Mistake | Correct |
|---------|---------|
| Using `_IS` for on-prem DC | Use `_DC` for datacenters |
| Using `_IS` for COLO | Use `_CI` for co-location |
| `US_MID_CT_DC` for Middletown | Correct is `US_MIC_CT_DC` (MID→MIC) |
| `US_PHX_AZ_IS` for Phoenix Aetna DC | Correct is `US_PHX_AZ_DC` |
| `US_WIN_CT_IS` for Windsor WDC | Correct is `US_WIN_CT_DC` |
| `US_HFD_CT_IS` for Hartford | Correct is `US_HFD_CT_CO1` (it's Corporate) |
| Bare `_CO` for Hartford | Hartford has `_CO1` — multiple sites |
| "Hartford CT - Corporate" | LM name is "Hartford CT - Aetna HQ" |
| "Las Vegas NV - Switch DC" | LM name is "Las Vegas NV - Switch Colo" |
| Adding subnet before LM entry exists | LM must exist first — hard gate |

---

## 12. LM vs IPAM: Location Derivation Rule

**Location is always derived from IP via NMS/LPM. Never from server owner field.**

The location derivation order:
1. IPAM LPM match → `CANONICAL_LOCATION` from matching subnet
2. Hostname translation (T5 resolver) → prefix registry → LM `HOSTNAME_PREFIX`
3. NMS path fragment → `NMS_PATH_FRAGMENT` in LM
4. Manual assignment (last resort, requires review)

**The server owner field in CMDB is NOT authoritative for location.** It reflects
organizational ownership, not physical or network location. A Scottsdale-owned
server physically running in Windsor must carry Windsor as its CANONICAL_LOCATION.

---

## LM Anchor Validation (preflight_lm_check.py)

`preflight_lm_check.py` v1.0.0 runs automatically before every `update_ipam.py`
write. Hard-stops with exit code 1 if any of the 20 critical anchors are missing
or have blank CANONICAL_NAME in the LM.

**20 required anchors:**

| Category | SITE_CODEs |
|---|---|
| Primary DCs | US_CUR_RI_DC, US_WOR_RI_DC, US_MIC_CT_DC, US_WIN_CT_DC, US_SCO_AZ_DC, US_ATL_GA_DC, US_PHX_AZ_DC |
| COLO | US_LVG_NV_CI, US_ATL_GA_CI, US_SPK_NV_CI, US_IAD_VA_CI, US_WDB_NJ_CI, US_CAR_NJ_CI, US_DFW_TX_CI |
| DR | US_WOO_RI_DR, US_WAT_MA_DR, US_WDB_NJ_DR, US_CDT_NJ_DR, US_PHL_PA_DR |
| NAAS Hub | US_SCA_CA_F9-NH |

Run standalone:
```bash
python3 preflight_lm_check.py --lm ./ipam-db/location_master_v5_10r1.csv
```

---

## LM Hierarchy Validation

The IPAM hierarchy audit (audit_ipam_hierarchy.py) cross-references the LM to:
1. Validate every child CANONICAL_LOCATION in each parent block exists in LM
2. Show LM LOCATION_TYPE distribution (Datacenter, IS, COLO, Corporate) per block
3. Confirm LM integrity before remediation actions

Current state: 617/617 parent blocks have all children validated against LM (0 CX1 violations).

