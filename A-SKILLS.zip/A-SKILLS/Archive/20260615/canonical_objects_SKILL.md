---
name: canonical-object-intent-model
description: >
  CCD Platform — Canonical Object Library and Intent-Based Policy Model
  (CVS Health Information Security). Use this skill for any task involving
  the canonical object library design, {PROVIDED}/{CONSUMES} dependency
  modelling, intent-based firewall policy translation, CPC service dataset
  design, or the relationship between APP/INFRA/DELIVERY/SERVICE objects
  and downstream policy generation. Trigger on: "canonical objects",
  "intent-based policy", "PROVIDED", "CONSUMES", "object dependency",
  "CPC services", "service catalog", "policy translation", "permit IP port",
  "APP object", "INFRA object", "DELIVERY object", "SERVICE object",
  "external service", "ext_canonical_objects", "build_canonical_app_objects",
  "object model", "dependency graph", "firewall intent".
---

# Canonical Object Library — Intent-Based Policy Model

## 1. Purpose and Core Problem

The CVS/Aetna firewall estate contains ~25,000+ rules expressed as
`permit source-IP destination-IP port` with additive, change-ticket-named
address objects (e.g. `infosys-access-PBM19166`, `PBM10599-SPLUNK-EXT_split_3`).
These rules:
- Cannot be audited for intent — no one knows what business function a rule serves
- Cannot be safely cleaned — removing a rule may break an unknown dependency
- Cannot be migrated — there is no machine-readable statement of what any application needs

**The canonical object library is the foundation for solving this.** It provides
a ground-truth, authoritative, dataset-derived object model that expresses
compute structures and their dependencies in terms a policy engine can consume.

**Delivery outcome:** An application owner can declare:
> "I provide this capability on these ports. I depend on these applications,
> services, infrastructure, and delivery systems."

From that declaration, a policy engine generates all required firewall rules —
no manual rule authoring, no stale ticket-named objects, no permit-any.

---

## 2. Object Taxonomy

Four internal object types plus one external. These are NOT interchangeable
and must not be mixed.

### 2.1 APP Object
**What it is:** The /32 IP addresses of application workload instances —
the servers running the business application code.

**Naming:** `APP_{ACRONYM}_{RD_SHORT}` / `APP_{ACRONYM}_{RD_SHORT}_NP`

**Keyed on:** PRIMARY_ACRONYM from ent_host_master, grouped by ROUTING_DOMAIN.

**Example:**
```
APP_RXCONNECT_PBM     530 IPs  225 VIPs   (RxConnect pharmacy, Internal-PBM)
APP_RXCONNECT_HCB      18 IPs    0 VIPs   (RxConnect, Internal-HCB)
```

### 2.2 INFRA Object
**What it is:** The /32 addresses of compute infrastructure — ESXi hypervisors,
bare metal, HMC, iSeries LPARs, Isilon storage controllers. The hardware/VM
layer that applications run ON. Not applications themselves.

**Naming:** `INFRA_{PLATFORM}_{LOCATION}_{ENV}`

**Keyed on:** delivery_infrastructure, grouped by SERVER_CLASS + CANONICAL_LOCATION + ENV.

**Example:**
```
INFRA_ESXI_SHEA_PROD      418 IPs   (ESXi hosts, Shea DC, production)
INFRA_IBM_ISERIES_SHEA     59 IPs   (iSeries LPARs, Shea DC)
```

### 2.3 DELIVERY Object
**What it is:** The /32 addresses of the delivery/platform layer — Kubernetes
worker nodes, OpenShift cluster members, DataPower gateways, F5 pool members,
IIB brokers. The middleware that delivers applications to consumers.

**Naming:** `DELIVERY_{PLATFORM}_{CONTEXT}_{LOCATION}_{ENV}`

**Keyed on:** delivery_platform, grouped by PLATFORM_TYPE + CANONICAL_LOCATION + ENV.

**Example:**
```
DELIVERY_OCP_PBM_SHEA_PROD     80 IPs   (OpenShift nodes, Shea DC, prod)
DELIVERY_GKE_GCP_USE4_PROD    600 IPs   (GKE workers, GCP US-East4, prod)
DELIVERY_DATAPOWER_PBM         34 IPs   (DataPower gateways, Internal-PBM)
```

### 2.4 SERVICE Object
**What it is:** Shared enterprise services consumed by applications and
infrastructure across the enterprise. Logical services with a well-known
function. Not application-specific — consumed by many APP/INFRA/DELIVERY objects.

**The CPC service list is the canonical inventory of these objects.**
See §5 for the full model.

**Naming:** `SVC_{SERVICE}_{HERITAGE}` (heritage suffix only where service
runs separate instances per-heritage)

**Example:**
```
SVC_AD_DC_CVS        53 IPs   (CVS Active Directory domain controllers)
SVC_QUALYS_CVS      103 IPs   (Qualys scanner appliances, CVS)
SVC_CENTRIFY_CVS    104 IPs   (Centrify connectors, CVS)
SVC_CROWDSTRIKE      --        (pending — agent-based, needs collector IPs)
SVC_TANIUM           --        (pending — agent-based, needs server IPs)
```

### 2.5 EXTERNAL Object (ext_canonical_objects)
**What it is:** Externally hosted services consumed by internal applications.
The modern equivalent of the CPC service list but for the outside world.
Not owned or operated by CVS.

**Naming:** `EXT_{PROVIDER}_{SERVICE}` or `EXT_{PROVIDER}_{REGION}`

**Current inventory:** 121 registered objects in ext_canonical_objects_v20260524.csv

**Examples:**
```
EXT_AWS_S3_USE1           Amazon S3, US-East-1
EXT_GCP_COMPUTE_USE4      GCP compute API endpoints
EXT_SALESFORCE_API        Salesforce API
EXT_OKTA                  Okta identity service
EXT_GITHUB                GitHub.com
```

---

## 3. The {PROVIDED} / {CONSUMES} Model

Every canonical object carries two dependency declarations.

### 3.1 {PROVIDED} — What this object exposes

The ports, protocols, and logical capability this object offers to consumers.
Expressed as a structured port/protocol specification.

**Sources:**
- CPC-CORE-SERVICES port definitions (for SERVICE objects)
- CPC-SERVICE-FLOWS port columns (protocol/port the service accepts)
- F5-VIP-REGISTRY (VIP port → pool member port mappings for APP objects)
- Manual declaration by application owner (aspirational)

**Example:**
```
APP_RXCONNECT_PBM   PROVIDED: 443/TCP, 8443/TCP, 8080/TCP
SVC_AD_DC_CVS       PROVIDED: 389/TCP-UDP, 636/TCP, 88/TCP-UDP, 445/TCP, 3268/TCP
SVC_QUALYS_CVS      PROVIDED: 443/TCP (inbound scan), 902/TCP
```

### 3.2 {CONSUMES} — What this object depends on

A structured dependency list across five categories. This is the core of
intent-based policy — from {CONSUMES}, a policy engine generates all
required allow rules.

```
CONSUMES_APPS       Other APP objects this application depends on
CONSUMES_INFRA      INFRA objects this application runs on
CONSUMES_DELIVERY   DELIVERY objects used by this application
CONSUMES_SERVICES   Internal SERVICE objects consumed (SVC_*)
CONSUMES_EXTERNAL   External service objects consumed (EXT_*)
```

**Example:**
```
APP_RXCONNECT_PBM
  CONSUMES_APPS:      APP_RXCLAIMADJUDICATION_PBM | APP_DISPENSINGPPS_PBM
  CONSUMES_INFRA:     INFRA_ESXI_SHEA_PROD | INFRA_ESXI_RIONE_PROD
  CONSUMES_DELIVERY:  DELIVERY_OCP_PBM_SHEA_PROD | DELIVERY_DATAPOWER_PBM
  CONSUMES_SERVICES:  SVC_AD_DC_CVS | SVC_QUALYS_CVS | SVC_CENTRIFY_CVS
                      | SVC_SPLUNK_CVS | SVC_NTP_CVS
  CONSUMES_EXTERNAL:  EXT_AWS_S3_USE1
```

---

## 4. Policy Translation

The canonical object model is the input to intent-based policy generation.

### 4.1 Translation logic

```
For each object O with CONSUMES_SERVICES = [SVC_CENTRIFY_CVS, SVC_AD_DC_CVS, ...]:

  For each service S in CONSUMES_SERVICES:
    Look up CPC-SERVICE-FLOWS WHERE SERVICE_SLUG matches S
    → Get required PORTS and PROTOCOL
    → Generate allow rule: O.MEMBER_IPS → S.MEMBER_IPS on PORTS/PROTOCOL

  For each app dependency A in CONSUMES_APPS:
    Look up A.PROVIDED_PORTS
    → Generate allow rule: O.MEMBER_IPS → A.MEMBER_IPS on A.PROVIDED_PORTS

  For each external service E in CONSUMES_EXTERNAL:
    Look up E.MEMBER_IPS (CIDRs from ext_canonical_objects)
    → Generate allow rule: O.MEMBER_IPS → E.MEMBER_IPS on E.PROVIDED_PORTS
```

### 4.2 What CPC-SERVICE-FLOWS actually is (corrected framing)

**CPC-SERVICE-FLOWS is the policy profile for SERVICE objects.**

It answers: "When an object declares it CONSUMES service X, what specific
flows must be permitted?" It is NOT a record of which objects consume which
services. It is the enforcement specification — the lookup table used by the
policy engine when it encounters a CONSUMES_SERVICES declaration.

```
Object declares: CONSUMES_SERVICES = SVC_CENTRIFY_CVS
Policy engine looks up: CPC-SERVICE-FLOWS WHERE SERVICE_SLUG = 'centrify'
  → CEN.FE.1: agent → connector 8080,8443/TCP
  → CEN.FE.3: agent → AD DCs 445,88,389/TCP
Generates rules accordingly.
```

**It was previously framed as firewall rules (output), not policy profiles (input).
This reframing is architecturally correct and does not require changing the data —
only how it is consumed.**

---

## 5. The CPC Service Dataset — Correct Design

### 5.1 What CPC-CORE-SERVICES is (and should remain)

An IP registry for internal SERVICE objects. Each row is a service endpoint:
IP address, service name, heritage, routing domain.

**Current state:** 794 rows, 18+ services, solid foundation.
**Role in model:** Provides MEMBER_IPS for each SVC_* canonical object.

**This dataset is correctly designed. No structural changes needed.**

### 5.2 What is missing from CPC-CORE-SERVICES

The service list is incomplete. The following agent-based services exist
across the estate but lack collector/server IP entries:

| Service | Type | Gap |
|---------|------|-----|
| CrowdStrike | EDR agent | Falcon collector IPs not registered |
| Tanium | Endpoint management | Tanium server IPs not registered |
| Jamf | Apple MDM | Jamf server IPs not registered |
| Tenable/Nessus | Vulnerability scan | Scanner IPs not in CPC registry |
| Carbon Black | EDR (legacy) | If still active, not registered |

**Fix:** For each agent-based service, add the server/collector IPs to
CPC-CORE-SERVICES as a new supplement entry. Run build_cpc_core_services.py
to rebuild the merged dataset.

### 5.3 What CPC-SERVICE-FLOWS is (corrected)

A policy profile registry. Each row defines a required flow for a managed
service — ports, protocol, source zone type, destination zone type.

**Current state:** 96 rows, 18 services. Correctly structured for its
corrected purpose.

**What it is NOT:** A record of which subnets or objects consume each service.
**What it IS:** The enforcement specification consulted when a CONSUMES_SERVICES
declaration is processed.

### 5.4 The CONSUMES_SERVICES derivation problem

Populating CONSUMES_SERVICES on each canonical object requires knowing which
objects consume each service. This cannot come from CPC-SERVICE-FLOWS (which
has no client-side IP data). It must come from:

**Tier 1 — Agent presence in EHM (buildable now):**
Cross-reference EHM APP_ACRONYMS against known agent/service patterns.
If hosts in APP_RXCONNECT have CrowdStrike app entries, APP_RXCONNECT
CONSUMES SVC_CROWDSTRIKE. This is heuristic but accurate enough for policy.

**Tier 2 — FW rule extraction (requires pipeline run):**
fw_rule_extraction_translation.py observes actual flows from source IPs to
CPC service IPs and derives consumption relationships from traffic evidence.
Most accurate but requires FW config inputs.

**Tier 3 — Zone-based inference (coarse, fast):**
All objects in PCI routing domain consume AD, Qualys, Centrify.
All cloud objects consume NTP, DNS. Etc. Good for bulk initial population,
refined by Tier 1 and Tier 2 passes.

### 5.5 The external service parallel

CONSUMES_EXTERNAL follows the same model as CONSUMES_SERVICES but for
externally hosted services. The ext_canonical_objects dataset (121 rows)
is the external equivalent of CPC-CORE-SERVICES.

**Derivation:** FW-SNAT-POOLS (6,418 rows) + external_ip_registry (37,881 rows)
show which internal objects are observed reaching external CIDRs.
Join those external CIDRs against ext_canonical_objects to get named services.

---

## 6. Schema Extension — canonical_app_objects v2.0 Target

Current schema (v1.x) has: OBJECT_NAME, OBJECT_TYPE, MEMBER_IPS, VIP_IPS,
SUBNET_CIDRS, LOCATIONS, MEMBER_COUNT, VIP_COUNT, SOURCE_DATASETS,
DATASET_VERSION.

Target schema additions for intent model:

| Column | Type | Description |
|--------|------|-------------|
| PROVIDED_PORTS | pipe-delimited | port/proto specs this object exposes |
| CONSUMES_APPS | pipe-delimited | APP object names this depends on |
| CONSUMES_INFRA | pipe-delimited | INFRA object names this runs on |
| CONSUMES_DELIVERY | pipe-delimited | DELIVERY object names used |
| CONSUMES_SERVICES | pipe-delimited | SVC object names consumed (internal) |
| CONSUMES_EXTERNAL | pipe-delimited | EXT object names consumed (external) |

**Phased population:**
- Phase 1: CONSUMES_INFRA, CONSUMES_DELIVERY — derivable from location
  matching now. build_canonical_app_objects.py v1.5.0.
- Phase 2: CONSUMES_SERVICES — Tier 1 agent-presence derivation from EHM.
  New script: build_consumes_services.py.
- Phase 3: PROVIDED_PORTS — from CPC-CORE-SERVICES + F5-VIP-REGISTRY.
- Phase 4: CONSUMES_APPS — requires FW extraction or SNOW CMDB.
- Phase 5: CONSUMES_EXTERNAL — from FW-SNAT-POOLS + ext_canonical_objects.

---

## 7. Open Items

| # | Item | Blocks | Approach |
|---|------|--------|----------|
| 1 | CPC-CORE-SERVICES: agent-based services missing (CrowdStrike, Tanium, Jamf) | SVC object completeness | Add collector/server IPs as CPC supplement |
| 2 | CONSUMES_SERVICES population | Intent policy Phase 2 | build_consumes_services.py — EHM agent pattern Tier 1 |
| 3 | CONSUMES_EXTERNAL population | Intent policy Phase 5 | FW-SNAT-POOLS + ext_canonical_objects join |
| 4 | CONSUMES_APPS population | Intent policy Phase 4 | Requires FW extraction or SNOW CMDB relationships |
| 5 | PROVIDED_PORTS on APP objects | Intent policy Phase 3 | F5-VIP-REGISTRY port mapping + CPC profile lookup |
| 6 | ext_canonical_objects expansion | CONSUMES_EXTERNAL coverage | FW extraction external CIDR → provider attribution |
| 7 | ASI CPC_SERVICES field | Deprecated in favour of object-level CONSUMES_SERVICES | Remove from active work queue |

