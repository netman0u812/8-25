---
name: cvs-docx-brand
description: >
  Apply CVS Health corporate InfoSec document branding to any Word (.docx) report
  generated with the docx-js library. Use this skill whenever creating a .docx
  document that should match CVS Health internal standards: security reports,
  remediation roadmaps, assessment findings, architecture documents, policy briefs,
  or any formal deliverable intended for CVS Health leadership or audit audiences.
  Triggers: "CVS branding", "CVS Health format", "corporate format", "InfoSec
  document style", "make it look CVS", "apply CVS template", "format for CVS",
  or any request to create a Word document in the context of CVS Health work.
  Always read this skill before writing any docx-js code for CVS Health documents.
---

# CVS Health — Corporate InfoSec DOCX Branding

Defines the complete color palette, typography, heading rules, table patterns,
cover block, and docx-js code constants for CVS Health internal security documents.
Apply every time a `.docx` is generated for CVS Health audiences.

---

## Color Palette

These are the only colors used in CVS Health InfoSec documents.
Never introduce additional colors — all emphasis is achieved through
weight, spacing, and these defined semantic values.

| Constant       | Hex       | Use                                                      |
|----------------|-----------|----------------------------------------------------------|
| `CVS_NAVY`     | `17447C`  | Table headers, cover accent bar, H2 subtitle text        |
| `CVS_NAVY_LT`  | `D6E4F0`  | Reserved — light navy tint (use sparingly, not in tables)|
| `CVS_GRAY_DK`  | `404040`  | All heading text (H1, H2, H3)                            |
| `CVS_GRAY_MD`  | `595959`  | All body paragraph text                                  |
| `CVS_GRAY_LT`  | `F2F2F2`  | Alternating table row fill                               |
| `CVS_RED`      | `CC0000`  | CRITICAL / P1 severity badges ONLY — no decorative use   |
| `CVS_AMBER`    | `C55A11`  | HIGH / P2 severity badges ONLY                           |
| `CVS_GREEN`    | `375623`  | LOW / P3 severity badges ONLY                            |
| `WHITE`        | `FFFFFF`  | Table header text, row backgrounds                       |
| FOOTER_GRAY    | `AAAAAA`  | Footer / metadata lines (italic)                         |

### Risk/severity row fills (light tints — table body rows only)

| Priority | Row fill  | Badge text color |
|----------|-----------|-----------------|
| P1 / CRITICAL | `FBEAEA` | `CVS_RED`    |
| P2 / HIGH     | `FEF3E2` | `CVS_AMBER`  |
| P3 / MEDIUM   | `EDF4E8` | `CVS_GREEN`  |
| Neutral        | `F2F2F2` | `CVS_GRAY_DK`|

---

## Typography

- **Font**: Arial throughout — universally available, no embedding required.
- **No Helvetica Neue** in docx (not reliably available on Windows); Arial is the
  correct substitute for internal documents.
- **Weights**: 400 (regular) and 700 (bold) only. Never use 600.
- **Heading text is NOT bold** — hierarchy is communicated through size, spacing,
  and the navy rule on H1. Bold on headings is reserved for table header cells only.

| Element        | Size (half-pts) | Bold  | Color        | Notes                         |
|----------------|-----------------|-------|--------------|-------------------------------|
| Cover title    | 44              | false | CVS_GRAY_DK  | Main document title           |
| Cover subtitle | 28              | false | CVS_NAVY     | Document type / subtitle      |
| Cover meta     | 18              | false | CVS_GRAY_MD  | Date, program, division line  |
| Heading 1      | 30              | false | CVS_GRAY_DK  | + navy bottom border rule     |
| Heading 2      | 24              | false | CVS_GRAY_DK  | No border                     |
| Body paragraph | 20              | false | CVS_GRAY_MD  | Line spacing after: 100       |
| Bullet item    | 20              | false | CVS_GRAY_MD  |                               |
| Table header   | 18              | true  | WHITE        | On CVS_NAVY fill              |
| Table body     | 18              | false | CVS_GRAY_DK  | Or CVS_RED/AMBER/GREEN for badges |
| Footer/meta    | 18              | false | AAAAAA       | Italic                        |

---

## Page Setup

Always landscape Letter for security reports and roadmaps (wide tables).
Use portrait Letter only when the document is primarily prose.

```javascript
properties: {
  page: {
    size: { width: 15840, height: 12240 },  // landscape Letter (DXA)
    margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 }  // 0.75" all sides
  }
}
// Content width = 15840 - 2160 = 13680 DXA
// For portrait Letter: width: 12240, height: 15840
// Content width = 12240 - 2880 = 9360 DXA (1" margins)
```

---

## docx-js Constants Block

Paste this verbatim at the top of every CVS Health document script.

```javascript
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  LevelFormat, PageBreak
} = require('docx');
const fs = require('fs');

// ── CVS Health InfoSec palette ────────────────────────────────────────────────
const CVS_NAVY    = "17447C";
const CVS_GRAY_DK = "404040";
const CVS_GRAY_MD = "595959";
const CVS_GRAY_LT = "F2F2F2";
const CVS_RED     = "CC0000";
const CVS_AMBER   = "C55A11";
const CVS_GREEN   = "375623";
const WHITE       = "FFFFFF";

// Risk row fills (light tints for table body rows)
const P1_FILL = "FBEAEA";
const P2_FILL = "FEF3E2";
const P3_FILL = "EDF4E8";

// ── Shared table border + cell margin ────────────────────────────────────────
const bdr  = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const bdrs = { top: bdr, bottom: bdr, left: bdr, right: bdr };
const cm   = { top: 80, bottom: 80, left: 120, right: 120 };
```

---

## Helper Functions

These four functions cover every paragraph type used in CVS Health documents.
Copy them verbatim; adjust only where noted.

```javascript
// ── Headings ──────────────────────────────────────────────────────────────────
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: CVS_NAVY, space: 4 } },
    children: [new TextRun({ text, font: "Arial", size: 30, bold: false, color: CVS_GRAY_DK })]
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, font: "Arial", size: 24, bold: false, color: CVS_GRAY_DK })]
  });
}

// ── Body text ─────────────────────────────────────────────────────────────────
// opts: pass italics, color overrides etc. as needed
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 100 },
    children: [new TextRun({ text, font: "Arial", size: 20, color: CVS_GRAY_MD, ...opts })]
  });
}

// ── Bullet list ───────────────────────────────────────────────────────────────
// Requires numbering reference "bullets" in Document config (see Document Setup)
function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { after: 60 },
    children: [new TextRun({ text, font: "Arial", size: 20, color: CVS_GRAY_MD })]
  });
}

// ── Spacer ────────────────────────────────────────────────────────────────────
function spacer() {
  return new Paragraph({ children: [new TextRun("")] });
}
```

---

## Table Helper Functions

```javascript
// ── Navy header cell ──────────────────────────────────────────────────────────
function hdrCell(text, w) {
  return new TableCell({
    borders: bdrs,
    width: { size: w, type: WidthType.DXA },
    shading: { fill: CVS_NAVY, type: ShadingType.CLEAR },
    margins: cm,
    children: [new Paragraph({
      children: [new TextRun({ text, font: "Arial", size: 18, bold: true, color: WHITE })]
    })]
  });
}

// ── Body cell ─────────────────────────────────────────────────────────────────
// fill: row background hex (WHITE, CVS_GRAY_LT, P1_FILL, P2_FILL, P3_FILL)
// color: text color hex
// bold: true for badge/priority cells
function cell(text, w, fill = WHITE, color = CVS_GRAY_DK, bold = false) {
  return new TableCell({
    borders: bdrs,
    width: { size: w, type: WidthType.DXA },
    shading: { fill, type: ShadingType.CLEAR },
    margins: cm,
    children: [new Paragraph({
      children: [new TextRun({ text, font: "Arial", size: 18, color, bold })]
    })]
  });
}
```

### Table patterns

**Standard data table** — navy header, alternating gray/white rows:
```javascript
// Alternating rows: pass CVS_GRAY_LT on even rows, WHITE on odd
new TableRow({ children: r.map((t, j) => cell(t, colWidths[j], i % 2 ? CVS_GRAY_LT : WHITE)) })
```

**Priority/remediation table** — colored row fills with badge in first cell:
```javascript
// P1 row
new TableRow({ children: [
  cell("P1", W[0], P1_FILL, CVS_RED,   true),   // badge cell
  cell("Action text", W[1], P1_FILL),             // content cells inherit fill
  cell("Scope",       W[2], P1_FILL),
  // ...
]})
// P2 row — same pattern with P2_FILL, CVS_AMBER
// P3 row — same pattern with P3_FILL, CVS_GREEN
```

**Summary/findings table** — white rows, severity text in rightmost cell:
```javascript
// Use colored text (no fill) for severity labels in body rows
cell("CRITICAL", w, WHITE, CVS_RED,   true)
cell("HIGH",     w, WHITE, CVS_AMBER, true)
cell("MEDIUM",   w, WHITE, CVS_GRAY_DK, true)
// On alternating gray rows, use CVS_GRAY_LT as fill instead of WHITE
```

---

## Cover Block

The cover uses a thick left navy border accent running across all four cover lines.
This is the CVS Health corporate document treatment — not a colored title block.

```javascript
function coverLine(text, size, color, spacingAfter = 60) {
  return new Paragraph({
    border: { left: { style: BorderStyle.SINGLE, size: 24, color: CVS_NAVY, space: 12 } },
    indent: { left: 280 },
    spacing: { after: spacingAfter },
    children: [new TextRun({ text, font: "Arial", size, bold: false, color })]
  });
}

// Usage — four lines: org tag, title, subtitle, date/program
coverLine("CVS Health  |  Information Security",          18, CVS_GRAY_MD),
coverLine("[ Document Title ]",                           44, CVS_GRAY_DK),
coverLine("[ Document Type / Subtitle ]",                 28, CVS_NAVY),
coverLine("[ Month Year ]  –  [ Program ]  |  [ Team ]", 18, CVS_GRAY_MD, 480),
```

---

## Document Setup (numbering + styles)

```javascript
const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: "\u2022",
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } }
      }]
    }]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal",
        quickFormat: true,
        run: { size: 30, bold: false, font: "Arial", color: CVS_GRAY_DK },
        paragraph: { spacing: { before: 320, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal",
        quickFormat: true,
        run: { size: 24, bold: false, font: "Arial", color: CVS_GRAY_DK },
        paragraph: { spacing: { before: 240, after: 100 }, outlineLevel: 1 } },
    ]
  },
  sections: [{ /* ... */ }]
});
```

---

## Footer Line

Always end the document body with an italic metadata line in AAAAAA gray:

```javascript
body(
  "Prepared by: [ Team ]  |  Data source: [ filename ]  |  [ Month Year ]",
  { color: "AAAAAA", italics: true }
)
```

---

## Design Rules (Non-Negotiable)

1. **Red is reserved for risk.** `CVS_RED` (#CC0000) appears only in CRITICAL/P1
   severity badges, never as decoration, never on headings, never on borders.

2. **Headings are never bold.** Size and the H1 navy rule carry the hierarchy.
   Bold is for table header cells only.

3. **No additional colors.** Do not introduce blues, teals, purples, or any hex
   not in the palette table above, regardless of source content.

4. **Always alternating rows.** Every table with more than three data rows uses
   `CVS_GRAY_LT` / `WHITE` alternation. Exception: priority tables where the
   entire row takes the P1/P2/P3 fill.

5. **Table widths always in DXA.** Never use `WidthType.PERCENTAGE` — it breaks
   in Google Docs. Column widths must sum exactly to the declared table width.

6. **Always set both `columnWidths` on the Table AND `width` on each cell.**
   Omitting either causes rendering failures on some Word versions.

7. **Page size must be explicit.** docx-js defaults to A4. Always declare
   US Letter dimensions (landscape or portrait) in section properties.

8. **No unicode bullets.** Use `LevelFormat.BULLET` with the numbering config.
   Never `\u2022` in a TextRun as a manual bullet character.

9. **Validate after every build.**
   ```bash
   python3 /mnt/skills/public/docx/scripts/office/validate.py output.docx
   ```

---

## Quick-Start Checklist

Before writing any code for a CVS Health document:

- [ ] Read `/mnt/skills/public/docx/SKILL.md` (docx-js mechanics)
- [ ] Paste the constants block from this skill
- [ ] Set page size explicitly (landscape Letter for tables, portrait for prose)
- [ ] Use `h1()`, `h2()`, `body()`, `bullet()`, `spacer()` for all paragraphs
- [ ] Use `hdrCell()` + `cell()` for all tables
- [ ] Cover block: four lines with left navy border accent
- [ ] Footer: italic AAAAAA metadata line
- [ ] Run validate.py before presenting the file
