---
name: canonical-app-objects
description: >
  CCD Platform — Canonical App Object Library (CVS Health Information Security).
  Use this skill for any task involving APP_Objects, INFRA_Objects, SERVICE_Objects,
  DELIVERY_Objects, VIP attribution, SNAT mapping, FW object consolidation, or
  intent-based firewall policy translation. Covers object taxonomy, dataset derivation
  rules, IP membership logic, VIP join, SNAT attribution, and the canonical object
  schema. Trigger on: "canonical objects", "app objects", "APP_Object", "INFRA_Object",
  "SERVICE_Object", "DELIVERY_Object", "VIP attribution", "SNAT mapping",
  "object consolidation", "fw intent", "canonical_app_objects", "build_canonical_app_objects",
  "fw_object_consolidation", "fw_policy_intent", "fw_third_party_access".
---

# CCD Platform — Canonical App Object Library

## 1. Purpose

The Canonical App Object Library is a ground-truth IP object model derived entirely from
authoritative CCD Platform datasets. It exists because the Panorama/FMC firewall estate
has ~15,000+ rules with additive, change-ticket-named objects (e.g., `infosys-access-PBM19166`,
`PBM10599-SPLUNK-EXT_split_3`) that cannot be rationalized without a canonical reference.

**Core principle:** Build the object library top-down from authoritative inventory
(EHM, infra, platform, IPAM, ASI, F5 VIP registry), not bottom-up from FW rule objects.

---

## 2. Object Taxonomy

Four strictly defined object types. These are NOT interchangeable.

### 2.1 APP_Object
**Definition:** The /32 IP addresses of the application workload instances themselves —
the actual servers running the application code.

**Source:** `ent_host_master` grouped by APP_ACRONYM.

**Rule:** One APP_Object per APP_ACRONYM per ROUTING_DOMAIN. If the same application
runs in both Internal-PBM and Internal-HCB, it gets two objects:
`APP_RXCONNECT_PBM` and `APP_RXCONNECT_HCB`.

**Example:**
```
OBJECT_NAME:   APP_RXCONNECT
OBJECT_TYPE:   APP
MEMBER_IPS:    10.112.x.x|10.114.x.x|...   (EHM /32 hosts for RxConnect)
VIP_IPS:       157.121.x.x|10.y.y.y         (F5 VIPs fronting RxConnect)
```

### 2.2 INFRA_Object
**Definition:** The /32 addresses of compute infrastructure — ESXi hosts, bare metal
hypervisor nodes, storage controllers, cluster members. NOT applications — these are
the hardware/VM layer that runs applications.

**Source:** `delivery_infrastructure` where INFRA_ROLE indicates compute/hypervisor.

**Naming:** `INFRA_[PLATFORM]_[LOCATION_CODE]_[ENV]`

**Examples:**
```
INFRA_ESXI_SHEA_PROD       → ESXi hosts at Scottsdale AZ - Shea DC
INFRA_ESXI_RIONE_PROD      → ESXi hosts at Woonsocket RI - RI One
INFRA_ESXI_MDC_PROD        → ESXi hosts at Middletown CT - Aetna MDC
INFRA_BAREMETAL_RIONE      → bare metal compute at RI One
```

**Rule:** INFRA_Objects are location-specific. Same ESXi version at two DCs = two objects.

### 2.3 SERVICE_Object
**Definition:** The /32 addresses of shared enterprise services consumed by applications
and infrastructure. Logical services with a well-known function, not application-specific.

**Source:** `delivery_infrastructure` grouped by SERVICE_ROLE. Also from `ent_host_master`
where APP_ACRONYM maps to a known enterprise service.

**Naming:** `SVC_[SERVICE_NAME]_[HERITAGE]` (heritage suffix only if service is per-heritage)

**Canonical service list (non-exhaustive):**

| OBJECT_NAME | SERVICE | Source Role |
|-------------|---------|-------------|
| SVC_AD_DC | Active Directory Domain Controllers | delivery_infrastructure:ROLE=DC |
| SVC_DNS_RESOLVERS | DNS resolvers | delivery_infrastructure:ROLE=DNS |
| SVC_NTP | NTP servers | delivery_infrastructure:ROLE=NTP |
| SVC_QUALYS | Qualys scanner appliances | delivery_infrastructure:ROLE=QUALYS |
| SVC_SCCM | SCCM/MECM management | delivery_infrastructure:ROLE=SCCM |
| SVC_SPLUNK_INDEXERS | Splunk indexers | delivery_infrastructure:ROLE=SPLUNK-IDX |
| SVC_SPLUNK_FORWARDERS | Splunk heavy forwarders | delivery_infrastructure:ROLE=SPLUNK-HF |
| SVC_INFOBLOX | Infoblox DDI | delivery_infrastructure:ROLE=INFOBLOX |
| SVC_CYBERARK | CyberArk PAM | delivery_infrastructure:ROLE=CYBERARK |
| SVC_SYSLOG | Syslog collectors | delivery_infrastructure:ROLE=SYSLOG |
| SVC_SNMP | SNMP management | delivery_infrastructure:ROLE=SNMP |
| SVC_ZPA | Zscaler Private Access | delivery_infrastructure:ROLE=ZPA |
| SVC_PROXY | Web proxy (Zscaler/BlueCoat) | delivery_infrastructure:ROLE=PROXY |
| SVC_VCENTER | VMware vCenter | delivery_infrastructure:ROLE=VCENTER |
| SVC_THOUSANDEYES | ThousandEyes agents | delivery_infrastructure:ROLE=THOUSANDEYES |

**Rule:** SERVICE_Objects span locations — `SVC_AD_DC` includes all DC IPs across all
sites. Heritage split only where the service is completely separate (e.g., `SVC_AD_DC_CVS`
vs `SVC_AD_DC_HCB` if CVS and Aetna AD forests are fully isolated).

### 2.4 DELIVERY_Object
**Definition:** The /32 addresses of the delivery/platform layer — Kubernetes worker nodes,
OpenShift cluster members, F5 pool members (not VIPs), Citrix delivery controllers,
DataPower gateways. The middleware layer that delivers applications to consumers.

**Source:** `delivery_platform` grouped by PLATFORM_TYPE + CLUSTER_ID + LOCATION.

**Naming:** `DELIVERY_[PLATFORM]_[CLUSTER_OR_CONTEXT]_[LOCATION_CODE]`

**Examples:**
```
DELIVERY_K8S_PROD_SHEA         → Kubernetes worker nodes, prod cluster, Shea DC
DELIVERY_K8S_PROD_RIONE        → Kubernetes worker nodes, prod cluster, RI One
DELIVERY_OPENSHIFT_HCB_MDC     → OpenShift nodes, Aetna MDC
DELIVERY_CITRIX_CONTROLLERS    → Citrix ADC/delivery controllers (all sites)
DELIVERY_DATAPOWER_PBM         → DataPower gateway nodes, Internal-PBM
DELIVERY_DATAPOWER_HCB         → DataPower gateway nodes, Internal-HCB
DELIVERY_F5_POOL_SHEA          → F5 pool members at Shea DC (backend servers, not VIPs)
```

**Rule:** DELIVERY_Objects are cluster-scoped, not application-scoped. A K8s cluster
serves many applications — the DELIVERY_Object is the cluster nodes, not an app's pods.

---

## 3. VIP Attribution (Not Object Membership)

VIP IPs are NOT members of any object type. They are the **front door** to an object,
attributed via F5-VIP-REGISTRY and F5-POOL-MEMBERS join.

**Join path:**
```
EHM host IP
  → F5-POOL-MEMBERS (where MEMBER_IP = host IP)
    → F5-VIP-REGISTRY (where VIP_ID matches)
      → VIP_IP
```

**Result:** Each APP_Object and DELIVERY_Object gets a `VIP_IPS` field listing the F5
VIPs that front it. VIPs can appear in multiple objects (shared VIPs).

**Policy flow with VIP:**
```
CLIENT_IP  →  VIP_IP (F5-VIP-REGISTRY)
                 →  DELIVERY_Object (F5 pool members / K8s ingress)
                        →  APP_Object (actual /32 app servers)
                               running on INFRA_Object (ESXi hosts)
                               consuming SVC_AD_DC, SVC_DNS, SVC_QUALYS
```

**SNAT layer (third-party access):**
```
VENDOR_SNAT_POOL (204.99.x.x)  →  FW  →  VIP_IP  →  DELIVERY  →  APP_Object
```

---

## 4. Dataset Schema

### canonical_app_objects.csv

| Column | Type | Description |
|--------|------|-------------|
| OBJECT_NAME | string | e.g. APP_RXCONNECT, SVC_AD_DC, INFRA_ESXI_SHEA_PROD |
| OBJECT_TYPE | enum | APP / INFRA / SERVICE / DELIVERY |
| APP_ACRONYM | string | Source APP_ACRONYM from EHM (APP_Objects only) |
| SERVICE_ROLE | string | Source ROLE from delivery_infrastructure (SERVICE/INFRA/DELIVERY) |
| HERITAGE | string | CVS / AETNA / OMNICARE / CAREMARK / MIXED |
| ROUTING_DOMAIN | string | Internal-PBM / Internal-HCB / Cloud-Azure / etc. |
| MEMBER_IPS | pipe-delimited | /32 IPs that are members of this object |
| VIP_IPS | pipe-delimited | F5 VIP IPs that front this object (join, not members) |
| SUBNET_CIDRS | pipe-delimited | /24+ CIDRs containing the member IPs (from IPAM) |
| LOCATIONS | pipe-delimited | Canonical location names from LM |
| MEMBER_COUNT | int | Count of unique MEMBER_IPS |
| VIP_COUNT | int | Count of unique VIP_IPS |
| SOURCE_DATASETS | pipe-delimited | Which datasets contributed: EHM|INFRA|PLATFORM|F5-VIP |
| DATASET_VERSION | string | Build version stamp |

### canonical_object_vs_fw_gap.csv

| Column | Description |
|--------|-------------|
| OBJECT_NAME | Canonical object |
| FW_GROUP_NAME | FW address group that overlaps with this object |
| MATCH_TYPE | EXACT / SUPERSET / SUBSET / PARTIAL |
| MATCHED_IPS | IPs in both canonical object and FW group |
| UNMATCHED_FW_IPS | IPs in FW group not in canonical object (stale candidates) |
| UNMATCHED_OBJ_IPS | IPs in canonical object not in any FW group (coverage gap) |
| RULE_COUNT | How many FW rules reference this FW group |
| FW_PLATFORMS | Which FW platforms have the group |
| CONSOLIDATION_ACTION | RETIRE_GROUP / RENAME_TO_CANONICAL / EXPAND_OBJECT / INVESTIGATE |

---

## 5. Derivation Rules

### 5.1 APP_Object derivation
```python
# Group EHM by APP_ACRONYM + ROUTING_DOMAIN
# Minimum 2 IPs to create an object (single-host apps go to review)
# Exclude IPs already in delivery_infrastructure or delivery_platform
# (those are SERVICE/INFRA/DELIVERY, not APP)
```

### 5.2 INFRA_Object derivation
```python
# delivery_infrastructure where INFRA_ROLE in:
#   ['ESXI', 'HYPERVISOR', 'BAREMETAL', 'COMPUTE', 'STORAGE-CTRL']
# Group by LOCATION + ENV (prod/nonprod/dev)
# Do NOT include management IPs (iDRAC, iLO) — those are SERVICE_Object (SVC_MGMT)
```

### 5.3 SERVICE_Object derivation
```python
# delivery_infrastructure where INFRA_ROLE in SERVICE_ROLE_MAP (see §2.3 table)
# Do NOT split by location UNLESS the service is architecturally isolated per-site
# Heritage split: check if CVS and Aetna share the service or run separate instances
```

### 5.4 DELIVERY_Object derivation
```python
# delivery_platform grouped by PLATFORM_TYPE + CLUSTER_ID + SITE_CODE
# F5 pool members: use F5-POOL-MEMBERS, NOT F5-VIP-REGISTRY
#   (VIPs go in VIP_IPS field, not MEMBER_IPS)
# DataPower: group by gateway_cluster + ROUTING_DOMAIN
# Citrix: group by farm/site
```

### 5.5 VIP join
```python
# For each object, find all VIPs where any MEMBER_IP appears as a pool member:
#   F5-POOL-MEMBERS[MEMBER_IP] → VIP_ID → F5-VIP-REGISTRY[VIP_IP]
# One-to-many: one app server can be in multiple VIP pools
# Add all matching VIP_IPs to the object's VIP_IPS field
```

---

## 6. Naming Conventions

```
APP_[ACRONYM]                          APP_RXCONNECT, APP_CAREMARK_CBS
APP_[ACRONYM]_[RD_SHORT]               APP_RXCONNECT_PBM, APP_RXCONNECT_HCB
INFRA_[PLATFORM]_[LOC]_[ENV]           INFRA_ESXI_SHEA_PROD, INFRA_ESXI_MDC_PROD
SVC_[SERVICE]                          SVC_AD_DC, SVC_QUALYS, SVC_SPLUNK_INDEXERS
SVC_[SERVICE]_[HERITAGE]               SVC_AD_DC_CVS, SVC_AD_DC_HCB
DELIVERY_[PLATFORM]_[CLUSTER]_[LOC]    DELIVERY_K8S_PROD_SHEA
DELIVERY_[PLATFORM]_[HERITAGE]         DELIVERY_DATAPOWER_PBM
```

**Hard rules:**
- No spaces in OBJECT_NAME — use underscores
- All uppercase
- Never include change ticket numbers (PBM12345) in canonical object names
- Never include IP addresses in object names
- RD_SHORT: PBM=Internal-PBM, HCB=Internal-HCB, AZ=Cloud-Azure, GCP=Cloud-GCP

---

## 7. Downstream Consumers

| Consumer | Uses |
|----------|------|
| `fw_object_consolidation.py` | Compares canonical objects vs FW address groups, outputs gap report |
| `fw_policy_intent.py` | Uses canonical objects to reconstruct zone-pair allow matrix |
| `build_external_ip_registry.py` | Uses SNAT_IPS from third-party access + canonical objects |
| Panorama migration | Canonical objects become the authoritative address-object library |
| FMC migration | Same — canonical objects replace change-ticket-named groups |
| CSNA host groups | Canonical objects validate/replace current FW-rule-derived host groups |

---

## 8. Build Script

**`build_canonical_app_objects.py`**

Input files (all from `--ipam-dir`):
- `ent_host_master_v*.csv`
- `delivery_infrastructure_v*.csv`
- `delivery_platform_v*.csv`
- `app_subnet_index_v*.csv`
- `all_IP_networks_v*.csv`
- `ent-ipdataset-F5-VIP-REGISTRY-*.csv`
- `ent-ipdataset-F5-POOL-MEMBERS-*.csv`

Output files (to `--out-dir`):
- `canonical_app_objects_vDATE.csv`
- `canonical_object_vs_fw_gap_vDATE.csv` (requires `fw_host_candidates_vDATE.csv`)

Key flags:
```bash
python3 build_canonical_app_objects.py \
    --ipam-dir ./ipam-db \
    --fw-dir   ./processed_outputs \
    --out-dir  ./processed_outputs \
    --min-members 2 \
    --dry-run
```

`--min-members 2` — objects with only 1 IP go to a review queue, not the main output.
`--dry-run` — prints object summary without writing files.

---

## 9. Validation Rules

- Every OBJECT_NAME must be unique
- Every MEMBER_IP must appear in exactly one object per OBJECT_TYPE
  (same IP can be in APP_RXCONNECT and SVC_AD_DC if it serves dual roles — rare, flag for review)
- VIP_IPS are allowed to appear in multiple objects (shared VIPs)
- HERITAGE=MIXED is valid only when confirmed by both routing domains being present in MEMBER_IPS
- MEMBER_COUNT must equal len(MEMBER_IPS.split('|'))
- No /32 from retail_networks should appear in any canonical object
  (retail IPs are in retail_networks only — never INFRA/APP/SERVICE/DELIVERY)
