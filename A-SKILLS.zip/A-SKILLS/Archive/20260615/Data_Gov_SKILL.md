---
name: ccd-platform-data-model
description: >
  CCD Platform (Cyber & Compliance Data) — CVS Health Information Security.
  Use this skill for any task involving the CCD Platform datasets, IPAM operations,
  iplookup.sh queries, pipeline stages, overlap management, firewall rule extraction,
  FW config parsing, CSNA host group generation, IPAM hierarchy remediation, or
  the INTERNET-FACING BGP dataset. Covers dataset schemas, architectural rules,
  update order, cross-check constraints, dual-dataset overlap model, and FW
  extraction pipeline. Trigger on: "IPAM", "iplookup", "all_IP_networks",
  "retail_networks", "location_master", "ent_host_master", "CSNA", "ROUTING_DOMAIN",
  "CANONICAL_LOCATION", "CX cross-check", "dual-allocation", "Internal-HCB",
  "Internal-PBM", "Internal-Retail", "fw_rule_extraction", "FMC", "FTD",
  "PAN-OS", "app_subnet_index", "CCD pipeline", "audit_ipam_hierarchy",
  "INTERNET-FACING", "hierarchy remediation", "WAN_P2P_AGGREGATE".
---

# CCD Platform — Data Model Reference

## 1. Platform Overview

The CCD (Cyber and Compliance Data) Platform is a Python/Bash toolset for enterprise
IPAM management, network security visibility, CSNA Stealthwatch host group generation,
and firewall enrichment at CVS Health.

**Core problem:** CVS and Aetna were never merged at the network layer after the 2018
acquisition. Both use RFC1918 10.x, 172.16.0.0/12, and CVS-owned public BGP space
in completely separate routing planes. The platform manages this overlap through strict
dataset separation and the ROUTING_DOMAIN field as the primary discriminator.

**Three-question data model:**

| Question | Field | Owner |
|---|---|---|
| **WHERE** is this network? | `SITE_CODE` / `CANONICAL_LOCATION` | Location Master |
| **WHOSE** network space? | `ROUTING_DOMAIN` + `HERITAGE` | IPAM |
| **WHAT** is on this subnet? | `NET_TYPE` | IPAM |

These three dimensions are orthogonal. None implies the other.

---

## 2. Dataset Catalog

### 2.1 location_master (LM)
**Current version:** v5.11  **Rows:** 11,527  **Key:** SITE_CODE / CANONICAL_NAME

Root of the entire model. Nothing enters any downstream dataset without a
CANONICAL_LOCATION that resolves to an active LM entry.

**20 critical anchors validated by preflight_lm_check.py before every IPAM write:**
Primary DCs: US_CUR_RI_DC, US_WOR_RI_DC, US_MIC_CT_DC, US_WIN_CT_DC, US_SCO_AZ_DC, US_ATL_GA_DC, US_PHX_AZ_DC
COLO: US_LVG_NV_CI, US_ATL_GA_CI, US_SPK_NV_CI, US_IAD_VA_CI, US_WDB_NJ_CI, US_CAR_NJ_CI, US_DFW_TX_CI
DR: US_WOO_RI_DR, US_WAT_MA_DR, US_WDB_NJ_DR, US_CDT_NJ_DR, US_PHL_PA_DR
NAAS Hub: US_SCA_CA_F9-NH

**SITE_CODE suffix taxonomy:**
_DC=datacenter, _CI=COLO, _IS=IaaS cloud, _DR=disaster recovery, _CO=corporate office,
_NH=NAAS hub, _RT=retail store, _MC=MinuteClinic, _OPT=optical, _HP=CarePlus/OSH,
_SP=specialty/Coram, _MO=mail order, _RD=distribution center

### 2.2 all_IP_networks (IPAM)
**Current version:** v3.94  **Key:** CIDR

Enterprise IPAM — all non-retail subnets. Single source of truth for subnet→location.
Pre-write gates: preflight_lm_check + overlap/containment check enforced by update_ipam.py v1.9.

**IPAM hierarchy rule (IPAM-6):** A more-specific subnet (/17+) inside a broader block
must have the same ROUTING_DOMAIN and CANONICAL_LOCATION as its parent.
Violations = HIGH. Tool: audit_ipam_hierarchy.py + apply_ipam_remediation.py.
Current state: 617 parent blocks remediated (3,669 child conflicts resolved).

**Routing domain vocabulary:**
Internal-PBM (CVS/Caremark on-prem), Internal-HCB (Aetna/healthcare on-prem),
Internal-Retail (CVS retail stores), Cloud-Azure, Cloud-GCP, Cloud-AWS,
Internet-Facing (CVS public BGP space), P2P-WAN (WAN point-to-point links),
Partner (third-party connectivity), COLO (co-location facilities)

### 2.3 retail_networks
**Current version:** v2.8  **Rows:** 294,341  **Key:** CIDR

Per-store /26 subnet allocations. Separate dataset because CVS retail uses
172.16.0.0/12 — the same space Aetna uses for DC infrastructure.
CX5 hard-blocks retail /26s from all_IP_networks.

### 2.4 ent_host_master (EHM)
**Current version:** v20260427r22  **Rows:** 69,140  **Key:** IP_ADDRESS

All enterprise application and server hosts. Cross-dataset dedup enforced:
a host IP appears in at most one of EHM / delivery_infrastructure / delivery_platform.

### 2.5 ent_network_device_master (NDM)
**Current version:** v20260519  **Rows:** 10,870  **Key:** MANAGEMENT_IP

### 2.6 delivery_infrastructure
**Current version:** v20260504r6  **Rows:** 5,755  **Key:** IP_ADDRESS
ESXi, HMC, iSeries, DataPower, Isilon. FW_POLICY field enriched.

### 2.7 delivery_platform
**Current version:** v20260504r4  **Rows:** 1,870  **Key:** IP_ADDRESS
Kubernetes, OCP, Docker, RHCOS nodes. FW_POLICY field enriched.

### 2.8 app_subnet_index (ASI)
**Current version:** v20260520r2  **Rows:** 4,000  **Key:** CIDR_24

/24 → application and service context.
- APP_ACRONYMS: the /24 HOSTS these applications (SERVER-role FW groups)
- CPC_SERVICES: the /24 CONSUMES these managed services (CLIENT-role FW groups)

### 2.9 ENT Ipdatasets (in ipdatasets/)

| Dataset | Version | Rows | Purpose |
|---|---|---|---|
| ent-ipdataset-INTERNET-FACING | v20260521 | 126 | Confirmed public CVS/Aetna BGP-announced subnets. CX11 authority. |
| ent-ipdataset-F5-VIP-REGISTRY | v20260520 | 15,127 | BIG-IP virtual servers with pool + SNAT mapping |
| ent-ipdataset-F5-POOL-MEMBERS | v20260520 | 62,091 | F5 pool member backend IPs per VIP |

---

## 3. Script Versions

| Script | Version | Purpose |
|---|---|---|
| ipam-db.py | v3.12.9 | Registry manager + CX1-CX12 audit engine. CX11 covers 204.99/16. |
| iplookup.sh | v3.20 | CLI query interface |
| preflight_lm_check.py | v1.0.0 | 20-anchor LM gate — hard-stops update_ipam.py on failure |
| update_ipam.py | v1.9 | IPAM import — preflight + overlap/containment check |
| update_app.py | v1.4 | EHM updates — cross-dataset IP dedup enforced |
| update_infrastructure.py | v1.3 | delivery_infrastructure — cross-dataset IP dedup |
| update_platform.py | v1.3 | delivery_platform — cross-dataset IP dedup |
| update_asi.py | v1.0.0 | app_subnet_index delta update |
| audit_ipam_hierarchy.py | v1.7.1 | IPAM hierarchy audit — LM + INTERNET-FACING validation |
| apply_ipam_remediation.py | v1.2.0 | Executes D/R/P/C/X/A remediation plan |
| generate_ipam_hierarchy_report.py | v1.1.0 | Interactive HTML hierarchy report |
| fw_rule_extraction_translation.py | v1.1.0 | Multi-format FW parser (PAN-OS, FTD, FMC JSON/CSV) |
| apply_prefix_corrections.py | v1.0.0 | NEW: applies prefix length corrections from allocation model |
| build_f5_vip_registry.py | v1.0.0 | BIG-IP TMSH parser → F5 ipdatasets |
| fw_ipam_review.py | v1.0.0 | Interactive MEDIUM IPAM candidate review |
| preprocess_p1.py | v1.5 | Stage 1: classify + gap fill + SITE_CODE derivation |
| preprocess_p2.py | v1.2 | Stage 3: normalize new hosts |
| generate_csna_hostgroups.py | v4.0.0 | CSNA Stealthwatch XML generator |
| build_csna_site_registry.py | v2.0.2 | CSNA site registry builder |

---

## 4. Pipeline Stages

### Update order — non-negotiable
```
LM → IPAM → NDM → EHM → Infra → Platform → ASI → CSNA
```

### CMDB/Qualys pipeline
Stage 1: preprocess_p1.py — classify all sources
Stage 2: update_app.py --enrich-only — EHM gap fill
Stage 3: preprocess_p2.py — normalize new hosts
Stage 4: update_ipam.py → update_network.py → update_app.py --add-only
Gate: ./ipam-db.py --cross-check after every import. 0 HIGH required.

### FW extraction pipeline (parallel)
```
build_f5_vip_registry.py          → F5 ipdatasets
fw_rule_extraction_translation.py → fw_ipam_candidates (HIGH)
                                    fw_ipam_review (MEDIUM)
                                    fw_host_candidates (/32 hosts)
                                    fw_infra_enhancement
                                    fw_platform_enhancement
                                    fw_asi_candidates
                                    fw_external_cidrs (→ EIR pending)
fw_ipam_review.py                 → fw_ipam_approved
update_infrastructure.py          → delivery_infrastructure
update_platform.py                → delivery_platform
update_ipam.py                    → all_IP_networks
update_app.py --add-file          → ent_host_master
update_asi.py --add-file          → app_subnet_index
```

**FW config format support:**
PAN-OS XML (Panorama export), PAN-OS CLI, Cisco FTD CLI, Cisco FMC JSON (_acp.json),
Cisco FMC CSV (_acp.csv/_prefilter.csv). Format auto-detected from file content/extension.

**EHM/NDM confidence gating:**
HIGH (EHM/NDM confirmed) → fw_ipam_candidates → auto-promote
MEDIUM (no host confirmation) → fw_ipam_review → manual review
/32 hosts → fw_host_candidates → EHM only, never IPAM

---

## 5. Cross-Check Engine (CX1-CX12) + Pre-Write Gates

| Rule | Severity | Description |
|---|---|---|
| CX1-AIN-LM-COVERAGE | HIGH | Every CANONICAL_LOCATION in IPAM must be in LM |
| CX1-CONTAINED (pre-write) | BLOCK | New subnet inside existing — allowed if same RD/location |
| CX1-CONTAINS-CONFLICT (pre-write) | BLOCK | New subnet contains existing with different RD or location |
| CX2-RETAIL-LM-COVERAGE | HIGH | Every retail location must be in LM |
| CX5-RETAIL-ISOLATION | HIGH | Retail /26s only in retail_networks |
| CX10-LM-SC-UNIQUE | HIGH | SITE_CODE must be unique within LM |
| CX11-INTERNET-FACING | HIGH | 204.99/16, 157.121/16, 167.69/16, 206.213/16 must be Internet-Facing. Cross-references ent-ipdataset-INTERNET-FACING. |
| CX12-CONTESTED-MISSING | MEDIUM | 172.16.0.0/12 entries with retail /26 children need CONTESTED_BLOCK=Y |
| PREFLIGHT-ANCHOR (pre-write) | BLOCK | 20 critical anchors must exist in LM |
| CROSS-DS-DEDUP (pre-write) | BLOCK | Host IP already in another host dataset |

---

## 6. IPAM Architecture — Dual-Allocation Model

172.16.0.0/12 shared between Internal-HCB (Aetna DC/campus) and Internal-Retail
(CVS retail /26 allocations). CX5 blocks retail /26s from all_IP_networks. CX12
requires CONTESTED_BLOCK=Y on /24 entries containing retail /26 children.

CVS public BGP blocks (CVS-owned, Internet-Facing):
- 204.99.0.0/16 — CVS PBM (sub-allocations may be Internal-PBM if not BGP-announced)
- 157.121.0.0/16 — Aetna public DMZ
- 167.69.0.0/16 — Aetna SIP/PCI
- 206.213.0.0/16 — Aetna/CVS shared internet-facing

Use ent-ipdataset-INTERNET-FACING to qualify individual subnets within these blocks.

---

## 7. IPAM Hierarchy Remediation

**Root cause of 3-year LM corruption:** 617 parent summary blocks had wrong
ROUTING_DOMAIN. This caused LPM lookups to return incorrect routing domains,
propagating corrupted location data into EHM, NDM, and CSNA.

**Pattern taxonomy:**
- WAN_P2P_AGGREGATE (2,050 conflicts): synthetic /24 over NMS /30 P2P links → P (set P2P-WAN)
- SYNTHETIC_AGGREGATE (1,348): auto-promoted parent, children authoritative → D (delete)
- CX11_VIOLATION (170): CVS BGP parent, children need Internet-Facing → C (fix children)
- CX11_INTERNAL_USE: CVS BGP but NOT in INTERNET-FACING dataset → A (accept Internal-PBM)
- HCB_PBM_BOUNDARY (91): wrong RD on Aetna/CVS boundary block → R (re-attribute)

**Toolchain:**
```bash
python3 audit_ipam_hierarchy.py --ipam-dir ./ipam-db --review
python3 apply_ipam_remediation.py --plan processed_outputs/ipam_hierarchy_remediation_vDATE.csv --live
./ipam-db.py --cross-check
```

---

## 8. Data Governance Rules (summary — full rules in ccd_data_governance_rules_v1.1.md)

- R1: Never rebuild from scratch — always merge from registered master
- R2: CANONICAL_LOCATION must resolve to LM CANONICAL_NAME exactly
- R3: Location derived from network topology (CIDR-LPM), never from server owner
- R7: 100.64.x.x (CGNAT) = GKE pod networking only — never host IPs
- R9: New data never overwrites existing — enhancement fills gaps only
- R11: Retail /26 subnets in 172.16-172.31 → retail_networks only
- R13: /32 host routes never valid IPAM entries → EHM via fw_host_candidates
- R14: 0 HIGH cross-check required before next pipeline stage

---

## 9. CVS DC Topology Reference

**Legacy CVS (Internal-PBM):** Shea DC (Scottsdale AZ), RI-One, RI-2100 Cumberland RI
**Legacy Aetna (Internal-HCB):** Middletown MDC, Windsor WDC, Phoenix PDC/CVTY
**COLO:** Switch LV (US_LVG_NV_CI), Switch ATL (US_ATL_GA_CI), Switch TRE Sparks NV (US_SPK_NV_CI)
**DR:** Woodbridge NJ Iron Mountain, Carlstadt NJ SunGard
**Cloud:** Azure (US_AZR_*_IS), GCP (US_GCP_*_IS), AWS (US_AWS_*_IS)
**Equinix** = cloud peering only — not primary DCs
**Retail:** 9,112 stores, 99.3% 128T SD-WAN, 172.16-172.31/26 per function per store

**IP overlap architecture:** CVS and Aetna share 10.x, 172.16.x, 100.64.x.
ROUTING_DOMAIN is the discriminator — always check it before assuming location.
