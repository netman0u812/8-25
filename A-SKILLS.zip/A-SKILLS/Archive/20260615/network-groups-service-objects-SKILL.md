---
name: network-groups-service-objects
description: >
  CCD Platform — Network Group and Service Object collection, generation, and
  reporting pipeline. Use this skill for any task involving build_network_groups.py,
  build_ng_report.py, build_service_objects.py, build_svc_report.py, EDL export,
  network object hierarchy, service object catalog, PA-compatible address groups,
  or the Net_Group/Net_Object versioned output directories. Covers input discovery,
  output structure, tier hierarchy, CLI flags, and the relationship between the
  network-source (location-based) and service-destination (function-based) object sets.
  Trigger on: "network groups", "service objects", "build_network_groups", "build_ng_report",
  "build_service_objects", "build_svc_report", "NG-DATACENTER", "NG-SVC-APP", "EDL export",
  "Net_Group", "Net_Object", "network object catalog", "service object catalog",
  "PAN-OS address groups", "tier-1 tier-2 tier-3", "NAAS-HUB", "ccd_network_groups.set",
  "ng_manifest.csv", "service_objects.set", "edl_catalog".
---

# Network Groups & Service Objects — Pipeline Reference

## 1. The Two Object Sets

The CCD firewall object model has two complementary halves:

| Set | Purpose | Builder | Report |
|-----|---------|---------|--------|
| **Network Groups** | SOURCE side — where is traffic coming from? Location-based CIDR hierarchy | `build_network_groups.py` | `build_ng_report.py` |
| **Service Objects** | DESTINATION side — what is being accessed? Function-based host/CIDR hierarchy | `build_service_objects.py` | `build_svc_report.py` |

Both feed PAN-OS address-group policy. Neither replaces the other — a complete rule references a Network Group (source) and a Service Object (destination).

---

## 2. Network Groups Pipeline

### 2.1 What it builds

A 3-tier PAN-OS source Network-Object hierarchy derived from IPAM + Location Master:

```
Tier-1  Business-unit / site-type class
        NG-DATACENTER, NG-DR, NG-CLOUD, NG-CORPORATE, NG-RETAIL,
        NG-MINUTECLINIC, NG-COLO, NG-NAAS-HUB, NG-PARTNER, NG-VPN, etc.

Tier-2  Location breakout (SITE_CODE for named facilities)
        NG-DATACENTER-SHEA-DC, NG-CORPORATE-EAST-VA, NG-RETAIL-PHARMA-TX, etc.
        Corporate: state + East/West region split (Mississippi line default)
        Retail/MC/Optical: function + state (e.g. NG-RETAIL-PHARMA-TX)
        Cloud: provider grouping (NG-CLOUD-AZURE, NG-CLOUD-GCP, etc.)

Tier-3  Concatenated CIDR address objects — the ONLY tier where IP literals exist
        addr-SHEA-DC-10.38.5.0_24, addr-RETAIL-TX-172.16.100.0_26, etc.
```

**Critical design rules:**
- Tier-1 classification comes from `location_master.LOCATION_TYPE` joined via SITE_CODE — NOT from the denormalized copy in `all_IP_networks`
- Retail emits **native /26 address groups** — no EDLs (conserves finite EDL slots for SOC feeds)
- LOCATION × IP is the grouping key — not IP alone (172.16.0.0/12 overlap between Aetna DC and CVS retail /26s requires SITE_CODE disambiguation)
- Retail SITE_CODE state code is at index 1: `US_<STATE>_<STORENUM>_<TYPE>`

### 2.2 Inputs

| Input | Auto-discovered from | Override flag |
|-------|---------------------|---------------|
| all_IP_networks | `ipam-db/all_IP_networks_v*.csv` | `--ipam` |
| location_master | `ipam-db/location_master_table.csv` (preferred) or `location_master_v*.csv` | `--lm` |
| retail_networks | `ipam-db/retail_networks_v*.csv` | `--retail` |
| internet_segments | `network-groups/internet_segments_v*.csv` | `--inet-segments` |

### 2.3 Outputs

All outputs land in a versioned directory: `./Net_Group/NG-YYYYMMDD_vN/`

| File | Content |
|------|---------|
| `ccd_network_groups.set` | PAN-OS set-format CLI — address objects + Tier-3/2/1 groups + retail /26 groups |
| `network_object_catalog_v*.csv` | Flat Tier1/Tier2/Tier3/CIDR manifest — fed to `build_ng_report.py` and `iplookup.sh --ng` |
| `ng_manifest.csv` | Summary: Tier1 class → row count |
| `ng_reconciliation.csv` | Rows where `all_IP_networks.LOCATION_TYPE` ≠ `location_master.LOCATION_TYPE` — data quality signal |
| `ng_overlap_violations.csv` | CIDR overlap violations from the 3-pass resolver (should be 0 HIGH before deployment) |
| `retail_oversized_blocks.csv` | Retail blocks broader than /26 — kept intact, flagged for review |
| `EDL/` subdir | PA-compatible EDL `.txt` files — one per Tier-1 class + one per named group (requires `--edl`) |

### 2.4 CLI

```bash
# Auto-discover all inputs, output to ./Net_Group/NG-YYYYMMDD_vN/
python3 build_network_groups.py

# Full explicit run
python3 build_network_groups.py \
    --ipam   ipam-db/all_IP_networks_v20260611r2.csv \
    --lm     ipam-db/location_master_table.csv \
    --retail ipam-db/retail_networks_v2.9.csv \
    --out    ./Net_Group/NG-20260612_v1 \
    --dry-run

# Dry-run (counts without writing files)
python3 build_network_groups.py --dry-run

# Include EDL .txt exports
python3 build_network_groups.py --edl

# Override East/West region split (default: Mississippi line)
python3 build_network_groups.py --east VA,NC,SC,GA,FL,MD,DE,NJ,NY,CT,RI,MA,NH,VT,ME,PA,WV,OH,MI

# Use LOCATION_TYPE from all_IP_networks instead of LM (not recommended)
python3 build_network_groups.py --tier1-source ipam

# Specify base directory for auto-discovery
python3 build_network_groups.py --base ~/Documents/IP_Lookup
```

### 2.5 3-Pass Overlap Resolver

Runs automatically before building the hierarchy. Writes `ng_overlap_violations.csv`.

| Pass | What it checks | Output |
|------|----------------|--------|
| Pass 1 — SITE_CODE uniqueness | Same CIDR under two SITE_CODEs → HIGH EXACT_DUP_CROSS_SITE (retail/DC 172.16 overlap is expected → INFO) | Per-SITE_CODE clean CIDR set |
| Pass 2 — Intra-site supernet suppression | Within a SITE_CODE, LPM wins — supernets suppressed. P2P /30-/31 and /32 host routes excluded | INFO INTRASITE_SUPERNET_SUPPRESSED |
| Pass 3 — Inter-site LPM conflict | Exact cross-site match → HIGH. More-specific from other site at /30-/31 → INFO P2P_SPLIT. More-specific at /29+ → HIGH SITE_CARVEOUT | Violation CSV |

**Gate:** 0 HIGH violations from the overlap resolver before deploying the `.set` file.

### 2.6 TIER1_TAXONOMY — LM LOCATION_TYPE → Tier-1 class mapping

Key mappings (as of v1.8.3):

| LM LOCATION_TYPE | Tier-1 Class |
|-----------------|-------------|
| DataCenter, DC | NG-DATACENTER |
| DR, DRSite | NG-DR |
| COLO, Colocation, CI | NG-COLO |
| Cloud, CloudInfra, IS | NG-CLOUD |
| Corporate, Office, SP | NG-CORPORATE |
| Retail, Store | NG-RETAIL |
| MinuteClinic, MC | NG-MINUTECLINIC |
| OpticalCenter, OC | NG-OPTICAL |
| CarePlus, CP | NG-CAREPLUS |
| NAAS-Hub, NH, VoIP-Hub | NG-NAAS-HUB |
| Cloud-Peering | NG-CLOUD (v1.8.3+) |
| Partner | NG-PARTNER |

Sites with LOCATION_TYPE not in the taxonomy fall into `ng_reconciliation.csv` as unclassified.

---

## 3. Network Groups Report

### 3.1 What it builds

A self-contained interactive HTML drill-down explorer from the `network_object_catalog_v*.csv`.
No web server, no internet, no external dependencies — open directly in a browser.

Features: Tier-1 class tree → click to expand locations → click location to see CIDRs. Live search. Summary statistics. IPAM LPM cross-links (optional, requires `--ipam` in the report — currently via `iplookup.sh`).

### 3.2 CLI

```bash
# Auto-discover latest catalog from Net_Group/NG-YYYYMMDD_vN/
python3 build_ng_report.py

# Explicit catalog
python3 build_ng_report.py --catalog ./Net_Group/NG-20260612_v1/network_object_catalog_v20260612.csv

# Explicit output path
python3 build_ng_report.py --catalog <file> --out ./reports/ng_report.html

# Specify base directory
python3 build_ng_report.py --base ~/Documents/IP_Lookup
```

Output defaults to the same versioned `Net_Group/NG-YYYYMMDD_vN/` directory as the catalog.

---

## 4. Service Objects Pipeline

### 4.1 What it builds

A destination-side service object catalog — the complement to network groups. Produces a PAN-OS address-group hierarchy keyed on function (what is this thing) rather than location (where is it).

**SERVICE OBJECT TAXONOMY:**

```
Tier-1 class        Tier-2 type    Tier-3 named group           Members
NG-SVC-APP          APP            SVC_{APP_ACRONYM}            /32 host IPs (from EHM)
NG-SVC-INFRA        INFRA          SVC_{INFRA_NAME}             /32 host IPs (from delivery_infrastructure)
NG-SVC-SERVICE      SERVICE        SVC_{SERVICE_NAME}           /32 host IPs (shared enterprise services)
NG-SVC-DELIVERY     DELIVERY       SVC_{DELIVERY_NAME}          /32 host IPs (from delivery_platform)
NG-SVC-CPC          CPC            SVC_CPC_{SLUG}               /32 host IPs (from CPC subnet → EHM LPM)
NG-EXT-INFRA        EXT_INFRA      EXT_INFRA_{PROVIDER}_{SVC}   CIDR ranges (external infrastructure)
NG-EXT-SVC          EXT_SVC        EXT_SVC_{PROVIDER}_{SVC}     CIDR ranges (external services)
NG-EXT-APP          EXT_APP        EXT_APP_{PROVIDER}_{SVC}     CIDR ranges (external apps)
NG-VPN-SVC          VPN            SVC_VPN_{PARTNER}            CIDR ranges (partner VPN side)
NG-P2P-SVC          P2P            SVC_P2P_{PARTNER}_{SITE}     CIDR ranges (partner P2P/MPLS side)
```

### 4.2 Inputs

| Input | Auto-discovered from | Override flag |
|-------|---------------------|---------------|
| canonical_app_objects | `processed_outputs/canonical_app_objects_v*.csv` | `--app-objects` |
| ent-ipdataset-CPC-CORE-SERVICES | `ipam-db/ent-ipdataset-CPC-CORE-SERVICES-v*.csv` | `--cpc-services` |
| ext_canonical_objects | `processed_outputs/ext_canonical_objects_v*.csv` | (auto) |
| ent-ipdataset-VPN-PROTECTED-SUBNETS | `ipdatasets/ent-ipdataset-VPN-PROTECTED-SUBNETS-v*.csv` | `--vpn-subs` |
| ent-ipdataset-P2P-PROTECTED-SUBNETS | `ipdatasets/ent-ipdataset-P2P-PROTECTED-SUBNETS-v*.csv` | `--p2p-subs` |

### 4.3 Outputs

All outputs land in: `./Net_Object/SO-YYYYMMDD_vN/`

| File | Content |
|------|---------|
| `service_objects_v*.set` | PAN-OS set-format address objects + groups |
| `service_object_catalog_v*.csv` | Tool-agnostic flat catalog — fed to `build_svc_report.py` and `iplookup.sh` |
| `EDL/` subdir | PA-compatible EDL `.txt` files — one per Tier-1 class + one per service object (requires `--edl`) |

### 4.4 CLI

```bash
# Auto-discover all inputs
python3 build_service_objects.py

# Specify base directory
python3 build_service_objects.py --base ~/Documents/IP_Lookup

# Dry-run
python3 build_service_objects.py --dry-run

# Include EDL .txt exports
python3 build_service_objects.py --edl

# Explicit inputs
python3 build_service_objects.py \
    --app-objects processed_outputs/canonical_app_objects_v20260612.csv \
    --cpc-services ipam-db/ent-ipdataset-CPC-CORE-SERVICES-v20260520.csv \
    --out ./Net_Object/SO-20260612_v1
```

---

## 5. Service Objects Report

### 5.1 What it builds

Self-contained interactive HTML — same drill-down pattern as the network groups report but for service objects. Left panel: Tier-1 class tree → named service objects. Right panel: member IPs/CIDRs, heritage, routing domain, count. Header stats. Live search.

Optional `--ipam` flag cross-links members back to their IPAM location via LPM ("which locations have hosts in this service?").

### 5.2 CLI

```bash
# Auto-discover latest catalog from Net_Object/SO-YYYYMMDD_vN/
python3 build_svc_report.py

# Explicit catalog
python3 build_svc_report.py --catalog ./Net_Object/SO-20260612_v1/service_object_catalog_v20260612.csv

# Explicit output
python3 build_svc_report.py --catalog <file> --out ./reports/svc_report.html

# Specify base
python3 build_svc_report.py --base ~/Documents/IP_Lookup
```

---

## 6. Standard Run Sequence

Run in this order. Do not skip steps.

```bash
# Step 1 — Confirm IPAM and LM are current (0 HIGH cross-check)
python3 ipam-db.py --cross-check

# Step 2 — Rebuild app_subnet_index if EHM was updated
python3 build_app_subnet_index.py
python3 ipam-db.py --import app-inventory/app_subnet_index_vDATE.csv --type app_subnet_index

# Step 3 — Rebuild canonical app objects (requires v2.2.0)
python3 build_canonical_app_objects_explorer.py

# Step 4 — Build network groups
python3 build_network_groups.py --dry-run        # check counts
python3 build_network_groups.py                  # write Net_Group/NG-YYYYMMDD_vN/

# Step 5 — Build network groups report
python3 build_ng_report.py                       # auto-discovers latest NG dir

# Step 6 — Build service objects
python3 build_service_objects.py --dry-run
python3 build_service_objects.py                 # write Net_Object/SO-YYYYMMDD_vN/

# Step 7 — Build service objects report
python3 build_svc_report.py

# Step 8 — View via local web server
./object-viewer-web-service.sh
# Open: http://127.0.0.1:8080/edl_catalog.html
```

---

## 7. Output Directory Structure

```
~/Documents/IP_Lookup/
├── Net_Group/
│   └── NG-20260612_v1/
│       ├── ccd_network_groups.set
│       ├── network_object_catalog_v20260612.csv
│       ├── ng_manifest.csv
│       ├── ng_reconciliation.csv
│       ├── ng_overlap_violations.csv
│       ├── retail_oversized_blocks.csv
│       ├── ng_report.html                    ← from build_ng_report.py
│       └── EDL/                              ← if --edl flag used
│           ├── NG-DATACENTER.txt
│           ├── NG-RETAIL.txt
│           └── ...
│
└── Net_Object/
    └── SO-20260612_v1/
        ├── service_objects_v20260612.set
        ├── service_object_catalog_v20260612.csv
        ├── svc_report.html                   ← from build_svc_report.py
        └── EDL/                              ← if --edl flag used
            ├── NG-SVC-APP.txt
            ├── NG-EXT-INFRA.txt
            └── ...
```

---

## 8. Script Versions (EOD June 11, 2026)

| Script | Version | Key recent changes |
|--------|---------|-------------------|
| build_network_groups.py | v1.8.3 | TIER1_TAXONOMY: added NAAS-Hub and Cloud-Peering entries; retail converted to native /26 groups (v1.1.0) |
| build_ng_report.py | v1.3.2 | discover_inputs() finds catalog in Net_Group/NG-YYYYMMDD_vN/ (v1.3.1) |
| build_service_objects.py | v1.0.3 | Output to versioned Net_Object/SO-YYYYMMDD_vN/ subdir (v1.0.3) |
| build_svc_report.py | v1.0.4 | discover_inputs() prefers Net_Object/SO-YYYYMMDD_vN/ (v1.0.4) |
| object-viewer-web-service.sh | — | Local HTTP server on 127.0.0.1:8080; serves IP_Lookup/ root |

---

## 9. Known Issues / Watchlist

| Item | Status | Notes |
|------|--------|-------|
| SD-WAN and RA-VPN NET_TYPEs | Generating LOW violations in `_AUDIT_VALID_NET_TYPES` | Add to allowlist in `ipam-db.py` (P2 next session) |
| app_subnet_index | STALE — v20260610r2 | Rebuild from EHM r11 before running service objects pipeline |
| build_canonical_app_objects_explorer.py | v2.2.0 required | v2.1.0 was incorrectly uploaded last session — upload correct version before object pipeline |
| P2P-PROTECTED-SUBNETS data quality | 11 rows with CIDR=10.0.0.0/8 from legacy ASA ACLs | Extractor script fix pending; patch required before service objects can ingest VPN/P2P dataset cleanly |
