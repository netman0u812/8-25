---
name: ipam-dataset-rules
description: >
  Authoritative rules for what IP data belongs in which CCD Platform dataset.
  Use whenever adding subnets, deciding dataset placement, reviewing IPAM imports,
  or building enrichment lookups. Prevents architectural errors like adding /32 hosts
  to all_IP_networks or putting retail subnets in the wrong dataset.
  Triggers on: "where does this subnet go", "what dataset", "should this be in IPAM",
  "which file", "what type ipdataset", "Internet-Facing", "retail subnet",
  "partner subnet", "public IP", "ENT ipdataset", "all_IP_networks vs",
  "add to IPAM", "/32 host", "FW candidate", "fw_ipam_candidates", "fw_host_candidates".
---

# CCD Platform — IPAM Dataset Placement Rules

## Decision Tree (apply in order — stop at first match)

```
Is it a retail store /26 subnet?
  YES → retail_networks ONLY. Never all_IP_networks. (CX5 hard block)

Is it a /32 host IP?
  YES → ent_host_master (EHM) via update_app.py --add-file
        NEVER all_IP_networks. (Rule R13 — /32 host routes are not valid IPAM entries)

Is it a physical compute infrastructure host? (ESXi, HMC, iSeries, DataPower, Isilon)
  YES → delivery_infrastructure via update_infrastructure.py
        Must NOT also be in EHM or delivery_platform (cross-dataset dedup enforced)

Is it a container/orchestration node? (K8s, OCP, Docker, RHCOS)
  YES → delivery_platform via update_platform.py
        Must NOT also be in EHM or delivery_infrastructure

Is it an external (non-CVS-owned) public IP from a FW rule?
  YES → fw_external_cidrs → build_external_ip_registry.py (EIR — pending)
        NEVER all_IP_networks

Is it a confirmed CVS/Aetna BGP-announced public subnet?
  YES → all_IP_networks with ROUTING_DOMAIN=Internet-Facing
        Cross-reference ent-ipdataset-INTERNET-FACING to confirm

Is it a subnet from a FW address object group (HIGH confidence — EHM/NDM confirmed)?
  YES → fw_ipam_candidates → update_ipam.py
        update_ipam.py v1.9 runs pre-write overlap check — will reject conflicts

Is it a subnet from a FW address object group (MEDIUM — no host confirmation)?
  YES → fw_ipam_review → manual review via fw_ipam_review.py → fw_ipam_approved

Is it a /24 → application context mapping?
  YES → app_subnet_index via update_asi.py
        SERVER-role groups → APP_ACRONYMS
        CLIENT-role groups → CPC_SERVICES

Is it a WAN P2P /30 or /29?
  YES → all_IP_networks with ROUTING_DOMAIN=P2P-WAN, NET_TYPE=P2P-WAN

Is it an F5 virtual server (VIP)?
  YES → ent-ipdataset-F5-VIP-REGISTRY via build_f5_vip_registry.py
        NOT all_IP_networks — VIP IPs resolve to pool members for attribution

Is it everything else (enterprise subnet, DC, corporate, cloud)?
  YES → all_IP_networks via update_ipam.py
```

---

## Dataset Placement Reference

| IP type | Dataset | Script |
|---|---|---|
| Enterprise subnets (/17-/29) | all_IP_networks | update_ipam.py |
| Retail /26 store subnets | retail_networks | (separate pipeline) |
| /32 host IPs from FW | ent_host_master | update_app.py --add-file |
| ESXi/HMC/iSeries/DataPower | delivery_infrastructure | update_infrastructure.py |
| K8s/OCP/Docker nodes | delivery_platform | update_platform.py |
| /24 → app context | app_subnet_index | update_asi.py |
| WAN P2P /30s | all_IP_networks (P2P-WAN) | update_ipam.py |
| CVS BGP public /24s | all_IP_networks (Internet-Facing) | update_ipam.py |
| External public IPs | ent-ipdataset-EXT-IP-REGISTRY (pending) | build_external_ip_registry.py |
| F5 VIP addresses | ent-ipdataset-F5-VIP-REGISTRY | build_f5_vip_registry.py |
| F5 pool member IPs | ent-ipdataset-F5-POOL-MEMBERS | build_f5_vip_registry.py |
| Confirmed public BGP subnets | ent-ipdataset-INTERNET-FACING | manual / BGP data |

---

## Hard Rules

1. **Never add /32s to all_IP_networks** — they are host routes, not subnets
2. **Never add retail /26s to all_IP_networks** — CX5 will block and flag HIGH
3. **Never add external public IPs to all_IP_networks** — they belong in EIR
4. **Cross-dataset dedup is enforced** — a host IP in delivery_infrastructure must
   not also be in ent_host_master (update scripts v1.3/v1.4 enforce at write time)
5. **F5 VIP IPs must be in F5-VIP-REGISTRY** — fw_rule_extraction_translation.py
   cross-references this to redirect attribution to pool members
6. **SNAT pool IPs must NOT generate IPAM candidates** — they are translated addresses

---

## ENT Ipdataset Registration

All ENT ipdatasets live in `ipdatasets/` and are registered in `ip_dataset.json`:

```bash
./ipam-db.py --import ./ipdatasets/ent-ipdataset-NAME-vDATE.csv --type ent-ipdataset
```

Current registered ENT ipdatasets:
- ent-ipdataset-INTERNET-FACING-v20260521 (126 rows)
- ent-ipdataset-F5-VIP-REGISTRY-v20260520 (15,127 rows)
- ent-ipdataset-F5-POOL-MEMBERS-v20260520 (62,091 rows)
