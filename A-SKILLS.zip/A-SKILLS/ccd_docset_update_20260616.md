# CCD Platform — Docset Update Memo
**Date:** 2026-06-16  
**Author:** M. J. Martin, Lead Director Information Security  
**Session:** Compute Substrate Attribution — New Pipeline Stage

---

## Summary of Changes

This session introduced `update_compute_substrate.py` as a new pipeline stage
and registered `compute_substrate` as a named ENT ipdataset. The following
CCD docset documents require updates.

---

## 1. CCD Pipeline Command Tree

**Document:** `CCD_Pipeline_Command_Tree_vX.Y.txt`  
**Change:** Insert new stage between `update_app.py` and `update_asi.py`

### Updated pipeline sequence (update chain):

```
preprocess_p1.py                    # CMDB → EHM raw build
preprocess_p2.py                    # EHM cross-check and validation
update_location.py                  # delta update location_master
update_ipam.py                      # delta update all_IP_networks
update_network.py                   # delta update ent_network_device_master
update_infrastructure.py            # stamp delivery_infrastructure fields
update_platform.py                  # stamp delivery_platform fields
update_app.py                       # stamp EHM app/enrichment fields
update_app.py --vmware-enrich       # stamp VMware exit fields (if CMDB updated)
update_compute_substrate.py         # ← NEW: derive COMPUTE_SUBSTRATE from EHM+IPAM
ipam-db.py --import ./ipam-db/compute_substrate_vDATE.csv --type compute_substrate
update_asi.py                       # delta update app_subnet_index
build_object_pipeline.py --edl      # Stages 1–5: canonical objects → EDL
collect-edl_bundle.sh               # package EDL catalog
```

---

## 2. CCD Data Dictionary / Dataset Catalog

**Document:** `CCD_Data_Dictionary_vX.Y.docx` or equivalent  
**Change:** Add new dataset entry

### New dataset: `compute_substrate`

| Field | Value |
|---|---|
| Stem | `compute_substrate` |
| Filename pattern | `compute_substrate_vYYYYMMDD.csv` |
| Location | `ipam-db/` |
| Produced by | `update_compute_substrate.py v1.0.0` |
| Registered as | ENT ipdataset (`COMPUTE-SUBSTRATE` in `ENT_DESCRIPTORS`) |
| Row key | `IP_ADDRESS` |
| Rows | ~61,492 (one per EHM host) |
| Refresh cadence | Every EHM update cycle, after `update_app.py` |

### Schema:

| Column | Description |
|---|---|
| `IP_ADDRESS` | Host IP — primary key, joins to EHM |
| `SITE_CODE` | FK to location_master |
| `CANONICAL_LOCATION` | Human-readable location |
| `ROUTING_DOMAIN` | EHM routing domain |
| `COMPUTE_SUBSTRATE` | Derived substrate type (see taxonomy below) |
| `SUBSTRATE_SOURCE` | How substrate was derived (see sources below) |
| `SUBSTRATE_CONFIDENCE` | Confidence level of derivation |
| `DATA_QUALITY_FLAG` | CMDB/IPAM data quality issues detected |
| `IPAM_CIDR` | Containing IPAM block (Tier 3 only) |
| `IPAM_NET_TYPE` | NET_TYPE of containing block (Tier 3 only) |
| `IPAM_ROUTING_DOMAIN` | ROUTING_DOMAIN of containing block (Tier 3 only) |
| `DATASET_VERSION` | Dataset version stamp |
| `LOC_MASTER_VERSION` | Location master version used during derivation |

### COMPUTE_SUBSTRATE taxonomy:

| Value | Description |
|---|---|
| `VMWARE` | VMware ESX hypervisor — HYPERVISOR=VMWARE stamp in EHM |
| `CLOUD_IAAS` | Cloud VM — Azure/GCP/AWS IaaS or cloud routing domain |
| `CLOUD_PAAS` | Cloud platform service |
| `CLOUD_SAAS` | Cloud SaaS application |
| `CLOUD_OTHER` | Cloud DaaS/FaaS |
| `IBM_LPAR` | IBM AIX LPAR — IS_VIRTUAL=TRUE + SERVER_CLASS=AIX Server |
| `SOLARIS_ZONE` | Solaris zone — IS_VIRTUAL=TRUE + SERVER_CLASS=Solaris Server |
| `SHARED_SERVER` | Shared application server — PLATFORM_TYPE=SHARED-SERVER |
| `CONTAINER` | Container workload — PLATFORM_TYPE=CONTAINER-BRIDGE |
| `BARE_METAL` | Physical on-premises server — IS_VIRTUAL=FALSE |
| `ONPREM_VIRTUAL_UNSTAMPED` | Virtual on-prem, hypervisor unknown (Hyper-V or missed VMware stamp) |
| `UNKNOWN` | No substrate signal available |

### SUBSTRATE_SOURCE values:

| Value | Description |
|---|---|
| `DIRECT` | Explicit EHM field signal (HYPERVISOR, CLOUD_COMPUTING, PLATFORM_TYPE, etc.) |
| `INFERRED_SUBNET` | /24 neighbor density inference within SITE_CODE |
| `INFERRED_IPAM` | IPAM LPM allocation context — substrate unknown, block context known |
| `UNRESOLVED` | No signal available from any tier |

### SUBSTRATE_CONFIDENCE values:

| Value | Description |
|---|---|
| `HIGH` | DIRECT explicit stamp, or 100% pure subnet inference |
| `MEDIUM` | DIRECT inferred (SITE_CODE prefix), or 80-99% subnet inference |
| `LOW` | 60-79% subnet inference, or DIRECT low-confidence signal |
| `CONTEXT_ONLY` | INFERRED_IPAM — allocation context only, substrate not known |
| `NONE` | UNRESOLVED |

### DATA_QUALITY_FLAG values:

| Value | Description |
|---|---|
| `CMDB_CLASS_CLOUD_MISMATCH` | Physical-only SERVER_CLASS (AIX/Solaris) on a cloud SITE_CODE — CMDB record is wrong |
| `IPAM_LOCATION_MISMATCH` | EHM ROUTING_DOMAIN is on-prem but IPAM resolves IP to a cloud block — IPAM or SITE_CODE attribution error |

---

## 3. Script Version Reference Table

**Document:** Any document containing the CCD script version table  
**Change:** Three version bumps + one new entry

| Script | Old Version | New Version | Change |
|---|---|---|---|
| `update_app.py` | v1.9 | v1.10 | `--vmware-enrich` flag added |
| `update_compute_substrate.py` | (new) | v1.0.0 | New pipeline stage |
| `ipam-db.py` | v3.15.13 | v3.15.14 | COMPUTE-SUBSTRATE ENT descriptor + diff config |
| `check_toolset.py` | v1.3.1 | v1.4.0 | Version entries updated |

---

## 4. CCD Runbook — EHM Update Cycle

**Document:** `CCD_EHM_Update_Runbook_vX.Y.docx` or equivalent  
**Change:** Insert `update_compute_substrate.py` step after `update_app.py`

### Insert after the `update_app.py` section:

---

**Step N+1: Derive Compute Substrate Attribution**

Run after every `update_app.py` cycle that updates HYPERVISOR, CLOUD_COMPUTING,
PLATFORM_TYPE, or ROUTING_DOMAIN fields.

```bash
# Dry run — review coverage summary before writing
python3 update_compute_substrate.py --dry-run

# Write to ipam-db/
python3 update_compute_substrate.py

# Register, checksum, diff against prior version, archive
python3 ipam-db.py \
    --import ./ipam-db/compute_substrate_v$(date +%Y%m%d).csv \
    --type compute_substrate \
    --description "Compute substrate attribution — three-tier derivation from EHM+IPAM"
```

**What to review in the dry-run output:**
- `Truly unresolvable` count should be < 50. Higher indicates an IPAM coverage gap.
- `DATA_QUALITY flags raised` — each flag is a CMDB or IPAM error requiring investigation.
- Per-site UNKNOWN% — sites with >50% UNKNOWN warrant a targeted CMDB refresh request.
- Compare CLOUD_IAAS count against known Azure/GCP/AWS host count — significant
  discrepancy indicates cloud hosts not stamped with ROUTING_DOMAIN or SITE_CODE.

**Expected output file:** `ipam-db/compute_substrate_vYYYYMMDD.csv`  
**Import diff:** shows hosts that changed substrate type since last cycle — review
before proceeding to `update_asi.py`.

---

## 5. ipam-db.py ENT Dataset Registry

**Document:** `CCD_IPAM_DB_Reference_vX.Y.docx` or equivalent  
**Change:** Add COMPUTE-SUBSTRATE to ENT ipdatasets table

| Descriptor | Stem | Produced by | Key | Purpose |
|---|---|---|---|---|
| `F5-VIP-REGISTRY` | `ent_f5_vip_registry` | `build_f5_vip_registry.py` | `VIP_IP` | F5 virtual server inventory |
| `F5-POOL-MEMBERS` | `ent_f5_pool_members` | `build_f5_vip_registry.py` | `MEMBER_IP` | F5 pool member IPs |
| `CPC-CORE-SERVICES` | `ent_cpc_core_services` | CPC template import | `IP_ADDRESS` | CPC baseline service IPs |
| `EGRESS-FW-TOPOLOGY` | `ent-ipdataset-EGRESS-FW-TOPOLOGY` | `build_egress_fw_topology.py` | `CIDR` | Egress firewall mapping |
| `EGRESS-FW-UNMATCHED` | `ent-ipdataset-EGRESS-FW-UNMATCHED` | `build_egress_fw_topology.py` | `SOURCE_SUBNET` | Unmatched egress subnets |
| **`COMPUTE-SUBSTRATE`** | **`compute_substrate`** | **`update_compute_substrate.py`** | **`IP_ADDRESS`** | **Per-host compute substrate attribution** |

---

## 6. Open Items Created This Session

The following items were identified during this session and require follow-up:

| Item | Site | Detail | Action |
|---|---|---|---|
| CMDB_CLASS_CLOUD_MISMATCH | `US_GCP_USE4_IS` | GKE node `gke-alta-prod` stamped SERVER_CLASS=AIX Server | CMDB correction — reclassify to Linux Server |
| CMDB_CLASS_CLOUD_MISMATCH | `US_AZR_UE2_IS` | `raz1domsapa` hostname (Shea PBM) at `100.64.1.61` — CGNAT IP in Azure pod CIDR space | Verify: is this host actually in Azure, or is IP assignment wrong in CMDB? |
| CMDB coverage gap | `US_HFD_CT_CO1` | Hartford Aetna HQ — 543 of 787 hosts UNKNOWN substrate | Request CMDB refresh for Hartford campus endpoint records |
| CMDB coverage gap | `IN_GGN_HR_TP` | Gurgaon India offshore — 103 hosts, 100% UNKNOWN | Request CMDB enrichment from offshore facility owner |
| LM/EHM attribution | `US_MPR_IL_CO1` | Mount Prospect — dispensing/SCADA workloads under Corporate LOCATION_TYPE | Reclassify LM entry to Mail-Order; remap EHM rows to `US_MPR_IL_MO` |
| IPAM cleanup | `100.64.0.0/16` | Parent /16 block in IPAM attributed to GCP — violates no-/16-parent rule | Review; determine if block should be decomposed or removed |

---

*CCD Platform | CVS Health Information Security | June 16, 2026*
