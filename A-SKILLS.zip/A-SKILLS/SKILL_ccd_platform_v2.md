---
name: ccd-platform-data-model
description: >
  CCD Platform (Cyber & Compliance Data) — CVS Health Information Security.
  Use this skill for any task involving the CCD Platform datasets, IPAM operations,
  iplookup.sh queries, pipeline stages, overlap management, firewall rule translation,
  or CSNA host group generation. Covers dataset schemas, architectural rules, update
  order, cross-check constraints, the dual-dataset overlap model, routing domain
  architecture, firewall topology model, and canonical object pipeline. Trigger on:
  "IPAM", "iplookup", "all_IP_networks", "retail_networks", "location_master",
  "ent_host_master", "CSNA", "ROUTING_DOMAIN", "CANONICAL_LOCATION", "CX cross-check",
  "dual-allocation", "Internal-HCB", "Internal-PBM", "Internal-Retail",
  "pa_rule_translator", "intent rules", "app_subnet_index", "CCD pipeline",
  "build_object_pipeline", "CPC", "service objects", "network groups", "EDL",
  "egress firewall", "fw_site_topology", "build_fw_site_topology".
---

# CCD Platform — Data Model Reference
**Updated:** 2026-06-15  **SKILL version:** 2.0

## 1. Platform Overview

The CCD (Cyber and Compliance Data) Platform is a Python/Bash toolset for enterprise
IPAM management, network security visibility, canonical object generation for Palo Alto
(PA) deployment, CSNA Stealthwatch host group generation, and firewall rule enrichment
at CVS Health.

**Core problem:** CVS and Aetna were never merged at the network layer after the 2018
acquisition. Both use RFC1918 10.x, 172.16.0.0/12, and CGNAT 100.64.x space in
completely separate routing planes. The platform manages this overlap through strict
dataset separation and the ROUTING_DOMAIN field as the primary discriminator.

**Routing domain sovereignty:**
- Internal-PBM = CVS sovereign address space
- Internal-HCB = Aetna sovereign address space
- Internal-Retail = Retail store space (172.16/12 /26s)
- SNAT is required for ALL cross-domain traffic due to RFC1918 overlap

**No internal FW within routing domains.** East-west traffic within Internal-PBM or
Internal-HCB does not traverse a firewall. Firewall enforcement only applies at domain
boundaries: extranet (PBM↔HCB), cloud peering, internet egress, and retail edge.

---

## 2. Dataset Catalog

### 2.1 location_master (LM)
**Current version:** v5.22  **Rows:** 11,570  **Key:** SITE_CODE / CANONICAL_NAME

The root of the entire model. Every physical and logical site. Nothing enters any
downstream dataset without a CANONICAL_LOCATION that resolves to an active LM entry.

| Column | Purpose |
|--------|---------|
| SITE_CODE | Primary key — format US_[CITY]_[STATE]_[TYPE] e.g. US_SCO_AZ_DC |
| CANONICAL_NAME | Human-readable location name e.g. "Scottsdale AZ - Shea DC" |
| LOCATION_TYPE | Retail / DataCenter / Corporate / MinuteClinic / CarePlus / COLO / Cloud / Partner / etc. |
| HERITAGE | CVS / AETNA / OMNICARE / OSH / SWITCH / PARTNER |
| STATUS | Active / Retired / Decom-Candidate |
| NET_TYPE | Operational function classification (see §6) |
| HOSTNAME_PREFIX | Hostname prefix used for T5 location derivation |

**Hard gate:** `CANONICAL_LOCATION` must exist in LM before ANY subnet or host row is
committed. Update order enforced: LM → IPAM → NDM → EHM → Infra → Platform.

### 2.2 all_IP_networks (IPAM)
**Current version:** v20260611r11  **Rows:** 24,944  **Key:** CIDR

Enterprise IPAM — all non-retail subnets. Single source of truth for subnet→location
mapping for DC, corporate, COLO, cloud, and Internet-Facing space.

| Column | Critical values |
|--------|----------------|
| CIDR | Network in CIDR notation (normalized, strict=False) |
| CANONICAL_LOCATION | Must match LM CANONICAL_NAME exactly |
| SITE_CODE | Must match LM SITE_CODE |
| ROUTING_DOMAIN | **Primary discriminator** — see §3 |
| HERITAGE | CVS / AETNA / SWITCH / OMNICARE / PARTNER |
| NET_TYPE | DataCenter / Corporate / DMZ / ISP-Link / Cloud-Azure / Internet-Facing / etc. |
| DATA_QUALITY | Authoritative / Inferred / Manual (never blank) |
| STATUS | Active / Reserved / Decom |

**Rules:**
- Retail /26 subnets NEVER appear here — they live in retail_networks only
- Every row requires DATA_QUALITY to be populated (blank = CX violation)
- BGP-announced public prefixes (206.213.x, 157.121 DMZ, 167.69 PCI/SIP) = Internet-Facing

### 2.3 retail_networks
**Current version:** v2.9  **Rows:** 294,343  **Key:** CIDR

Per-store /26 subnet allocations. Exists as a separate dataset specifically because CVS
retail stores use 172.16.0.0/12 — the same space Aetna uses for DC infrastructure. This
separation is architectural, not optional.

| Column | Notes |
|--------|-------|
| CIDR | /26 per-store function, /24 parent summary rows, /32 device rows |
| STORE_NUMBER | CVS store number — format US_[STATE]_[STORE_NUM]_[TYPE] |
| FACILITY_TYPE | Retail-Store / MinuteClinic / Optical |
| NET_TYPE | Retail-Store / Retail-MinuteClinic / Retail-Optical |
| SITE_CODE | US_[STATE]_[STORE_NUM]_[TYPE] format |
| ROUTING_DOMAIN | Always Internal-Retail |

### 2.4 placeholder_networks
**Current version:** v20260605  **Rows:** 48

Synthetic /32 or summary entries for active LM locations that have no real IPAM entry.
Ensures CX6 (LM-ORPHAN) never fires for valid locations that simply have no subnets yet.
Rebuilt from location_master whenever LM advances.

### 2.5 ent_host_master (EHM)
**Current version:** v20260525r21  **Rows:** 61,492  **Key:** IP_ADDRESS

All enterprise application and server hosts. The host-level enrichment layer above IPAM.

Key columns: IP_ADDRESS, SERVER_NAME, FQDN, APPLICATION, APM_IDS, APP_ACRONYMS,
HERITAGE, ROUTING_DOMAIN, CANONICAL_LOCATION, PCI_DESIGNATION, RISK_TIER,
ARA_PHI, ARA_PII, SOX_CRITICAL, IN_QUALYS, IN_WIZ, IN_SNOW, CSNA_HOSTGROUP_PATH,
NORM_METHOD, LOCATION_CONFIDENCE.

**Note:** EHM was split into three datasets: `ent_host_master` (application/server hosts),
`delivery_infrastructure` (ESXi, HMC, iSeries, DataPower, Isilon), and
`delivery_platform` (Kubernetes, OpenShift, Docker, RHCOS).

### 2.6 delivery_infrastructure
**Current version:** v20260504r9  **Rows:** 5,763  **Key:** IP_ADDRESS
ESXi hosts, HMC, iSeries, DataPower, Isilon nodes.
PLATFORM_TYPE: ESX-HOST / CONTAINER-BRIDGE / SHARED-PLATFORM.

### 2.7 delivery_platform
**Current version:** v20260504r6  **Rows:** 1,875  **Key:** IP_ADDRESS
Kubernetes clusters, OpenShift, Docker, RHCOS nodes.
PLATFORM_TYPE: KUBERNETES.

### 2.8 ent_network_device_master (NDM)
**Current version:** v20260525  **Rows:** 10,875  **Key:** MANAGEMENT_IP

Network devices — firewalls, routers, switches, load balancers, wireless controllers, SBCs.
DEVICE_TYPE values: fw-pa / fw-cisco / fw-checkpoint / l3switch / router / lb / sbc / wireless-ctl.

### 2.9 app_subnet_index
**Current version:** v20260615  **Rows:** 2,608  **Key:** CIDR_24

Application coverage aggregated to /24 level. Links subnets to APM IDs, app acronyms,
PCI scope, risk tier, and primary site.

Key columns: CIDR_24, IPAM_APP_ID, APP_ACRONYMS, APM_IDS, PCI_DESIGNATION, RISK_TIER,
HERITAGE, PRIMARY_SITE, APP_COUNT, PROD_APP_COUNT.

**Important:** Rebuild app_subnet_index before each service objects or network groups run
if EHM has been updated since last build.

### 2.10 csna_site_registry
**Current version:** v2.30  **Rows:** 380

CSNA Stealthwatch site registry. Maps CANONICAL_LOCATION to CSNA zone hierarchy for host
group generation. Built by `build_csna_site_registry.py` from location_master + all_IP_networks.

### 2.11 CPC-CORE-SERVICES (ENT ipdataset)
**Current version:** v20260615  **Rows:** 1,677

CPC infrastructure service catalog. Includes 705 per-service entries and 961 rollup rows.
Referenced by `build_cpc_service_catalog.py v1.2.1`.

### 2.12 EGRESS-FW-TOPOLOGY (ENT ipdataset)
**Current version:** v20260613  **Rows:** 69,745

Internet egress firewall topology derived from Zscaler breadcrumb data. Maps source subnets
to their observed egress firewall. Built by `build_egress_fw_topology.py v1.0.0`.

### 2.13 EGRESS-FW-UNMATCHED (ENT ipdataset)
**Current version:** v20260613  **Rows:** 861

Source subnets from Zscaler data that could not be matched to an IPAM entry. Starting point
for routing domain UNKNOWN remediation.

---

## 3. ROUTING_DOMAIN Values

ROUTING_DOMAIN is the PRIMARY overlap discriminator. Two IPs at the same address are
unambiguous if they carry different ROUTING_DOMAINs.

| Value | What it covers |
|-------|---------------|
| Internal-PBM | CVS/Caremark enterprise DC, campus, COLO (CVS heritage) |
| Internal-HCB | Aetna enterprise DC, campus, COLO (Aetna heritage) |
| Internal-Retail | CVS retail stores (172.16.0.0/12 /26 allocations) |
| COLO | Switch LV / Switch ATL / Switch TRE COLO (vendor-neutral) |
| Cloud-Azure | Azure VNet subnets |
| Cloud-GCP | GCP VPC subnets |
| Cloud-AWS | AWS VPC subnets |
| Cloud-Peering | Equinix cloud exchange (peering only, not primary DC) |
| Internet-Facing | BGP-announced public prefixes (AS6646: 206.213.x, 157.121 DMZ, 167.69 PCI) |
| Partner | Third-party B2B and ISP peering links |
| Offshore | Offshore development sites |

**Key constraint:** ROUTING_DOMAIN must never be UNKNOWN in production. All UNKNOWN rows
in all_IP_networks must be resolved before FW topology build. Target: 0 UNKNOWN.

---

## 4. Overlap Management Rules

### 4.1 The dual-dataset model (non-negotiable)

172.16.0.0/12 is governed by two authoritative datasets operating in parallel:
- `all_IP_networks` owns /24 and above in this space (Aetna DC infrastructure)
- `retail_networks` owns /26 per-store allocations (CVS retail stores)

The same physical /24 can appear in both with different ROUTING_DOMAINs. This is correct
and by design — they are completely separate routing planes.

### 4.2 LPM query order for 172.x (formal rule PR-01)

For any IP in 172.16.0.0/12:

| Query prefix length | Mode | Primary dataset | Secondary |
|--------------------|------|-----------------|-----------|
| /32 (host) | LPM | ent_host_master (if found), then retail_networks | all_IP_networks as context |
| /26 | Most-specific | retail_networks (store allocation) | all_IP_networks for parent |
| /24 or wider | LPM | all_IP_networks | retail_networks for child /26s |

---

## 5. Pipeline Stages

The CCD pipeline is orchestrated by `build_object_pipeline.py v1.3.1`.

| Stage | Script(s) | Output | Gate |
|-------|-----------|--------|------|
| Stage 0 | `build_canonical_app_objects.py` / `build_user_access_objects.py` / `build_cpc_service_catalog.py` | Canonical APP, USER_ACCESS, SERVICE objects | 0 HIGH cross-check |
| Stage 1 | `preprocess_p1.py` | Candidate hosts for enrichment | Gate CLEAR required |
| Stage 2 | `update_*.py --enrich-only` | Enriched host records | 0 HIGH after each |
| Stage 3 | `preprocess_p2.py` | Final host candidates | 0 HIGH cross-check |
| Stage 4 | `update_*.py` (add new hosts/subnets) | LM → IPAM → NDM → EHM → Infra → Platform | Order enforced |
| Stage 5 | `build_network_groups.py` / `build_ng_report.py` | Network groups (NG-YYYYMMDD_vN), EDL txt files | 0 HIGH |
| Stage 6 | `generate_csna_hostgroups.py` | CSNA host groups (CONTINUITY PASS required) | CONTINUITY PASS |

**Standard rebuild:**
```bash
python3 build_object_pipeline.py --edl   # Stages 0–5
./collect-edl_bundle.sh                  # EDL bundle distribution
```

**Partial runs:**
```bash
python3 build_object_pipeline.py --skip-obj   # Skip Stage 0, run 1–5
python3 build_object_pipeline.py --svc-only   # Stage 0 service objects only
python3 build_object_pipeline.py --ng-only    # Stage 5 network groups only
```

**June 15 pipeline output baseline:**
- NG-20260615_v3 — 14,380 address objects, 728 EDL files, 0 HIGH violations
- SO-20260615_v3 — 3,499 objects, 61,431 member IPs, 3,499 EDL files
- CSNA — 113,725 rows, 6,051 host groups, CONTINUITY PASS
- EDL bundle — ccd_objects_20260615.zip distributed

---

## 6. Canonical Object Model

The CCD Platform generates five object classes consumed by PA Panorama:

| Class | Script | Description |
|-------|--------|-------------|
| APP objects | `build_canonical_app_objects.py v1.8.3` | Application subnet groups from EHM + ASI. Tier-1 through Tier-4 hierarchy including INET_SEG_* and canonical app/service/infra/delivery objects. |
| INFRA objects | (integrated in build_canonical_app_objects.py) | Network infrastructure subnet groups |
| SERVICE objects | `build_cpc_service_catalog.py v1.2.1` + `build_service_objects.py v1.0.5` | CPC core services; output in SO-YYYYMMDD_vN/ |
| DELIVERY objects | (delivery_infrastructure + delivery_platform sources) | Platform and delivery infrastructure |
| USER_ACCESS objects | `build_user_access_objects.py v1.0.0` | VPN/remote access groups |

**Enterprise rollup aggregates** — SVC_*_ALL objects:
- SVC_*_ALL aggregates span BOTH CPC service catalog AND EHM sources
- Split between `build_cpc_service_catalog.py` (CPC side) and EHM enrichment pipeline
- These are the canonical service group objects delivered to PA Panorama

**Four-tier network object hierarchy:**
- Tier-1: Routing domain aggregates (Internal-PBM, Internal-HCB, etc.)
- Tier-2: Heritage/function aggregates (DC, campus, COLO, cloud)
- Tier-3: Site-level objects (per-SITE_CODE)
- Tier-4: INET_SEG_* and application-specific objects

**Output directory convention:** `Net_Group/NG-YYYYMMDD_vN/` for network groups,
`Net_Object/SO-YYYYMMDD_vN/` for service objects. Version sorting uses
`(int(date), int(revision))` tuple — lexicographic sort is wrong.

---

## 7. Firewall Topology Model

### 7.1 Five Firewall Tiers

The CVS Health firewall estate has five distinct tiers. No internal firewall exists
within a routing domain; enforcement is at domain boundaries only.

| Tier | Type | Role | Status |
|------|------|------|--------|
| 1 | Internet Egress FWs | Per-routing-domain internet egress (GLR) | Mapped via EGRESS-FW-TOPOLOGY |
| 2 | Extranet FWs | CVS↔Aetna inter-domain boundary (PBM↔HCB) | Not yet mapped |
| 3 | Retail Edge FWs | Store edge enforcement | Not yet mapped |
| 4 | Cloud Peering FWs | CVS and Aetna have SEPARATE peering paths into Azure/GCP/AWS | Not yet mapped |
| 5 | Specialty FWs | Purpose-built at specific application or partner boundaries | Not yet mapped |

**Important:** Cloud peering paths are separate for CVS and Aetna — they are NOT the same
path and NOT the same firewall.

### 7.2 Known Egress Firewalls (confirmed from Zscaler data, June 2026)

| Firewall | Connections | Site |
|----------|-------------|------|
| RRIWSCP-SEC-EXT-EMPTEMP-PA-02 | 172,109 | RI One (Woonsocket) |
| cme-fw-hubprodglr-1/2/3/4 | ~154K each | Cumberland/MDC cluster |
| win-fw-glr-pa-a | 137,175 | Windsor WDC |
| PAZSHDC-SEC-EXTWIR-PA-01 | 91,858 | Shea DC |
| mid-fw-glr-pa-a | 29,254 | Middletown MDC |
| lgs1501-01b-0104-ext-pa-fw01 | 11,218 | Las Vegas Switch COLO |

### 7.3 FW Topology Build Order

The firewall topology map is the foundational prerequisite for Cisco MPE mesh policy
engineering and the July 30 gate items.

```
1. Routing domain UNKNOWN remediation (0 UNKNOWN target)
       ↓
2. build_fw_site_topology.py → fw_site_topology_vDATE.csv
       ↓
3. FW Estate Report (current rule inventory per device)
       ↓
4. generate_fw_consolidation_report.py (WS-10, July 30 gate)
       ↓
5. Intent Policy (Cisco MPE / Istio / Cilium)
```

### 7.4 fw_site_topology schema (target)

```
SITE_CODE, CANONICAL_LOCATION, ROUTING_DOMAIN, HERITAGE,
EGRESS_FIREWALL, SUBNET_COUNT, CONNECTION_COUNT, DATA_SOURCE
```

---

## 8. Cross-Check Rules (CX1–CX13)

| Rule | Description | Severity |
|------|-------------|----------|
| CX1 | CIDR is valid and not in reserved/junk space (240.x, synthesized /24s) | HIGH |
| CX2 | CANONICAL_LOCATION resolves to an active LM entry | HIGH |
| CX3 | ROUTING_DOMAIN is a valid controlled vocabulary value | HIGH |
| CX4 | DATA_QUALITY is populated (Authoritative / Inferred / Manual) — also TYPE-SYNC | HIGH / MEDIUM |
| CX5 | No cross-domain subnet containment within all_IP_networks | HIGH |
| CX6 | Every active LM entry has an IPAM or placeholder_networks entry | HIGH |
| CX7 | csna_site_registry entries have backing location_master entry | MEDIUM |
| CX8 | HERITAGE consistent with ROUTING_DOMAIN | MEDIUM |
| CX9 | No duplicate CIDRs in all_IP_networks | HIGH |
| CX10 | No /32 host entries in all_IP_networks | MEDIUM |
| CX11 | 206.213/157.121/167.69 BGP-announced prefixes = Internet-Facing | HIGH |
| CX12 | all_IP_networks entries with retail_networks /26 children flagged | MEDIUM |
| CX13 | NET_TYPE consistent with SITE_CODE LOCATION_TYPE (NET-TYPE-SC-MISMATCH) | MEDIUM |

**Current cross-check baseline (June 15):**
- HIGH: 0 (gate clear)
- MEDIUM: 292 (275 CX13, 13 CX4-TYPE-SYNC, 4 CX7)
- CX13-275: Corporate NET_TYPE on Cloud/Partner SITE_CODEs — carry-forward
- CX4-13: Sparks NV, Carlstadt NJ COLO; distribution centers Mail-Order vs SPECIALTY
- CX7-4: Richardson TX Campbell orphans, Azure ExpressRoute orphans

**IPAM operational rules (non-negotiable):**
1. Every IPAM update gets a new version number — no exceptions
2. Location = derived from IP via NMS/LPM, never from server owner field
3. Subnet ownership = hub device location, not spoke
4. Retail /26 subnets → retail_networks only, never all_IP_networks
5. App/server data clarifies and enhances IPAM — it never drives subnet location
6. Hard gate: no IP enters any master without verified CANONICAL_LOCATION in LM
7. Update order: LM → IPAM → NDM → EHM → Infra → Platform
8. `--dry-run` every script before writing; `--cross-check` after every import; 0 HIGH
   required to continue; on HIGH violation: `ipam-db.py --restore` immediately
9. Never delete/move/archive any location_master file without explicit confirmation
   AND verified backup

---

## 9. iplookup.sh Command Reference (v3.23)

### Core lookups

| Command | What it does |
|---------|-------------|
| `-l <IP>` | Five-tier LPM lookup: retail_networks → IPAM → host masters → app_subnet_index → ip_dataset |
| `-l <IP/24>` | Containment mode for 172.x: returns Aetna HCB /24 + ALL CVS retail /26 store allocations |
| `-store <NUM>` | Retail store lookup by store number |
| `-host <NAME\|IP>` | Search all host masters by FQDN, hostname, or IP |
| `--hostname <fqdn>` | Hostname translation → location |
| `-dom <domain>` | All subnets for a DNS domain |
| `-app <ID>` | Lookup by IPAM_APP_ID, APM ID, or app acronym |
| `-svc <name>` | CPC infrastructure service lookup |
| `-k <keyword>` | Free-text or structured field search (AND logic with multiple -k flags) |
| `-loc <name>` | Location-based subnet lookup |
| `-lt` | Tag / field value enumeration |
| `-td <CIDR>` | Subnet tree diagram |

### Inventory & filter commands

| Command | What it does |
|---------|-------------|
| `--nt <value>` | Filter all_IP_networks by NET_TYPE |
| `--nt-list` | NET_TYPE taxonomy with row counts |
| `--sc <code>` | Site code lookup |
| `--sc-subnets <code>` | All subnets for a site code |
| `--sc-list` | Full site code catalogue |
| `--ng <name>` | Network group lookup |
| `--ng-list` | All network groups with member counts |
| `-app-list` | App subnet inventory |
| `-device-list-fw-pa` | Palo Alto firewall inventory |
| `-device-list-all` | All network devices |
| `-infra-list` | delivery_infrastructure inventory |
| `-platform-list` | delivery_platform inventory |
| `--pci` | All PCI-scoped blocks |
| `--loc <str>` | Location substring filter |
| `--heritage <str>` | Heritage filter |
| `--routing-domain <str>` | Routing domain filter |
| `--ds <stem>` | Browse registered cloud/provider dataset |

**Planned commands (Objective 2, not yet implemented):**
- `--rd <IP>` — return ROUTING_DOMAIN for a given IP (via IPAM LPM)
- `--rd-list` — list all routing domains with subnet counts
- `--egress-fw <IP>` — return EGRESS_FIREWALL for a given IP (via fw_site_topology)
- `--fw-list` — list all known egress firewalls with subnet counts

### Modifier flags

`--loc` / `--heritage` / `--routing-domain` / `--net-type` / `--csv` apply to all inventory
commands. `--platform-type` / `--os-group` / `--server-class` apply to `-infra-list` and
`-platform-list`.

---

## 10. Five-Tier IP Resolution

Used by `iplookup.sh -l` and firewall rule translation:

| Tier | Source | Resolves |
|------|--------|---------|
| T1 | ent_host_master (IP_ADDRESS exact match) | APPLICATION, APM_IDS, ROUTING_DOMAIN, CSNA path |
| T2 | app_subnet_index (CIDR_24 match) | APP_ACRONYMS, APM_IDS, PCI_DESIGNATION, RISK_TIER |
| T3 | all_IP_networks (LPM) | ROUTING_DOMAIN, CANONICAL_LOCATION, HERITAGE, NET_TYPE |
| T4 | PA address object name signal | Application identity from naming conventions |
| T5 | cpc_infra_services.csv / CPC-CORE-SERVICES | CPC infrastructure service context (NTP, AD, DNS) |

---

## 11. Script Inventory (Current Versions)

### Core platform / IPAM

| Script | Version | Role |
|--------|---------|------|
| ipam-db.py | 3.15.12 | Registry manager, cross-check engine, dataset import |
| preprocess_p1.py | 2.0 | First-pass host candidate extraction |
| preprocess_p2.py | 1.3 | Second-pass host candidate refinement |
| update_app.py | 1.9 | Application record updates |
| update_network.py | 1.3 | Network/subnet updates |
| update_ipam.py | 1.14 | IPAM import |
| update_location.py | 1.2 | Location master updates |
| update_infrastructure.py | 1.2.1 | Delivery infrastructure updates |
| update_platform.py | 1.2.1 | Delivery platform updates |
| update_asi.py | 1.0.0 | App subnet index updates |
| check_toolset.py | 1.3.1 | Platform health check (39+ tests, 6 groups) |

### Object pipeline

| Script | Version | Role |
|--------|---------|------|
| build_object_pipeline.py | 1.3.1 | Master pipeline orchestrator (Stage 0–5) |
| build_canonical_app_objects.py | 1.8.3 | Canonical APP objects (four-tier hierarchy) |
| build_user_access_objects.py | 1.0.0 | USER_ACCESS objects |
| build_cpc_service_catalog.py | 1.2.1 | CPC service catalog + SERVICE objects |
| build_service_objects.py | 1.0.5 | Service object EDL generation |
| build_svc_report.py | 1.0.5 | Service object report |
| build_network_groups.py | 1.8.4 | Network groups + EDL txt files |
| build_ng_report.py | 1.3.2 | Network group report |
| build_edl_catalog.py | 1.1.2 | EDL catalog HTML |
| build_internet_segments.py | 1.1.0 | Internet segment objects |

### Location / CSNA / host master

| Script | Version | Role |
|--------|---------|------|
| build_location_master.py | 3.4 | Location master build |
| build_network_device_master.py | 2.6 | Network device master build |
| build_app_subnet_index.py | 1.9.1 | App subnet index |
| build_app_inventory.py | 1.0.0 | App inventory |
| build_csna_site_registry.py | 2.1.0 | CSNA site registry |
| generate_csna_hostgroups.py | 4.0.3 | CSNA host group generation (Stage 6) |
| build_ipam_location_remediation.py | 1.0.0 | IPAM location remediation |

### Firewall / Zscaler / VPN

| Script | Version | Role |
|--------|---------|------|
| build_zscaler_topology.py | 1.0.4 | Zscaler topology from breadcrumb CSV |
| build_zscaler_topology_report.py | 1.0.3 | Zscaler topology HTML report |
| build_egress_fw_topology.py | 1.0.0 | Egress FW topology (EGRESS-FW-TOPOLOGY dataset) |
| build_fw_gateway_attribution.py | 1.0.0 | FW gateway attribution |
| find_unmatched_source_subnets.py | 1.4.0 | Find Zscaler subnets not in IPAM |
| enrich_zscaler_flows.py | 2.0.0 | Zscaler flow enrichment |
| build_vpn_registry.py | 1.1.1 | VPN peer registry |
| build_p2p_link_registry.py | 1.0.1 | P2P link registry |
| build_p2p_policy_map.py | 1.0.5 | P2P policy map |
| fw_rule_extraction_translation.py | 1.1.0 | FW rule extraction and translation |
| setup_fw_configs.sh | 1.9.0 | FW config setup |

### Enrichment / utilities

| Script | Version | Role |
|--------|---------|------|
| enrich_asi_cpc_services.py | 1.0.0 | ASI enrichment with CPC services |
| enrich_eir.py | 1.1.0 | External IP registry enrichment |
| enrich_ipam_sitecode.py | 1.0.0 | IPAM site code enrichment |
| classify_net_type.py | 1.0.0 | NET_TYPE classification |
| resolve_unknown_subnets.py | 1.0.0 | Unknown subnet resolution |
| preflight_lm_check.py | 1.0.1 | Location master preflight check |
| collect_session_files.py | 1.7.3 | Session file collection for handoff |
| collect_ccd_session.py | 3.0.0 | Session bundle generation |
| data_source_registry.py | 1.0.0 | Data source registry |
| dsr.py | 1.0.0 | DSR CLI |

**Version mismatches flagged (June 15):**
- preprocess_p1.py: DUAL-VER-MISMATCH (expected v2.x clean)
- test_iplookup.sh: found 2.1, expected v2.4.0
- test_geo_ip.sh: version unknown, expected v1.0.0

---

## 12. Version Conventions

**Scripts:** MAJOR.MINOR.PATCH
- Bug fix → PATCH (in `__version__` and changelog only, not filename)
- Feature → MINOR
- Breaking change → MAJOR

**Datasets:** `vYYYYMMDD` or `vYYYYMMDDrN` for same-day revisions.

**Three stamps required on every dataset:**
1. Versioned filename (e.g. `all_IP_networks_v20260611r11.csv`)
2. `#VERSION=` header in file
3. `DATASET_VERSION` + `LOC_MASTER_VERSION` columns

**`vbare` is a hard stop** — never use the bare filename in production.

**Version sort:** `(int(date), int(revision))` tuple — lexicographic sort is wrong.

---

## 13. DC Topology Quick Reference

| Site | Code | Heritage | Routing Domain |
|------|------|----------|----------------|
| Scottsdale AZ - Shea DC | US_SCO_AZ_DC | CVS | Internal-PBM |
| Woonsocket RI - RI One | US_WOR_RI_CO1 | CVS | Internal-PBM |
| Cumberland RI - 2100 Highland | US_CUM_RI_CO4 | CVS | Internal-PBM |
| Middletown CT - Aetna MDC | US_MID_CT_IS | AETNA | Internal-HCB |
| Windsor CT - Aetna WDC | US_WIN_CT_IS | AETNA | Internal-HCB |
| Hartford CT - Aetna HQ | US_HFD_CT_IS | AETNA | Internal-HCB |
| Phoenix AZ - Aetna DC | US_PHX_AZ_IS | AETNA | Internal-HCB (decommissioning → Las Vegas via Zerto) |
| Las Vegas NV - Switch Core | US_LAS_NV_CI | SWITCH | COLO (logical partition per routing domain) |
| Atlanta GA - Switch COLO | US_ATL_GA_CI | SWITCH | COLO (logical partition per routing domain) |
| Sparks NV - Switch TRE | US_SPK_NV_CI | SWITCH | COLO |
| Woodbridge NJ - Iron Mountain | US_WDB_NJ_CI | CVS | COLO |
| Carlstadt NJ - SunGard DR | US_CAR_NJ_CI | CVS | COLO |

**Notes:**
- Equinix = cloud peering only, not primary DC
- Richardson TX / Dallas Caremark = retiring
- Superloop = Switch network connectivity product at TRE, not a separate facility
- Switch CORE / Switch KEEP = vendor product names for Las Vegas and Atlanta campus partitions
- Five9 = NaaS contact center (US_SCA_CA_NH NAAS-HUB, not CALL-CENTER)

---

## 14. Open Items (June 15, 2026)

| Priority | Item | Status |
|----------|------|--------|
| P1 | Routing domain UNKNOWN remediation (6,415 rows in Zscaler data) | Start this session |
| P1 | build_fw_site_topology.py — foundational for Cisco MPE | Start this session |
| P1 | iplookup.sh --rd / --egress-fw commands | Not yet implemented |
| P1 | CX13-275 NET_TYPE=Corporate on Cloud/Partner SITE_CODEs | Carry-forward |
| P2 | preprocess_p1.py DUAL-VER-MISMATCH | Fix version string |
| P2 | test_iplookup.sh at v2.1, expected v2.4.0 | Bump version |
| P2 | SVC_SMTP_HCB — verify HCB SMTP relay fleet | Confirm with HCB team |
| P3 | Infoblox DNS resolver fleet not in CPC catalog | Q4, enterprise team dependency |
| WS-9 | enrich_vpn_flows.py | July 30 gate — not started |
| WS-10 | generate_fw_consolidation_report.py | July 30 gate — blocked on FW topology |

---

## 15. Session Startup Sequence

```bash
# 1. Verify platform health
./check_toolset.py --fast

# 2. Confirm cross-check baseline
python3 ipam-db.py --cross-check

# Standard rebuild cycle
python3 build_object_pipeline.py --edl   # Stages 0–5
./collect-edl_bundle.sh                  # Bundle distribution
python3 generate_csna_hostgroups.py      # Stage 6

# IPAM update sequence
python3 ipam-db.py --dry-run --import <file>
python3 ipam-db.py --import <file>
python3 ipam-db.py --cross-check         # Must show 0 HIGH before continuing
```
