#!/usr/bin/env python3
"""
build_known_unknown_ip_resolver.py

CCD Platform -- CVS Health Information Security

Reviews all unknown_ip_subnets_*.csv reports produced by
build_IP_Network_Egress_FW_topology.py, cleans out non-candidate traffic
(public IPs, link-local artifacts, CS-only noise that was never a real
user-subnet candidate), attempts to resolve a CANONICAL_LOCATION for each
remaining candidate using real evidence only (fw_route_db.sqlite device
routes cross-referenced against ent_network_device_master, then direct
ent_network_device_master / ent_host_master IP containment), and produces
two outputs:

  1. An ipam-db.py-ready ADD patch (all_IP_networks schema) for every
     subnet that resolves with real evidence.
  2. A new persistent dataset -- known_unknown_ip_prefixes -- holding every
     qualifying subnet that does NOT resolve. This is a first-class,
     versioned CCD dataset, not a throwaway file: it's meant to be re-run
     against on a future session as more evidence (an updated route_db, a
     fuller NDM sweep) becomes available, without re-deriving the whole
     159-subnet universe from scratch each time.

DELIBERATE NON-GOAL: this script never infers a location from /16 sibling
membership or any other statistical-neighborhood heuristic. That approach
was tried by hand across several review passes and repeatedly produced
confident-but-wrong answers once checked against real device/route
evidence (see e.g. the 10.190.67.0/24 and 10.38.64.0/24 cases in the
project history -- sibling inference named the wrong site or no site at
all in both). A subnet with no real evidence goes to
known_unknown_ip_prefixes, full stop -- it does not get a guessed
CANONICAL_LOCATION.

Evidence tiers, in priority order:
  1. fw_route_db.sqlite -- the tightest matching route (prefix length >=
     --min-route-prefix, default /15) whose device is resolvable in NDM.
     Routes tighter than /15 that don't resolve to a real device are
     treated the same as no evidence -- default/supernet catch-all routes
     (typically /8 and /0) show up on nearly every firewall in the estate
     and carry no location signal; the --min-route-prefix floor exists
     specifically to reject those.
  2. ent_network_device_master -- direct IP containment: a real network
     device (firewall/switch/router) with a management IP inside the
     subnet.
  3. ent_host_master -- direct IP containment: a real registered host
     inside the subnet.

NET_TYPE is deliberately NOT inferred for resolved subnets -- it's left
blank with a REVIEW_REQUIRED flag in DATA_QUALITY, because nothing in any
of the three evidence tiers speaks to wired/wireless/VPN/etc. Guessing it
was tried by hand earlier in this project and correctly flagged by a
human reviewer as unsupported by evidence; the script does not repeat
that mistake.

Usage:
  python3 build_known_unknown_ip_resolver.py

  Run from the same directory as ipam-db.py (or pass --db-dir). Every
  input auto-discovers from --db-dir (default ./ipam-db, matching
  ipam-db.py's own default) exactly the way ipam-db.py and
  fw_route_db.py already do -- all_IP_networks and location_master via
  best_versioned() (highest-version CSV by stem), ent_network_device_
  master and ent_host_master the same way, fw_route_db.sqlite by reading
  its registered filename out of ipam-db.json (same lookup fw_route_db.py
  itself uses). unknown_ip_subnets reports auto-discover from
  --reports-dir (default ./FW-Egress_Out, where build_IP_Network_Egress_
  FW_topology.py writes them).

  Explicit flags (--ipam, --lm, --ndm, --ehm, --route-db, --unknown-files)
  exist only to override a single file -- they don't turn off
  auto-discovery for everything else. Example, pinning just the route DB
  to a specific snapshot while everything else auto-discovers:

  python3 build_known_unknown_ip_resolver.py \
      --route-db fw_route_db_v20260730.sqlite

  Add --dry-run to preview counts and the resolution breakdown without
  writing any files.

Changelog:
  v1.4.0 -- 2026-08-17  Extended known_unknown_ip_prefixes to also accept
            HOST-level records, a genuinely different real population
            from this script's original SUBNET-only scope. Confirmed
            real gap: 742 real hosts in preprocess_p1.py's UNRESOLVED
            quarantine (ent-ipdataset-{PBM,HCB}-INT-ENT-HOST-UNRESOLVED)
            have a real, already-known CANONICAL_LOCATION/SITE_CODE --
            unlike a SUBNET row, which has none -- and are missing real
            app attribution specifically, not location evidence. New
            RECORD_TYPE column ('SUBNET'|'HOST') discriminates which
            field set is populated; new load_app_unknown_hosts()
            excludes real DNS-resolution-gap rows (523, a different
            problem) and rows already covered by a real, identified
            application (152 -- Epic/Workato/SevOne/Oak Street Health/
            Exchange-DAG, found by hostname pattern and cross-referenced
            via --app-recommendations) -- what remains is the genuine
            known-unknown-for-app-attribution population. New
            best_versioned_hyphen() -- the real UNRESOLVED files use a
            hyphen before the version ('-v20260816'), not the underscore
            best_versioned() expects ('_v...'); confirmed via direct
            fnmatch test before writing a second function rather than
            silently getting zero matches. HOST rows get STATUS=
            'App-Unresolved', deliberately different from SUBNET rows'
            'Unresolved', since these are not the same kind of gap.
            Verified end-to-end against the real files: found exactly
            742 real HOST known-unknowns, matching the count from the
            manual audit this fix was built from.
  v1.3.0 -- 2026-07-30  NET_TYPE inference from real sibling data, plus a
            hard-requirement fix this surfaced. Confirmed against a real
            ipam-db.py run: NET_TYPE isn't just conventionally expected --
            R10-REQUIRED hard-blocks any all_IP_networks import with it
            blank, meaning every prior version's patch was fundamentally
            unimportable without manual editing first. Checked what
            NET_TYPE existing rows at each of the three resolved
            locations actually carry: DataCenter at 85-93% share in every
            case -- a real, strong majority, not a coin flip. Added
            NET_TYPE inference to location_fields_for(): majority
            NET_TYPE among existing rows already at the resolved
            CANONICAL_LOCATION, required to hold --min-net-type-share
            (default >50%) of non-blank values before it's used. This is
            a different, much safer inference than the sibling-/16
            location-guessing this script deliberately never does
            elsewhere -- the location itself is already confirmed by real
            route_db/NDM evidence at this point; this only fills in an
            attribute *within* an already-trusted location. DATA_QUALITY
            changed from the invented 'Confirmed-AutoResolved-
            REVIEW_NET_TYPE' (not a valid value -- flagged by R12-DQ-
            SCHEMA, which only accepts Authoritative|Inferred|Manual) to
            'Inferred', which is both valid and accurate. Rows resolved
            to a location with NO majority NET_TYPE (rare given the real
            data, but possible) now split into a separate
            resolved_NEEDS_NET_TYPE_REVIEW_<date>.csv rather than going
            into the same ADD patch as the clean rows -- putting a
            still-blank-NET_TYPE row in the main patch would make the
            whole patch fail the same R10-REQUIRED block for every row,
            not just the one that needs it.
  v1.2.0 -- 2026-07-30  Added a "Next steps" block at the end of a real
            (non-dry-run) run, mirroring ipam-db.py's own convention
            (e.g. do_update_patch's "Registry not updated -- run --import
            to register..." block). Prints the exact copy-pasteable
            commands for the rest of the workflow -- apply the resolved
            patch, register the new all_IP_networks version, cross-check,
            register known_unknown_ip_prefixes, and two concrete
            iplookup.sh spot-checks (one IP from a newly-resolved subnet,
            one from whatever's still unresolved) -- using the real
            generated filenames rather than placeholders wherever the
            filename is actually known at this point in the run.
  v1.1.1 -- 2026-07-30  Fixed discover_route_db(): fw-db/ (fw_route_db.
            sqlite, fw_group_db.sqlite, fw_rule_db.sqlite) is a SIBLING
            directory to ipam-db/, not a subdirectory of it -- confirmed
            directly against a real deployment where auto-discovery found
            every other input correctly but reported fw_route_db "not
            found" despite it being genuinely registered. v1.1.0 only
            ever tried os.path.join(db_dir, filename), which silently
            fails for every real in_place-registered fw-db/ file with no
            error -- Tier 1 route evidence (the tier that resolved 11 of
            12 subnets in testing) just never ran, degrading everything
            to NDM/EHM-only. Added resolve_entry_path(), copied verbatim
            from ipam-db.py's own _resolve_entry_path() (v3.18.0): checks
            entry['source'] (the original absolute path stored at
            import time) first, then falls back to the portable
            {db_dir}/../fw-db/{filename} location, exactly matching how
            ipam-db.py's own --list resolves the same entries.
  v1.1.0 -- 2026-07-30  Auto-discovery, matching the rest of the CCD
            toolset. v1.0.x required five explicit file paths spelled out
            by hand (--route-db/--ndm/--ehm/--ipam/--lm) plus
            --unknown-dir, inconsistent with how ipam-db.py and
            fw_route_db.py already work (best_versioned() glob-based CSV
            discovery; fw_route_db.sqlite resolved via its registered
            filename in ipam-db.json). Added best_versioned() (copied
            verbatim from ipam-db.py v3.18.1) and discover_route_db()
            (mirrors fw_route_db.py's own registry-read approach). New
            --db-dir (default ./ipam-db) and --reports-dir (default
            ./FW-Egress_Out, where the topology builder writes its
            output) drive auto-discovery of every input. All five
            previous explicit flags still exist, now purely as
            single-file overrides -- passing one no longer disables
            auto-discovery for the rest.
  v1.0.1 -- 2026-07-30  Fixed Tier 1 route-device NDM lookup requiring
            unanimous agreement across all NDM records for a device before
            trusting it. Real NDM data has multi-sourced records per device
            (e.g. pdc-fw-cvty-1 had 3 records: 2x "Phoenix AZ - Aetna DC",
            1x "Phoenix AZ - Corporate (Cotton Center)") which made
            unanimity too strict and silently dropped resolvable subnets
            into known_unknown_ip_prefixes. Switched to strict-majority
            vote (>50%, not just plurality), matching the logic already
            used in Tiers 2/3. Caught by comparing this script's dry-run
            output against a full manual pass over the same data.
  v1.0.0 -- 2026-07-30  Initial release.
            Built after a full manual pass through this exact workflow
            (159 unmatched private/CGNAT /24s -> 14 real qualified
            candidates -> 13 resolved with real evidence -> 1 held as
            genuinely unknown). This script automates that pipeline so
            future sessions don't repeat it by hand. Two outputs:
            all_IP_networks ADD patch (resolved) and a new
            known_unknown_ip_prefixes dataset (unresolved, held for
            re-review). Explicitly excludes sibling-/16 inference as a
            resolution method -- see module docstring for why.
"""

__version__ = "1.4.1"
# v1.4.1  2026-08-23  Fixed next steps output: removed meaningless
#          "Spot-check with iplookup.sh" step that printed when there
#          were 0 resolved and 0 unresolved rows -- no commands, no
#          context, no actionable information. Spot-check step now only
#          prints when clean_rows exist, with specific IP and expected
#          result. Register known_unknown_ip_prefixes step now fires
#          when app_unknown_rows exist (not just unresolved subnets).

import argparse
import csv
import glob
import ipaddress
import itertools
import json
import os
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime

csv.field_size_limit(50_000_000)

ALL_IP_NETWORKS_COLS = [
    'CIDR', 'PREFIX_LEN', 'NETWORK_ADDRESS', 'BROADCAST_ADDRESS', 'SITE_CODE',
    'CANONICAL_LOCATION', 'LOCATION_TYPE', 'HERITAGE', 'STATUS', 'NET_TYPE',
    'ROUTING_DOMAIN', 'FACILITY_TYPE', 'STORE_NUMBER', 'COMM_TYPE',
    'DATA_QUALITY', 'SOURCE', 'DATASET_VERSION', 'LOC_MASTER_VERSION',
    'CONTESTED_BLOCK', 'EXT_ID_REFS',
]

KNOWN_UNKNOWN_COLS = [
    'RECORD_TYPE',  # v1.4.0: 'SUBNET' (original) or 'HOST' (new) -- discriminates
                    # which set of fields below is populated. See load_app_unknown_
                    # hosts() docstring for why HOST rows exist and what they mean.
    'SOURCE_SUBNET', 'PREFIX_LEN', 'TRAFFIC_SOURCE', 'CONNECTIONS',
    'UNIQUE_IPS', 'FIRST_SEEN', 'LAST_SEEN', 'RUNS_SEEN', 'CONSISTENCY_PCT',
    'ROUTE_DB_CHECKED', 'ROUTE_DB_BEST_PREFIX', 'ROUTE_DB_BEST_DEVICE',
    'NDM_CHECKED', 'NDM_DEVICE_COUNT', 'EHM_CHECKED', 'EHM_HOST_COUNT',
    'CLOSEST_IPAM_LOCATION_HINT', 'CLOSEST_IPAM_DISTANCE_24S',
    # v1.4.0 HOST-record fields. Deliberately separate from the SUBNET
    # fields above rather than overloading them -- e.g. SOURCE_SUBNET
    # means "an unattributed traffic-observed subnet" for a SUBNET row
    # and would mean something different (the /24 a known host sits in)
    # for a HOST row; keeping them distinct columns avoids silently
    # conflating two different kinds of evidence under one header.
    'IP_ADDRESS', 'SERVER_NAME', 'CANONICAL_LOCATION', 'SITE_CODE',
    'ROUTING_DOMAIN', 'HERITAGE', 'HOST_EVIDENCE_SOURCE',
    'STATUS', 'DATASET_VERSION', 'SOURCE', 'NOTES',
]

LINK_LOCAL = ipaddress.ip_network('169.254.0.0/16')
CGNAT = ipaddress.ip_network('100.64.0.0/10')


def is_private_or_cgnat(ip_str):
    try:
        addr = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return addr.is_private or addr in CGNAT


def is_link_local(net):
    return net.overlaps(LINK_LOCAL)


def load_csv_rows(path, skip_hash_comments=True):
    with open(path, encoding='utf-8-sig', errors='replace') as f:
        if skip_hash_comments:
            lines = [l for l in f if not l.startswith('#')]
            reader = csv.DictReader(lines)
        else:
            reader = csv.DictReader(f)
        return list(reader), (reader.fieldnames or [])


def get_report_version_date(path):
    """Best-effort ordering key so the most recent snapshot of a given
    subnet wins when the same SOURCE_SUBNET appears across multiple
    unknown_ip_subnets_*.csv files. Prefers the #VERSION= header; falls
    back to a date pattern in the filename."""
    try:
        with open(path, encoding='utf-8-sig', errors='replace') as f:
            for line in f:
                if line.startswith('#VERSION='):
                    m = re.search(r'(\d{8})', line)
                    if m:
                        return m.group(1)
                if not line.startswith('#'):
                    break
    except Exception:
        pass
    m = re.search(r'(\d{8})', os.path.basename(path))
    return m.group(1) if m else '00000000'


def load_unknown_reports(paths):
    """Merge all unknown_ip_subnets snapshots. For each SOURCE_SUBNET,
    keep the row from the most recent snapshot file (report fields like
    RUNS_SEEN/CONSISTENCY_PCT/LAST_SEEN are already cumulative in this
    tool's own design, so the latest snapshot is authoritative -- no
    manual merging of counters needed)."""
    best = {}
    best_date = {}
    for p in paths:
        rows, fields = load_csv_rows(p)
        if 'SOURCE_SUBNET' not in fields:
            print(f"  [SKIP] {os.path.basename(p)} -- no SOURCE_SUBNET column, not an unknown_ip_subnets report")
            continue
        d = get_report_version_date(p)
        for r in rows:
            sub = r.get('SOURCE_SUBNET', '').strip()
            if not sub:
                continue
            if sub not in best or d >= best_date[sub]:
                best[sub] = r
                best_date[sub] = d
    return best


def filter_candidates(merged, ipam_tree):
    """Clean pass: drop public IPs, link-local artifacts, subnets already
    resolved in the live IPAM, and CS-only (non-qualified) noise."""
    kept = {}
    dropped_public = dropped_linklocal = dropped_already_ipam = dropped_unqualified = 0

    for sub, row in merged.items():
        try:
            net = ipaddress.ip_network(sub, strict=False)
        except ValueError:
            continue

        sample_ip = str(net.network_address)
        if not is_private_or_cgnat(sample_ip):
            dropped_public += 1
            continue
        if is_link_local(net):
            dropped_linklocal += 1
            continue
        if ipam_tree is not None and ipam_tree.search_best(sample_ip) is not None:
            dropped_already_ipam += 1
            continue

        qualified = (row.get('QUALIFIED', '') or '').strip().upper()
        traffic_source = (row.get('TRAFFIC_SOURCE', '') or '').strip().upper()
        if qualified:
            is_qualified = qualified == 'YES'
        else:
            # Fall back to recomputing from TRAFFIC_SOURCE if the report
            # predates the QUALIFIED column.
            is_qualified = traffic_source in ('ZSCALER', 'BOTH')
        if not is_qualified:
            dropped_unqualified += 1
            continue

        kept[sub] = row

    stats = {
        'total_reports_merged': len(merged),
        'dropped_public': dropped_public,
        'dropped_link_local': dropped_linklocal,
        'dropped_already_in_ipam': dropped_already_ipam,
        'dropped_unqualified_cs_only': dropped_unqualified,
        'candidates_kept': len(kept),
    }
    return kept, stats


def load_ndm_index(ndm_path):
    """Build both an IP-containment index and a device-name index for NDM."""
    rows, fields = load_csv_rows(ndm_path)
    ip_field = None
    for cand in ('MANAGEMENT_IP', 'IP_ADDRESS'):
        if cand in fields:
            ip_field = cand
            break
    name_field = 'DEVICE_NAME' if 'DEVICE_NAME' in fields else (
        'DEVICE' if 'DEVICE' in fields else None)
    if name_field is None:
        # positional fallback seen in this dataset's export (col 2)
        name_field = fields[1] if len(fields) > 1 else None

    by_ip = []  # list of (ip_obj, row)
    by_name = {}  # normalized name -> list of rows
    for r in rows:
        ip = r.get(ip_field, '') if ip_field else ''
        if ip:
            try:
                by_ip.append((ipaddress.ip_address(ip), r))
            except ValueError:
                pass
        name = (r.get(name_field, '') or '').strip()
        if name:
            by_name.setdefault(name.lower(), []).append(r)
    return by_ip, by_name, name_field


def ndm_ip_hits(net, ndm_by_ip):
    return [r for (ip, r) in ndm_by_ip if ip in net]


def ndm_device_lookup(device_label, ndm_by_name):
    """ROUTE_DB_MATCH_DEVICE labels often carry a trailing serial number
    in parens, e.g. 'APP Firewalls-RI ... (026909004791)' -- strip that
    before matching against NDM device names."""
    clean = re.sub(r'\s*\([^)]*\)\s*$', '', device_label).strip().lower()
    if clean in ndm_by_name:
        return ndm_by_name[clean]
    # try case-insensitive substring as a fallback (hostname prefixes)
    for name, rows in ndm_by_name.items():
        if clean and (clean == name or clean in name or name in clean):
            return rows
    return []


def load_ehm_ips(ehm_path):
    rows, fields = load_csv_rows(ehm_path)
    ip_field = 'IP_ADDRESS' if 'IP_ADDRESS' in fields else None
    hits = []
    for r in rows:
        ip = r.get(ip_field, '') if ip_field else ''
        if ip:
            try:
                hits.append((ipaddress.ip_address(ip), r))
            except ValueError:
                pass
    return hits


def load_app_unknown_hosts(unresolved_paths, already_identified_names):
    """
    New in v1.4.0. Loads HOST-level "known unknown" candidates -- a
    genuinely different population from this script's original SUBNET-
    level scope (see module docstring). These come from preprocess_p1.py's
    p1_unresolved quarantine (ent-ipdataset-{PBM,HCB}-INT-ENT-HOST-
    UNRESOLVED-*.csv): real hosts with a real, already-known
    CANONICAL_LOCATION/SITE_CODE (unlike a SUBNET row, which has none of
    that) that are missing real APM/app attribution specifically.

    Confirmed real precedent for this exact split, found manually
    2026-08-17 auditing these same files: of 1,410 combined PBM+HCB
    UNRESOLVED rows, 523 had zero DNS resolution at all (SERVER_NAME ==
    IP_ADDRESS or blank) -- a different, more fundamental problem than
    app attribution, and NOT included here; 152 matched a real,
    identifiable application by hostname pattern (Epic, Workato, SevOne,
    Oak Street Health, Exchange DAG -- see app_attribution_recommendations
    output) and also don't belong here, since they have a real answer
    already, just not yet formally registered. What's left -- real
    hostname, real location, no identifiable pattern -- is the genuine
    "known unknown" population this function surfaces.

    already_identified_names: set of SERVER_NAME values already covered
    by a real pattern match (Epic/Workato/SevOne/OSH/Exchange-DAG) --
    excluded here so a host doesn't appear in both outputs.

    Returns a list of dicts, one per real unmatched host.
    """
    def is_bare(name, ip):
        return (not name or not name.strip()
                or name.strip() == ip
                or name.replace('.', '').isdigit())

    out = []
    for path in unresolved_paths:
        if not path or not os.path.isfile(path):
            continue
        rows, _ = load_csv_rows(path)
        for r in rows:
            ip = r.get('IP_ADDRESS', '').strip()
            name = r.get('SERVER_NAME', '').strip()
            if not ip:
                continue
            if is_bare(name, ip):
                continue  # real DNS-resolution gap, different problem
            if name in already_identified_names:
                continue  # already has a real, identified answer
            out.append(r)
    return out


def query_route_db(conn, net, min_prefix):
    """Return the tightest route(s) covering `net` with prefix_len >=
    min_prefix, grouped by (route_cidr, device). Rejects anything looser
    than min_prefix outright -- that's how /8 and /0 catch-all noise
    gets excluded without ever reaching the caller."""
    cur = conn.cursor()
    cur.execute("SELECT device, dest_cidr FROM fw_routes")
    best_prefix = -1
    best = []  # list of (route_cidr, device)
    for device, route_cidr in cur.fetchall():
        try:
            route_net = ipaddress.ip_network(route_cidr, strict=False)
        except ValueError:
            continue
        if route_net.prefixlen < min_prefix:
            continue
        if net.subnet_of(route_net) if net.prefixlen >= route_net.prefixlen else route_net.subnet_of(net):
            if route_net.overlaps(net):
                if route_net.prefixlen > best_prefix:
                    best_prefix = route_net.prefixlen
                    best = [(route_cidr, device)]
                elif route_net.prefixlen == best_prefix:
                    best.append((route_cidr, device))
    return best_prefix, best


def location_fields_for(canonical_location, ipam_rows_by_location, lm_rows_by_location,
                         min_net_type_share=0.5):
    """Pull SITE_CODE/LOCATION_TYPE/HERITAGE/ROUTING_DOMAIN/FACILITY_TYPE
    for a resolved CANONICAL_LOCATION from real existing rows -- never
    invented. Prefers an existing all_IP_networks row at that location;
    falls back to location_master if all_IP_networks has no rows there
    yet.

    NET_TYPE is inferred the same way: majority NET_TYPE among existing
    rows already at this location, required to hold at least
    min_net_type_share (default 50%) of rows with a non-blank NET_TYPE.
    This is a different, much safer inference than the sibling-/16
    location-guessing this script deliberately avoids elsewhere -- the
    location here is already confirmed by real route_db/NDM evidence;
    this only fills in an attribute *within* an already-trusted location,
    not the location itself. Below the confidence threshold, NET_TYPE
    comes back blank (net_type_confidence=None) rather than guessed."""
    net_type, net_type_share, net_type_n = '', 0.0, 0
    rows = ipam_rows_by_location.get(canonical_location)
    if rows:
        counts = defaultdict(int)
        total = 0
        for r in rows:
            nt = r.get('NET_TYPE', '').strip()
            if nt:
                counts[nt] += 1
                total += 1
        if total:
            top_nt, top_count = max(counts.items(), key=lambda x: x[1])
            share = top_count / total
            if share >= min_net_type_share:
                net_type, net_type_share, net_type_n = top_nt, share, total

    if rows:
        r = rows[0]
        return {
            'SITE_CODE': r.get('SITE_CODE', ''),
            'LOCATION_TYPE': r.get('LOCATION_TYPE', ''),
            'HERITAGE': r.get('HERITAGE', ''),
            'ROUTING_DOMAIN': r.get('ROUTING_DOMAIN', ''),
            'FACILITY_TYPE': r.get('FACILITY_TYPE', ''),
            'NET_TYPE': net_type,
            'NET_TYPE_SHARE': net_type_share,
            'NET_TYPE_N': net_type_n,
        }
    if lm_rows_by_location:
        lr = lm_rows_by_location.get(canonical_location)
        if lr:
            return {
                'SITE_CODE': lr.get('SITE_CODE', ''),
                'LOCATION_TYPE': lr.get('LOCATION_TYPE', ''),
                'HERITAGE': lr.get('HERITAGE', ''),
                'ROUTING_DOMAIN': lr.get('ROUTING_DOMAIN', ''),
                'FACILITY_TYPE': lr.get('LOCATION_TYPE', ''),
                'NET_TYPE': '',
                'NET_TYPE_SHARE': 0.0,
                'NET_TYPE_N': 0,
            }
    return None


def build_ipam_location_index(ipam_path):
    rows, _ = load_csv_rows(ipam_path)
    by_loc = defaultdict(list)
    for r in rows:
        loc = r.get('CANONICAL_LOCATION', '')
        if loc:
            by_loc[loc].append(r)
    return rows, by_loc


def build_ipam_radix(ipam_rows):
    try:
        import radix
    except ImportError:
        return None
    tree = radix.Radix()
    for r in ipam_rows:
        cidr = r.get('CIDR', '').strip()
        if not cidr:
            continue
        try:
            tree.add(cidr)
        except Exception:
            pass
    return tree


def best_versioned_hyphen(db_dir, stem):
    """Same real logic as best_versioned(), but for stems that use a
    hyphen before the version instead of an underscore -- confirmed real,
    checked directly: ent-ipdataset-{PBM,HCB}-INT-ENT-HOST-UNRESOLVED-v*.csv
    uses '-v', not '_v'. best_versioned()'s glob (f'{stem}_v*.csv') was
    verified NOT to match these real filenames before writing this --
    silently finding zero files is worse than an explicit second function
    for the naming convention that's actually real here."""
    best_file = None
    best_key = (-1, -1, -1, -1, -1)
    for f in glob.glob(os.path.join(db_dir, f'{stem}-v*.csv')):
        bn = os.path.basename(f)
        mr = re.search(r'-v(\d{8})r(\d+)\.csv$', bn)
        if mr:
            key = (int(mr.group(1)), int(mr.group(2)), 0, -1, 0)
        else:
            mr2 = re.search(r'-v(\d{8})\.csv$', bn)
            key = (int(mr2.group(1)), 0, 0, -1, 0) if mr2 else (-1, -1, -1, -1, -1)
        if key > best_key:
            best_key = key
            best_file = f
    return best_file


def best_versioned(db_dir, stem):
    """Find highest versioned CSV for a stem in db_dir.

    Copied verbatim from ipam-db.py's own best_versioned() (v3.18.1) so
    this script discovers files exactly the same way every other CCD tool
    does -- not a second, slightly-different convention. Supports vX.Y,
    vX.Ya, vX.YrN, vX_Y, vX_YrN, vYYYYMMDD, vYYYYMMDDrN.
    """
    best_file = None
    best_key = (-1, -1, -1, -1, -1)
    for f in glob.glob(os.path.join(db_dir, f'{stem}_v*.csv')):
        bn = os.path.basename(f)
        mr = re.search(r'_v(\d{8})r(\d+)\.csv$', bn)
        if mr:
            key = (int(mr.group(1)), int(mr.group(2)), 0, -1, 0)
        else:
            m8 = re.search(r'_v(\d{8})\.csv$', bn)
            if m8:
                key = (int(m8.group(1)), 0, 0, -1, 0)
            else:
                m2 = re.search(r'_v(\d+)[._](\d+)([a-z]?)(?:r(\d+))?\.csv$', bn)
                if m2:
                    letter_ord = ord(m2.group(3)) if m2.group(3) else -1
                    rev = int(m2.group(4)) if m2.group(4) else 0
                    key = (0, int(m2.group(1)), int(m2.group(2)), letter_ord, rev)
                else:
                    continue
        if key > best_key:
            best_key, best_file = key, f
    if best_file:
        return best_file
    bare = os.path.join(db_dir, f'{stem}.csv')
    return bare if os.path.isfile(bare) else None


def resolve_entry_path(db_dir, entry):
    """Resolve the real path to a registry entry's file, accounting for
    in_place registration (large .sqlite databases -- fw_rule_db,
    fw_route_db, fw_group_db -- registered without ever being copied into
    db_dir). Copied verbatim from ipam-db.py's own _resolve_entry_path()
    (v3.18.0) -- fw-db/ is a SIBLING directory to ipam-db/, not a
    subdirectory of it, and in_place entries store their original
    absolute import-time path in entry['source'] as the first-choice
    resolution before falling back to the portable {db_dir}/../fw-db/
    {filename} guess. Getting this wrong (as v1.1.0 did -- it only ever
    tried os.path.join(db_dir, fname)) silently drops Tier 1 route
    evidence for every real fw-db/ deployment without any error, which
    is worse than failing loudly."""
    fname = entry.get('filename', '')
    if not fname:
        return None
    if entry.get('in_place'):
        source = entry.get('source')
        if source and os.path.isfile(source):
            return source
        portable = os.path.join(db_dir, '..', 'fw-db', fname)
        return portable if os.path.isfile(portable) else None
    fpath = os.path.join(db_dir, fname)
    return fpath if os.path.isfile(fpath) else None


def discover_route_db(db_dir):
    """Same approach as fw_route_db.py's own auto-discovery: read the
    currently-registered fw_route_db entry out of ipam-db.json and
    resolve its real path with resolve_entry_path() (handles the
    fw-db/-is-a-sibling-directory case), rather than globbing for *.sqlite
    (a registry entry is the authoritative pointer, since multiple stale
    .sqlite files can otherwise sit side by side with no way to tell
    which one is current)."""
    reg_path = os.path.join(db_dir, 'ipam-db.json')
    if os.path.isfile(reg_path):
        try:
            with open(reg_path, encoding='utf-8') as f:
                reg = json.load(f)
            entry = reg.get('files', {}).get('fw_route_db', {})
            resolved = resolve_entry_path(db_dir, entry)
            if resolved:
                return resolved
        except Exception:
            pass
    # Fall back to bare-name guesses, same convention as fw_route_db.py.
    for candidate in (os.path.join(db_dir, 'fw_route_db.sqlite'),
                      os.path.join(db_dir, '..', 'fw-db', 'fw_route_db.sqlite')):
        if os.path.isfile(candidate):
            return candidate
    return None


def discover_unknown_reports(reports_dir):
    if not reports_dir or not os.path.isdir(reports_dir):
        return []
    return sorted(
        os.path.join(reports_dir, fn) for fn in os.listdir(reports_dir)
        if fn.startswith('unknown_ip_subnets') and fn.endswith('.csv')
    )



def main():
    ap = argparse.ArgumentParser(
        description="Review unknown_ip_subnets reports, resolve what can be "
                    "resolved with real evidence, hold the rest as "
                    "known_unknown_ip_prefixes. Auto-discovers all inputs "
                    "from --db-dir by default, same convention as "
                    "ipam-db.py and fw_route_db.py -- explicit flags exist "
                    "only to override a specific file.")
    ap.add_argument('--version', action='version', version=f'build_known_unknown_ip_resolver.py v{__version__}')
    ap.add_argument('--db-dir', default='./ipam-db',
                     help="IPAM directory to auto-discover all_IP_networks, location_master, "
                          "ent_network_device_master, ent_host_master, and fw_route_db from "
                          "(default: ./ipam-db, matching ipam-db.py's own default).")
    ap.add_argument('--reports-dir', default='./FW-Egress_Out',
                     help="Directory of unknown_ip_subnets_*.csv reports -- defaults to "
                          "./FW-Egress_Out, where build_IP_Network_Egress_FW_topology.py "
                          "writes them.")
    ap.add_argument('--unknown-files', nargs='*', default=[],
                     help='Explicit list of additional unknown_ip_subnets_*.csv files, on top of --reports-dir')
    # v1.4.0: HOST-record inputs, real precedent found 2026-08-17 -- see
    # load_app_unknown_hosts() docstring. Separate --*-dir from
    # --reports-dir since these come from preprocess_p1.py's quarantine
    # output (processed_outputs/), not build_IP_Network_Egress_FW_
    # topology.py's (FW-Egress_Out/) -- genuinely different real
    # directories, not safe to assume they're the same.
    ap.add_argument('--unresolved-dir', default='./processed_outputs',
                     help='Directory to auto-discover ent-ipdataset-{PBM,HCB}-INT-ENT-HOST-'
                          'UNRESOLVED-*.csv from, for HOST-record known-unknowns (default: '
                          './processed_outputs, matching preprocess_p1.py\'s own output location)')
    ap.add_argument('--app-recommendations',
                     help='Override: explicit path to app_attribution_recommendations_*.csv '
                          '(default: auto-discovered from --out-dir). Real hostnames already '
                          'identified here are excluded from the HOST known-unknown output -- '
                          'they have a real answer already, just not yet formally registered.')
    ap.add_argument('--route-db', help='Override: explicit path to fw_route_db*.sqlite (default: auto-discovered from --db-dir/ipam-db.json)')
    ap.add_argument('--ndm', help='Override: explicit path to ent_network_device_master*.csv (default: auto-discovered from --db-dir)')
    ap.add_argument('--ehm', help='Override: explicit path to ent_host_master*.csv (default: auto-discovered from --db-dir)')
    ap.add_argument('--ipam', help='Override: explicit path to all_IP_networks*.csv (default: auto-discovered from --db-dir)')
    ap.add_argument('--lm', help='Override: explicit path to location_master*.csv (default: auto-discovered from --db-dir)')
    ap.add_argument('--out-dir', default='.', help='Output directory')
    ap.add_argument('--min-route-prefix', type=int, default=15,
                     help='Reject route_db matches looser than this prefix length as catch-all noise (default: /15)')
    ap.add_argument('--min-net-type-share', type=float, default=0.5,
                     help='Minimum share (0-1) the majority NET_TYPE must hold among existing sibling '
                          'rows at a resolved location before it gets inferred (default: 0.5 = >50%%)')
    ap.add_argument('--dry-run', action='store_true', help='Preview counts only, write nothing')
    args = ap.parse_args()

    today = datetime.now().strftime('%Y%m%d')

    # ---- Auto-discover every input from --db-dir, same as the rest of the
    #      toolset -- explicit flags (above) override a single file without
    #      giving up auto-discovery for everything else. ----
    ipam_path  = args.ipam  or best_versioned(args.db_dir, 'all_IP_networks')
    lm_path    = args.lm    or best_versioned(args.db_dir, 'location_master')
    ndm_path   = args.ndm   or best_versioned(args.db_dir, 'ent_network_device_master')
    ehm_path   = args.ehm   or best_versioned(args.db_dir, 'ent_host_master')
    route_path = args.route_db or discover_route_db(args.db_dir)

    if not ipam_path or not os.path.isfile(ipam_path):
        print(f"ERROR: all_IP_networks not found in {args.db_dir} -- pass --ipam explicitly, "
              f"or --db-dir if it lives elsewhere.")
        sys.exit(1)

    print(f"Auto-discovered from {args.db_dir}:")
    print(f"  all_IP_networks             : {os.path.basename(ipam_path)}")
    print(f"  location_master             : {os.path.basename(lm_path) if lm_path else '(not found -- optional)'}")
    print(f"  ent_network_device_master   : {os.path.basename(ndm_path) if ndm_path else '(not found -- optional)'}")
    print(f"  ent_host_master             : {os.path.basename(ehm_path) if ehm_path else '(not found -- optional)'}")
    print(f"  fw_route_db                 : {os.path.basename(route_path) if route_path else '(not found -- optional, via ipam-db.json)'}")

    # ---- Gather unknown_ip_subnets report files ----
    report_files = discover_unknown_reports(args.reports_dir) + list(args.unknown_files)
    if not report_files:
        print(f"\nERROR: no unknown_ip_subnets_*.csv files found in {args.reports_dir} "
              f"-- pass --reports-dir, or list files explicitly with --unknown-files")
        sys.exit(1)

    print(f"\nLoading {len(report_files)} unknown_ip_subnets report(s) from {args.reports_dir}...")
    merged = load_unknown_reports(report_files)
    print(f"  {len(merged)} distinct SOURCE_SUBNET values across all reports")

    # ---- IPAM (required) ----
    print(f"\nLoading IPAM: {ipam_path}")
    ipam_rows, ipam_by_loc = build_ipam_location_index(ipam_path)
    ipam_tree = build_ipam_radix(ipam_rows)
    if ipam_tree is None:
        print("  WARNING: 'radix' module not available -- cannot verify subnets "
              "aren't already registered. Install py-radix for this check.")
    print(f"  {len(ipam_rows)} rows loaded")

    lm_by_loc = {}
    if lm_path:
        lm_rows, _ = load_csv_rows(lm_path)
        for r in lm_rows:
            loc = r.get('CANONICAL_LOCATION', '') or r.get('SITE_DC_NAME', '')
            if loc:
                lm_by_loc[loc] = r

    # ---- Clean pass ----
    print("\nFiltering candidates...")
    candidates, stats = filter_candidates(merged, ipam_tree)
    for k, v in stats.items():
        print(f"  {k:<30} {v}")

    # ---- Load evidence sources ----
    route_conn = None
    if route_path:
        print(f"\nOpening route DB: {route_path}")
        route_conn = sqlite3.connect(route_path)
        cur = route_conn.cursor()
        try:
            cur.execute("SELECT COUNT(*) FROM fw_devices")
            dev_count = cur.fetchone()[0]
            print(f"  {dev_count} device(s) in route DB")
            if dev_count == 0:
                print("  WARNING: route DB has 0 devices -- this looks like an "
                      "empty/uninitialized file, not a real populated snapshot. "
                      "Route-based resolution will find nothing.")
        except sqlite3.OperationalError:
            print("  WARNING: route DB missing expected tables -- skipping route evidence")
            route_conn = None

    ndm_by_ip, ndm_by_name = [], {}
    if ndm_path:
        print(f"\nLoading NDM: {ndm_path}")
        ndm_by_ip, ndm_by_name, name_field = load_ndm_index(ndm_path)
        print(f"  {len(ndm_by_ip)} devices with a parseable management IP, "
              f"{len(ndm_by_name)} distinct device names (matched on {name_field!r})")

    ehm_by_ip = []
    if ehm_path:
        print(f"\nLoading EHM: {ehm_path}")
        ehm_by_ip = load_ehm_ips(ehm_path)
        print(f"  {len(ehm_by_ip)} hosts with a parseable IP")

    # ---- Resolve each candidate ----
    print(f"\nResolving {len(candidates)} candidate(s)...")
    resolved = []
    unresolved = []

    for sub, row in sorted(candidates.items()):
        net = ipaddress.ip_network(sub, strict=False)
        evidence = {
            'route_db_checked': bool(route_conn),
            'route_db_best_prefix': '',
            'route_db_best_device': '',
            'ndm_checked': bool(ndm_path),
            'ndm_device_count': 0,
            'ehm_checked': bool(ehm_path),
            'ehm_host_count': 0,
        }
        resolved_location = None
        resolved_source_note = None

        # Tier 1: route_db, cross-referenced against NDM for a real location
        if route_conn is not None:
            best_prefix, best_matches = query_route_db(route_conn, net, args.min_route_prefix)
            if best_matches:
                evidence['route_db_best_prefix'] = f'/{best_prefix}'
                evidence['route_db_best_device'] = '; '.join(sorted(set(d for _, d in best_matches)))
                for route_cidr, device in best_matches:
                    ndm_hits = ndm_device_lookup(device, ndm_by_name)
                    locs = [h.get('CANONICAL_LOCATION', '') for h in ndm_hits if h.get('CANONICAL_LOCATION')]
                    if locs:
                        loc_counts = defaultdict(int)
                        for l in locs:
                            loc_counts[l] += 1
                        top_loc, top_count = max(loc_counts.items(), key=lambda x: x[1])
                        # Require the winner to have clear majority (more than
                        # half the votes), not just a plurality -- a near-tie
                        # (e.g. 2 vs 2) is genuine ambiguity and should not
                        # resolve; a clear majority (e.g. 2 of 3) should.
                        if top_count > len(locs) / 2:
                            resolved_location = top_loc
                            note = (f"route_db:{route_cidr}:{device} -> NDM CANONICAL_LOCATION "
                                    f"({top_count}/{len(locs)} device record(s) agree)")
                            resolved_source_note = note
                            break

        # Tier 2: direct NDM IP containment
        if resolved_location is None and ndm_path:
            hits = ndm_ip_hits(net, ndm_by_ip)
            evidence['ndm_device_count'] = len(hits)
            if hits:
                locs = defaultdict(int)
                for h in hits:
                    locs[h.get('CANONICAL_LOCATION', '')] += 1
                top_loc = max(locs.items(), key=lambda x: x[1])[0]
                if top_loc:
                    resolved_location = top_loc
                    resolved_source_note = f"ndm:{len(hits)} device(s) directly in subnet"

        # Tier 3: direct EHM IP containment
        if resolved_location is None and ehm_path:
            hits = ehm_ip_hits(net, ehm_by_ip)
            evidence['ehm_host_count'] = len(hits)
            if hits:
                locs = defaultdict(int)
                for h in hits:
                    locs[h.get('CANONICAL_LOCATION', '')] += 1
                top_loc = max(locs.items(), key=lambda x: x[1])[0]
                if top_loc:
                    resolved_location = top_loc
                    resolved_source_note = f"ehm:{len(hits)} host(s) directly in subnet"

        if resolved_location:
            loc_fields = location_fields_for(resolved_location, ipam_by_loc, lm_by_loc,
                                              min_net_type_share=args.min_net_type_share)
            if loc_fields is None:
                # Resolved a location name but it has no existing IPAM/LM
                # row to source SITE_CODE etc. from -- hold rather than
                # invent a site code.
                unresolved.append((sub, row, evidence, f"resolved to '{resolved_location}' but no "
                                                          f"existing IPAM/LM row to source SITE_CODE from"))
                continue
            resolved.append((sub, row, resolved_location, loc_fields, resolved_source_note, evidence))
        else:
            unresolved.append((sub, row, evidence, None))

    print(f"  Resolved:   {len(resolved)}")
    print(f"  Unresolved: {len(unresolved)}")

    if args.dry_run:
        print("\nDRY RUN -- no files written.")
        print("\nResolved subnets:")
        for sub, row, loc, _, note, _ in resolved:
            print(f"  {sub:<18} {loc:<35} [{note}]")
        print("\nUnresolved (going to known_unknown_ip_prefixes):")
        for sub, row, evidence, reason in unresolved:
            tag = reason or "no evidence in any tier"
            print(f"  {sub:<18} {tag}")
        return

    os.makedirs(args.out_dir, exist_ok=True)

    # ---- Split resolved rows: ones with a confident NET_TYPE go into the
    #      clean, auto-importable ADD patch; ones without go into a
    #      separate manual-review file instead. R10-REQUIRED (confirmed
    #      against a real ipam-db.py run) hard-blocks any all_IP_networks
    #      import with a blank NET_TYPE -- writing those rows into the same
    #      patch as the clean ones would make the whole patch unimportable
    #      until every row was fixed, not just the ones that need it. ----
    clean_rows = []
    needs_review_rows = []
    for sub, row, loc, loc_fields, note, evidence in resolved:
        net_type = loc_fields.get('NET_TYPE', '')
        if net_type:
            clean_rows.append((sub, row, loc, loc_fields, note, evidence))
        else:
            needs_review_rows.append((sub, row, loc, loc_fields, note, evidence))

    def _build_row(sub, loc, loc_fields, note):
        net = ipaddress.ip_network(sub, strict=False)
        out = {c: '' for c in ALL_IP_NETWORKS_COLS}
        out['CIDR'] = sub
        out['PREFIX_LEN'] = str(net.prefixlen)
        out['NETWORK_ADDRESS'] = str(net.network_address)
        out['BROADCAST_ADDRESS'] = str(net.broadcast_address)
        out['CANONICAL_LOCATION'] = loc
        out['SITE_CODE'] = loc_fields['SITE_CODE']
        out['LOCATION_TYPE'] = loc_fields['LOCATION_TYPE']
        out['HERITAGE'] = loc_fields['HERITAGE']
        out['ROUTING_DOMAIN'] = loc_fields['ROUTING_DOMAIN']
        out['FACILITY_TYPE'] = loc_fields['FACILITY_TYPE']
        out['STATUS'] = 'Active'
        net_type = loc_fields.get('NET_TYPE', '')
        out['DATA_QUALITY'] = 'Inferred'
        if net_type:
            pct = loc_fields['NET_TYPE_SHARE'] * 100
            n = loc_fields['NET_TYPE_N']
            out['NET_TYPE'] = net_type
            source_note = (f"{note}; NET_TYPE inferred from {pct:.0f}% "
                            f"({n} rows) of existing {loc!r} subnets sharing this value")
        else:
            out['NET_TYPE'] = ''
            source_note = f"{note}; NET_TYPE left blank -- no majority NET_TYPE at {loc!r} (REVIEW REQUIRED)"
        out['SOURCE'] = f'known_unknown_resolver_{today} ({source_note})'
        return out

    # ---- Write clean ADD patch (every row passes R10-REQUIRED) ----
    patch_path = os.path.join(args.out_dir, f'patch_known_unknown_RESOLVED_ADD_{today}.csv')
    with open(patch_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=ALL_IP_NETWORKS_COLS)
        writer.writeheader()
        for sub, row, loc, loc_fields, note, evidence in clean_rows:
            writer.writerow(_build_row(sub, loc, loc_fields, note))
    print(f"\nWrote {len(clean_rows)} resolved row(s) with a confident NET_TYPE -> {patch_path}")
    print(f"  NET_TYPE inferred from majority sibling rows at each resolved CANONICAL_LOCATION "
          f"(not guessed, not left blank) -- ready to import as-is.")

    needs_review_path = None
    if needs_review_rows:
        needs_review_path = os.path.join(args.out_dir, f'resolved_NEEDS_NET_TYPE_REVIEW_{today}.csv')
        with open(needs_review_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=ALL_IP_NETWORKS_COLS)
            writer.writeheader()
            for sub, row, loc, loc_fields, note, evidence in needs_review_rows:
                writer.writerow(_build_row(sub, loc, loc_fields, note))
        print(f"\nWrote {len(needs_review_rows)} row(s) with a resolved location but NO "
              f"majority NET_TYPE -> {needs_review_path}")
        print(f"  These have a real, evidence-backed CANONICAL_LOCATION but no confident "
              f"NET_TYPE to infer -- fill in NET_TYPE by hand before importing this file "
              f"(--update-patch will otherwise pass schema validation but the all_IP_networks "
              f"import will hard-block on R10-REQUIRED).")

    # ---- v1.4.0: Load HOST-level known-unknowns (real, different population --
    # see load_app_unknown_hosts() docstring) ----
    already_identified = set()
    app_rec_path = args.app_recommendations
    if not app_rec_path:
        _matches = glob.glob(os.path.join(args.out_dir, 'app_attribution_recommendations_*.csv'))
        app_rec_path = max(_matches, key=os.path.getmtime) if _matches else None
    if app_rec_path and os.path.isfile(app_rec_path):
        _rec_rows, _ = load_csv_rows(app_rec_path)
        already_identified = set(r.get('SERVER_NAME', '').strip() for r in _rec_rows)
        print(f"\n  App-attribution recommendations found: {app_rec_path} "
              f"({len(already_identified)} already-identified hostnames excluded)")
    else:
        print(f"\n  [WARN] No app_attribution_recommendations file found -- HOST known-unknowns "
              f"will include any real, pattern-identifiable hosts too (none excluded).")

    unresolved_pbm = best_versioned_hyphen(args.unresolved_dir, 'ent-ipdataset-PBM-INT-ENT-HOST-UNRESOLVED')
    unresolved_hcb = best_versioned_hyphen(args.unresolved_dir, 'ent-ipdataset-HCB-INT-ENT-HOST-UNRESOLVED')
    app_unknown_hosts = load_app_unknown_hosts(
        [p for p in (unresolved_pbm, unresolved_hcb) if p], already_identified)
    print(f"  HOST known-unknowns: {len(app_unknown_hosts)} (real hostname, real location, "
          f"no identifiable app pattern, excludes DNS-resolution-gap and already-identified rows)")

    # ---- Write known_unknown_ip_prefixes dataset for unresolved subnets ----
    known_unknown_path = os.path.join(args.out_dir, f'known_unknown_ip_prefixes_v{today}.csv')
    with open(known_unknown_path, 'w', newline='') as f:
        f.write('#STEM=known_unknown_ip_prefixes\n')
        f.write(f'#VERSION=v{today}\n')
        f.write(f'#ROWS={len(unresolved) + len(app_unknown_hosts)}\n')
        f.write(f'#TOOL=build_known_unknown_ip_resolver.py v{__version__}\n')
        writer = csv.DictWriter(f, fieldnames=KNOWN_UNKNOWN_COLS)
        writer.writeheader()
        for sub, row, evidence, reason in unresolved:
            net = ipaddress.ip_network(sub, strict=False)
            out = {c: '' for c in KNOWN_UNKNOWN_COLS}
            out['RECORD_TYPE'] = 'SUBNET'
            out['SOURCE_SUBNET'] = sub
            out['PREFIX_LEN'] = str(net.prefixlen)
            out['TRAFFIC_SOURCE'] = row.get('TRAFFIC_SOURCE', '')
            out['CONNECTIONS'] = row.get('CONNECTIONS', '')
            out['UNIQUE_IPS'] = row.get('UNIQUE_IPS', '')
            out['FIRST_SEEN'] = row.get('FIRST_SEEN', '')
            out['LAST_SEEN'] = row.get('LAST_SEEN', '')
            out['RUNS_SEEN'] = row.get('RUNS_SEEN', '')
            out['CONSISTENCY_PCT'] = row.get('CONSISTENCY_PCT', '')
            out['ROUTE_DB_CHECKED'] = evidence['route_db_checked']
            out['ROUTE_DB_BEST_PREFIX'] = evidence['route_db_best_prefix']
            out['ROUTE_DB_BEST_DEVICE'] = evidence['route_db_best_device']
            out['NDM_CHECKED'] = evidence['ndm_checked']
            out['NDM_DEVICE_COUNT'] = evidence['ndm_device_count']
            out['EHM_CHECKED'] = evidence['ehm_checked']
            out['EHM_HOST_COUNT'] = evidence['ehm_host_count']
            out['CLOSEST_IPAM_LOCATION_HINT'] = row.get('CLOSEST_IPAM_LOCATION', '')
            out['CLOSEST_IPAM_DISTANCE_24S'] = row.get('CLOSEST_IPAM_DISTANCE_24S', '')
            out['STATUS'] = 'Unresolved'
            out['DATASET_VERSION'] = f'v{today}'
            out['SOURCE'] = f'known_unknown_resolver_{today}'
            out['NOTES'] = reason or 'No evidence in any tier (route_db/NDM/EHM)'
            writer.writerow(out)
        # v1.4.0: HOST rows -- real location already known, app attribution
        # is the actual gap here, so STATUS is deliberately different
        # ('App-Unresolved') from the SUBNET rows' 'Unresolved' (which
        # means location itself is unknown) -- these are not the same
        # kind of gap and shouldn't read as if they were.
        for h in app_unknown_hosts:
            out = {c: '' for c in KNOWN_UNKNOWN_COLS}
            out['RECORD_TYPE'] = 'HOST'
            out['IP_ADDRESS'] = h.get('IP_ADDRESS', '')
            out['SERVER_NAME'] = h.get('SERVER_NAME', '')
            out['CANONICAL_LOCATION'] = h.get('CANONICAL_LOCATION', '')
            out['SITE_CODE'] = h.get('SITE_CODE', '')
            out['ROUTING_DOMAIN'] = h.get('ROUTING_DOMAIN', '')
            out['HERITAGE'] = h.get('HERITAGE', '')
            out['HOST_EVIDENCE_SOURCE'] = h.get('SOURCE_FILE', '')
            out['STATUS'] = 'App-Unresolved'
            out['DATASET_VERSION'] = f'v{today}'
            out['SOURCE'] = f'known_unknown_resolver_{today}'
            out['NOTES'] = ('Real host, real location, no identifiable app pattern found in '
                             'hostname (see app_attribution_recommendations for the ones that '
                             'were identifiable) -- genuine known-unknown for app attribution.')
            writer.writerow(out)
    print(f"Wrote {len(unresolved)} unresolved subnet row(s) + {len(app_unknown_hosts)} "
          f"app-unresolved host row(s) -> {known_unknown_path}")
    print("  This is a first-class versioned CCD dataset (STEM=known_unknown_ip_prefixes) "
          "-- register it in ipam-db.json (--import --type known_unknown_ip_prefixes) so "
          "future sessions build on it instead of re-deriving from scratch.")

    if route_conn:
        route_conn.close()

    # ---- Next steps -- mirrors ipam-db.py's own "Next steps" convention ----
    print(f"\n{'='*70}")
    print("Next steps")
    print(f"{'='*70}")
    step = 1
    if clean_rows:
        print(f"\n  {step}. Apply the resolved patch to all_IP_networks")
        print(f"     python3 ipam-db.py --update-patch {patch_path} --dry-run")
        print(f"     python3 ipam-db.py --update-patch {patch_path}")
        step += 1
        print(f"\n  {step}. Register the new all_IP_networks version it writes")
        print(f"     python3 ipam-db.py --import all_IP_networks_v<new>.csv --type all_IP_networks")
        step += 1
        print(f"\n  {step}. Cross-check -- confirm 0 HIGH before trusting the import")
        print(f"     python3 ipam-db.py --cross-check")
        step += 1
    if needs_review_rows:
        print(f"\n  {step}. Fill in NET_TYPE by hand for the {len(needs_review_rows)} row(s) "
              f"with no majority, then patch those separately")
        print(f"     {needs_review_path}  (edit NET_TYPE column, then --update-patch same as above)")
        step += 1
    if unresolved or app_unknown_rows:
        print(f"\n  {step}. Register known_unknown_ip_prefixes")
        print(f"     python3 ipam-db.py --import {known_unknown_path} --type known_unknown_ip_prefixes")
        step += 1
    if clean_rows:
        sample_sub, sample_loc = clean_rows[0][0], clean_rows[0][2]
        sample_ip = str(ipaddress.ip_network(sample_sub, strict=False).network_address + 1)
        print(f"\n  {step}. Verify resolved subnet resolves correctly in iplookup.sh:")
        print(f"     ./iplookup.sh {sample_ip}    # should show {sample_loc}")
        step += 1
    print()


if __name__ == '__main__':
    main()
