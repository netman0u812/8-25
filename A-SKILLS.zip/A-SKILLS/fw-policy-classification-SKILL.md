---
name: fw-policy-classification
description: How to classify and interpret CVS Health firewall rules, zones, address-groups, and trust boundaries correctly across a mixed ASA/FTD/PA/CheckPoint estate with 15+ acquisitions' worth of heritage naming. Use whenever interpreting what a rule's src/dst zones or an ANY match actually means, deciding whether a zone name or naming convention is trustworthy, analyzing traffic direction (Edge/egress vs DMZ/Extranet, true-DMZ vs Extranet), reasoning about firewall chaining (a rule's local view is never the whole path -- and the missing hop may not even be a firewall), or building/reviewing any tool that interprets firewall rules (fwlookup.py's classify_scope(), FW_SEGMENT/FW_ROLE logic, etc.). For classifying a firewall by Firewall Class (Internet Egress/Ingress, Cloud Egress/Ingress, PCI, Cross-Company, etc.) or determining single-class vs. multi-class devices, use the companion skill fw-class-taxonomy first, then this skill to interpret that device's specific rules. Read this BEFORE trusting a zone name, hostname pattern, security-level number, or a bare "source/destination constrained (not ANY)" as evidence a rule is actually narrow -- on this estate all of these are frequently misleading, and this skill documents exactly which signals are and aren't, confirmed against real production Panorama configs, not assumed.
---

# FW Policy Classification

How to correctly classify and interpret firewall rules, zones, address-groups, and trust boundaries on CVS Health's estate.

## The organizing thesis: this is an identity-vs-IP architecture conflict, not a naming-hygiene problem

Every finding in this skill is a symptom of one root cause, not an independent issue:

**You can build Zero Trust Network Access (ZTNA) on Palo Alto, using User-ID and App-ID against a small set of well-designed zones. Or you can operate Palo Alto as a faster ASA, using IP/network-object address-groups matched against interface-equivalent zones -- Router Extended Access List logic wearing PA's config syntax. These are architecturally opposite approaches, and this estate is confirmed, repeatedly, on real data, to be doing the second one while the platform (PA, FTD) is fully capable of the first.**

ZTNA requires abandoning IP-based trust and embracing namespace/identity -- PA fully supports this via User-ID/App-ID zone-based policy. Implementing PA *as* an ASA is the direct architectural opposite of ZTNA, regardless of what the platform vendor label says. **Three different vendor products (ASA, FTD, PA) does not mean three different management philosophies -- confirmed here they're all being operated under one philosophy: ASA/router interface-to-interface (or zone-to-zone standing in for interface-to-interface) policy.**

Every piece of real evidence below is this same choice, made repeatedly, not independent problems:
- 13 separate DMZ-named zones (one per vendor/purpose) instead of a small zone set differentiated by policy -- IP/network segmentation standing in for identity segmentation
- Narrow-source/broad-destination ACL-shaped rules (see `Private-Cloud-Infra-1` below) -- a permit tuple, not a decision about *who* should reach *what*
- FMC rule-IDs surviving in PA rule comments, ASA `nameif` vocabulary surviving in PA zone names -- artifacts of the ACL mindset outliving the platform migration
- Per-host static manual NAT (`STATIC-manualnat-*`, one entry per object) -- classic ASA one-to-one NAT provisioning, not PA's NAT policy used at the scale it's designed for
- 96% of PA rules using `application=any`, 99%+ alert-only, no real App-ID or SGT usage (confirmed independently, security stack capability-alignment work) -- App-ID exists on every one of these boxes and is essentially unused

**Practical implication for classification work**: don't treat any of the findings below as isolated data-quality issues to normalize away. They're all pointing at the same underlying fact about how this estate is actually operated, and a classification model that doesn't name that fact explicitly will keep re-discovering its symptoms one at a time.

## Device Type-Class: the required first step before reading any rule

**To understand a firewall's rules and address-groups, first understand what Firewall Class(es) that device is supporting.** The full 10-class taxonomy, how each class maps to a real data source, and the decision procedure for single-class vs. multi-class devices (Shea/Vegas-pattern consolidated hardware vs. Aetna/Cloud-pattern disaggregated devices) now live in the companion skill **`fw-class-taxonomy`** -- read that first, then come back here for how to correctly interpret the specific rules once the device's class is known.

**The required interpretation sequence for any rule**: (1) identify the device, (2) determine which Firewall Class(es) it's actually supporting (`fw-class-taxonomy`), (3) only then interpret the policy and address-group structure below in light of that.

## ANY is not "everywhere" -- it's the gateway of last resort

**The single most important reading rule for any ACL-style firewall on this estate**: when a rule matches `ANY` (source or destination), that `ANY` is not literally unbounded. It is implicitly scoped by the device's own topological position -- specifically, **`ANY` on a given interface/zone means "whatever traffic naturally arrives here, because this device is the gateway of last resort for its source population."** It is not an explicit statement that the rule author intended to permit the entire internet; it's the ACL-mindset's way of expressing "this is just how routing works at this point in the topology," using a permit statement because the ASA/router model requires one even for implicit, structurally-determined traffic.

**This is precisely why the IPAM/topology infrastructure exists** -- not as a side project, as the deliberate mechanism for contextualizing what `ANY` actually means for a given device. Three real, already-built (if partial) pieces exist toward this specifically:

- **`HERITAGE`** (`fw_config_manifest.py`, pulled from `fw_location_topology.py`'s own `HERITAGE` column via `topo_info.get('HERITAGE', '')`) -- an attempt to ascribe which legacy organization (Aetna, CVS, etc.) a device's "home" network actually belongs to, since heritage boundaries are a real, historical driver of what counts as home for a given device.
- **`EGRESS_FIREWALL_CLUSTER`/`ASSIGNED_FW`** (`fw_location_topology.py`) -- an attempt to map locations to their assigned egress firewall for Internet, Cloud, and Cross-Company traffic specifically, i.e. a first pass at recording *which* gateway-of-last-resort a given location's traffic actually uses.
- **`plugin_fw_class_tag.py`** (`fwlookup.py --fw-class DEVICE_NAME`, added 2026-08-05, per `fw_class_tagging_retooling_spec.md`) -- the newest and most authoritative piece: computes Home/Not-Home directly from `fw_route_db.sqlite`'s real `fw_interfaces`/`fw_routes` data (not zone names, not hostnames, not naming convention), then determines real traffic direction from actual `fw_rule_db` ALLOW-rule counts on the resolved Home↔Not-Home zone-pair. **Current real scope, stated honestly**: `INTERNET_EGRESS`/`INTERNET_INGRESS` are implemented and verified; `CLOUD_EGRESS`/`CLOUD_INGRESS` and `PCI` are not yet (need a real cloud-IP-range reference and `FW_SEGMENT` respectively, neither wired in yet). A device outside that scope returns `UNCLASSIFIED` honestly rather than a guessed class -- see the plugin's own module docstring for the exact current boundary. This is the mechanism `HERITAGE`/`EGRESS_FIREWALL_CLUSTER` were the first, partial attempts toward -- extend this one going forward for Home/Not-Home resolution specifically, the other two remain the right signal for heritage/assigned-cluster context that isn't derivable from route data alone.

**None of these three are complete** -- `EGRESS_FIREWALL_CLUSTER` is confirmed scoped to internet egress only (no equivalent for Intercompany/Cloud chains, see below), heritage assignment is a real, ongoing effort not a finished ground truth, and `plugin_fw_class_tag.py` covers only 2 of the 10 real Firewall Classes so far. All three should be treated as complementary, real, still-growing mechanisms -- extend them rather than duplicate them with a new, separate approach.

This is also the real, technical justification for `fwlookup.py`'s default noise-reduction behavior (`v1.17.0`): a query commonly returned 200+ rules for one IP, the overwhelming majority being generic `any/any` base-connectivity rules (`ipinip`/`gre`/high-port `udp`) that exist on nearly every firewall and match literally any IP. **This isn't just visual noise to filter for convenience -- these rules were never meant to be read as rule-author-intended, IP-specific policy the way a narrowly-scoped rule is.** They're the expression of gateway-of-last-resort routing, not a deliberate decision about the specific queried IP. TARGETED is the default; `--all` restores the unfiltered view for when the gateway-of-last-resort rules themselves are what you actually want to see (e.g. auditing base connectivity coverage across the estate).

## "Source/destination constrained" does not mean narrow -- verify what the objects actually resolve to

Confirmed on a real rule, `Private-Cloud-Infra-1` (`PAZSHDC-SEC-PAN-PROD-01`, `from Trust; to DMZ_corp;`, `service TCP-SSH`): the rule uses named objects on both sides, not literal `ANY` -- but that alone tells you nothing about actual scope. Resolving both objects:

- **`Private-Cloud-Infra`** (source) → exactly **6 specific hosts** (three apparent primary/secondary pairs across three subnets: `10.249.16.31/32`+`.32`, `10.124.154.29/32`+`.30`, `10.228.234.29/32`+`.30`). Genuinely narrow.
- **`DMZ-CORP-SUBNETS-CPC`** (destination) → **four full `/24` networks** (`10.86.248.0/24` through `10.86.251.0/24`, ~1,000 addresses). Genuinely broad.

**The real shape: narrow, fixed source → broad destination range, SSH only.** Not "the internal network reaches DMZ" -- a small, designated set of 6 management/jump hosts can SSH into essentially the entire DMZ-corp subnet space. The source constraint is doing real security work (compromise of one of 1000+ DMZ hosts doesn't grant broader SSH reach; compromise of one of the 6 source hosts opens SSH to ~1,000 targets). **Always resolve both sides of a rule before characterizing it as "constrained" -- a rule can look properly scoped from the rule text alone and still be a meaningful risk once the objects are actually resolved.** `fw_group_lookup.py`/`fw_group_db.sqlite` is the tool for this resolution step; don't reason about scope from object names alone.

## Zone naming: unreliable, confirmed with real, conflicting examples

Confirmed against a real Panorama export (`Panoramas_-_07-15-2026.zip`, the 4 real PA management devices: `MID-PAN-PROD-01`, `PAZSHDC-SEC-PAN-PROD-01`, `RRISHDC-SEC-PAN-PROD-01`, `WIN-PAN-PROD-01`): 35 zone blocks checked, no single naming convention dominates. `Trust`/`Untrust` (genuinely PA-native) coexists with `inside`/`outside_untrusted` (ASA `nameif` vocabulary, carried over) and `egress_untrusted`/`ingress_untrusted` (a third, directional convention) in the *same* export. Separately: 13 distinct DMZ-named zones exist (`APP_DMZ`, `DMZ-PDE`, `DMZ2`, `DMZ`, `DMZ_1/2/3`, `DMZ_corp`, `DMZ_pdc`, `Infoblox_DMZ`, `Semafone_DMZ`, `ebDMZ`, `mnmt_dmz`) -- one per vendor/purpose, itself evidence of the ACL/interface mindset (see thesis above).

**You cannot tell from a zone's name alone whether it's a reliable signal.** Verify per-device: does this specific device's zone naming actually correlate with real traffic direction, checked against its actual rules? Don't assume a convention holds estate-wide because it holds on one device.

### True DMZ vs. Extranet: defined by Trust-reachability, not by the word "DMZ" in the zone name

A zone literally named `DMZ_pdc`/`DMZ_corp` can still be functionally an **Extranet / Public-Facing DMZ**, not a true DMZ, if Trust can reach into it at all. Confirmed on real data:

- **`DMZ_pdc`/`DMZ_corp`**: real `Trust → DMZ_pdc/DMZ_corp` rules exist (`INSIDE-TO-DMZ-PING`: ping/traceroute only; `Private-Cloud-Infra-1` and related SSH/management rules, see above). Trust genuinely initiates into these zones, narrowly, for diagnostics and administration. **Functionally Extranet, despite the "DMZ" name.**
- **`Semafone_DMZ`** (a PCI-adjacent payment vendor zone): confirmed **zero** Trust-initiated rules found anywhere. The only traffic found is DMZ-initiated: `Semafone_DMZ → Outside` (NAT-level) is confirmed, and a reverse `Outside → Semafone_DMZ` NAT entry also exists (inbound from the vendor's own cloud, via NAT to `obj-204.99.15.65`). **The defining property is not "outbound only" -- it's Trust-isolation specifically.** A true DMZ can legitimately receive inbound from Internet/Outside; what makes it a true DMZ is that Trust never reaches in.

**Classification rule**: check whether Trust ever appears as `from` in any rule targeting the zone. If yes (even narrowly, even just for SSH/ping), it's functionally Extranet regardless of its name. If Trust never appears, it's a true DMZ, and its Internet-facing reachability (inbound and/or outbound) is a separate, orthogonal question.

### How internal users actually reach a true-DMZ public-facing workload (no privileged path exists)

Worked real example, `Semafone_DMZ`: since Trust is isolated from the zone directly, and the workload is only reachable via its public IP (`204.99.15.65`) through Outside-facing NAT, **an internal Trust-side user takes the identical path an external internet client takes** -- out through Untrust, redirected by upstream network infrastructure (a switch, *not* the firewall -- see below) based on the public destination IP, arriving back at the firewall as ordinary Untrust-sourced inbound traffic.

**This redirect happens on network infrastructure outside the firewall's config, and that hop is invisible to any FW-config-based tool.** If reasoning about a path like this, don't assume you can fully trace it in `fw_rule_db`/`fw_group_db`/Panorama configs alone -- there may be a hop (a switch doing policy-based routing, in this confirmed case) that these tools have zero visibility into.

**Why the firewall needs no special hairpin/U-turn NAT logic for this**: PA resolves NAT *before* the security-policy zone lookup. By the time the packet reaches the firewall, it has already been redirected by the switch and arrives as ordinary Untrust-sourced traffic destined for the workload's public IP -- indistinguishable from a genuine external client. NAT resolves the destination zone to DMZ; security policy evaluates it as standard inbound DMZ access, same rule either way. The firewall's job starts and ends at "is this permitted Untrust→DMZ traffic to this NAT'd destination" -- whether the original client was truly external or was Trust redirected through the switch is invisible to, and irrelevant to, the firewall.

**Why the Trust→Untrust→switch→DMZ path even gets triggered at all**: it depends on Trust's own routing table *not* having a more-specific internal route to the DMZ subnet. If it did, that route would win over the default path toward Untrust, and the redirect-via-public-IP mechanism would never trigger -- traffic would route internally instead, bypassing the switch. The mechanism only works because those DMZ subnets are deliberately absent from Trust's internal routing.

## Segment, zone, and policy: base vocabulary

- **A network segment** is a network interface (or sub-interface).
- **A zone** is a named collection of one or more interfaces.
- **A policy/rule** is applied zone-to-zone (PA, FTD, Juniper/ScreenOS) or interface-to-interface (legacy ASA without zones).

## Platform trust models: two genuinely different systems

### ASA: numeric security levels (0-100), an implicit trust hierarchy

Higher level = more trusted. Default (rarely relied on alone in practice, since real devices layer explicit ACLs on top): higher→lower permitted by default ("downhill"), lower→higher denied by default, same-level denied unless explicitly allowed. The cascade is a straight numeric comparison, not tier-by-tier: a 100/99/98/97/0 stack means 100 reaches everything below it directly. A leaner, more realistic real-world pattern: `0=Untrust, 10=DMZ, 75=MGMT, 100=Trust` (non-even spacing is deliberate, leaves room to insert tiers later).

**Given the acquisition history, security-level assignment is very unlikely to be consistent across all ASA devices.** Do not trust the numbers as a classification signal without checking whether the device's actual ACLs match what the levels imply.

### PA, FTD, Juniper/Netscreen (ScreenOS): explicit named zones, no implicit hierarchy

No numeric ranking; the zone name itself is the classification. Structurally cleaner than ASA's model -- undermined here by the naming-unreliability problem above. **FTD inherited PA's zone model** (post-Sourcefire); treat FTD and PA identically for classification -- `fw_rule_db`'s `src_zone`/`dst_zone` are real, authoritative zone data for both. **On legacy ASA specifically**, the same columns hold the interface's `nameif`, not a real zone -- there's no zone abstraction on ASA at all.

**Cisco and PA are not federated -- no cross-device context on either platform.** Three PA firewalls in a traffic path are independently just "a firewall with a Trust zone and an Untrust zone" with zero adaptive coordination between them. This applies uniformly to every "inner" Type-Class sitting behind some boundary firewall -- PCI behind Internet Egress, Cross-Company behind Internet Egress, Cloud behind Internet Egress. One partial signal exists: `fw_location_topology.csv`'s `EGRESS_FIREWALL_CLUSTER`/`ASSIGNED_FW` (read by `fwlookup.py --egress-map`), scoped specifically to internet egress. **Confirmed no equivalent exists for Intercompany or Cloud chains** -- checked directly against `build_fw_location_topology.py`.

**Panorama Device Groups are shared authoring, not runtime coordination.** Confirmed real: `DG_AZ_EXT_DMZ` (`description "Shea DMZ"`) is a real device-group, and the same name appears as a policy container in real rule output. Device Groups let you write a rule set once and push it to every assigned device identically -- they create zero runtime relationship between the devices that receive it.

## Object portability vs. zone portability: opposite properties

Confirmed on a real rule (`Outside_access_in_589`, `PAZSHDC-SEC-PAN-PROD-01`): `from Outside; to any; source SFTP_SRC_Grp; destination SecureTransPort-CMX-WEB-VIP-HOST;`

- **Zone names** (`from Outside`) are **device-local** -- the same name means different IPs on different devices. This is what makes "one shared rule, 20 heterogeneous Edge firewalls via a Device Group" work.
- **Named address objects** (`SFTP_SRC_Grp`) are **globally shared** within the device-group -- the same object name resolves to the same actual IPs everywhere referenced (this is what `fw_group_db.sqlite` captures: `SFTP_SRC_Grp = 100.0.0.0/8, 104.0.0.0/8, ...`, identical wherever the rule references it).

Two ways to keep a single shared rule (one Device-Group-pushed policy, many devices with different local networks) working despite zones being device-local: (1) **User-ID based** -- SRC stays `any` globally, qualification happens on identity, resolved locally per device. (2) **Per-firewall EDL based** -- the rule references the same EDL name everywhere, but each firewall fetches it from a distinct source URL, inverting the shared-object problem rather than avoiding it. **Whether any EDL in this environment is actually deployed the second way is unconfirmed** -- check `build_edl_catalog.py`/`object-viewer-web-service.sh` directly before assuming; the platform's own EDL usage confirmed so far (Custom Objects, User Access EDLs) is the static/API-controlled mode, same shared-object-name behavior as a static object, just delivered via EDL syntax.

**EDL's actual origin**: introduced to support NSX firewall integration via a plug-in (dynamic membership sync), later extended to external threat-intel subscription feeds. Supports both dynamic (live-polled) and static (API-controlled, scheduled refresh) modes. Real threat-intel EDL content in this environment: `3,678 threat intel CIDRs`, `1,418 Tor exit nodes` (`build_external_ip_registry.py`) -- the genuine subscription-feed use case.

## Home/Not-Home: the practical policy basis, distinct from zone/security-level trust

Most L4 ACLs on this estate are best interpreted as **Home Net (Trust) to Not-Home/Untrust**, not strictly zone-to-zone or security-level-to-security-level:

- **Home/Trust** = any subset of IPs actually bound to the firewall's own internal network -- not necessarily the whole RFC1918 block; a real internal subnet is just as much "home" as a /8 reference.
- **Not-Home/Untrust** = anything outside that boundary, including genuine public internet *and* other organizations' networks reached via partner connections (B2B-MPLS, B2B-VPN). **Not-Home ≠ public.** A partner's private `10.x` space reached over B2B-MPLS is genuinely not-home but not public -- a strict "is this a public IP" check (the current `is_public()` in `build_external_ip_registry.py`/`fw_audit_patterns.py`) will miss it.

**When building or reviewing a broad-source/risky-destination audit** (e.g. `fwlookup.py --broad-src-public-dst`): the current implementation checks "SRC is `any` or the literal RFC1918 top-level block" and "DST doesn't overlap private/reserved space" -- both narrower than the real Home/Not-Home distinction. A more accurate version checks SRC against the firewall's *actual* registered internal space via IPAM, and flags not-home destinations more broadly than strictly-public ones.

## Edge vs. DMZ/Extranet: classify by traffic direction

- **Edge Firewall**: internal clients → external servers (client-to-server, egress pattern).
- **DMZ/Extranet Firewall**: external clients → internally-hosted servers (server-to-client from the internal perspective, ingress pattern).

Must be derived from real rule data (which zone/network sits in `src_zone` vs `dst_zone` on actual ALLOW rules, internal side identified via IPAM-registered space) -- not from hostname or zone name, both unreliable here for the reasons established above. **Status: defined but not yet implemented as a tool** -- no script currently computes this.

### The Internet Ingress three-tier chain

A defined, deliberate evolution of Internet Ingress, not a single-hop firewall: (1) **Internet Ingress Screening FW** -- outermost, deliberately **no SNAT**, so the real client source IP survives past this tier; (2) **Public-Facing FW** -- the published-service enforcement point, still sees the real client IP; (3) **DMZ/Extranet-to-Internal FW** -- the final hop into true internal servers. The no-SNAT detail at tier 1 is load-bearing: it's why tiers 2 and 3 can still do meaningful client-based policy at all, rather than everything downstream collapsing to "traffic from the screening firewall." **Whether this three-tier pattern extends to Cloud Ingress or other ingress-shaped classes is unconfirmed** -- don't assume it generalizes without checking.

## HA pairs and logical firewall grouping

A single logical firewall (active/standby pair, multi-context chassis) shows up as multiple separate rows in raw manifest/inventory data -- e.g. `PIH-SEC-M1A-PCI-01XAact`/`XAstby` are the same physical device. `fwlookup.py`'s `ha_stem_and_role()` (`v1.15.0`+) strips known HA/context suffixes (`XAact`, `XAstby`, trailing `-a`/`-b`/`-act`/`-stby`/etc.) to derive the logical stem and groups on it for `--inv` display. **Deliberately conservative**: a bare numeric suffix (`-01`/`-02`) with no HA marker is treated as two independent devices, not a pair -- confirmed against real data that e.g. `RRICMDC-SEC-INT-PCI-01`/`-02` are genuinely separate, not an HA pair.

## Existing real classification systems -- what each one actually measures

Two independently-computed, genuinely different taxonomies exist; a single firewall gets both values simultaneously.

**`FW_SEGMENT`** (`fw_config_manifest.py`, read by `fwlookup.py --inv SEGMENT`) -- **hostname pattern matching** against an ordered regex list, falling through to `INTERNAL-DC`. Naming-convention-based -- subject to the same reliability caveats as everything else naming-based here. Values: `EGRESS, PCI, CLOUD, RA-VPN, B2B-VPN, B2B-MPLS, INTERCOMPANY, AFFILIATE, INTERNAL-DC, RETAIL-SDWAN, MGMT`, plus `KNOWN GAPS`.

**`FW_ROLE`** (`build_fw_location_topology.py`, read by `fwlookup.py --egress-map`) -- **actual routing-domain membership**, empirical/data-derived, the more trustworthy of the two where both are available:
```python
if is_sdwan_hub(fw_name): return 'RETAIL-SDWAN-HUB'   # the one name-based exception
if 'Internet-Facing' in routing_domains:
    return 'CLOUD-EDGE' if 'Cloud' in routing_domains else 'INTERNET-EDGE'
if 'Partner' in routing_domains or 'MPLS' in routing_domains: return 'MPLS-EDGE'
if not routing_domains: return 'MGMT'
return 'INTERNAL'
```
Values: `INTERNET-EDGE, CLOUD-EDGE, MPLS-EDGE, INTERNAL, MGMT, RETAIL-SDWAN-HUB`.

**Do not conflate the two lists or invent a combined taxonomy without checking both source files.** Confirmed 2026-07-28: `DMZ-INTERNET-INGRESS` does not exist anywhere in `fw_location_topology.py`, `fw_config_manifest.py`, or `fwlookup.py`.

## Signal trust hierarchy: what to believe, in order

1. **Actual rule/interface data from the real config** (matched CIDR width, actual `src_zone`/`dst_zone`, actual permitted direction, actual routing-domain membership, actual resolved object content) -- real regardless of naming or migration history.
2. **`FW_ROLE`-style empirical classification** over `FW_SEGMENT`-style naming classification, where both exist.
3. **Zone names verified as internally consistent on the specific device** (e.g. `egress_untrusted` genuinely indicates direction where used) -- verify per-device, never assume estate-wide.
4. **Hostname patterns and generic zone names/security-level numbers** (`inside`/`outside`, bare `Trust`/`Untrust`, `FW_SEGMENT` regex matches) -- first-pass filter only, never the sole basis for a security-relevant conclusion.
5. **A rule's own claim of being "source/destination constrained"** -- meaningless until both objects are actually resolved; see `Private-Cloud-Infra-1` above for a confirmed real case where "constrained" hid a genuinely broad destination.

## Related tools and files

- `fw-class-taxonomy` skill -- companion skill, the authoritative 10-class Firewall Class taxonomy and how to determine which class(es) a device supports; use that first to know what a device is, this skill to correctly interpret its specific rules
- `fwlookup.py` -- `--inv [SEGMENT]` (FW_SEGMENT-based, HA-grouped), `--egress-map SITE` (FW_ROLE/HA_ROLE-based), `classify_scope()`/default TARGETED filtering (gateway-of-last-resort-aware noise reduction, `v1.17.0`)
- `fw_route_db.sqlite`/`build_fw_route_db.py` -- `fw_interfaces` (directly-connected subnets per device) and `fw_routes` (full routing table per device, indexed for range lookups) -- the real, already-built data source for determining what's actually Home for a given device, rather than inferring it from zone names or hostname
- `fw_group_lookup.py` -- real address-group membership resolution (`fw_group_db.sqlite`) -- use this before characterizing any rule's objects as narrow or broad
- `fw_audit_patterns.py` -- `--broad-src-public-dst`, currently narrower than the full Home/Not-Home model above
- `build_fw_config_manifest.py` -- `_SEGMENT_RULES`, the real hostname-pattern classification logic
- `build_fw_location_topology.py` -- `fw_role()`, the real routing-domain-based classification logic; also the source of `HERITAGE` and `EGRESS_FIREWALL_CLUSTER`/`ASSIGNED_FW`, existing (partial) mechanisms for contextualizing what `ANY`/Home means per device -- see above
- `plugin_fw_class_tag.py` (`fwlookup.py --fw-class`) -- the newest, most authoritative Home/Not-Home mechanism, computed directly from `fw_route_db.sqlite` real route/interface data -- see above for its current real scope
- `ccd-fw-pipeline` skill -- build order and dependency graph for the scripts that produce the data this skill interprets
