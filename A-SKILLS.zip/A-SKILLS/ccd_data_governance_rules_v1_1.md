# CCD Platform — Data Governance Rules
## Location Master, IPAM, SITE_CODE, NET_TYPE, Host Datasets, FW Data, and EIR

**Version:** 1.1
**Date:** 2026-05-21
**Status:** Canonical — all scripts must conform to these rules
**Author:** M. J. Martin — Lead Director, Information Security, CVS Health

### Changelog — v1.0 → v1.1
- Added IPAM hierarchy invariant (Rule IPAM-6) — root cause of 3-year LM corruption
- Added /32 host route prohibition (Rule IPAM-7)
- Added pre-write overlap rule (Rule IPAM-8)
- Added LM anchor validation requirement (Rule LM-7)
- Added cross-dataset host exclusivity rule (Rule HOST-1 through HOST-4)
- Added FW data classification rules (Rule FW-1 through FW-5)
- Added EIR rules (Rule EIR-1 through EIR-3)
- Updated tier architecture to include EIR as Tier 1
- Flagged IPAM-1 as in-progress (SITE_CODE migration not complete)
- Added NET_TYPE remediation rules (NT-4 through NT-5)
- Documented what every corruption event traced to

---

## The Three Questions

Every subnet in the estate is fully described by three independent questions:

| Question | Field | Owner |
|---|---|---|
| **WHERE** is this network? | `SITE_CODE` | Location Master |
| **WHOSE** network space is it? | `ROUTING_DOMAIN` + `HERITAGE` | IPAM |
| **WHAT** is on this subnet? | `NET_TYPE` | IPAM |

These three dimensions are orthogonal. None implies the other. A location
(`US_MNR_PA_SP`) has many subnets with different routing domains. A routing
domain (`Internal-HCB`) spans many locations. A NET_TYPE (`Application`)
appears in every routing domain. Never conflate them.

---

## Location Master (LM) — Rules and Responsibilities

### What the LM IS
The LM is a **normalisation engine**. It takes every form a location reference
arrives in across all data sources and normalises it to a single canonical
SITE_CODE. It is the root of the entire model — nothing enters any downstream
dataset without a CANONICAL_LOCATION that resolves to an active LM entry.

### What the LM contains
Physical location data only:

| Field | Description | Rule |
|---|---|---|
| `SITE_CODE` | Structured machine identifier | Primary key. Format: `[ITU_CC]_[IATA]_[ST]_[SITE_TYPE]` |
| `CANONICAL_NAME` | Human-readable identifier | Derived from defining attributes. Never arbitrary text. |
| `LOCATION_TYPE` | Site type code | Must be from site_code_taxonomy.csv (17 valid types) |
| `CITY` | Geographic city | Defining attribute |
| `STATE` | State / province / region | Defining attribute |
| `COUNTRY` | ITU country code | From itu_country_codes.csv |
| `ADDRESS` | Physical street address | Optional — physical location only |
| `HERITAGE` | Corporate lineage | CVS / AETNA / OSH / OMNICARE / CAREMARK / SWITCH / PARTNER |
| `STATUS` | Lifecycle state | Active / Retired / Pending / Placeholder |
| `HOSTNAME_PREFIX` | Hostname translation anchor | Derived from SITE_CODE |
| `LATITUDE` / `LONGITUDE` | Geographic coordinates | For mapping |
| `FACILITY_OWNER` | Who owns the building | CVS, AETNA, Switch, Iron Mountain, Equinix, etc. |
| `DATASET_VERSION` | Data governance version stamp | Auto-stamped on import |

### What the LM does NOT contain

| Field | Reason | Correct Location |
|---|---|---|
| `NET_TYPE` | Network use context — per subnet not per location | IPAM |
| `ROUTING_DOMAIN` | Network routing domain — per subnet not per location | IPAM |
| `ENVIRONMENT` | Prod / NonProd — operational classification | IPAM |
| Tenant qualifiers | CVS/Aetna/PCI — heritage distinction | IPAM HERITAGE + ROUTING_DOMAIN |
| Application names | SecureHub / RxConnect — app layer | app_subnet_index |
| VPC / network names | Cloud VPC identifiers | IPAM |

### LM Rules — Non-Negotiable

**Rule LM-1: The LM is the sole creator of SITE_CODEs.**
No pipeline script, no data source, no automated process creates a SITE_CODE.
The LM assigns SITE_CODEs. Everything else references them.

**Rule LM-2: No location enters the LM without HR validation.**
Every non-infrastructure location must have HR confirmation (>= 10 employees
of the expected BU type) OR confirmed IPAM data. Zero HR + zero IPAM = phantom.
Exception: infrastructure types (DC/CI/CP/IX/NH/DR/IS/SS) — validated by
FACILITY_OWNER and network evidence instead.

**Rule LM-3: Cloud LM entries are Provider + Region only.**
`US_GCP_USE4_IS` — not `US_GCP_USE4_CVS_IS` or `US_GCP_USE4_PCI_IS`.
Tenant, VPC, environment, application — none of these are location qualifiers.

**Rule LM-4: One SITE_CODE per physical function.**
Same building, different functions = different SITE_CODEs.
Same building, same function = one SITE_CODE (merge duplicates).

**Rule LM-5: The CANONICAL_NAME is derived, never assigned.**
Format: `{CITY} {STATE} - {LOCATION_TYPE_LABEL}`
The pipeline cannot create an arbitrary CANONICAL_NAME string.

**Rule LM-6: SITE_CODE format is validated against registries.**
IATA/city code must exist in city_code_registry.csv.
SITE_TYPE code must exist in site_code_taxonomy.csv.
Invalid SITE_CODE = hard reject.

**Rule LM-7: 20 critical anchors must be present in every LM version.**  *(NEW v1.1)*
The following site codes must exist with non-blank CANONICAL_NAME in every LM
version. `preflight_lm_check.py` validates this before every `update_ipam.py`
execution and hard-stops with exit code 1 on failure.

| Category | SITE_CODEs |
|---|---|
| Primary DCs | US_CUR_RI_DC, US_WOR_RI_DC, US_MIC_CT_DC, US_WIN_CT_DC, US_SCO_AZ_DC, US_ATL_GA_DC, US_PHX_AZ_DC |
| COLO | US_LVG_NV_CI, US_ATL_GA_CI, US_SPK_NV_CI, US_IAD_VA_CI, US_WDB_NJ_CI, US_CAR_NJ_CI, US_DFW_TX_CI |
| DR | US_WOO_RI_DR, US_WAT_MA_DR, US_WDB_NJ_DR, US_CDT_NJ_DR, US_PHL_PA_DR |
| NAAS Hub | US_SCA_CA_F9-NH |

Any IPAM update that runs against an LM missing one of these anchors propagates
corrupted location data downstream. This single gate prevents the class of
corruption events that affected the platform for three months in 2026.

---

## IPAM (all_IP_networks) — Rules and Responsibilities

### What IPAM contains
Network subnet data — one row per CIDR:

| Field | Description | Valid Values |
|---|---|---|
| `CIDR` | Subnet in CIDR notation | Valid IPv4/IPv6 CIDR |
| `CANONICAL_LOCATION` | Human-readable location | Must match LM CANONICAL_NAME exactly |
| `SITE_CODE` | Location FK → LM.SITE_CODE | Must exist in LM |
| `ROUTING_DOMAIN` | Whose network space | From routing_domain_registry |
| `NET_TYPE` | Use context of this subnet | From net_type_registry |
| `HERITAGE` | Which entity owns the subnet | CVS / AETNA / OSH / OMNICARE / PARTNER |
| `DATA_QUALITY` | Confidence level | Authoritative / Inferred / Manual |
| `LOC_MASTER_VERSION` | LM version used for classification | Auto-stamped |
| `DATASET_VERSION` | IPAM dataset version | Auto-stamped |

### IPAM Rules — Non-Negotiable

**Rule IPAM-1: SITE_CODE migration in progress.**
Target state: SITE_CODE replaces CANONICAL_LOCATION as the primary location FK.
Current state: CANONICAL_LOCATION remains the primary FK; SITE_CODE is populated
and must match LM. Both fields are maintained during the migration period.
Full migration target: LM v6.0.

**Rule IPAM-2: ROUTING_DOMAIN is a per-subnet field.**
A location has many subnets with different routing domains. ROUTING_DOMAIN
describes the network space of each individual subnet, not the location.

**Rule IPAM-3: NET_TYPE is a per-subnet field.**
The same SITE_CODE will have User-Wired, Application, WAN-P2P, Management
subnets. NET_TYPE classifies each subnet independently.

**Rule IPAM-4: Prod/NonProd belongs in ENVIRONMENT.**
Production vs non-production is an operational classification — never a
location qualifier and never part of a SITE_CODE.

**Rule IPAM-5: Tenant/VPC/application is NOT in SITE_CODE or CANONICAL_NAME.**
SecureHub → NET_TYPE. RxConnect → app_subnet_index.APP_ACRONYMS.
PCI scope → compliance metadata. CVS vs Aetna → HERITAGE + ROUTING_DOMAIN.

**Rule IPAM-6: Parent-child subnets must have consistent routing domain and location.**  *(NEW v1.1)*
This is the **root cause of three months of LM corruption in 2026**. Every
more-specific subnet (/17+) that sits inside a broader IPAM block must have
the same ROUTING_DOMAIN and CANONICAL_LOCATION as its parent — or the parent
must be a true summary block (/16 or broader).

When violated:
- LPM lookups return consistent results but the parent block has wrong attribution
- Downstream datasets (EHM, NDM, infra, platform) inherit the parent's wrong location
- CSNA hostgroups place hosts in the wrong zone
- Security reports misattribute traffic

Enforcement: `audit_ipam_hierarchy.py` scans for violations. `update_ipam.py`
v1.8+ blocks any candidate that would create a new violation at write time
(`CX1-CONTAINS-CONFLICT`). Existing violations require remediation of the
**parent block** — the children are usually correctly attributed.

Severity classification:
- **HIGH**: ROUTING_DOMAIN conflict — different network ownership domains
- **MEDIUM**: Cross-city CANONICAL_LOCATION conflict
- **LOW**: Same-city, different facility (acceptable in some cases)

Current state (audit of v3.92): **617 offending parent blocks, 3,669 child
conflicts**. Remediation is in progress. Run `audit_ipam_hierarchy.py` after
every IPAM update to track progress.

**Rule IPAM-7: /32 host routes are never valid IPAM entries.**  *(NEW v1.1)*
Individual host IPs (/32) belong in `ent_host_master` or `delivery_infrastructure`
or `delivery_platform`. They are never imported into `all_IP_networks`.
FW-derived /32 entries are routed to `fw_host_candidates` → `update_app.py`.
`update_ipam.py` rejects all /32 candidates with `R1-HOSTROUTE`.

**Rule IPAM-8: Pre-write validation is mandatory before every write.**  *(NEW v1.1)*
`update_ipam.py` v1.8+ performs three gates before writing any file:

1. **preflight_lm_check.py** — validates 20 critical LM anchors. Hard-stop on failure.
2. **Exact duplicate check** — rejects CIDRs already in all_IP_networks.
3. **Containment/overlap check** — rejects candidates that would create
   ROUTING_DOMAIN or CANONICAL_LOCATION conflicts with existing entries.

If any gate fails, no file is written. The IPAM is not modified.

---

## NET_TYPE — Rules and Responsibilities

### What NET_TYPE IS
NET_TYPE answers: **"What devices and traffic are on this specific subnet?"**
It is the use context of a single subnet row in IPAM.

### What NET_TYPE is NOT
- Not a location attribute (not in LM)
- Not a business function (that is SITE_TYPE)
- Not a heritage indicator (that is HERITAGE + ROUTING_DOMAIN)
- Not an application name (that is app_subnet_index)
- Not an environment (that is ENVIRONMENT)

### NET_TYPE Tiers

| Tier | Description | Examples |
|---|---|---|
| 0 | Nothing known | Unknown |
| 1 | Heritage known only | CVS-Unclassified / AETNA-Unclassified |
| 2 | Heritage + broad category | CVS-User / CVS-Server / CVS-Network |
| 3 | Confirmed specific | User-Wired / Application / IOT-Camera / WAN-P2P |

### NET_TYPE Rules

**Rule NT-1: NET_TYPE lives in IPAM only.**
Removed from LM. CSNA zone is derived from SITE_CODE LOCATION_TYPE component.

**Rule NT-2: NET_TYPE uses controlled vocabulary.**
Only values from net_type_registry.csv are valid.

**Rule NT-3: Start with placeholder — promote with evidence.**
Unknown → CVS-Unclassified / AETNA-Unclassified → Tier 2 → Tier 3.
Never guess. Use the correct placeholder tier.

**Rule NT-4: Heritage-branded NET_TYPE values are prohibited.**  *(NEW v1.1)*
`CVS-DC`, `AETNA-DC`, `HCB-Server`, `CVS-Corporate` — these embed heritage
into a field that answers "what" not "whose". Heritage belongs in the
`HERITAGE` and `ROUTING_DOMAIN` fields.

Current violations in v3.92 IPAM are known and under remediation. New entries
must not use heritage-branded values. Valid alternatives: `DataCenter`,
`Corporate`, `Application`, `Distribution`.

**Rule NT-5: BU labels are not NET_TYPE values.**  *(NEW v1.1)*
`Omnicare`, `Caremark`, `MinuteClinic` as NET_TYPE values are BU identifiers,
not subnet use context. BU identity belongs in HERITAGE and SITE_CODE.
Valid for the SITE_CODE suffix (e.g. `_MC`, `_SP`) — not in NET_TYPE.

---

## Host Datasets — Mutual Exclusivity Rules  *(NEW v1.1)*

Three datasets hold IP-keyed host records. They are designed to be mutually
exclusive by function — a given IP address belongs in at most one of them.

| Dataset | Hosts it contains | Key field |
|---|---|---|
| `ent_host_master` | Application and server hosts | `IP_ADDRESS` |
| `delivery_infrastructure` | ESXi, HMC, iSeries, DataPower, Isilon, storage | `IP_ADDRESS` |
| `delivery_platform` | Kubernetes, OCP, Docker, RHCOS nodes | `IP_ADDRESS` |

**Rule HOST-1: An IP address may appear in at most one host dataset.**
If a host IP is in `delivery_infrastructure`, it must not be in `ent_host_master`
or `delivery_platform`. `update_app.py` v1.4+, `update_infrastructure.py` v1.3+,
and `update_platform.py` v1.3+ enforce this at write time by loading all three
datasets and rejecting any candidate already present in another.

**Rule HOST-2: Classification drives dataset placement.**
Application/server hosts → `ent_host_master`
Physical compute infrastructure → `delivery_infrastructure`
Container/orchestration nodes → `delivery_platform`
When in doubt: if the host runs workloads, it is EHM. If it is a hypervisor
or platform node, it is infra or platform.

**Rule HOST-3: FW-derived /32 hosts go to EHM only.**
Host IPs discovered through FW rule analysis (`fw_host_candidates`) are
candidates for `ent_host_master` via `update_app.py --add-file`. They are
never added to IPAM. They are subject to Rule HOST-1 cross-dataset dedup.

**Rule HOST-4: FW_POLICY field carries service context, not attribution.**
`delivery_infrastructure.FW_POLICY` and `delivery_platform.FW_POLICY` are
populated by `fw_rule_extraction_translation.py` with the FW object group
names that reference each host's /24. This field provides service visibility
context — it does not override the host's dataset placement or location.

---

## FW-Derived Data Classification Rules  *(NEW v1.1)*

Firewall configuration analysis is a major source of network intelligence but
produces data of varying quality. These rules govern how FW-derived data is
classified and where it lands.

**Rule FW-1: FW object groups must be classified by SERVER vs CLIENT role
before any data is attributed to subnets.**

| Role | Classification signal | Attribution |
|---|---|---|
| SERVER | Group name contains `_server`, `_host`, `_mgr`, `_relay`, `_broker`, `_proxy`, `_controllers`, `_DC`, `_SVR`, `_REPO` | The /24 HOSTS this service → `APP_ACRONYMS` in app_subnet_index |
| CLIENT | Group name contains `_ACCESS`, `_client`, `_endpoint`, `_agent`, `_agents`, `_managed`, `_workload` | The /24 CONSUMES this service → `CPC_SERVICES` in app_subnet_index |
| UNKNOWN | No clear signal | Treat as SERVER for conservative attribution |

Misclassifying a CLIENT group as SERVER attributes services to the wrong
subnets. The distinction is critical for accurate application visibility.

**Rule FW-2: HOST-BASED vs SUBNET-BASED policy determines /32 handling.**
FW object groups where ≥70% of members are /32 hosts are host-based policies.
For host-based groups: the /32 hosts go to `fw_host_candidates` → EHM.
The /24 parent still gets service context if the service is relevant.
For subnet-based groups: the resolved /24s get the full attribution.

**Rule FW-3: F5 VIP cross-reference is mandatory.**
When a FW rule destination matches a known F5 VIP IP, attribution must go
to the pool member subnets — not the VIP IP. VIP IPs are load balancer
addresses; the real application is in the pool member subnets.
`fw_rule_extraction_translation.py` enforces this via F5-VIP-REGISTRY.

**Rule FW-4: SNAT pool IPs are filtered from IPAM candidates.**
F5 SNAT pool member IPs appear as FW rule sources but represent translated
addresses, not real source hosts. They must not generate IPAM candidates or
EHM host records. `build_f5_vip_registry.py` produces F5-SNAT-POOLS for
this filter.

**Rule FW-5: FW-derived IPAM candidates require EHM or NDM confirmation.**
A subnet visible in a FW object group alone is insufficient evidence for
IPAM promotion. EHM hosts or NDM devices in the /24 are required for
HIGH-confidence promotion via `update_ipam.py`. Unconfirmed candidates
route to `fw_ipam_review.csv` for manual review.

Rationale: FW object groups frequently contain overly broad summary blocks
that span multiple DC locations and routing domains. Promoting them without
confirmation introduces the ROUTING_DOMAIN conflicts described in IPAM-6.

**Rule FW-6: FW-derived broad blocks must not span routing domain boundaries.**
A FW-derived IPAM candidate that would contain existing subnets with different
ROUTING_DOMAIN or CANONICAL_LOCATION is rejected with CX1-CONTAINS-CONFLICT.
This is `update_ipam.py` v1.8+ enforcement. The 13 blocked candidates from
the May 2026 FW extraction are examples of this rule correctly firing.

---

## External IP Registry (EIR) — Rules  *(NEW v1.1)*

The External IP Registry (EIR) is a Tier 1 dataset that tracks every external
IP/CIDR that appears in firewall rules, enriched with ASN, geolocation, and
provider attribution. It is built by `build_external_ip_registry.py`.

**Rule EIR-1: External CIDRs are never added to all_IP_networks.**
External IPs (non-RFC1918, non-CVS-BGP) belong in the EIR — never in IPAM.
IPAM is for internal network space only.

**Rule EIR-2: EXT_IDs are assigned by the EIR build process only.**
Format: `EXT-YYYYMMDD-NNNNNN`. No other process creates EXT_IDs.

**Rule EIR-3: EXT_ID_REFS back-patch links IPAM and ASI to the EIR.**
When the EIR is built, it back-patches `EXT_ID_REFS` into the IPAM rows
and app_subnet_index rows that reference those external IPs. CX13 validates
that every EXT_ID_REFS value exists in the EIR. This creates a bidirectional
link between internal network intelligence and external IP intelligence.

---

## The Tier Architecture (Updated)

```
TIER 1 — MASTER DATASETS (governed, versioned, gated)
  location_master           → SITE_CODE, physical location only
  all_IP_networks           → SITE_CODE(FK), ROUTING_DOMAIN, NET_TYPE
  ent_host_master           → application/server host inventory
  ent_network_device_master → network device inventory
  delivery_infrastructure   → ESXi, HMC, iSeries, DataPower, Isilon
  delivery_platform         → Kubernetes, OCP, Docker, RHCOS
  app_subnet_index          → /24 → APP_ACRONYMS + CPC_SERVICES
  retail_networks           → retail /26 subnets
  external_ip_registry      → external CIDRs with ASN/geo (EIR) [pending]

TIER 1b — ENT IPDATASETS (reference, registered in ip_dataset.json)
  ent-ipdataset-F5-VIP-REGISTRY   → BIG-IP virtual servers
  ent-ipdataset-F5-POOL-MEMBERS   → F5 backend pool members
  ent-ipdataset-F5-SNAT-POOLS     → SNAT translation IPs (filter list)

TIER 2 — DERIVED DATASETS (built from Tier 1, purpose-specific)
  csna_site_registry        → built from LM + IPAM for CSNA
  placeholder_networks      → LM-anchored subnets pending IPAM

TIER 3 — DELIVERABLES
  CSNA_Import_*.xml         → Stealthwatch / Cisco CSNA import
  FW_Rule_Report.html       → firewall analysis
  ipam_hierarchy_report     → audit output from audit_ipam_hierarchy.py

CONSUMERS
  iplookup.sh               → reads Tier 1 directly (query only)
  generate_csna_*           → Tier 1 → Tier 2 → Tier 3
  fw_rule_extraction_*      → Tier 1 → FW configs → Tier 1 candidates
  audit_ipam_hierarchy.py   → Tier 1 audit → Tier 3 report
```

---

## What Every Corruption Event Traced To

| Corruption event | Rule violated |
|---|---|
| WSL/WSM/ABE retail artifacts in LM | LM-1: pipeline created SITE_CODEs from hostnames |
| Cloud tenant qualifiers (GCP-CVS, GCP-PCI) | LM-3: tenant qualifiers in location names |
| NET_TYPE in LM | LM/IPAM boundary: IPAM field placed in LM |
| CANONICAL_LOCATION string drift | IPAM-1: string FK instead of structured SITE_CODE |
| Prod/NonProd as location names | IPAM-4: operational classification as location qualifier |
| SecureHub/RxConnect as locations | IPAM-5: application/architecture as location qualifier |
| Duplicate Corporate entries | LM-4: same function, same location — should be one entry |
| Work At Home in LM | LM-2: no HR confirmation, no IPAM data — phantom |
| 3,669 child subnet misattributions (2026) | IPAM-6: parent blocks with wrong routing domain |
| FW-derived broad blocks poisoning IPAM | FW-5 + FW-6: unconfirmed, unvalidated FW candidates |
| EHM hosts with wrong location | IPAM-6 cascade: child inherited parent's wrong routing domain |
| Heritage-branded NET_TYPE drift | NT-4: CVS-DC / AETNA-DC / HCB-Server in NET_TYPE |
| Host IP in multiple datasets | HOST-1: cross-dataset exclusivity not enforced |

---

*End of document. All rules are canonical. Scripts that violate these rules
are incorrect regardless of whether the output "looks right". Correctness
is defined by the rules, not by the output.*
