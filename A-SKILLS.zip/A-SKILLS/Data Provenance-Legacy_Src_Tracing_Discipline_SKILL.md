---
name: ccd-data-provenance
description: >
  CCD Platform data provenance and legacy raw-data-source tracing discipline.
  Use when building/fixing a tool that resolves device location from raw
  NMS/inventory sources, when a dataset like mgmt_ip_index has no build script,
  or when backfilling DATA_SOURCES/LAST_SEEN_* provenance or file auto-discovery.
  Triggers on: "no build script exists", "historical versioning", "data source
  legacy tracing", "there is no other SOT", "provenance", "auto-discovery",
  "LAST_SEEN", "OUT-OF-SERVICE". Documents real design principles and bugs
  already found, so they aren't rediscovered from scratch.
---

# CCD Platform — Data Provenance & Legacy Source Tracing Discipline

## The Problem This Skill Solves

Derived datasets in this platform (`ent_network_device_master`, `mgmt_ip_index`,
`all_IP_networks`) have repeatedly been built by bulk/administrative assignment —
one CIDR block, one location, standing in for what should have been many
individually-verified entries. Every real, confirmed location-mislabeling bug
found this session (Cumberland RI absorbing devices from across the country,
Scottsdale AZ doing the same, `mgmt_ip_index`'s own `10.2.100-102.x` range doing
it too) traces back to exactly this pattern. Separately, some datasets
(`mgmt_ip_index`) have no known build script at all — they were hand-assembled
once and never had a real, repeatable maintenance process.

This skill exists so the next time either problem shows up, the hard-won
principles and real bugs already found don't have to be rediscovered.

---

## Principle 1: There Is No Other Source of Truth Than the Device Itself

Direct operator instruction, 2026-08-07: *"The whole point of extracting the IPs
of the management interfaces is to validate the location, which has to come from
the devices. There is no other SOT."*

This is a hard, enforced rule for any tool that builds a location-resolution
dataset from raw sources:

- **Every entry must trace back to a real, specific device's own reported data**
  — its hostname (via the real, curated `HOSTNAME_PREFIX_MAP`), or a per-device
  field like NetBrain's `Site`/`Location`. Never a bulk CIDR-block assignment,
  no matter how many devices would conveniently share one.
- **Output defaults to `/32`** (one row per device). A broader block is only
  ever emitted when every individual device within it was independently
  confirmed at the same real site — earned by evidence, never assumed for
  tidiness.
- **If no real per-device evidence resolves a device, exclude it — don't guess.**
  A dataset with fewer, trustworthy rows is more valuable than one with full
  coverage built on inference.

Real confirmation this principle works: `build_mgmt_ip_index.py`, built this
way, independently re-derived the exact same correct answer (`San Antonio TX`)
for a device (`SNA-DIS-M1A-02`) that a separate, earlier investigation had
already found mislabeled to Cumberland RI via a coarse `all_IP_networks` block
— two completely different mechanisms, same real answer. That kind of
independent corroboration is only possible when both paths trace to real,
individual evidence.

---

## Principle 2: Reuse Real Resolution Logic — Never Reimplement It

When building a new per-device tool (`build_mgmt_ip_index.py`,
`refresh_ndr_provenance.py`), import and call the already-tested functions from
`build_network_device_master.py` directly (`resolve_hostname_prefix()`,
`decode_netbrain_site()`) rather than reimplementing hostname/site decoding.
Two independently-written copies of the same logic will eventually diverge —
confirmed repeatedly this session (`lpm_lookup()` vs a hand-rolled duplicate,
`location_naming_variances.csv` vs `location_variance.py`'s own hardcoded dict).

```python
try:
    from build_network_device_master import resolve_hostname_prefix, decode_netbrain_site
except ImportError:
    print('FATAL: this script deliberately reuses real, already-tested logic...')
    sys.exit(2)
```

Fail loudly if the import fails — a silent fallback to reimplemented logic
defeats the whole point.

---

## Principle 3: Report Raw Fact, Never a Verdict

A device that stops appearing in current sources is not proof it's gone — real,
confirmed this session: 1,645 of 2,406 devices that "disappeared" from a
refreshed FTC report were still alive and tracked in NDM the whole time. Every
real source in this platform is a periodic, stale-by-definition snapshot; three
stale sources agreeing a device is gone still only means three snapshots
happen to align, not that anything is true *right now*.

Design consequence: don't compute a confidence-weighted `REMOVED` verdict.
Report the raw fact and let a human judge it:

- `LAST_SEEN_DATE` / `LAST_SEEN_SOURCE` / `LAST_SEEN_VERSION` — the most
  recent date, across every source ever ingested, that this device was
  actually present in something. No inference, no threshold.
- `STATUS` vocabulary: `ACTIVE | ADDED | OUT-OF-SERVICE | MOVED | CHANGED`
  (RMAC — Remove/Add/Move/Change). `OUT-OF-SERVICE` is deliberately not
  called `REMOVED` — it states an observable fact (not currently seen
  anywhere), not a claim about what happened.
- A dropped hostname's row is **retained, never deleted** — carried forward
  with its real last-known state. This is what makes future "was this
  device replaced, or did it move?" questions answerable at all; deleting
  the row destroys the only evidence.

---

## Principle 4: Auto-Discovery Must Prefer Real Version Over mtime

Confirmed, repeated real bug this session (`locate_ndm_sources.py` v1.1.0
through v1.4.0): file modification time reflects when a file was last
touched/copied, not its real content date. A stale snapshot copied recently
will beat a genuinely current file if selection uses mtime.

```python
def _key(path):
    m = re.search(r'[-_]v(\d{8})(?:r(\d+))?\.csv$', os.path.basename(path))
    if m:
        return (1, int(m.group(1)), int(m.group(2)) if m.group(2) else 0)
    return (0, 0, os.path.getmtime(path))  # mtime ONLY as last resort
```

Real, confirmed extension of this bug: the regex must accept **both**
`_v20260804` (underscore, `ent_network_device_master`-style) **and**
`-v20260804` (hyphen, `ent-ipdataset-*`-style) — confirmed this session that
using only one convention silently made an entire dataset family fall back to
pure mtime, invisibly, with no error.

For files with genuinely no embedded date at all (`fw-inv-3-26.csv`,
`Cisco_FMCs.csv`) — don't guess via mtime either. Require an explicit
`--<source>-date YYYYMMDD` override and report `UNKNOWN` if none is given,
rather than silently trusting mtime.

---

## Principle 5: A Free-Text Location Field Is a Real, Underused Corroboration Signal

Raw NMS exports often carry two separate location-shaped fields — e.g.
NetBrain's `Site` (an administrator-configured hierarchical path) and
`Location` (free text, sometimes SNMP-sourced, sometimes manually entered).
Confirmed this session: `load_netbrain()` only ever read `Site`; `Location`
was captured nowhere, used nowhere, despite sometimes containing more
specific or more accurate data (a real device's `Site` said `LINTHICUM, MD`;
its own `Location` correctly said `"Middletown Rack N64"`).

When building or fixing a per-device resolution tool, check whether a
free-text corroboration field is being silently discarded. If a resolved
location and a free-text field disagree, that's real signal — but building
the contradiction check correctly is genuinely hard. Real, confirmed
false-positive classes to guard against, all found by testing against real
data, not assumed in advance:

- **Absence isn't contradiction.** A generic sub-location string ("Network
  Closet 1", "1CVS Data Center - POD2-2") that doesn't mention any city at
  all is uninformative, not evidence of a conflict. Only flag a
  contradiction when the free-text field contains its *own* recognizable,
  different `City, ST`-shaped place — never merely "the expected city's
  name is absent."
- **Hyphens can be inside a city name.** `San-Diego`, `Wilkes-Barre`,
  `Mendota-Heights` are real, correctly-formatted city names — a regex that
  treats every hyphen as a field separator will silently fail to match
  them.
- **Word concatenation isn't matched by punctuation normalization alone.**
  `"Blue Bell"` vs `"Bluebell"`, `"West Hollywood"` vs `"WestHollyWood"` —
  a hyphen/whitespace-only normalizer (the platform's own
  `normalize_loc_name()`) won't catch these. Accept this as a known, safe
  gap (falls through to "no clear signal," never to false trust) rather
  than building a more aggressive matcher that risks false positives
  instead.
- **`"DC"` is ambiguous in this platform's own convention.** It usually
  means "Data Center" (`Shea DC`, `Aetna MDC`), not Washington D.C. —
  exclude it from state-code matching.
- **Common English words coincidentally match real state/province codes** —
  `"HOSTED ON..."` parses as city=`HOSTED`, state=`ON` (Ontario) under a
  naive regex. Maintain a small, bounded exclusion list for confirmed real
  cases (`ON, IN, OR, OK, OF, TO, AT, BY, AS, IS, IT, SO`) rather than
  chasing a complete dictionary — the failure mode (exclusion) is already
  safe.

---

## Principle 6: Filters Meant to Be Narrow Can Still Be Broad in Practice — Quantify First

A condition combining two signals ("coarse block AND non-Authoritative")
can look safely narrow just from how it reads. Confirmed this session: such
a filter, built to catch 3 known-bad cases, matched **37.2% of the entire
real `all_IP_networks` dataset** (9,467 of 25,464 rows) once checked
directly — `Inferred` data quality turned out to be the *majority* real
state, not a rare red flag. Deployed as a hard gate, it inflated a real
review queue from 4 to 85 records in one live run, almost entirely false
positives.

**Before trusting a filter meant to be narrow, count how many real rows it
actually matches against the full dataset** — not just the handful of
confirmed cases that motivated building it.

When a heuristic proves too broad, prefer real, independent corroborating
data over refining the heuristic further on the same data that produced
the uncertainty in the first place. (See Principle 5 — the fix here was
switching to real FTC hint corroboration, not tuning the coarse/
non-Authoritative threshold.)

---

## Principle 7: Externalize the Source List — Adding a Source Should Be a Data Change

A hardcoded Python list of sources (`SOURCES = [...]`) means every new raw
source type requires a code edit and version bump. Confirmed this session
(`locate_ndm_sources.py` v1.5.0): externalizing as a real, versioned CSV
(`ndm_source_registry_v*.csv` — columns `FLAG, DESCRIPTION, GLOB_PATTERNS,
REQUIRED, SOURCE_CODE`) makes "add a new source" a data change instead.

Keep the old hardcoded list as a graceful **fallback only** — used if the
registry genuinely can't be found or read — never delete it outright; a
tool with zero sources configured is worse than one running on stale
defaults.

---

## Principle 8: A Legacy Dataset With No Build Script Is a Real, Nameable Gap

If a dataset (`mgmt_ip_index`) has real rows with real `SOURCE`/
`DATA_QUALITY` provenance but no script anywhere reproduces or extends it,
say so plainly rather than treating the dataset as unconditionally
authoritative forever. Confirmed this session: `mgmt_ip_index` itself had
two coarse, wholesale-attributed ranges (`10.2.100.0/24`,
`10.2.102.0/24`) with the exact same failure signature as the
`all_IP_networks` bug it was meant to fix — a "trusted" source can still
carry the same real defect if it was never built with Principle 1's
discipline in the first place.

When this gap is found: confirm directly with the operator that no build
tool exists (don't assume), then build one following Principles 1–7,
rather than continuing to patch symptoms in whatever consumes the
untraceable legacy file.

---

## Principle 9: A Decision-Application Handler Must Never Feed Automated Resolution

A human-curated override (`OVERRIDE`, `KEEP_OLD_LOCATION`, etc. in a `review_decisions.json`-style workflow) must be genuinely final — it cannot merely set the same field an automated resolution layer also reads as *input*, or that layer will silently re-process and potentially overwrite the human decision. Confirmed real, live bug this session: an `OVERRIDE` handler set both `CANONICAL_LOCATION` (the real output field) and `_nms_location` (an internal field a resolution layer also reads as its own starting point) — meaning any device whose hostname happened to coincidentally match something elsewhere in the resolution chain had its curated decision silently discarded. Real, measured impact: only 6 of 42 real `OVERRIDE` decisions survived to the final output on the run that exposed this.

The fix has two parts, and both matter: (1) a decision handler should only ever set the real, final output field, never an internal field an earlier-stage resolver also consumes; (2) add an explicit flag (`_decision_override` or equivalent) that later stages check *first* and short-circuit on, so the protection holds even for future devices whose other internal fields happen to be populated for unrelated reasons. Relying on "this internal field happens to be empty for today's specific devices" is fragile — a device that has real underlying data in that field will still hit the original bug.

---

## Principle 10: A Coarse-Block Distrust Threshold Needs Its Boundary Tested, Not Just Its Existence

Building a filter that distrusts "coarse and unverified" data is not the same as getting its boundary right. Confirmed real, live case: a coarse+non-Authoritative backstop was built and correctly caught every `/24`-or-broader bad block — but a `/25` block with the identical real failure signature (one hub wholesale-claiming a range genuinely used by devices at Chicago, Phoenix, and East Windsor) slid through untouched, because the threshold was written as `<= 24`, and a `/25` is narrower than `/24`.

Before extending a threshold like this, quantify the real, additional scope first (same discipline as Principle 6) — don't just widen it on faith. Real, confirmed check this session: extending from `/24` to `/25` added 1,094 additional real rows to the backstop's coverage, a reasonable, bounded increase — not extended further, since `/26` and narrower more often represent legitimate small single-site subnets or genuine point-to-point links, not administrative multi-device pools.

---

## Principle 11: A Statistical Anomaly Check's Assumptions May Not Generalize Across Device Categories

A heuristic built around one real assumption (e.g., "device count at a location should scale with employee headcount") can be entirely correct for the device category it was built against, and produce a confident, wrong result for a different one. Confirmed real, live case: a subnet-diversity-per-employee check correctly flagged a genuine problem for endpoint devices, then also flagged 55 devices at a real, legitimate Aetna network-management hub as anomalous — because those 55 were 53 load balancers (`DEVICE_CLASS=LOAD_BALANCER`) and 2 WAN routers, whose `CONNECTED_SUBNETS` field reflects what they *route or serve* across the whole enterprise, not physical density at their own site. Confirmed via the raw IPs themselves: the 55 devices spanned 9 completely different `/16` ranges — the real signature of a centrally-managed appliance farm, not a single overcrowded office.

Before trusting an anomaly flag, check what the flagged rows actually *are* (`DEVICE_CLASS`, `INFRA_ROLE`), not just whether the flag fired. The fix here excluded the specific device categories whose core metric means something structurally different, rather than adding a location-specific exception — the same false positive would otherwise recur at any other real site with the same device mix.

---

## Principle 12: A Legacy System's Own Field Can Become a Systematic Fix, Once Cross-Referenced Correctly

A prior, superseded system can carry real, already-computed answers to a current problem, even if the system itself is retired. Confirmed real, decisive case this session: a legacy, pre-purge dataset (predating the platform's current architecture) had its own `MULTI_SITE` field with real, confirmed site counts for 197 address ranges — found by direct inspection, not assumed. Cross-referencing this against the current, live coarse-block problem immediately confirmed every incident-by-incident case already found by hand that day, plus new ones never investigated (including a single `/24` independently confirmed to span 60 real, distinct sites).

The real, structural value here: replacing a hand-curated, 3-entry exception list (found one incident at a time) with a 198-entry, externally-loaded, evidence-backed registry turns "keep discovering these one at a time forever" into "load what a prior system already knew, plus what's found from here." When investigating a systemic data-quality problem, check whether an older or parallel system already computed the answer before re-deriving it from scratch.

---

## Principle 13: A Narrow (`/29`-`/31`) Entry Always Needs a Real, Broader Covering Parent

An IPAM registry's own remove-safety validation may require any sufficiently narrow entry (a real point-to-point link, `/29`-`/31`) to have a genuine `/28`-or-broader parent registered elsewhere, regardless of whether that narrow entry has its own `SITE_CODE` or looks self-sufficient. Confirmed real, live case: attempting to remove 146 confirmed-wrong coarse `/24` blocks failed validation for 78 of them, because 1,304 real, narrower child entries (mostly genuine WAN circuit `/30`s) depended on those same coarse blocks as their only registered covering parent — removing the parent would have left real, valid child entries with no LPM coverage at all.

This means a coarse block cannot always simply be corrected or removed in isolation — check what narrower, real entries depend on it for LPM coverage first. Real, additional finding from the same investigation: those dependent `/30`s were also independently mis-typed (`NET_TYPE=DataCenter`/`Corporate`, inherited from the wrong coarse parent, rather than the platform's own established `WAN-P2P` convention) — a second, genuine correction discovered only by tracing why the first one was blocked.

---

## Checklist Before Delivering Any Provenance/Legacy-Tracing Tool

- [ ] Every output row traces to a real, individual device record — no bulk
      CIDR/administrative assignment anywhere
- [ ] Resolution logic imported from `build_network_device_master.py`, not
      reimplemented
- [ ] `STATUS`/`LAST_SEEN_*` report observable fact, not an inferred verdict
- [ ] Dropped/missing records are retained, not deleted
- [ ] File auto-discovery prefers real embedded version over mtime, handles
      both `_v` and `-v` conventions, and requires an explicit override
      (never a silent mtime guess) for genuinely undated files
- [ ] Any free-text corroboration field is tested against real data for the
      known false-positive classes in Principle 5 before trusting its output
- [ ] Any coarse/heuristic filter is quantified against the *full* real
      dataset, not just the motivating cases, before being deployed as a gate
- [ ] Source list is externalized (or explicitly justified as not needed)
- [ ] Tested against real, uploaded data — not just synthetic examples —
      before delivery
- [ ] Any decision-application/override handler sets only the real, final
      output field — never an internal field a resolution layer also reads
      as input (Principle 9)
- [ ] Any coarse-block threshold's exact boundary (not just its existence)
      is tested against real data, and its real, additional scope is
      quantified before widening it (Principle 10)
- [ ] Any anomaly/statistical check's flagged rows are inspected for
      `DEVICE_CLASS`/`INFRA_ROLE` before trusting the flag, not just whether
      it fired (Principle 11)
- [ ] Checked whether a legacy or parallel system already computed the
      answer to a systemic data-quality problem before re-deriving it by
      hand (Principle 12)
- [ ] Before removing any coarse block, checked whether real, narrower
      (`/29`-`/31`) entries depend on it as their only covering parent
      (Principle 13)
