# CCD Platform — Data Governance Rules
## Location Master, IPAM, SITE_CODE, and NET_TYPE

**Version:** 1.0  
**Date:** 2026-05-10  
**Status:** Canonical — all scripts must conform to these rules

---

## The Three Questions

Every subnet in the estate is fully described by three independent questions:

| Question | Field | Owner |
|---|---|---|
| **WHERE** is this network? | `SITE_CODE` | Location Master |
| **WHOSE** network space is it? | `ROUTING_DOMAIN` + `HERITAGE` | IPAM |
| **WHAT** is on this subnet? | `NET_TYPE` | IPAM |

These three dimensions are orthogonal. None implies the other.

---

## Location Master (LM) — Rules and Responsibilities

### What the LM IS
The LM is a **normalisation engine**. It takes every form a location reference 
arrives in across all data sources and normalises it to a single canonical SITE_CODE.

### What the LM contains
Physical location data only:

| Field | Description | Rule |
|---|---|---|
| `SITE_CODE` | Structured machine identifier | Primary key. Format: `[ITU_CC]_[IATA]_[ST]_[SITE_TYPE]` |
| `CANONICAL_NAME` | Human-readable identifier | Derived from defining attributes. Never arbitrary text. |
| `LOCATION_TYPE` | Site type code | Must be from site_code_taxonomy.csv (17 valid types) |
| `CITY` | Geographic city | Defining attribute |
| `STATE` | State / province / region | Defining attribute |
| `COUNTRY` | ITU country code | From itu_country_codes.csv |
| `ADDRESS` | Physical street address | Optional — physical location only |
| `HERITAGE` | Corporate lineage | CVS / AETNA / OSH / OMNICARE / CAREMARK / SWITCH / PARTNER |
| `STATUS` | Lifecycle state | Active / Retired / Pending / Placeholder |
| `HOSTNAME_PREFIX` | Hostname translation anchor | Derived from SITE_CODE — lowercase, underscores→hyphens |
| `LATITUDE` / `LONGITUDE` | Geographic coordinates | For mapping |
| `FACILITY_OWNER` | Who owns the building | CVS, AETNA, Switch, Iron Mountain, Equinix, etc. |
| `DATASET_VERSION` | Data governance version stamp | Auto-stamped on import |
| `NOTE` | Free text | Clarifications only |

### What the LM does NOT contain
| Field | Reason | Correct Location |
|---|---|---|
| `NET_TYPE` | Network use context — per subnet not per location | IPAM |
| `ROUTING_DOMAIN` | Network routing domain — per subnet not per location | IPAM |
| `ENVIRONMENT` | Prod / NonProd — operational classification | IPAM |
| Tenant qualifiers | CVS/Aetna/PCI — heritage distinction | IPAM HERITAGE + ROUTING_DOMAIN |
| Application names | SecureHub / RxConnect — app layer | app_subnet_index |
| VPC / network names | Cloud VPC identifiers | IPAM |
| `BASE_IP` | Legacy — removed | N/A |
| `REGION` | Legacy — removed | N/A |
| `CSNA_SITE_NAME` | CSNA output field — removed | csna_site_registry (Tier 2) |
| `NMS_PATH_FRAGMENT` | NMS-specific — removed | Tier 2 derived dataset |

### LM Rules — Non-Negotiable

**Rule LM-1: The LM is the sole creator of SITE_CODEs.**  
No pipeline script, no data source, no automated process creates a SITE_CODE.  
The LM assigns SITE_CODEs. Everything else references them.

**Rule LM-2: No location enters the LM without HR validation.**  
Every non-infrastructure location must have HR confirmation (>= 10 employees  
of the expected BU type) OR confirmed IPAM data. Zero HR + zero IPAM = phantom.  
Exception: infrastructure types (DC/CI/CP/IX/NH/DR/IS/SS) — validated by  
FACILITY_OWNER and network evidence instead.

**Rule LM-3: Cloud LM entries are Provider + Region only.**  
`US_GCP_USE4_IS` — not `US_GCP_USE4_CVS_IS` or `US_GCP_USE4_PCI_IS`.  
Tenant, VPC, environment, application — none of these are location qualifiers.

**Rule LM-4: One SITE_CODE per physical function.**  
Same building, different functions = different SITE_CODEs.  
Same building, same function = one SITE_CODE (merge duplicates).  
`US_BGV_IL_CO` and `US_BGV_IL_CC` can coexist — different functions.  
`US_ATL_GA_CI` and `US_ATL_GA_CI` cannot coexist — remove the duplicate.

**Rule LM-5: The CANONICAL_NAME is derived, never assigned.**  
Format: `{CITY} {STATE} - {LOCATION_TYPE_LABEL}`  
The pipeline cannot create an arbitrary CANONICAL_NAME string.

**Rule LM-6: SITE_CODE format is validated against registries.**  
IATA/city code must exist in city_code_registry.csv.  
SITE_TYPE code must exist in site_code_taxonomy.csv.  
Invalid SITE_CODE = hard reject by ccd_schema.py.

---

## SITE_CODE — Rules and Responsibilities

### Format
```
[ITU_CC]_[IATA]_[ST]_[SITE_TYPE]
   US   _ WOO  _ RI _    CO
   US   _ GCP  _USE4_    IS
   PH   _ MNL  _ MM _    TP
```

### SITE_CODE Rules

**Rule SC-1: SITE_CODE flows outward FROM the LM.**  
LM creates → IPAM references → consumers derive from.  
Nothing writes SITE_CODEs back to the LM.

**Rule SC-2: Every IPAM subnet must reference a valid SITE_CODE.**  
Cross-check CX1 validates this on every import. Hard stop on violation.

**Rule SC-3: HOSTNAME_PREFIX is derived from SITE_CODE.**  
`US_BGV_IL_CO` → `us-bgv-il-co`  
No separate hostname prefix management required.

**Rule SC-4: Retail stores use 5-digit store number.**  
`05275` not `US_BGV_IL_RT`. The store number IS the SITE_CODE for retail.

**Rule SC-5: Multiple SITE_CODEs for multi-use locations.**  
One physical address can have CO + CC + MO SITE_CODEs.  
Each represents a distinct network function at that location.

---

## IPAM (all_IP_networks) — Rules and Responsibilities

### What IPAM contains
Network subnet data — one row per CIDR:

| Field | Description | Valid Values |
|---|---|---|
| `CIDR` | Subnet in CIDR notation | Valid IPv4/IPv6 CIDR |
| `SITE_CODE` | Location FK → LM.SITE_CODE | Must exist in LM |
| `ROUTING_DOMAIN` | Whose network space | 21 values from routing_domain_registry.csv |
| `NET_TYPE` | Use context of this subnet | 57 values from net_type_registry.csv |
| `HERITAGE` | Which entity owns the subnet | CVS / AETNA / OSH / OMNICARE / PARTNER |
| `ENVIRONMENT` | Operational classification | Prod / NonProd / DR / Test / Unknown |
| `DATA_QUALITY` | Confidence level | Confirmed / Inferred / Observed / Placeholder |
| `LOC_MASTER_VERSION` | LM version used for classification | Auto-stamped |
| `DATASET_VERSION` | IPAM dataset version | Auto-stamped |

### IPAM Rules — Non-Negotiable

**Rule IPAM-1: SITE_CODE replaces CANONICAL_LOCATION.**  
The string `Monroeville PA - Specialty` is replaced by `US_MNR_PA_SP`.  
Human-readable names are joined from the LM at query time — never stored in IPAM.

**Rule IPAM-2: ROUTING_DOMAIN is a per-subnet field.**  
A location (`US_MNR_PA_SP`) has many subnets with different routing domains.  
ROUTING_DOMAIN describes the network space of each individual subnet.

**Rule IPAM-3: NET_TYPE is a per-subnet field.**  
The same SITE_CODE will have User-Wired, Application, WAN-P2P, Management subnets.  
NET_TYPE classifies each subnet's use context independently.

**Rule IPAM-4: Prod/NonProd belongs in ENVIRONMENT.**  
AWS does not sell stable and unstable infrastructure.  
Production vs non-production is an operational classification → ENVIRONMENT field.  
It is never a location qualifier and never part of a SITE_CODE.

**Rule IPAM-5: Tenant/VPC/application is NOT in SITE_CODE or CANONICAL_NAME.**  
SecureHub → NET_TYPE = Infrastructure  
RxConnect → app_subnet_index.APP_ACRONYMS  
PCI scope → compliance metadata, not location  
CVS vs Aetna → HERITAGE + ROUTING_DOMAIN

---

## NET_TYPE — Rules and Responsibilities

### What NET_TYPE IS
NET_TYPE answers: **"What devices and traffic are on this specific subnet?"**  
It is the use context of a single subnet row in IPAM.

### What NET_TYPE is NOT
- Not a location attribute (not in LM)
- Not a business function (that is SITE_TYPE)
- Not a heritage indicator (that is HERITAGE + ROUTING_DOMAIN)
- Not an application name (that is app_subnet_index)
- Not an environment (that is ENVIRONMENT)

### NET_TYPE Tiers
| Tier | Description | Examples |
|---|---|---|
| 0 | Nothing known | Unknown |
| 1 | Heritage known only | CVS-Unclassified / AETNA-Unclassified |
| 2 | Heritage + broad category | CVS-User / CVS-Server / CVS-Network |
| 3 | Confirmed specific | User-Wired / Application / IOT-Camera / WAN-P2P |

All subnets start at Tier 0-2. Discovery data promotes to Tier 3.

### NET_TYPE Rules

**Rule NT-1: NET_TYPE lives in IPAM only.**  
Removed from LM. The previous LM NET_TYPE (CSNA zone override) is replaced  
by deriving CSNA zone from SITE_CODE LOCATION_TYPE component.

**Rule NT-2: NET_TYPE uses controlled vocabulary.**  
Only values from net_type_registry.csv are valid.  
ccd_schema.py rejects any other value at write time.

**Rule NT-3: Start with placeholder — promote with evidence.**  
Unknown heritage → Unknown  
ROUTING_DOMAIN known → CVS-Unclassified or AETNA-Unclassified  
Host data available → promote to Tier 2 or 3  
Never guess — use the correct placeholder tier.

---

## The Tier Architecture

```
TIER 1 — MASTER DATASETS (pure, governed by ccd_schema.py)
  location_master      → SITE_CODE, physical location data only
  all_IP_networks      → SITE_CODE(FK), ROUTING_DOMAIN, NET_TYPE, ENVIRONMENT
  ent_host_master      → host inventory
  ent_network_device_master → network device inventory
  app_subnet_index     → application mapping
  retail_networks      → retail store subnets
  delivery_*           → delivery data

TIER 2 — DERIVED DATASETS (built from master, purpose-specific)
  csna_site_registry   → built from LM + IPAM for CSNA
  fw_rule_context      → built from LM + IPAM + NDM for FW work

TIER 3 — DELIVERABLES
  CSNA_Import_*.xml    → Stealthwatch / Cisco CSNA
  FW_Rule_Report.html  → firewall analysis
  New FW rules         → policy changes

CONSUMERS
  iplookup.sh          → reads Tier 1 directly (query only)
  generate_csna_*      → reads Tier 1 → builds Tier 2 → produces Tier 3
  generate_fw_*        → reads Tier 1 → builds Tier 2 → produces Tier 3
```

---

## What This Fixes

Every corruption event in the LM history was caused by violating one of these rules:

| Corruption | Rule violated |
|---|---|
| WSL/WSM/ABE retail artifacts | LM-1: pipeline created SITE_CODEs from hostnames |
| Cloud tenant qualifiers (GCP-CVS, GCP-PCI) | LM-3: tenant qualifiers in location names |
| NET_TYPE in LM | LM boundary: IPAM field placed in LM |
| CANONICAL_LOCATION string drift | SC-1/2: string FK instead of structured SITE_CODE |
| Prod/NonProd as location names | IPAM-4: operational classification as location qualifier |
| SecureHub/RxConnect as locations | IPAM-5: application/architecture as location qualifier |
| Duplicate Corporate entries | LM-4: same function, same location — should be one entry |
| Work At Home in LM | LM-2: no HR confirmation, no IPAM data — phantom |

