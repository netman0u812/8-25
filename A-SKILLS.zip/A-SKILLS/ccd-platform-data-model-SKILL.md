---
name: ccd-platform-data-model
description: >
  CCD Platform (Cyber & Compliance Data) — CVS Health Information Security.
  Use this skill for any task involving the CCD Platform datasets, IPAM operations,
  iplookup.sh queries, pipeline stages, overlap management, firewall rule translation,
  or CSNA host group generation. Covers dataset schemas, architectural rules, update
  order, cross-check constraints, and the dual-dataset overlap model. Trigger on:
  "IPAM", "iplookup", "all_IP_networks", "retail_networks", "location_master",
  "ent_host_master", "CSNA", "ROUTING_DOMAIN", "CANONICAL_LOCATION", "CX cross-check",
  "dual-allocation", "Internal-HCB", "Internal-PBM", "Internal-Retail",
  "pa_rule_translator", "intent rules", "app_subnet_index", "CCD pipeline".
---

# CCD Platform — Data Model Reference

## 1. Platform Overview

The CCD (Cyber and Compliance Data) Platform is a Python/Bash toolset for enterprise IPAM
management, network security visibility, CSNA Stealthwatch host group generation, and
firewall rule enrichment at CVS Health.

**Core problem:** CVS and Aetna were never merged at the network layer after the 2018
acquisition. Both use RFC1918 10.x, 172.16.0.0/12, and CGNAT 100.64.x space in completely
separate routing planes. The platform manages this overlap through strict dataset separation
and the ROUTING_DOMAIN field as the primary discriminator.

---

## 2. Dataset Catalog

### 2.1 location_master (LM)
**Current version:** v5.9g  **Rows:** 11,526  **Key:** SITE_CODE / CANONICAL_NAME

The root of the entire model. Every physical and logical site. Nothing enters any downstream
dataset without a CANONICAL_LOCATION that resolves to an active LM entry.

| Column | Purpose |
|--------|---------|
| SITE_CODE | Primary key — format US_[CITY]_[STATE]_[TYPE] e.g. US_SCO_AZ_DC |
| CANONICAL_NAME | Human-readable location name e.g. "Scottsdale AZ - Shea DC" |
| LOCATION_TYPE | Retail / DataCenter / Corporate / MinuteClinic / CarePlus / COLO / etc. |
| HERITAGE | CVS / AETNA / OMNICARE / OSH / SWITCH / PARTNER |
| STATUS | Active / Retired / Decom-Candidate |
| NET_TYPE | Operational function classification (see §6) |
| HOSTNAME_PREFIX | Hostname prefix used for T5 location derivation |

**Hard gate:** `CANONICAL_LOCATION` must exist in LM before ANY subnet or host row is committed.

### 2.2 all_IP_networks (IPAM)
**Current version:** v3.80  **Rows:** 20,957  **Key:** CIDR

Enterprise IPAM — all non-retail subnets. Single source of truth for subnet→location mapping
for DC, corporate, COLO, cloud, and Internet-Facing space.

| Column | Critical values |
|--------|----------------|
| CIDR | Network in CIDR notation (normalized, strict=False) |
| CANONICAL_LOCATION | Must match LM CANONICAL_NAME exactly |
| SITE_CODE | Must match LM SITE_CODE |
| ROUTING_DOMAIN | **Primary discriminator** — see §3 |
| HERITAGE | CVS / AETNA / SWITCH / OMNICARE / PARTNER |
| NET_TYPE | DataCenter / Corporate / DMZ / ISP-Link / Cloud-Azure / Internet-Facing / etc. |
| DATA_QUALITY | Authoritative / Inferred / Manual (never blank) |
| STATUS | Active / Reserved / Decom |

**Rules:**
- Retail /26 subnets NEVER appear here — they live in retail_networks only
- Every row requires DATA_QUALITY to be populated (blank = CX violation)
- BGP-announced public prefixes (206.213.x, 157.121 DMZ, 167.69 PCI/SIP) = Internet-Facing

### 2.3 retail_networks
**Current version:** v2.8  **Rows:** 294,341  **Key:** CIDR

Per-store /26 subnet allocations. Exists as a separate dataset specifically because CVS retail
stores use 172.16.0.0/12 — the same space Aetna uses for DC infrastructure. This separation
is architectural, not optional.

| Column | Notes |
|--------|-------|
| CIDR | /26 per-store function, /24 parent summary rows, /32 device rows |
| STORE_NUMBER | CVS store number (may use old format e.g. 01234 or new US_ST_01234_RT) |
| FACILITY_TYPE | Retail-Store / MinuteClinic / Optical |
| NET_TYPE | Retail-Store / Retail-MinuteClinic / Retail-Optical |
| INFRA_ROLE | Device role for /32 host entries |
| SITE_CODE | US_[STATE]_[STORE_NUM]_[TYPE] format |
| ROUTING_DOMAIN | Always Internal-Retail |

### 2.4 placeholder_networks
**Current version:** v20260511  **Rows:** 91

Synthetic /32 or summary entries for active LM locations that have no real IPAM entry. Ensures
CX6 (LM-ORPHAN) never fires for valid locations that simply have no subnets yet.
Rebuilt from location_master whenever LM advances. Must be rebuilt when LM version advances
(current gap: built against v5.9c, LM is at v5.9g).

### 2.5 ent_host_master (EHM)
**Current version:** v20260427r16  **Rows:** 69,218  **Key:** IP_ADDRESS

All enterprise application and server hosts. The host-level enrichment layer above IPAM.

Key columns: IP_ADDRESS, SERVER_NAME, FQDN, APPLICATION, APM_IDS, APP_ACRONYMS,
HERITAGE, ROUTING_DOMAIN, CANONICAL_LOCATION, PCI_DESIGNATION, RISK_TIER,
ARA_PHI, ARA_PII, SOX_CRITICAL, IN_QUALYS, IN_WIZ, IN_SNOW, CSNA_HOSTGROUP_PATH,
NORM_METHOD, LOCATION_CONFIDENCE.

### 2.6 ent_network_device_master (NDM)
**Current version:** v20260504  **Rows:** 10,849  **Key:** MANAGEMENT_IP

Network devices — firewalls, routers, switches, load balancers, wireless controllers, SBCs.
DEVICE_TYPE values: fw-pa / fw-cisco / fw-checkpoint / l3switch / router / lb / sbc / wireless-ctl.

### 2.7 delivery_infrastructure
**Current version:** v20260504r4  **Rows:** 5,755  **Key:** IP_ADDRESS

ESXi hosts, HMC, iSeries, DataPower, Isilon nodes.
PLATFORM_TYPE: ESX-HOST (5,084) / CONTAINER-BRIDGE (68) / SHARED-PLATFORM (44).

### 2.8 delivery_platform
**Current version:** v20260504r2  **Rows:** 1,870  **Key:** IP_ADDRESS

Kubernetes clusters, OpenShift, Docker, RHCOS nodes.
PLATFORM_TYPE: KUBERNETES (1,105).

### 2.9 app_subnet_index
**Current version:** v20260509r2  **Rows:** 2,608  **Key:** CIDR_24

Application coverage aggregated to /24 level. Links subnets to APM IDs, app acronyms,
PCI scope, risk tier, and primary site.

Key columns: CIDR_24, IPAM_APP_ID, APP_ACRONYMS, APM_IDS, PCI_DESIGNATION, RISK_TIER,
HERITAGE, PRIMARY_SITE, APP_COUNT, PROD_APP_COUNT.

### 2.10 csna_site_registry
**Current version:** v2.27  **Rows:** 379

CSNA Stealthwatch site registry. Maps CANONICAL_LOCATION to CSNA zone hierarchy for host
group generation. Built by build_csna_site_registry.py from location_master + all_IP_networks.

---

## 2.x New Datasets (added 2026-08-21/22)

### ip_classification_ref
**Current version:** v20260822  **Rows:** 2,039  **Key:** CIDR
**Built by:** `build_ip_classification_ref.py` v1.9.1 (default `--ipam-dir ./ipam-db`, no flags needed)

Per-CIDR evidence-based classification for all non-RFC1918/CGNAT space.
`FINAL_CLASSIFICATION`: PUBLIC / PRIVATE / PROVIDER_NETWORK / BOGUS_IPAM_ENTRY

**Evidence priority (strongest first):**
1. EGRESS-FW-TOPOLOGY HIGH+TC (3,069 per-CIDR traffic-confirmed entries)
2. F5-VIP-REGISTRY EXTERNAL tier
3. FW-SNAT-POOLS external-DMZ NAT
4. fw_rule_db ip_context external-DMZ IPs
5. NDM DMZ/Perimeter/B2B zone connected-subnets  
   NOTE: WAN_EDGE **deliberately excluded** — SD-WAN routers have 11.0.0.0/8 (CVS private
   SD-WAN space) in CONNECTED_SUBNETS, causing false PUBLIC classifications before v1.6.0.
6. DNS corroboration (Internet-Facing ROUTING_DOMAIN + public-looking app DNS)

**PRIVATE-forcing signals** (only apply when NO positive evidence found):
- fw_location_topology INTERNAL_CIDRS
- mgmt_ip_index management-plane IPs

**Evidence priority bug fixed v1.7.0:** INTERNAL_CIDRS was overriding confirmed positive
FW-SNAT evidence. Real fix: collect all positive PUBLIC evidence FIRST; PRIVATE-forcing
signals only apply when none found. Confirmed real false negative before fix:
12.226.56.0/24 had real FW-SNAT external-DMZ NAT but was forced PRIVATE by INTERNAL_CIDRS.

**Downstream consumers:** Every tool that needs public vs private distinction now checks
ip_classification_ref FIRST, falls back to RFC1918 heuristic only when no evidence exists:
build_fw_location_topology.py, build_fw_snat_pools.py, fwlookup.py,
build_p2p_policy_map.py, validate_ip.py, plugin_audit_patterns.py, preprocess_p1.py.

### ip_context_export (vbare — unversioned, rebuilt each fw_rule_db build)
**Rows:** ~179,823  **Key:** ip_value
Per-IP IPAM enrichment from real production FW rules. Auto-exported by
`build_fw_rule_db.py` v1.20.0 to `ipam-db/` after every real build.
Registered as MANAGED_STEMS entry (ipam-db.py v3.33.0).
Consumed by `build_ip_classification_ref.py` as optional Evidence tier 1b.

### public_ipv4_ipam / private_ipv4_ipam / partner_provider_ipv4_ipam
**Current version:** v20260822  Auto-rebuilt from `all_IP_networks × ip_classification_ref`
- `public_ipv4_ipam`: 344 rows (genuinely internet-routed CVS/Aetna space)
- `private_ipv4_ipam`: 1,561 rows (publicly-numbered, privately-routed)
- `partner_provider_ipv4_ipam`: 134 rows (GCP/Azure Cloud Interconnect + confirmed partners)

### EGRESS-FW-TOPOLOGY (ent-ipdataset)
**Current version:** v20260820  **Rows:** 371,821
Per-CIDR egress firewall mapping from `build_IP_Network_Egress_FW_topology.py`.
HIGH+TRAFFIC_CONFIRMED=Y rows (3,069) are the **strongest PUBLIC classification evidence**.
Supersedes the old `fw_location_topology` INTERNET_EGRESS_CIDRS pipe-delimited column.

### EGR_* Egress ROUTING_DOMAIN Codes
Added to `all_IP_networks` for subnets with confirmed egress firewall assignments.
Format: `EGR_{FIREWALL_LOGICAL}-{SUFFIX}` where suffix is TC (Traffic-Confirmed) or TI (Inferred).

**Current confirmed codes:**
- `EGR_MDC-TC` / `EGR_MDC-TI` — Middletown CT - Aetna MDC
- `EGR_WDC-TC` / `EGR_WDC-TI` — Windsor CT - Aetna WDC  
- `EGR_SHEAW-TC` / `EGR_SHEAW-TI` — Scottsdale AZ - Shea DC (West egress/Wireless)
- `EGR_SHEAE-TC` / `EGR_SHEAE-TI` — Scottsdale AZ - Shea DC (East ext)
- `EGR_RI1-TC` / `EGR_RI1-TI` — Woonsocket RI - RI One
- `EGR_LV-TC` / `EGR_LV-TI` — Las Vegas NV - Switch COLO

**CX11-INTERNET-FACING exemption:** EGR_*-TC and EGR_*-TI satisfy the cross-check.
ipam-db.py v3.32.0 added this exemption — do NOT revert rows to Internet-Facing.
6,525 rows propagated across 10 firewalls in 2026-08-21 session.

---

## 3. ROUTING_DOMAIN Values

ROUTING_DOMAIN is the PRIMARY overlap discriminator. Two IPs at the same address are
unambiguous if they carry different ROUTING_DOMAINs.

| Value | What it covers |
|-------|---------------|
| Internal-PBM | CVS/Caremark enterprise DC, campus, COLO (CVS heritage) |
| Internal-HCB | Aetna enterprise DC, campus, COLO (Aetna heritage) |
| Internal-Retail | CVS retail stores (172.16.0.0/12 /26 allocations) |
| COLO | Switch LV / Switch ATL / Switch TRE COLO (vendor-neutral) |
| Cloud-Azure | Azure VNet subnets |
| Cloud-GCP | GCP VPC subnets |
| Cloud-AWS | AWS VPC subnets |
| Cloud-Peering | Equinix cloud exchange (peering only, not primary DC) |
| Internet-Facing | BGP-announced public prefixes (AS6646: 206.213.x, 157.121 DMZ, 167.69 PCI) |
| Partner | Third-party B2B and ISP peering links |
| Offshore | Offshore development sites |

**Key constraint:** Public BGP-announced prefixes must be Internet-Facing, never Internal-HCB
or Internal-PBM. This was corrected in all_IP_networks v3.80 (133 rows reclassified).

---

## 4. Overlap Management Rules

### 4.1 The dual-dataset model (non-negotiable)

172.16.0.0/12 is governed by two authoritative datasets operating in parallel:
- `all_IP_networks` owns /24 and above in this space (Aetna DC infrastructure)
- `retail_networks` owns /26 per-store allocations (CVS retail stores)

The same physical /24 can appear in both with different ROUTING_DOMAINs. This is correct
and by design — they are completely separate routing planes.

### 4.2 LPM query order for 172.x (formal rule PR-01)

For any IP in 172.16.0.0/12:

| Query prefix length | Mode | Primary dataset | Secondary |
|--------------------|------|-----------------|-----------|
| /32 (host) | LPM | ent_host_master (if found), then retail_networks | all_IP_networks as context |
| /26 (store) | LPM | retail_networks | all_IP_networks as context |
| /24 or broader | CONTAINMENT | all_IP_networks (subnet owner) | retail_networks: ALL /26 store allocations within the block |

**This rule must be in code, not convention.** iplookup.sh v3.18 implements it correctly.

### 4.3 Retail /26 hard rules

- Retail /26 subnets NEVER appear in all_IP_networks — retail_networks only
- LPM on a /24 query must perform CONTAINMENT (find all /26s inside) not single-IP LPM
- CX5 (cross-domain containment) does NOT fire between all_IP_networks and retail_networks —
  they are intentionally separate datasets. CX12 (pending) will track these for audit.

### 4.4 Active conflicts (as of v3.80)

28 all_IP_networks /24 entries contain retail /26 children at a different routing domain.
11 are exact /24 dual-ownership conflicts (same CIDR in both datasets).
CX12 cross-check rule pending. T3-01 architecture decision required before resolution.

**T3-01 options:**
- Option A: CONTESTED_BLOCK=Y flag + LPM engine routing-domain-aware precedence
- Option B: Separate aetna_dmz_networks dataset (parallel to retail_networks)
- Option C: Verify Aetna DMZ ranges decommissioned (no action needed if confirmed)

---

## 5. Update Order (Non-Negotiable)

```
LM → IPAM → NDM → EHM → Infra → Platform → CSNA
```

Each layer depends on the integrity of the layer above. Required gates before advancing:
- `ipam-db.py --dry-run` before every import
- `ipam-db.py --cross-check` after every import — 0 HIGH violations required
- On HIGH violation: `ipam-db.py --restore` immediately

---

## 6. NET_TYPE Taxonomy

| Value | Description |
|-------|-------------|
| DataCenter | DC infrastructure (replaces legacy CVS-DC, AETNA-DC) |
| Corporate | Office / campus subnets |
| DMZ | Demilitarised zone segments |
| Internet-Facing | BGP-announced public space (new — all_IP_networks v3.80) |
| ISP-Link | ISP peering transport /30s and BGP peer IPs (new — v3.80) |
| Cloud-Azure / Cloud-GCP / Cloud-AWS | Cloud provider VNet/VPC space |
| Cloud-Peering | Exchange/Equinix peering |
| Retail-Store / Retail-MinuteClinic / Retail-Optical | Retail store types (retail_networks only) |
| Omnicare | Omnicare pharmacy operations |
| CarePlus | CarePlus HMO field sites |
| Mail-Order | Mail order pharmacy facilities |
| Distribution | Distribution centers |
| Specialty | Specialty pharmacy sites |
| P2P-WAN | Point-to-point WAN links |
| CGNAT | Carrier-grade NAT space (100.64.x.x) |
| Partner | Third-party / partner connectivity |
| NAAS-HUB | Network-as-a-Service provider hub (Five9 VoIP) |

Heritage (CVS vs Aetna) is in the HERITAGE column, NOT NET_TYPE.

---

## 7. CX Cross-Check Engine

All cross-checks run via `ipam-db.py --cross-check`. 0 HIGH required before any stage advances.

| Rule | Check | Severity |
|------|-------|----------|
| CX1 | Every IPAM CIDR has non-blank CANONICAL_LOCATION | HIGH |
| CX2 | CANONICAL_LOCATION resolves to an active LM entry | HIGH |
| CX3 | ROUTING_DOMAIN is a valid controlled vocabulary value | HIGH |
| CX4 | DATA_QUALITY is populated (Authoritative / Inferred / Manual) | HIGH |
| CX5 | No cross-domain subnet containment within all_IP_networks | HIGH |
| CX6 | Every active LM entry has an IPAM or placeholder_networks entry | HIGH |
| CX7 | SITE_CODE matches the LM entry for CANONICAL_LOCATION | MEDIUM |
| CX8 | HERITAGE consistent with ROUTING_DOMAIN | MEDIUM |
| CX9 | No duplicate CIDRs in all_IP_networks | HIGH |
| CX10 | No /32 host entries in all_IP_networks | MEDIUM |
| CX11 (pending) | 206.213/157.121/167.69 BGP-announced prefixes = Internet-Facing | HIGH |
| CX12 (pending) | all_IP_networks entries with retail_networks /26 children flagged | MEDIUM |

---

## 8. iplookup.sh Command Reference (v3.18)

### Core lookups

| Command | What it does |
|---------|-------------|
| `-l <IP>` | Five-tier LPM lookup: retail_networks → IPAM → host masters → app_subnet_index → ip_dataset |
| `-l <IP/24>` | Containment mode for 172.x: returns Aetna HCB /24 + ALL CVS retail /26 store allocations |
| `-store <NUM>` | Retail store lookup by store number |
| `-host <NAME\|IP>` | Search all host masters by FQDN, hostname, or IP |
| `--hostname <fqdn>` | Hostname translation → location |
| `-dom <domain>` | All subnets for a DNS domain |
| `-app <ID>` | Lookup by IPAM_APP_ID, APM ID, or app acronym |
| `-svc <name>` | CPC infrastructure service lookup |
| `-k <keyword>` | Free-text or structured field search (AND logic with multiple -k flags) |
| `-loc <name>` | Location-based subnet lookup |
| `-lt` | Tag / field value enumeration |
| `-td <CIDR>` | Subnet tree diagram |

### Inventory & filter commands

| Command | What it does |
|---------|-------------|
| `--nt <value>` | Filter all_IP_networks by NET_TYPE |
| `--nt-list` | NET_TYPE taxonomy with row counts |
| `--sc <code>` | Site code lookup |
| `--sc-subnets <code>` | All subnets for a site code |
| `--sc-list` | Full site code catalogue |
| `-app-list` | App subnet inventory |
| `-device-list-fw-pa` | Palo Alto firewall inventory |
| `-device-list-all` | All network devices |
| `-infra-list` | delivery_infrastructure inventory |
| `-platform-list` | delivery_platform inventory |
| `--pci` | All PCI-scoped blocks |
| `--loc <str>` | Location substring filter |
| `--heritage <str>` | Heritage filter |
| `--routing-domain <str>` | Routing domain filter |
| `--ds <stem>` | Browse registered cloud/provider dataset |

### Modifier flags

`--loc` / `--heritage` / `--routing-domain` / `--net-type` / `--csv` apply to all inventory commands.
`--platform-type` / `--os-group` / `--server-class` apply to `-infra-list` and `-platform-list`.

---

## 9. Five-Tier IP Resolution (IPAM + Host)

Used by `iplookup.sh -l` and `pa_rule_translator.py`:

| Tier | Source | Resolves |
|------|--------|---------|
| T1 | ent_host_master (IP_ADDRESS exact match) | APPLICATION, APM_IDS, ROUTING_DOMAIN, CSNA path |
| T2 | app_subnet_index (CIDR_24 match) | APP_ACRONYMS, APM_IDS, PCI_DESIGNATION, RISK_TIER |
| T3 | all_IP_networks (LPM) | ROUTING_DOMAIN, CANONICAL_LOCATION, HERITAGE, NET_TYPE |
| T4 | PA address object name signal | Application identity from naming conventions |
| T5 | cpc_infra_services.csv | CPC infrastructure service context (NTP, AD, DNS) |

---

## 10. Firewall Rule Translation Pipeline

**Script:** `pa_rule_translator.py v2.0.0`

Parses PA Panorama XML and CLI curly-brace configs → resolves endpoints via five-tier IPAM →
generates APP objects, SERVICE objects, intent rules, and provenance map.

**Supported formats:**
- Panorama XML (PAN-OS `<response><result><config>` wrapper)
- CLI curly-brace — Panorama device-group format (MID/WIN)
- CLI curly-brace — per-device vsys format (PAZ/RRI)

**Intent rule profile tiers:**

| Tier | Label | Condition |
|------|-------|-----------|
| 1 | Standard internal | Both endpoints internal, no PCI |
| 2 | Sensitive internal | PCI-scoped or High Risk endpoint |
| 3 | External standard | ROUTING_DOMAIN=Internet-Facing destination |
| 4 | External high inspection | Unknown external / CDN / cloud |
| 5 | Restricted privileged | AD, CyberArk, PAM, identity infrastructure |

**Consolidation patterns detected:**
- DC_FAN_IN: many-sources → same DC destination (create shared APP objects)
- DATAPOWER_FAN_OUT: few DataPower gateways → many backend targets
- MULTI_FILE_DUPLICATE: same rule duplicated across Panorama instances

**Run command:**
```bash
python3 pa_rule_translator.py \
  "3.18.2026_Running.config" \
  "PAZSHDC-SEC-PAN-PROD-01_20260514.config" \
  "MID-PAN-PROD-01_20260514.config" \
  --all-ip-networks all_IP_networks_v3.80.csv \
  --app-subnet-index app_subnet_index_v20260509r2.csv \
  --ent-host-master ent_host_master_v20260427r16.csv \
  --output-dir ./rule_translation/ \
  --action-filter allow
```

---

## 11. Pipeline Stages

| Stage | Script | Gate |
|-------|--------|------|
| 0 | `build_location_candidates.py` | Only for non-CMDB supplemental sources |
| 1 | `preprocess_p1.py` | Gate CLEAR required first |
| 2 | `update_*.py --enrich-only` | 0 HIGH cross-check after each |
| 3 | `preprocess_p2.py` | 0 HIGH cross-check |
| 4 | `update_*.py` (add new hosts/subnets) | Order: LM → IPAM → NDM → EHM → Infra → Platform |

---

## 12. Version Conventions

**Scripts:** MAJOR.MINOR.PATCH  
- Bug fix → PATCH (in __version__ and changelog only, not filename)
- Feature → MINOR
- Breaking change → MAJOR

**Datasets:** MAJOR.MINOR in filenames  
- Date-format: vYYYYMMDD or vYYYYMMDDrN for rebuilt versions

**Three stamps required on every dataset:**
1. Versioned filename (e.g. `all_IP_networks_v3.80.csv`)
2. `#VERSION=` header in file
3. `DATASET_VERSION` + `LOC_MASTER_VERSION` columns

**`vbare` is a hard stop** — never use the bare filename in production.

---

## 13. Known Open Items (as of 2026-05-19)

| # | Item | Blocks |
|---|------|--------|
| 1 | WSL/WSM retail site codes conflict with Aetna RBO hostnames | LM v5.10 |
| 2 | all_IP_networks v3.78 Observed→Inferred DATA_QUALITY patch | v3.79 applied |
| 3 | placeholder_networks built against LM 5.9c (current: 5.9g) | Rebuild needed |
| 4 | Qualys pipeline stale since EHM r13 (current: r16) | Refresh needed post-EHM rebuild |
| 5 | T3-01 RFC1918 HCB overlap architecture decision | 24 Aetna DMZ CIDRs blocked |
| 6 | CX11 Internet-Facing consistency rule | Pending implementation |
| 7 | CX12 Cross-dataset containment rule | Pending T3-01 decision |
| 8 | retail_networks 2,100 missing CANONICAL_LOCATION rows | Store master sync needed |
| 9 | 11 exact /24 dual-ownership conflicts | T3-01 required |

---

## 14. DC Topology Quick Reference

| Site | Code | Heritage | Routing Domain |
|------|------|----------|----------------|
| Scottsdale AZ - Shea DC | US_SCO_AZ_DC | CVS | Internal-PBM |
| Woonsocket RI - RI One | US_WOR_RI_CO1 | CVS | Internal-PBM |
| Cumberland RI - 2100 Highland | US_CUM_RI_CO4 | CVS | Internal-PBM |
| Middletown CT - Aetna MDC | US_MID_CT_IS | AETNA | Internal-HCB |
| Windsor CT - Aetna WDC | US_WIN_CT_IS | AETNA | Internal-HCB |
| Hartford CT - Aetna HQ | US_HFD_CT_IS | AETNA | Internal-HCB |
| Phoenix AZ - Aetna DC | US_PHX_AZ_IS | AETNA | Internal-HCB |
| Las Vegas NV - Switch Colo | US_LAS_NV_CI | SWITCH | COLO |
| Atlanta GA - Switch COLO | US_ATL_GA_CI | SWITCH | COLO |
| Sparks NV - Switch TRE | US_SPK_NV_CI | SWITCH | COLO |
| Woodbridge VA - Iron Mountain | US_WDB_VA_CI | CVS | COLO |
| Carlstadt NJ - SunGard DR | US_CAR_NJ_CI | CVS | COLO |

Equinix = cloud peering only, not primary DC. Richardson TX/Dallas Caremark = retiring.
Superloop is Switch's network connectivity product at TRE, not a separate facility.
