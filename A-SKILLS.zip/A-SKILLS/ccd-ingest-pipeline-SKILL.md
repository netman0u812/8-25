---
name: ccd-ingest-pipeline
description: CCD Platform ingest pipeline architecture — PP1, PP2, PP3, the real script dependency graph, the non-negotiable update order (LM → IPAM → NDM → EHM → Infra → Platform), and the debugging methodology that finds real bugs in this pipeline rather than trusting documentation or assumed behavior. Use this skill whenever the user asks about ingest_pipeline_1.py, ingest_pipeline_2.py, ingest_pipeline_3.py, preprocess_p1.py, preprocess_p2.py, staging_status.py, which script runs before/after another, why a dataset shows stale in staging_status.py, whether a script's flags/behavior match its documentation, EHM/NDM/IPAM/LM consistency, or any update_*.py / build_*.py CCD Platform script. Also trigger when investigating a data-quality bug that might originate upstream of the dataset where it's visible — this skill documents the real bug classes (independent-field trust, native_gate misclassification, silent staging-without-promotion, lexicographic version-sort bugs) already found in this codebase, and the verification method that catches the next one instead of re-deriving it from scratch.
---

# CCD Ingest Pipeline

This skill exists because a full session was spent reconstructing this pipeline's real structure — tracing scripts, reading actual source instead of trusting docstrings, and finding several real, confirmed bugs along the way. The goal here isn't just to hand over a diagram; it's to hand over the *way of working* that found real bugs seven times in one session, so the next investigation starts from confirmed ground instead of from zero.

## The core principle, stated once, applies everywhere below

**Never trust a script's documented behavior, another script's assumption about it, or a config flag describing it — verify against the actual source before relying on it.** Every real bug found this session was found this way, not by reading a docstring and believing it. `ingest_pipeline_2.py`'s own `STAGE_CONFIG` explicitly marks stages `verified: True/False` for exactly this reason — treat that as the right instinct to imitate, not just a quirk of one file.

## Real pipeline architecture (three tiers, not one pipeline)

```
PP1 (ingest_pipeline_1.py)          PP2 (ingest_pipeline_2.py)              PP3 (ingest_pipeline_3.py)
Group A: known IP + location        Group B: NO IPAM COVERAGE / NEW          Derived datasets, downstream
─────────────────────────           ─────────────────────────────            of PP1/PP2, previously unordered
preprocess_p1.py                    preprocess_p2.py  (runs TWICE:           ───────────────────────────────
  ↓                                   Pass A = location+ipam only,          Tier 1 (independent):
update_app.py --enrich-only            Pass B = network/app/infra/            build_network_device_master.py
update_infrastructure.py               platform, against the now-             build_apm_master.py
update_platform.py                     current LM/IPAM from Pass A)         Tier 2 (needs EHM):
update_network.py                   commits in order:                        build_app_inventory.py
(no ordering needed between           location → ipam → network →            build_compute_substrate.py
 these four — pure gap-fill,           app → infra → platform                build_citrix_inventory.py
 each against its own master)        cross_check_gate() (0 HIGH) between      build_cpc_service_catalog.py
                                        Pass A and Pass B commits            Tier 3 (needs Tier 1/2 outputs):
                                     build_unresolved_ip_registry.py           build_app_subnet_index.py
                                        (builds, does NOT auto-promote —       build_known_unknown_ip_resolver.py
                                        see "Staging vs. promotion" below)   Tier 4 (needs everything):
                                                                               generate_csna_hostgroups.py
```

**These three pipelines do not call each other.** Confirmed by direct grep, not assumed: zero references to any PP3-tier script inside PP1 or PP2. If you're investigating "why didn't X get picked up," check which tier X's builder is in — a fresh PP2 run does not trigger PP3.

## The one non-negotiable rule: update order

`location_master → all_IP_networks (IPAM) → ent_network_device_master (NDM) → ent_host_master (EHM) → Infrastructure → Platform`

This is enforced for real, in code, inside PP2's `run_pipeline()` — `for stream in PASS_A_ORDER: ...` then `for stream in PASS_B_ORDER: ...`, each followed by a hard `cross_check_gate()` (0 HIGH required to proceed). It is **not** enforced across PP1 (deliberately — those four scripts are independent pure gap-fills) or across PP3 (each PP3 stage does its own prerequisite check instead, since PP3 covers datasets outside the six-master core order).

## `build_*.py` vs `update_*.py` — two different jobs, not two names for the same job

**`build_*.py` = full rebuild from raw sources.** Ignores whatever the current registered dataset says; reconstructs it from scratch from the actual raw inputs (a spreadsheet, raw NMS/FW exports, etc).

**`update_*.py` = delta-apply against an already-existing dataset.** Loads the current registered file, applies gap-fill/enrichment/candidate rows on top of it, writes a new version. Does not reconstruct from raw sources at all.

Not every dataset has both. Confirmed this session:

- **`location_master`, `all_IP_networks` (ipam), `ent_network_device_master` (ndm), `delivery_infrastructure`, `delivery_platform`**: have both a `build_*.py` (full rebuild) and an `update_*.py` (delta) — two different tools for two different situations, not redundant.
- **`apm_master`**: `build_apm_master.py` only. No delta-update companion — it fully rebuilds from the raw APM spreadsheet every time it runs. Treat `build_apm_master.py` as the primary and only build path for this dataset, not one half of a pair.
- **`ent_host_master` (EHM)**: `update_app.py` only, in what's been reviewed this session. No `build_ent_host_master.py`-style full-rebuild script has surfaced — EHM appears to be maintained entirely through delta application against whatever preprocess_p1.py/preprocess_p2.py generate. Confirm this rather than assume it if a full EHM rebuild is ever actually needed.

**EHM's real maintenance chain, confirmed against actual source (2026-08-07)**: EHM has no single "build from scratch" script the way `location_master`/`ent_network_device_master`/`apm_master` do. It's entirely process-maintained across three chained tools, each with one job:
1. `preprocess_p1.py` (Group A — known IP + location) reads raw CMDB/APM/Risk-Registry sources, compares against current EHM, and writes `p1_ehm_enhancement_*.csv` — gap-fill or location-drift-detected `LOCATION_REDERIVED` rows. Never touches EHM directly.
2. `preprocess_p2.py` (Group B — no IPAM coverage, or genuinely new) handles what PP1 can't; writes candidate files like `app_candidates_*.csv`.
3. `update_app.py` is the **only** thing that actually writes to `ent_host_master`. It applies whatever PP1/PP2 produced — never reconstructs from raw sources itself.

This matters structurally: a flaw anywhere in this three-stage chain corrupts the one shared file most of the rest of the platform reads from (`build_app_inventory.py`, `build_compute_substrate.py`, `build_citrix_inventory.py`, `build_known_unknown_ip_resolver.py`, `generate_csna_hostgroups.py` all consume EHM directly or transitively). There is no independent "rebuild from scratch" escape hatch if this chain is ever found to be systematically wrong — fixing it means fixing whichever of the three stages is actually broken, not re-running a clean build.

When investigating a dataset's freshness or correctness, check which tool(s) actually exist for it before assuming the standard build+update pair applies — it doesn't always.

## Real, confirmed bug classes — recognize the pattern, not just the instance

Each of these was found by reading actual source, not by assumption. They're listed as *classes* because the same shape of bug is likely to recur elsewhere in scripts not yet audited.

### 1. Independent-field trust (the deepest one found this session)

A location gets represented by *several* related fields (`CANONICAL_LOCATION`, `ROUTING_DOMAIN`, `SITE_CODE`) that must stay mutually consistent. If a function applies enhancement/enrichment fields **independently, one at a time**, an upstream process that only emits a *partial* update (e.g. a new `CANONICAL_LOCATION` without a matching `SITE_CODE`) silently produces an inconsistent row — one field updated, its siblings stale.

**Real case**: `update_app.py`'s `apply_enrichment()` applied `LOCATION_REDERIVED` fields per-field from a dict keyed by `IP → {field: value}`. `preprocess_p1.py` (upstream, not always available to fix directly) apparently emitted a location update without a paired `SITE_CODE` update for the same IP. Result: a real 7-person Aetna office (`SITE_CODE=US_MIC_CT_DC`, actually Middletown) had `CANONICAL_LOCATION` silently overwritten to `'Linthicum MD - Corporate'` on 16 hosts, while `SITE_CODE` correctly stayed `US_MIC_CT_DC` — the mismatch is the signature: **one correct field, one wrong field, from the same "atomic" update.**

**Fix pattern**: when several fields must stay consistent, re-derive them *together* from one authoritative lookup (in this case, a fresh IPAM LPM on the row's own IP) rather than trusting each field's independently-supplied value. Don't fix this by validating one field against another after the fact — fix it by not letting them diverge in the first place.

**Where to check for this pattern**: any function that loops over `{field: value}` pairs and applies them one at a time, where more than one of those fields encodes related identity (location, ownership, classification).

### 2. Silent staging without promotion

A builder writes its output to `processed_outputs/` or its own `--out-dir`, and stops. Nothing calls `ipam-db.py --import` afterward. The dataset sits "staged" indefinitely, invisible unless someone runs `staging_status.py` and notices.

**Real case**: `ingest_pipeline_2.py`'s `stage_registry()` calls `build_unresolved_ip_registry.py` and nothing else — no import step. Confirmed via `staging_status.py` output showing `ent-ipdataset-OTHER-INT-ENT-HOST-UNRESOLVED`: live version `v20260720 (1r)`, staged `v20260805 (2r)`, "NEWER BUILD WAITING, not yet promoted."

**This is the default assumption for every PP3-tier builder too** — none of them auto-promote either. Run `staging_status.py` after any pipeline run, every time; don't assume a clean pipeline exit means the live registry is current.

**A worse variant of this same bug, confirmed real: a builder that doesn't even write to `processed_outputs/` in the first place is invisible to `staging_status.py`, not just unpromoted.** `staging_status.py`'s `--staging-dir` default is literally `processed_outputs` — it only ever looks there. `build_apm_master.py`'s original default `--out-dir` was `.` (current directory), inconsistent with every other `build_*.py` script. The practical effect: an `apm_master` rebuild wouldn't show up as "staged, waiting to be promoted" — it would show up as nothing at all, indistinguishable from a script that had never been run. Confirmed and fixed (v1.1.2, default changed to `processed_outputs`) — but the general lesson is the real one: **a script's output directory isn't just a file-organization choice, it determines whether the platform's own staleness-detection tooling can see the dataset exists at all.** Check every `build_*.py`/`update_*.py` script's actual default `--out-dir` against `staging_status.py`'s real `--staging-dir` default before trusting that a clean run will be visible.

### 3. `native_gate` / documented-behavior misclassification

An orchestrator's config claims a wrapped script behaves a certain way (has an interactive prompt, requires a specific flag) without that claim ever having been checked against the script's real source.

**Real case**: `ingest_pipeline_2.py`'s `STAGE_CONFIG` assumed `update_infrastructure.py` and `update_platform.py` had `native_gate=True` (a real interactive `input()`-based review). Direct source read of `apply_additions()` in both: zero `input()` calls anywhere. Both auto-commit exactly like the already-confirmed `app`/`network`/`ipam` stages. The wrong classification didn't just cost log fidelity — it meant the operator was told "proceeding to the script's own interactive review" when no such review exists.

**Verification method that catches this**: for any orchestrator wrapping another script, grep that script directly for `input(` before trusting a claim about its interactivity. Takes seconds, and it's the only way to actually know.

### 4. Lexicographic version-sort bugs

`sorted(glob.glob(pattern))[-1]` or equivalent does a **string** sort. `v20260729r10` sorts *before* `v20260729r2` as a string (`'1' < '2'`). This silently picks a stale file once same-day revisions reach double digits.

**Real, confirmed in production**: this exact bug was independently found and fixed in four separate files before being consolidated into `ipam_enrichment.py`'s `find_latest_versioned()`, which uses a real numeric `(date, revision)` sort key. `find_registered_dataset()` (`ipam_db_registry.py`, `build_network_device_master.py`) has the equivalent fix built in from the start.

**Check for this**: any `sorted(glob(...))` or `max(glob(...), key=os.path.getmtime)` pattern selecting a versioned CCD dataset file. `getmtime` has its own problem — file modification time isn't the same as the semantic version encoded in the filename; a file touched/copied later can have a newer mtime than a file with a higher real version number.

**Check for this class systematically, not just reactively** — a full sweep of every uploaded CCD script this session found 7 real, confirmed instances total: `build_app_inventory.py`, `build_apm_master.py`, `build_app_subnet_index.py`, `build_citrix_inventory.py`, `build_network_device_master.py` (a second, separate instance beyond the one already fixed), `update_app.py` (three separate instances: `find_latest()`, `load_cross_dataset_ips()`, `find_latest_adl()`), and — genuinely ironic given its purpose — `staging_status.py` itself, the tool meant to verify everything else is current. If this bug class is this common, assume any new script touching versioned filenames has it until checked directly, don't wait for a live incident.

### 5. Missing/wrong `#VERSION=` header assumptions

Not every CCD dataset file has a `#VERSION=` comment header — `location_master_v5.33.csv` doesn't; its version lives only in the filename. A function that assumes the header exists and returns `'unknown'` when it doesn't will silently fail on 100% of rows for that specific dataset, while working fine for every other dataset that does follow the convention.

**Real case**: `build_compute_substrate.py`'s `_read_version_header()` returned `'unknown'` for `LOC_MASTER_VERSION` on all 61,492 rows in production, confirmed, before being fixed with a filename-based fallback.

### 6. Sibling scripts sharing a versioning convention, inconsistently implemented

Two scripts manage different datasets but use the identical `vYYYYMMDD`/`vYYYYMMDDrN` versioning convention. One correctly checks whether the stored date is still today before deciding to bump the revision suffix or roll to a fresh date. The other doesn't — it always reuses the old date and just increments the revision, forever, regardless of how much real time has passed.

**Real case**: `update_location.py`'s `bump_lm_version()` correctly does `f'v{d}r{rev}' if d == TODAY else f'v{TODAY}'`. `update_app.py`'s `bump_ehm_version()` (same convention, sibling dataset) had no such check — just `f'v{d}r{rev}'`, unconditionally. Confirmed real, live consequence: `ent_host_master` was stuck at `v20260525r31` in August, over two months and 31 real updates past its base date, because every single update correctly bumped the revision counter but never once refreshed the date. Every consumer and every human judging that dataset's freshness from its filename was being misled the entire time.

**Where to check for this**: any two scripts that manage different datasets but use the same versioning scheme (grep for the same `re.search(r'v(\d{8})r?(\d+)?'` pattern across scripts) — confirm each one's date-rollover logic actually checks the current date, not just assumes the pattern match implies correctness. A version bump function *parsing* the convention correctly is not the same as *applying* it correctly.

### 8. Fix cross-cutting concerns at the real choke point, not in each individual script

A "next step" or "what do I run now" message that appears after several different scripts' runs might not actually be printed by those scripts at all — it can be coming from a shared, central tool every one of them calls into (like `ipam-db.py --import`, which every `build_*.py`/`update_*.py` script this session shells out to). Patching the individual scripts to improve that message fixes it for exactly the scripts touched and nowhere else; the same message keeps being wrong for every other dataset type the central tool also handles.

**Real case**: this session initially patched `build_app_subnet_index.py` and `build_apm_master.py` individually to prompt-and-auto-import, closing the "wrong placeholder filename" problem for those two scripts only. The actual "Next steps — rebuild downstream in order" text with unresolved `<N>` placeholders (the thing that caused a real `zsh: no such file or directory: N` failure) turned out to live in `ipam-db.py`'s own centralized hint table, covering many more dataset types (`location_master`, `csna_site_registry`, `all_IP_networks`, `fw_config_manifest`, `ent_host_master`, and more) — none of which were touched by the individual-script patches. The real fix went into `ipam-db.py` itself: resolve each hint's placeholder against what's actually on disk right now, and offer to execute the step immediately rather than printing unresolvable predicted-future-filename text. One fix, applied at the actual choke point, closes the gap for every dataset type at once instead of one script at a time.

**When investigating "why does this output look wrong," check whether the printing code is actually in the script that appears to be producing it, or in a shared tool it shells out to** — the two can be visually indistinguishable in a terminal, since subprocess output streams into the same unbroken block as the caller's own output.

### 9. "Kept in sync deliberately" comments need active verification, not just trust

A comment stating that one function mirrors another "exactly, kept in sync deliberately" is a design intent, not a guarantee — fixing a bug in one copy doesn't automatically fix the other, and nothing enforces the sync unless it's actively checked both ways.

**Real case**: `build_apm_master.py`'s `find_source()` is documented as mirroring `preprocess_p1.py`'s `_find_apm_database_file()` "exactly." The lexicographic version-sort bug was found and fixed in `build_apm_master.py` (v1.1.1) without checking whether the original it claims to mirror had the same fix — it didn't. The two were silently out of sync until both were checked directly.

**When a comment claims two functions are kept in sync, check both, not just the one in front of you.**

### 10. Verify a theory against real source before treating it as confirmed — sometimes it's wrong, and that's still valuable to know

The `LOCATION_REDERIVED` independent-field-trust bug (class #1 above) was originally diagnosed as a defensive fix in `update_app.py`, reasoning that `preprocess_p1.py` (unavailable at the time) probably emitted a partial update. When `preprocess_p1.py` finally became available and was actually read, the real generation logic (`classify_record()` in `preprocess_p1.py`) turned out to be internally consistent by construction — `CANONICAL_LOCATION` and `SITE_CODE` are both derived from the exact same matched IPAM row object, so this specific code path cannot produce the kind of partial, inconsistent emission the original theory assumed. The defensive fix in `update_app.py` is still correct and still valuable — it protects against the *pattern* regardless of origin — but the original corruption's true entry point remains unconfirmed, likely predating this version of the code or entering through a different pathway entirely (manual correction, historical migration). **Don't let a plausible, unverified theory calcify into an assumed fact once the tool that could confirm or falsify it becomes available — go back and actually check.**

## Verification methodology — how to actually check, not just read

1. **Grep the real script for the flag/behavior being assumed** — `add_argument`, `input(`, the actual function name — before trusting an orchestrator's claim, a docstring, or a prior session's summary about it.
2. **Build a synthetic test that reproduces the bug pattern exactly**, run it against the *unfixed* code first to confirm it actually reproduces, then against the fix. Don't trust a fix that was only reasoned about — this session caught a real `--dry-run` regression this way, in code written minutes earlier, by testing before shipping rather than after.
3. **Test the real pipeline end-to-end when possible**, not just the unit you changed. Several real numbers reported in this session (subnet counts, mismatch counts, coverage percentages) turned out to be wrong on first computation — mixing `DEVICE`/`L3_INTERFACE` rows, confounding device-class composition with location correctness — and were only caught by testing against the *actual* full dataset instead of a hand-picked sample.
4. **When a metric "confirms" an anomaly, decompose it before trusting it.** A site-wide average can look wrong purely because of population composition (e.g. a site that's 97% load-balancers will have a different interfaces-per-device average than a site that's mostly routers, with nothing wrong at either site). Check the same metric within a controlled subgroup before concluding the aggregate means what it looks like it means.
5. **Cross-check against a source already confirmed clean**, not against another equally-unverified source. `location_master` and `all_IP_networks` were directly verified against each other (zero mismatches) before being trusted as the reference point for finding real errors in `compute_substrate` and `ent_host_master`.

### 7. No persistent "next command" reference across stateless sessions

A fix delivered in one conversation turn, or one session, does not persist as a reminder into the next. If the exact next command to run isn't restated explicitly, every time a fix is delivered — not just the first time — there is no other trigger that surfaces it. The operator (or a future session with no memory of this one) has no way to know a fix exists in code but hasn't been run against real data, unless it's said again, plainly, attached to the fix itself.

**Discipline going forward, for any script fix delivered in this pipeline**: end with the literal, copy-pasteable command(s) needed to actually execute it against real data — not just "this is fixed," but the exact next command. If multiple fixes are pending across multiple scripts, list all of them in run order, every time, even if some were already stated in an earlier turn. Treat "fixed in code" and "run against real production data" as two separate facts that both need to be true, and say explicitly which one currently holds when reporting status — do not let "delivered" or "confirmed" imply "executed."

**A `build_*.py`/`update_*.py` command is never, by itself, a complete instruction — it must always be paired with its `ipam-db.py --import` follow-up, or explicitly stated as not yet needing one.** Confirmed real: this exact mistake was made while giving operator-facing guidance in this same session, immediately after documenting the underlying bug class (#2, silent staging without promotion) — stating "run `build_apm_master.py`" without its import step reproduces the identical failure mode as a script that writes to `processed_outputs/` and stops. The fix's own script output already prints the real import command (`Next step: python3 ipam-db.py --import ...`) — use that literal line rather than reconstructing or guessing the versioned filename.

## Known, currently-open gaps (as of 2026-08-07)

- `ingest_pipeline_2.py`'s `location` stage: `native_gate=True` is source-confirmed correct, but has never been exercised in a real live run the way the other five stages have.
- `preprocess_p1.py` and `preprocess_p2.py` themselves were never available to audit directly this session — every fix involving them was a defensive fix in a downstream consumer, not a fix at the actual point of generation. If either becomes available, the `LOCATION_REDERIVED` independent-field-trust bug class should be checked there directly.
- PP3 (`ingest_pipeline_3.py`) is new and unrun against real production data — treat every stage as `verified: False` until it's actually been exercised live, same discipline PP2 used for its own rollout.
- `build_csna_site_registry.py` and `generate_csna_hostgroups.py` are mid-rebuild to reflect the real 11-egress-domain model (CVS DC hubs, Aetna DC hubs, Vegas COLO, CVS/Aetna Equinix cloud peering, Retail as its own domain) discovered this session — not yet complete.
