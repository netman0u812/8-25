---
name: cvs-aetna-ip-prefix-allocations
description: >
  Real, confirmed reference for CVS/Aetna's six legacy IANA-registered
  public IPv4 blocks used INTERNALLY despite being real public address
  space: 167.69.0.0/16, 157.121.0.0/16, 204.99.0.0/16, 206.213.0.0/16,
  198.187.0.0/16, 152.145.0.0/16. Documents each block's real owner,
  primary use case, and PUBLIC-vs-PRIVATE split, all confirmed against
  real SNAT/VIP/device/app data. ALWAYS consult before re-deriving this
  -- took four days of real cross-validation (2026-08-16 to 08-19).
  Trigger on any mention of these six prefixes, "IANA public block",
  "classful allocation", "public vs private IP", "who owns this IP
  range", "CVS Aetna address space", "legacy public block used
  internally", or any question about what a CVS/Aetna IP is used for.
---

# CVS/Aetna Legacy IANA Public Block Reference

## Framing: three categories, not two

There are really **three** categories of IP space relevant to this
enterprise, not two ("public" and "private"). Confusing them is the
single most consequential mistake to avoid, and it's a real mistake
that was made in production code (`build_external_ip_registry.py`,
before this investigation) before it was caught.

**1. RFC1918 + CGNAT (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`,
`100.64.0.0/10`) -- definitionally internal, zero investigation ever
needed.** These ranges are inherently non-internet-routable by IANA
definition. There is no ambiguity to resolve here, ever.

**2. Real IANA-registered public space that the enterprise itself owns
-- "Administratively Relevant" space.** This is the six-block category
this whole skill documents. Critically: **owning a block of real public
address space says nothing on its own about whether it's currently
routed publicly or privately.** That has to be determined with real
evidence (see below) -- IPAM's own `ROUTING_DOMAIN` tag is not
sufficient by itself. A block being "Administratively Relevant" (CVS or
Aetna owns and controls it) is a completely different, orthogonal
question from whether it happens to be public or private *today*. Some
Administratively Relevant blocks are mostly public (`204.99`, `198.187`,
`152.145`), some are mostly private (`167.69`, `206.213`), one has no
clean answer at all (`157.121`) -- but all six are equally
"Administratively Relevant" regardless of that split, because CVS/Aetna
owns and controls every one of them.

**3. Everything else -- genuinely external/untrusted space.** Real
third parties: internet destinations, SaaS/cloud providers (including
the `34.x`/`35.x` Google Cloud ranges CVS has real Cloud Interconnect
into -- see `PROVIDER_NETWORK` below), partners, and unknown/threat
space. This is space the enterprise does NOT own or control, full stop,
regardless of whether it's technically "public" in the address-space
sense.

**The real, confirmed bug this framing prevents:** `build_external_ip_
registry.py`'s `is_public()` check only tests whether an address avoids
RFC1918/CGNAT/other IANA-reserved ranges -- it has no concept of
category 2 vs category 3. Confirmed by direct measurement: **84% of
what that script calls "external" within these six legacy families is
actually category 2 (Administratively Relevant CVS/Aetna infrastructure),
not category 3 (a real external/untrusted destination).** An "External
IP Registry" should mean category 3 only. A `CVS_OWNED='Y'` flag bolted
on afterward is not the same as correctly scoping the dataset in the
first place -- it doesn't distinguish CVS from Aetna, and it doesn't
distinguish "administratively relevant AND genuinely public" from
"administratively relevant BUT privately used," which is exactly the
distinction that matters for risk scoring, rule interpretation, and any
downstream security conclusion built on top of it.

**The practical rule going forward:** before treating any IP as
"external" or "untrusted" in this environment, check it against
category 2 first (the six blocks below, or the real `HERITAGE` field in
IPAM) -- if it's Administratively Relevant, it is NOT external/
untrusted regardless of its current public/private routing status.
Only address space that is neither RFC1918/CGNAT nor Administratively
Relevant is genuinely external.

## The core finding

CVS Health and Aetna both hold real, IANA-registered public IPv4 `/16`
allocations from before RFC1918 private space was standard practice.
Rather than migrate off them, both companies kept using this real public
address space **internally** -- for infrastructure, applications, and
WAN links that need guaranteed-unique addressing (especially important
post-merger, where CVS's and Aetna's RFC1918 `10.x`/`172.16.x` ranges
overlap).

This means: **a block being "publicly registered" does NOT mean it's
actually internet-routed.** Whether a given subnet is really public or
private has to be checked against real evidence -- IPAM's own
`ROUTING_DOMAIN` field is frequently wrong or stale for this exact
reason, and should never be trusted alone (see "Why IPAM's ROUTING_DOMAIN
can't be trusted alone" below).

## The six real blocks, confirmed

| Block | Real Owner | Primary Use Case | Public | Private |
|---|---|---|---|---|
| `167.69.0.0/16` | AETNA (99.6%) | Aetna's internal core claims/app backbone (QNXT, ClaimsXTEN, UCCE, Guardium) | 13 | 889 |
| `157.121.0.0/16` | Fragmented -- no clean single owner (CVS/AETNA/Caremark/Mixed) | Shared cross-enterprise app hosting pool -- highest real host density of all six blocks (EDA, HDP, HealthRulesPayor, EIClaims, CaseTrakkerDynamo) | 4 | 343 |
| `204.99.0.0/16` | CVS (80%) | Customer-facing app delivery -- Caremark.com client portal, pharmacy dispensing (DispensingTristar), SAP. Real external+internal F5 VIPs (1,208 EXTERNAL / 796 INTERNAL), heavy SNAT egress (3,214 hits) | 144 | 33 |
| `206.213.0.0/16` | AETNA (82%) | Internal security/ops tooling -- Splunk SIEM (SPLUNKENTnonPCI, SplunkPCI), Firemon firewall policy mgmt. Zero real VIPs despite heavy F5 device presence (self-IPs, not service VIPs) | 20 | 97 |
| `198.187.0.0/16` | CVS (91%) | Internet egress / consumer web gateway -- heavy SNAT (1,141 hits), VIPs present but 100% INTERNAL tier. Real apps: CaremarkDotComMPDM, Medicare plans site | 64 | 4 |
| `152.145.0.0/16` | CVS (92%) | **Not application space at all** -- WAN circuit addressing: MPLS partner interconnects (named `RRICMCP-SEC-MPLSEAST-01-<PartnerName>`), SD-WAN edges, DMVPN. Only 2% of the full `/16` is actually registered (1,344 of 65,536 addresses); the rest is unprovisioned | 25 | 1 |

Full row-by-row detail (every real CIDR, owner, and address count) is in
`references/cidr_ownership_detail.csv`, bundled with this skill.

## Why IPAM's ROUTING_DOMAIN can't be trusted alone

`all_IP_networks.ROUTING_DOMAIN` (`Internet-Facing` / `Internal-PBM` /
`Internal-HCB`) reflects **documented historical intent**, not verified
current reality. Real, confirmed example: `167.69.x` and `157.121.x`
blocks are tagged `Internet-Facing` in IPAM at the block level, but the
real hosts sitting on them are internal production applications --
because the block was *originally* registered as public address space,
even though it's been used privately for years.

**Real evidence sources, in order of reliability, for determining actual
public/private status of any specific subnet in these six blocks:**

1. **Firewall rule zone evidence** (`rules.src_zone`/`dst_zone` in
   `fw_rule_db.sqlite`, joined via `rule_ips`) -- classify zones as
   EXTERNAL (`outside`, `external`, `internet`, `untrust`, any zone
   containing `dmz`) vs INTERNAL (`inside`, `internal`, `corpnet`,
   `cvsnetwork`, `cvszone`, `aetnazone`). The blank/empty zone value is a
   real, large, still-unexplained gap -- never guess at it.
2. **Real SNAT egress evidence** (`ent-ipdataset-FW-SNAT-POOLS`,
   `ent-ipdataset-F5-SNAT-POOLS`) -- a real SNAT_IP hit is strong
   evidence of genuine external/egress use.
3. **Real F5 VIP evidence** (`ent-ipdataset-F5-VIP-REGISTRY`) --
   `F5_TIER=EXTERNAL` means genuinely internet-reachable;
   `F5_TIER=INTERNAL` means internally load-balanced despite living on
   public-numbered space.
4. **Real host/app evidence** (`ent_host_master`) -- `ROUTING_DOMAIN` at
   the HOST level (not the block level) tells you how that specific
   real server is actually used today.
5. **Real device infrastructure evidence** (`ent_network_device_master`)
   -- for non-application space (WAN links, firewall interfaces), this
   is often the ONLY real evidence available. Check `CONNECTED_SUBNETS`
   and `MANAGEMENT_IP` for containment, and `HOSTNAME`/`DEVICE_TYPE`/
   `INFRA_ROLE` for real functional context (e.g. `MPLSEAST` in a
   hostname is a real, confirmed WAN-circuit signal even when
   `INFRA_ROLE=SECURITY` because the device is a firewall terminating
   the circuit, not a router).

**IMPORTANT: these files all start with `#`-prefixed comment/version
lines that MUST be stripped before CSV parsing** (`lines = [l for l in f
if not l.startswith('#')]`) -- forgetting this silently produces a
DictReader with the wrong header row and zero real matches on every
lookup, with no error. This is a real, confirmed, easy-to-repeat mistake
-- it happened once already during this exact investigation.

## Real, confirmed one-off findings (don't re-investigate these)

- **`11.1.x.x/25`** (37 real blocks, NOT part of the six main blocks
  above): a deliberate SD-WAN system-ip overlay addressing scheme.
  Confirmed via 279 real matching devices (262 explicitly `sdwan`-
  hostnamed, the other 13 `WAN_EDGE` routers or `Loopback65529`
  interfaces). `11.0.0.0/8` (DoD-reserved space) was deliberately chosen
  because it guarantees no real collision with internet traffic. This is
  PRIVATE, always -- even though rule-zone evidence can misleadingly
  suggest PUBLIC, because SD-WAN overlay tunnels legitimately transit the
  internet-facing interface as *transport*, even though the system-ip
  itself is never a real destination.
- **`11.11.11.0/24`**: confirmed BOGUS/stale. `DATA_QUALITY=Inferred`.
  Real historical device found (`EDA-SEC-M1A-MAT-01`, an ASA HA failover
  pair) but `STATUS=MOVED` -- the device relocated and IPAM was never
  updated. Not a live entry.
- **`152.161.222.132/30`**: real, `HERITAGE=AETNA`, `Authoritative`, at
  Hartford CT - Aetna HQ. Confirmed via a real WAN_EDGE router
  (`HLB-WR-VDC-1`). Do not confuse with `152.145.x` (CVS) -- same first
  two-and-a-bit octets, completely different owner and block.
- **`152.145.224.0/24`**: real, CVS, PRIVATE. Confirmed via 12+ real
  firewalls/SD-WAN routers at Woonsocket RI - RI One, all
  `HERITAGE=CVS`. (This one briefly showed as `UNKNOWN` during the
  investigation before the device-master cross-check was run against
  it -- it was never actually unresolved, just unchecked.)

## Real overlap finding: 253 cases, all clean containment, not conflicts

`204.99` (150), `206.213` (50), `167.69` (28), and `157.121` (25) each
have real cases where a broad legacy supernet is tagged PRIVATE while
smaller, more specific subnets carved out *inside* that same range are
independently tagged PUBLIC. **This is not a data conflict** -- every
single one of the 253 cases is pure containment (a smaller range fully
inside a larger one), never an identical-CIDR disagreement or a partial/
ambiguous intersection. This is exactly how normal CIDR hierarchies and
routing work (a router having both a default route and a more-specific
route is not a "conflict"). **The resolution rule: the more specific
entry always wins (longest-prefix-match)** -- it reflects real,
current, granular use; the coarser entry it sits inside is the stale
historic blanket reservation. `198.187` and `152.145` have zero overlap
-- they never had a coarse blanket entry to begin with.

## Bundled reference files

- `references/cidr_ownership_detail.csv` -- every real CIDR across all
  six blocks, its owner, and its address count, in address order.
- `references/final_classification.csv` -- the full, final
  PUBLIC/PRIVATE/PROVIDER_NETWORK/BOGUS classification for all real
  public CIDR rows in `all_IP_networks`, with the evidence behind each
  call.

## What this skill does NOT cover

- The `34.x`/`35.x` Google Cloud ranges and other cloud-provider space
  documented in IPAM for Cloud Interconnect visibility -- these are
  PROVIDER_NETWORK, not CVS/Aetna's own address space at all, and are a
  separate, already-solved category (see `PROVIDER_NETWORK_list.csv`
  from the same investigation).
- Anything about which specific FW rules/objects reference these blocks
  at the rule level -- that's the master object consolidation work
  (`ccd-platform-data-model` and `create-update-ipam-dataset` skills),
  a related but separate initiative.

## Additional confirmed findings (2026-08-22)

**198.187.114.0/24 and 198.187.114.128/25 at Shea DC:**
Confirmed PUBLIC by real FW-SNAT external-DMZ NAT (198.187.114.209, MID-EDMZ-ASA).
Were incorrectly tagged Internal-PBM in all_IP_networks — corrected in r33 (CX11 batch5).

**204.99.3.0/25 at Shea DC:**
Confirmed PUBLIC (in 204.99/16 CVS public block via EGRESS-FW-TOPOLOGY evidence).
Was incorrectly tagged Internal-PBM — corrected (CX11 batch6).

**11.0.0.0/8 is CVS SD-WAN platform space (PRIVATE, not Category 1 or 2):**
This is a real fourth category that catches people: CVS uses 11.x as their internal
SD-WAN overlay address space. It is NOT RFC1918 (so `is_private()` returns False),
NOT a CVS/Aetna IANA-registered block, and NOT genuinely external. SD-WAN routers
(INFRA_ROLE=WAN_EDGE) have 11.x addresses in their CONNECTED_SUBNETS. This caused
false PUBLIC classifications in `build_ip_classification_ref.py` before WAN_EDGE was
removed from the NDM evidence tier (v1.6.0, 2026-08-21).

**EGR_* ROUTING_DOMAIN propagation (2026-08-21):**
6,525 rows in all_IP_networks were updated from Internet-Facing/Internal-* to specific
EGR_*-TC codes (traffic-confirmed egress firewall assignments) across 10 firewalls.
These rows remain in the six IANA blocks but now carry precise egress attribution.
CX11-INTERNET-FACING cross-check: EGR_* codes are explicitly exempted (ipam-db.py v3.32.0).
