# CCD Platform — Object Model Revamp Session Prompt
## Version 1.0 | June 14, 2026 | M. J. Martin, Lead Director Information Security

---

## PURPOSE OF THIS DOCUMENT

This prompt provides complete context for the next CCD Platform engineering session.
It covers all work identified in the June 14 session needed to properly structure the
CCD data model for firewall rule object generation. The primary goal is to replace
"any/any" firewall rules with properly named source and destination objects built
from structured, correctly classified network data.

Location master and IPAM site mapping are stable. The work now is purely about
correctly classifying and structuring data that already exists.

---

## CURRENT PLATFORM STATE (EOD June 14, 2026)

```
location_master          v5.22         11,570 rows    STABLE
all_IP_networks          v20260611r4   24,940 rows    NEEDS NET_TYPE PATCH
ent_host_master          v20260525r16  61,425 rows    CURRENT
app_subnet_index         v20260614      2,608 rows    CURRENT
canonical_app_objects    v20260614      2,976 objects  NEEDS USER-ACCESS CLASS
delivery_infrastructure  v20260504r9    5,763 rows    CURRENT
delivery_platform        v20260504r6    1,875 rows    CURRENT
csna_site_registry       v2.30          STALE — needs rebuild after all changes
F5-VIP-REGISTRY          v20260613     15,114 rows    CURRENT
F5-POOL-MEMBERS          v20260613     93,838 rows    CURRENT
EGRESS-FW-TOPOLOGY       v20260613     69,745 rows    CURRENT
Cross-check: 0 HIGH / 289 MEDIUM (all pre-existing carry-forward)
```

### Key script versions in use:
```
preprocess_p1.py              v2.6    ← JUST UPDATED (deployed this session)
preprocess_p2.py              v1.3
update_app.py                 v1.8
build_app_subnet_index.py     v1.9.1
build_canonical_app_objects.py v1.5.6
build_cpc_core_services.py    v1.2.1
build_network_groups.py       v1.8.4
build_service_objects.py      v1.0.3
build_ng_report.py            v1.3.2
build_svc_report.py           v1.0.4
build_edl_catalog.py          v1.1.1
build_object_pipeline.py      (orchestrator)
generate_csna_hostgroups.py   v4.0.1
ipam-db.py                    v3.15.12
iplookup.sh                   v3.23
```

---

## ARCHITECTURAL CONTEXT

### The Core Problem
The CVS Health PA estate has 96% of firewall rules with src=any or dst=any.
Replacing "any" requires named firewall objects. Named objects require correctly
classified data. The object model has three gaps:

1. **Services incorrectly routed** — MQ, Veeam, AppDynamics, ZIA proxies being
   sent to delivery_infrastructure instead of CPC-CORE-SERVICES/SERVICE_Objects
2. **User networks not classified** — Citrix VDI pools, VPN pools, WLAN, wired
   user subnets all stamped Corporate/DataCenter in IPAM with no user-access identity
3. **IoT/OT not modeled** — building systems, physical security, OT networks
   have no NET_TYPE and no object class

### Object Model — Current vs Target

```
CURRENT OBJECTS          COUNT   ROLE IN FW POLICY
─────────────────────────────────────────────────────────────────────
APP_Objects              2,698   Destination: named application servers
INFRA_Objects               78   Destination: ESXi/DataPower/Isilon
SERVICE_Objects             57   Destination: AD/NTP/DNS/Splunk/Qualys
DELIVERY_Objects           143   Destination: shared K8s/container platform

TARGET — ADDITIONS NEEDED
─────────────────────────────────────────────────────────────────────
USER-ACCESS_Objects        TBD   Source: Citrix pools / VPN pools / WLAN / wired
EXTENDED_SERVICE_Objects   TBD   Destination: MQ / Veeam / AppD / ZIA proxy fleet
IOT_Objects                TBD   Source: IoT device subnets (cameras, badges, kiosks)
OT_Objects                 TBD   Source: OT/BMS/SCADA subnets
```

### NET_TYPE Vocabulary — Current vs Target

```
CURRENT NET_TYPE values (selected):
  DataCenter, Corporate, Cloud-Azure, Cloud-GCP, COLO, VPN, DMZ, etc.

NEW NET_TYPE values needed:
  User-Access-VDI      Citrix worker pools, Azure VDI pools
  User-Access-VPN      AnyConnect pools, remote user pools
  User-Access-WLAN     Wireless client subnets
  User-Access-Wired    Corporate wired user subnets
  IoT                  IP cameras, badge readers, ATMs, kiosks, printers
  OT                   SCADA, BMS, HVAC, industrial control systems
```

### Network Group Tier-1 — Current vs Target

```
CURRENT TIER1:
  NG-DATACENTER, NG-CORPORATE, NG-RETAIL, NG-CLOUD, NG-COLO, NG-DR
  NG-CAREPLUS, NG-PARTNER, NG-NAAS-HUB, NG-MINUTECLINIC, NG-OPTICAL
  NG-INTERNET-FACING, NG-VPN-PARTNERS

NEW TIER1 needed:
  NG-USER-ACCESS    All user-facing access networks (VDI/VPN/WLAN/wired)
    Tier-2: NG-USER-ACCESS-CITRIX-SHEA-DC
    Tier-2: NG-USER-ACCESS-CITRIX-RIONE
    Tier-2: NG-USER-ACCESS-VPN-SHEA
    Tier-2: NG-USER-ACCESS-VPN-WDC
    Tier-2: NG-USER-ACCESS-WLAN-[SITE]
  NG-IOT            IoT device subnets
  NG-OT             OT/BMS/SCADA subnets
  NG-ZIA-PROXY      ZIA proxy appliance subnets per site
```

---

## WORKSTREAM 1: preprocess_p1.py — ROUTING FIX

### Current version: v2.6 (deployed June 14, 2026)

### What v2.6 added (complete — do NOT redo):
- ZSCALER-PROXY class: catches zscapl/zscadl/zscam/zscaw/prdusczpa/pzscaler/apianl
- CITRIX-VDI class: ctx*/xen*/pvs*/MCS images (mazp-mcs*/rac2-mcs*)/worker roles (crt/prx/mth/ehy/ce2)
- SHARED-INFRA class: IBM MQ/IIB/Tibco/ACE, Veeam/TSM, DBA mgmt, AppDynamics,
  NTP-Tick, DNS/DHCP, Mail relay, NAS storage, Print, CyberArk/QRadar/Tenable

### Routing correction needed (NOT YET DONE):
The SHARED-INFRA nodes currently route to delivery_infrastructure. This is wrong.
They should route to ent_host_master with a SERVICE_ACRONYM so they become
SERVICE_Objects in the canonical object model — same way CPC services work.

**Required change in preprocess_p1.py:**
For SHARED-INFRA class, instead of `return 'SHARED-INFRA', 'delivery_infrastructure', True`
route to `return 'SHARED-INFRA', 'ent_host_master', True` with SERVICE_ACRONYM
derived from the hostname pattern:

```
Hostname pattern           SERVICE_ACRONYM    CPC group
─────────────────────────────────────────────────────────
*pbmqct* / *ibmmq*        SVC-IBM-MQ         MESSAGING
*iibap* / *tibsrv*        SVC-MIDDLEWARE     MESSAGING
*veeam* / *tsmvar*        SVC-BACKUP         DATA-PROTECTION
*appdl*                   SVC-APPD           MONITORING
*ntp-tick* / *cld-ntp*    SVC-NTP            CORE-INFRA
*dhcpsrv* / *dnsmgr*      SVC-DNS-DHCP       CORE-INFRA
*exchsrv* / *smtprelay*   SVC-MAIL           MESSAGING
*nas-tcg* / *nassrv*      SVC-STORAGE        STORAGE
*printsrv* / *mer-az-print SVC-PRINT         FACILITIES
*cyberark* / *tenablesrv* SVC-SECURITY-INFRA SECURITY
zscapl* / xzscam*         SVC-ZIA-PROXY      NETWORK-SECURITY
```

### IMPORTANT: Citrix VDI endpoints that correctly stay in APM gate:
```
WMER-A*, WCOV-A*, WPDC-A*       Windows VDI endpoints — need app attribution
Wx01*/Wx02*/Wx03*/Wx04*         VDI client endpoints
W2K16*/W2K22*                   Windows master images
_EpicCitrix*                    Epic Citrix template images
replica-*                       VM replica records
```
These are end-user computing assets — do NOT route them to delivery_infrastructure.
They must go through the APM gate to get attributed to their application.

### After routing fix, re-run full pipeline:
```
python3 preprocess_p1.py --dry-run
python3 preprocess_p1.py
python3 update_app.py --enrich-only      # commit enhancements
python3 preprocess_p2.py
python3 update_app.py                    # commit new hosts
```

---

## WORKSTREAM 2: IPAM NET_TYPE PATCH

### Objective
Reclassify user-access and IoT/OT subnets in all_IP_networks from their current
incorrect NET_TYPE (Corporate/DataCenter) to correct user-access types.

### Source data: Copy_of_Users_and_VDI_Networks.xlsx (57 entries)
This file is the authoritative (if imperfect) user network inventory.
Key findings from analysis:
- Only 2 CIDRs completely missing from IPAM: 10.46.211.0/24, 10.46.212.0/22 (Meritain Azure DR-VDI)
- 25 EXACT matches — need NET_TYPE reclassification only
- 25 PARENT BLOCK matches — parent supernet in IPAM, children need reclassification
- 5 CHILD OF matches — subnet of larger IPAM block, needs reclassification

### NET_TYPE mapping from xlsx labels:
```
XLSX LABEL                NET_TYPE target        ROUTING_DOMAIN   NOTES
─────────────────────────────────────────────────────────────────────────────
CVS Azure-VDI             User-Access-VDI         Cloud-Azure      Internal-PBM
CVS Azure PCI-VDI         User-Access-VDI         Cloud-Azure      PCI=Y
CVS on-Prem-VDI           User-Access-VDI         Internal-PBM     On-prem DCs
HCB Azure-VDI             User-Access-VDI         Cloud-Azure      Internal-HCB
HCB on-Prem-VDI           User-Access-VDI         Internal-HCB     On-prem
HCB EMR on-Prem-VDI       User-Access-VDI         Internal-HCB     Epic clinical
HCB VPN User              User-Access-VPN         Internal-HCB     10.56/60.0.0/15
HCB User                  User-Access-Wired       Internal-HCB     10.103.0.0/16
Call Center Remote User   User-Access-VPN         Internal-PBM     10.138.0.0/16
Retail VPN Users          User-Access-VPN         Internal-Retail  10.168.0.0/16
PSS VPN Users             User-Access-VPN         Internal-PBM     10.180.0.0/16
Meritain Azure DR-VDI     User-Access-VDI         Cloud-Azure      HCB subsidiary
CVTY-VDI                  User-Access-VDI         Internal-HCB     Coventry
None (10.20/111/121...)   INVESTIGATE             Unknown          Zscaler breadcrumbs
```

### Specific subnets with WRONG location/type (priority fixes):
```
10.85.108.0/26    stamped VPN/Offshore-Contractor → CVS Azure PCI-VDI (wrong location!)
10.85.172.64/26   stamped VPN/Offshore-Contractor → CVS Azure PCI-VDI (wrong location!)
10.85.174.0/23    stamped VPN/Offshore-Contractor → CVS Azure PCI-VDI (wrong location!)
10.118.228.0/22   stamped DataCenter/Shea → CVS on-Prem-VDI (NET_TYPE wrong)
10.118.232.0/21   stamped DataCenter/Shea → CVS on-Prem-VDI (NET_TYPE wrong)
10.220.120.0/21   stamped DataCenter/RI → CVS on-Prem-VDI (NET_TYPE wrong)
10.220.192.0/21   stamped DataCenter/RI → CVS on-Prem-VDI (NET_TYPE wrong)
10.214.128.0/20   stamped DataCenter/Shea → CVS on-Prem-VDI (NET_TYPE wrong)
10.214.120.0/21   stamped DataCenter/Shea → CVS on-Prem-VDI (NET_TYPE wrong)
```

### ZPA App Connector subnet (add to IPAM):
```
10.105.17.0/24    NET_TYPE=ZPA-CONNECTOR   Windsor CT - Aetna WDC   Internal-HCB
                  8 App Connector nodes confirmed: prdusczpa1/2, pzscalerzx03-08
```

### Script to build: patch_net_type_user_access.py
Read Copy_of_Users_and_VDI_Networks.xlsx + all_IP_networks → produce
patch CSV for ipam-db.py --update-patch. Must:
- Normalize CIDRs (strip spaces)
- Map labels to NET_TYPE using table above
- For PARENT BLOCK matches: find all child /24s in IPAM and reclassify each
- Flag None-labelled entries as User-Access-Unknown for Zscaler forensics
- Output: user_network_net_type_patch_vDATE.csv
- Dry-run mode: show changes without writing

### After patch:
```
python3 ipam-db.py --update-patch ipam-db/user_network_net_type_patch_vDATE.csv --dry-run
python3 ipam-db.py --update-patch ipam-db/user_network_net_type_patch_vDATE.csv
python3 ipam-db.py --cross-check   # 0 HIGH required
```

---

## WORKSTREAM 3: CPC-CORE-SERVICES EXPANSION

### Current state: v20260605, 859 rows, 46 AD domain objects + NTP/DNS/Splunk/Qualys

### What needs to be added to build_cpc_core_services.py:
```
SERVICE GROUP          SERVICE_ACRONYM     SOURCE HOSTS           COUNT
──────────────────────────────────────────────────────────────────────────
IBM MQ brokers         SVC-IBM-MQ          *pbmqct*, *ibmmq*       ~45
IIB/ACE/Tibco          SVC-MIDDLEWARE      *iibap*, *tibsrv*       ~30
Veeam nodes            SVC-VEEAM           *veeam*                 ~20
TSM/backup             SVC-TSM             *tsmvar*, *tsmsvr*      ~17
AppDynamics            SVC-APPD            *appdl*, *appdsvr*      ~18
ZIA proxy appliances   SVC-ZIA-PBM         eri2zscapl*/paz1zscapl* 121
ZIA proxy nodes (HCB)  SVC-ZIA-HCB         xzscam*/xzscaw*        120
ZPA App Connectors     SVC-ZPA             prdusczpa*/pzscaler*      8
Print servers          SVC-PRINT           *printsrv*, *mer-az-*    ~5
```

### These SERVICE_Objects are DESTINATION objects in FW rules:
- Rule: src=NG-DATACENTER-SHEA dst=SVC-IBM-MQ port=1414
- Rule: src=NG-USER-ACCESS dst=SVC-ZIA-PBM port=9400 (ZIA proxy enrollment)

### After CPC expansion:
```
python3 build_cpc_core_services.py
python3 ipam-db.py --import ... --type CPC-CORE-SERVICES
```

---

## WORKSTREAM 4: build_canonical_app_objects.py — ADD USER_ACCESS CLASS

### Current version: v1.5.6 — builds APP/INFRA/SERVICE/DELIVERY objects

### New object class: USER_ACCESS_Objects

Grouped by site × access-method from:
- all_IP_networks WHERE NET_TYPE IN ('User-Access-VDI','User-Access-VPN',
  'User-Access-WLAN','User-Access-Wired','IoT','OT')
- ent_host_master WHERE platform_class = 'CITRIX-VDI'
- VPN-RA-GROUPS dataset (when populated)

### Object naming convention:
```
USER-ACCESS-CITRIX-SHEA-DC     Citrix worker pool at Shea DC
USER-ACCESS-CITRIX-RIONE       Citrix worker pool at RI One
USER-ACCESS-CITRIX-MDC         Citrix farm at Middletown
USER-ACCESS-CITRIX-WDC         Citrix farm at Windsor
USER-ACCESS-CITRIX-PHOENIX     Citrix farm at Phoenix (Aetna)
USER-ACCESS-CITRIX-HARTFORD    Citrix farm at Hartford (Aetna)
USER-ACCESS-VPN-SHEA           AnyConnect pool at Shea (PBM users)
USER-ACCESS-VPN-WDC            AnyConnect pool at Windsor (HCB users)
USER-ACCESS-VPN-HCB-LARGE      10.56.0.0/15 + 10.60.0.0/15 (huge HCB pools)
USER-ACCESS-VPN-RETAIL         Retail VPN 10.168.0.0/16
USER-ACCESS-VPN-PSS            PSS VPN 10.180.0.0/16
USER-ACCESS-VPN-CALLCENTER     Call Center Remote 10.138.0.0/16
USER-ACCESS-WLAN-[SITE]        Wireless client pools per site
USER-ACCESS-WIRED-HCB          HCB wired user 10.103.0.0/16
USER-ACCESS-AZURE-VDI-PBM      CVS Azure VDI 10.98.0.0/16 etc.
USER-ACCESS-AZURE-VDI-HCB      HCB Azure VDI 10.141-142.0.0/16 etc.
```

### These USER-ACCESS_Objects are SOURCE objects in FW rules:
- Rule: src=USER-ACCESS-CITRIX-SHEA dst=APP-RXCONNECT port=8080,443
- Rule: src=USER-ACCESS-VPN-WDC dst=APP-HEALTHRULES port=443
- Rule: src=USER-ACCESS-AZURE-VDI-PBM dst=APP-MINUTECLINIC port=443,8443

### Build sequence change in build_canonical_app_objects.py:
Add section 10: Build USER_ACCESS_Objects from IPAM user-access NET_TYPE subnets
After section 9 (existing IPAM enrichment).

---

## WORKSTREAM 5: build_network_groups.py — ADD USER-ACCESS TIER

### Current version: v1.8.4

### New TIER1_TAXONOMY entries needed:

Add to TIER1_TAXONOMY mapping:
```python
'User-Access-VDI':    'NG-USER-ACCESS',
'User-Access-VPN':    'NG-USER-ACCESS',
'User-Access-WLAN':   'NG-USER-ACCESS',
'User-Access-Wired':  'NG-USER-ACCESS',
'IoT':                'NG-IOT',
'OT':                 'NG-OT',
'ZPA-CONNECTOR':      'NG-ZIA-PROXY',
```

### Tier-2 grouping for NG-USER-ACCESS:
Unlike NG-DATACENTER (grouped by SITE_CODE), USER-ACCESS groups by
ACCESS_METHOD × SITE:
```
NG-USER-ACCESS-CITRIX-SHEA-DC
NG-USER-ACCESS-CITRIX-RIONE
NG-USER-ACCESS-CITRIX-MDC
NG-USER-ACCESS-CITRIX-WDC
NG-USER-ACCESS-CITRIX-PHOENIX
NG-USER-ACCESS-CITRIX-HARTFORD
NG-USER-ACCESS-VPN-SHEA
NG-USER-ACCESS-VPN-WDC
NG-USER-ACCESS-AZURE-VDI-PBM
NG-USER-ACCESS-AZURE-VDI-HCB
NG-USER-ACCESS-VPN-RETAIL
NG-USER-ACCESS-VPN-LARGE-HCB
```

Tier-2 key derivation: NET_TYPE + CANONICAL_LOCATION SITE_CODE
(e.g. User-Access-VDI + US_SCO_AZ_DC → NG-USER-ACCESS-CITRIX-SHEA-DC)

### IoT/OT tier:
Simple — NG-IOT and NG-OT with Tier-2 by site (when data is available).
Initially sparse — will grow as Zscaler breadcrumb analysis identifies subnets.

---

## WORKSTREAM 6: build_service_objects.py — ADD SERVICE OBJECTS

### Current version: v1.0.3

### New service object sources:
After CPC-CORE-SERVICES expansion (Workstream 3), build_service_objects.py
will automatically pick up the new SVC-IBM-MQ, SVC-ZIA-PBM, etc. entries
since it reads from CPC-CORE-SERVICES.

### New DELIVERY_Objects needed — ZIA proxy fleet per site:
```
ZIA-PBM-RIONE      eri2zscapl10-26v (26 nodes)  10.249.28.x, 10.228.166.x
ZIA-PBM-SHEA       paz1zscapl10-24v (24 nodes)  10.124.190.x, 10.249.152.x
ZIA-PBM-SHEA-EXT   eaz1zscapl10-26v (26 nodes)  10.249.152.x, 10.217.188.x
ZIA-HCB-MDC        xzscam02-38p     (37 nodes)  10.102.9.x, 10.102.29.x
ZIA-HCB-WDC        xzscaw02-38p     (38 nodes)  10.102.9.x, 10.102.25.x, 10.102.128.x
ZIA-AZURE-PBM      eac2/4zscapl*    (17 nodes)  10.155.x, 10.223.x
ZIA-GCP            egc1/2/4zscapl*  (13 nodes)  10.236.x
ZPA-CONNECTORS-WDC prdusczpa1/2 + pzscalerzx03-08 (8 nodes) 10.105.17.x
```

---

## WORKSTREAM 7: CSNA HOSTGROUPS REBUILD

### Current version: v4.0.1 (STALE against EHM r16)

### Must run AFTER all workstreams above complete:
```
python3 build_csna_site_registry.py    # rebuild registry against current LM
python3 generate_csna_hostgroups.py    # rebuild against EHM r16+
```

### New host group paths needed:
```
/Root/User-Access/CVS-PBM/Citrix/Shea-DC/
/Root/User-Access/CVS-PBM/Citrix/RI-One/
/Root/User-Access/CVS-PBM/VPN/Shea/
/Root/User-Access/HCB/Citrix/Hartford/
/Root/User-Access/HCB/Citrix/Phoenix/
/Root/User-Access/HCB/VPN/Windsor/
/Root/Services/ZIA-Proxy/PBM/RI-One/
/Root/Services/ZIA-Proxy/HCB/Windsor/
/Root/Services/ZIA-Proxy/HCB/Middletown/
```

---

## WORKSTREAM 8: FULL OBJECT PIPELINE REBUILD

### After all above complete, run the full object pipeline:
```
python3 build_app_subnet_index.py
python3 ipam-db.py --import app-inventory/app_subnet_index_vDATE.csv --type app_subnet_index
python3 build_canonical_app_objects.py     # now includes USER_ACCESS_Objects
python3 ipam-db.py --import processed_outputs/canonical_app_objects_vDATE.csv --type CANONICAL-APP-OBJECTS
python3 build_object_pipeline.py --edl     # network groups + service objects + EDL catalog
```

### Expected new object counts (approximate):
```
APP_Objects          2,698  (unchanged)
INFRA_Objects           78  (unchanged)
SERVICE_Objects        ~200  (was 57 — +MQ/Veeam/AppD/ZIA/ZPA/Print)
DELIVERY_Objects       ~160  (was 143 — +ZIA fleet per site)
USER_ACCESS_Objects    ~25   (NEW — Citrix/VPN/WLAN/wired grouped by site)
```

---

## DEPENDENCY ORDER (STRICT)

```
Step 1:  Fix preprocess_p1.py SHARED-INFRA routing (WS-1)
Step 2:  Re-run preprocess_p1 → p2 → update_app (full pipeline)
Step 3:  Build patch_net_type_user_access.py (WS-2)
Step 4:  Apply NET_TYPE patch → ipam-db.py --update-patch
Step 5:  ipam-db.py --cross-check (0 HIGH gate)
Step 6:  Expand build_cpc_core_services.py (WS-3)
Step 7:  Rebuild CPC-CORE-SERVICES, import to ipam-db
Step 8:  Add USER_ACCESS class to build_canonical_app_objects.py (WS-4)
Step 9:  Add NG-USER-ACCESS to build_network_groups.py (WS-5)
Step 10: Update build_service_objects.py for ZIA fleet (WS-6)
Step 11: Rebuild app_subnet_index
Step 12: Rebuild canonical_app_objects (includes USER_ACCESS)
Step 13: Run build_object_pipeline.py --edl (network groups + service objects)
Step 14: Rebuild CSNA hostgroups (WS-7)
Step 15: Rebuild EDL catalog
```

---

## DATA GAPS — BLOCKING OR DEFERRED

### Blocking (cannot complete without):
```
Cisco ASA configs for Shea + Windsor VPN concentrators
→ Needed for: RA VPN pool ranges (VPN-RA-GROUPS dataset population)
→ Without this: USER-ACCESS-VPN objects will use xlsx data only (incomplete)
→ Ask: Cisco NMS team / Windsor/Shea network ops for running-config exports

WLAN controller export (per-site SSID-to-VLAN-to-subnet mapping)
→ Needed for: User-Access-WLAN NET_TYPE classification
→ Without this: wireless client subnets remain in Corporate/unknown
→ Ask: Wireless team for WLC subnet export
```

### Deferred (Zscaler breadcrumb approach):
```
None-labelled user networks (10.20/111/121/31.x)
→ Will be identified over time through Zscaler flow analysis
→ As Zscaler topology snapshots accumulate, source subnets with high
  user-pattern traffic (many IPs, many destinations, browser-class apps)
  can be flagged as User-Access candidates
→ No immediate action required — these stay as Corporate for now

IoT/OT subnet identification
→ No formal network segmentation exists at CVS
→ NDM/switch VLAN data needed for definitive classification
→ Defer — use Zscaler breadcrumb to identify IoT patterns over time
```

---

## CONTEXT: WHY THIS MATTERS FOR FIREWALL RULES

Once this object model is complete, the firewall rule translation pipeline
(WS-9 enrich_vpn_flows.py, WS-10 generate_fw_consolidation_report.py) can
produce meaningful rule recommendations:

```
BEFORE (current state):
  Rule 4821: src=any dst=any app=any action=allow [useless]

AFTER (with complete object model):
  Rule 4821: src=USER-ACCESS-CITRIX-SHEA dst=APP-RXCONNECT
             app=ssl port=443 action=allow [meaningful]

  Rule 7203: src=NG-DATACENTER-SHEA dst=SVC-IBM-MQ
             app=ssl port=1414 action=allow [meaningful]

  Rule 9041: src=USER-ACCESS-VPN-WDC dst=APP-HEALTHRULES
             app=ssl port=443 action=allow [meaningful]
```

The Cisco MPE POC (WS-9, July 30 gate) and FW consolidation report
(WS-10, July 30 gate) both depend on this object model being complete.

---

## FILES PRODUCED THIS SESSION (June 14, 2026)

Available in ~/Downloads after download:

```
preprocess_p1.py v2.6              DEPLOY TO ~/Documents/IP_Lookup/
build_citrix_inventory.py v1.0.0   DEPLOY TO ~/Documents/IP_Lookup/
CCD_Pipeline_Architecture_v3_0.docx
CCD_FW_Topology_Pipeline_v1_0.docx
CCD_Pipeline_Command_Tree_v3_0.txt
CCD_Object_Model_Revamp_Prompt_v1_0.md  ← THIS FILE
```

### Deploy preprocess_p1.py v2.6 immediately:
```bash
cp ~/Downloads/preprocess_p1.py ~/Documents/IP_Lookup/
python3 preprocess_p1.py --dry-run
python3 preprocess_p1.py
python3 update_app.py --enrich-only
python3 preprocess_p2.py
python3 update_app.py
python3 build_app_subnet_index.py
python3 ipam-db.py --import app-inventory/app_subnet_index_vDATE.csv --type app_subnet_index
python3 build_canonical_app_objects.py
python3 ipam-db.py --import processed_outputs/canonical_app_objects_vDATE.csv --type CANONICAL-APP-OBJECTS
```

---

## QUICK-START FOR NEXT SESSION

Upload to new chat:
1. This file (CCD_Object_Model_Revamp_Prompt_v1_0.md)
2. preprocess_p1.py (current deployed version from ~/Documents/IP_Lookup/)
3. build_canonical_app_objects.py
4. build_network_groups.py
5. build_service_objects.py
6. build_cpc_core_services.py
7. all_IP_networks_vDATE.csv (latest)
8. Copy_of_Users_and_VDI_Networks.xlsx
9. ent_host_master_vDATE.csv (latest r16+)

Start next session with:
> "Read CCD_Object_Model_Revamp_Prompt_v1_0.md and the uploaded scripts.
>  Start with Workstream 1: fix the SHARED-INFRA routing in preprocess_p1.py,
>  then build patch_net_type_user_access.py for Workstream 2."

---
*CCD Platform | CVS Health Information Security | June 14, 2026*
*M. J. Martin, Lead Director Information Security*
