---
name: ccd-host-ingest-pipeline
description: CCD Platform host ingest pipeline — preprocess_p1.py, preprocess_p2.py, update_app.py, update_infrastructure.py, update_platform.py, update_network.py, update_ipam.py. Full ingest cycle, classification logic, stage gates, ADL auto-discovery, terminal output discipline, and all confirmed bugs fixed. Use whenever asked about host ingest, preprocess, enhancement workflow, unresolved files, or the update_*.py scripts. Read before modifying any of these scripts or proposing a run order.
sources: [chat]
aliases: [preprocess_p1, preprocess_p2, update_app, update_infrastructure, update_platform, update_network, update_ipam, host_ingest, ehm, delivery_infrastructure, delivery_platform, ent_host_master]
---

# CCD Platform — Host Ingest Pipeline

**Last confirmed:** 2026-08-23 (Yggdrasil, full cycle completed end-to-end)

---

## Current Script Versions

| Script | Version | Notes |
|--------|---------|-------|
| `preprocess_p1.py` | v2.12.4 | IPAM candidate pre-filter added |
| `preprocess_p2.py` | v1.6.4 | SUGGESTED_MASTER priority, PROXY tightened |
| `update_app.py` | v1.19 | ADL date-sort fix, next step corrected |
| `update_infrastructure.py` | v1.2.6 | old_ver fix, next step corrected |
| `update_platform.py` | v1.2.6 | old_ver fix, Ingest cycle complete |
| `update_network.py` | v1.7 | Before→After output |
| `update_ipam.py` | v1.17 | Before→After output |
| `ccd_host_enrichment.py` | v1.1.0 | Shared library — ADL date-sort fix |

---

## Pipeline Overview

The host ingest pipeline processes application, infrastructure, and platform hosts
from Risk Registry, APM, CMDB, and Qualys sources into three registered datasets:

```
Sources: Risk Registry / APM / CMDB / Qualys / ADL
         ↓
preprocess_p1.py  ── matches known hosts → ent_host_master (no action)
                  ── enhances gap fields → update_app / infra / platform
                  ── new hosts → preprocess_p2.py
                  ── IPAM gaps → update_ipam.py
                  ↓
preprocess_p2.py  ── classifies new hosts by SUGGESTED_MASTER
                  ── routes to: update_app / infra / platform / network
                  ↓
update_app.py           → ent_host_master
update_infrastructure.py → delivery_infrastructure
update_platform.py      → delivery_platform
update_network.py       → ent_network_device_master (rare — see warning)
update_ipam.py          → all_IP_networks
```

---

## Full Run Sequence

### Prerequisites (already run by NMS pipeline)
```bash
python3 build_nms_db.py
python3 commit_nms.py
```

### Pass 1
```bash
python3 preprocess_p1.py
```

Outputs two sections:

**RUN NOW** (no review needed, run immediately):
```bash
python3 update_ipam.py          # if ipam_candidates > 0
python3 build_nms_db.py         # if IPAM was updated (rebuild NDM with new subnets)
python3 commit_nms.py           # if NDM was rebuilt
```

**REVIEW REQUIRED** (review the enhancement file before running):
```bash
# Review p1_ehm_enhancement_{date}.csv first
python3 update_app.py

# Review p1_infra_enhancement_{date}.csv first  
python3 update_infrastructure.py

# Review p1_platform_enhancement_{date}.csv first
python3 update_platform.py
```

### Pass 2
```bash
python3 preprocess_p2.py
```

Outputs RUN NOW showing only non-zero candidate counts:
```bash
python3 update_app.py           # app_candidates_{date}.csv
python3 update_infrastructure.py # infra_candidates_{date}.csv
python3 update_platform.py      # platform_candidates_{date}.csv (last — prints "Ingest cycle complete")
```

---

## preprocess_p1.py — Pass 1

### What it does
Compares all source records (63,061 in 2026-08-23 run) against registered datasets:

| Result | Count (2026-08-23) | Action |
|--------|-------------------|--------|
| MATCHED | 55,690 (88%) | No action — host already known |
| ENHANCEMENT | 516 (1%) | Gap-fill fields → update_*.py --enrich-only |
| NEW | 6,855 (10%) | Unknown hosts → preprocess_p2.py |
| NO IPAM COVERAGE | 1,327 | → p1_no_ipam_hosts (cannot locate) |
| UNRESOLVED (no APM gate) | 4,684 | → quarantined ent-ipdataset-*-UNRESOLVED files |

### IPAM Candidate Pre-Filter (v2.12.4)
`check_ipam_coverage()` pre-filters before generating candidates:
1. Link-local `169.254.x.x` — skip
2. Loopback `127.x.x.x` — skip
3. `/24 already in all_IP_networks` — LPM check on network address

**Confirmed real (2026-08-23):** 138 candidates → 24 after filter. 114 were multi-homed
hosts where a secondary IP's /24 was already registered from a different host IP.

### Unresolved Host Files (quarantined)
Hosts that failed the APM gate — no application attribution. Registered in ipam-db:

| File | Rows | Description |
|------|------|-------------|
| `ent-ipdataset-OTHER-INT-ENT-HOST-UNRESOLVED` | 3,406 | Cloud/Colo, no APM |
| `ent-ipdataset-PBM-INT-ENT-HOST-UNRESOLVED` | 787 | CVS PBM internal |
| `ent-ipdataset-INTERNET-FACING-UNRESOLVED` | 280 | Internet-facing |
| `ent-ipdataset-HCB-INT-ENT-HOST-UNRESOLVED` | 211 | Aetna internal |

Schema includes `RESOLUTION_METHOD`, `RESOLUTION_DATE`, `NOTES` columns for tracking.
These need to be imported after each cycle — they go stale otherwise.
Resolution requires APM registration or manual business unit assignment.

---

## preprocess_p2.py — Pass 2

### classify_device() Priority Order (v1.6.4)

**Priority 1: SUGGESTED_MASTER field — always wins**
```
delivery_infrastructure  → infrastructure candidates
delivery_platform        → platform candidates  
ent_network_device_master → network candidates
ent_host_master          → application candidates
```

**Priority 2: Marker matching** (only fires when SUGGESTED_MASTER is blank)

```python
INFRA_MARKERS   = ['VMWARE', 'ESXI', 'ESX SERVER', 'HMC', 'IBM HMC', 
                   'ISERIES', 'ZOS', 'MAINFRAME', 'DATAPOWER', 'ISILON', ...]
PLATFORM_MARKERS = ['KUBERNETES', 'K8S', 'OPENSHIFT', 'OCP', 'DOCKER', ...]
NETWORK_MARKERS  = ['BLUECOAT', 'NETWORK CONSOLE', 'F5-VIP', 'FIREWALL',
                   'PROXY APPLIANCE', 'WEB PROXY', 'FORWARD PROXY']
```

**Confirmed real bugs fixed (2026-08-23):**

Bug 1: 40 Windows servers (`mvmt*/wvmt*` Aetna VMs) routed to `network_candidates`
- Root cause: `APP_NAMES: AAD Application proxy` matched bare `PROXY` marker
- `SUGGESTED_MASTER=delivery_infrastructure` was not being checked first
- Fix: SUGGESTED_MASTER checked before any marker matching (v1.6.3)

Bug 2: 4 Palo Alto Panorama servers (`paz1panapw*`, `pri2panapw*`) routed to network
- Root cause: `APP_NAMES: Palo Alto Networks Cloud Firewall` matched `FIREWALL` marker
- `SUGGESTED_MASTER=ent_host_master` was being ignored
- Fix: `ent_host_master` → application added to SUGGESTED_MASTER routing (v1.6.4)

Bug 3: Bare `PROXY` in NETWORK_MARKERS too broad
- Matched 'AAD Application proxy', 'Reverse Proxy' app names
- Fix: replaced with `PROXY APPLIANCE`, `WEB PROXY`, `FORWARD PROXY` (v1.6.3)

### Stage 2 Gate
`preprocess_p2.py` is blocked until all stage2_required stems are committed:
```
✓  ent_host_master       fills committed
✓  delivery_platform     fills committed
→  All Stage 2 commitments complete — safe to run p2.
```
If blocked: run `update_app.py --enrich-only` and `update_platform.py --enrich-only`

### Output (2026-08-23 confirmed)
```
844 new hosts processed
  249 → app_candidates       (update_app.py)
  418 → infra_candidates     (update_infrastructure.py)
  177 → platform_candidates  (update_platform.py)
    0 → network_candidates   (should always be 0 after classifier fix)
    0 → location_candidates
    0 → ipam_candidates
    0 → unmapped
  100% location coverage
```

---

## update_app.py — EHM Updates

**Feeds:** `ent_host_master` (64,577 rows, v20260823r4)

**Two modes:**
- `--enrich-only` — applies p1 enhancement fills only, no new hosts
- Default — applies enhancements + adds new app_candidates from p2

**ADL auto-discovery (v1.19):** Scans `IP_Datasets_Raw/APP_DATA-*/ADL_Application_Info_Report_*.csv`.
Sorts by **date in filename** (M-D-YYYY pattern), not mtime.

**Confirmed real bug (2026-08-23):** July 15 ADL selected over August 7 because July 15
had a later mtime (re-extracted after Aug 7 file was already present). Fix: `_date_key()`
extracts month/day/year from filename. Handles single-digit month/day (APP_DATA-8-7).

**Downstream trigger:** After EHM update, `ipam-db.py` prompts to rebuild
`app_subnet_index` via `build_app_subnet_index.py`. This is correct — always run it.

**Next step:** `python3 update_infrastructure.py`

---

## update_infrastructure.py — Delivery Infrastructure

**Feeds:** `delivery_infrastructure` (6,190 rows after 2026-08-23 cycle, was 5,772)

**ADL auto-discovery:** Via `ccd_host_enrichment.py` shared library v1.1.0 (same date-sort fix).

**Confirmed real bug (2026-08-23):** `old_ver` NameError — variable used in Before→After
summary but never defined. Fixed: captured from master_path filename via regex at load time.

**Next step:** `python3 update_platform.py`

---

## update_platform.py — Delivery Platform

**Feeds:** `delivery_platform` (2,052 rows after 2026-08-23 cycle, was 1,875)

**ADL auto-discovery:** Via `ccd_host_enrichment.py` shared library v1.1.0.

**Next step:** `Ingest cycle complete.` (last script in p2 update sequence)

---

## update_network.py — WARNING

**Do NOT use for adding hosts to NDM.** This script writes directly to the registered
NDM CSV, bypassing `nms_db.sqlite`. Devices added this way are unknown to `build_nms_db.py`
and will be flagged as ACTIVE_DELETED (BLOCKED) on the next diff.

**Confirmed real (2026-08-23):** 40 hosts routed to network_candidates by p2 classifier
bug. Would have caused 40 BLOCKED devices on next NMS build. Fix was in p2 classifier
(SUGGESTED_MASTER priority) — network_candidates should always be 0 after v1.6.4.

**Architectural gap:** If `update_network.py` must be used, the device needs to also be
written to `raw_host_master` in `nms_db.sqlite` so `build_nms_db.py` knows about it.
This is deferred — fix the p2 classifier instead.

---

## update_ipam.py — IPAM Candidate Import

**Feeds:** `all_IP_networks` (25,705 rows as of 2026-08-23)

**When to run:** Only when `preprocess_p1.py` produces non-zero `ipam_candidates`.

**Validation gates:**
- `DUPLICATE` — /24 already in all_IP_networks (most common rejection — 114/138 in 2026-08-23)
- `R8-RETAIL-COVERAGE` — 172.16.0.0/12 already covered by retail aggregate
- `CX1-CONTAINS-CONFLICT` — would create /24 parent conflicting with existing more-specific

**After running:** Rebuild NDM to pick up new subnets:
```bash
python3 build_nms_db.py
python3 commit_nms.py
```

---

## ADL Auto-Discovery — Shared Fix

Both `update_app.py` (inline) and `ccd_host_enrichment.py` (shared library, used by
`update_infrastructure.py` and `update_platform.py`) now sort ADL files by date in
filename, not mtime.

**Pattern:** `M-D-YYYY` or `MM-DD-YYYY` in filename. Falls back to `APP_DATA-M-D` directory
name. Handles single-digit month/day (APP_DATA-8-7 common in CVS/Aetna naming).

**Deploy both files when updating:** `ccd_host_enrichment.py` + `update_app.py`

---

## ipam-db.py Downstream Chain — Known Removals (v3.35.0, v3.36.0)

These were removed from automatic next-step prompts — they are downstream consumers
that run on their own cadence, NOT rebuild steps:

- `generate_csna_hostgroups.py` — CSNA is a consumer of IPAM data
- `generate_fw_rule_report.py` — requires `--log` with FW log files
- Self-referential `app_subnet_index` re-import from `ent_host_master` chain

---

## Terminal Output Pattern (all scripts)

Every script follows Before → After → Next step (Rule 7, ccd-versioning-discipline):
```
──────────────────────────────────────────────────────────────
  Before  :  ent_host_master_v20260823r1.csv
  After   :  ent_host_master_v20260823r2.csv
──────────────────────────────────────────────────────────────

  Next step: python3 update_infrastructure.py
```

Verbose/debug output belongs behind `--verbose`. Normal run shows state only.

---

## Known Remaining Gaps (2026-08-23)

- `nms_lm_crosscheck_v20260823.csv` — 992 MEDIUM gaps, not imported
- `nms_unclassified_v20260823.csv` — 21 rows for review
- `p1_no_ipam_hosts` — 1,327 hosts with no IPAM coverage
- `p1_unattributed_subnet_report` — 14,349 hosts across 30 sites
- `ent-ipdataset-*-UNRESOLVED` files — 4,684 quarantined hosts, stale in ipam-db
- RISK_TIER: EDR, AppEx, T1, T2 not in `RISK_PRIORITY` in `build_app_subnet_index.py`
- ADL data freshness: check `IP_Datasets_Raw/APP_DATA-*/` for latest export date
