# CCD Platform — EDL Dataset & Object Pipeline Reference

**CVS Health Information Security — CCD Platform**
Last updated: 2026-06-24

---

## 1. Overview

The CCD object pipeline produces four distinct EDL (External Dynamic List) dataset families from the IPAM and host master datasets. Each family serves a different role in Palo Alto Networks firewall policy:

| Family | Source script | Palo Alto role | Count (v20260623) |
|--------|--------------|----------------|-------------------|
| **Network Groups (NG)** | `build_network_groups.py` | Policy source side — "where is the traffic coming from?" | 727 EDL files |
| **Service Objects (SO)** | `build_service_objects.py` | Policy destination side — "what application/server is being reached?" | 3,213 EDL files |
| **Cloud Services (IPDATASET)** | `build_ipdataset_objects.py` | External provider IP blocks for allow/block policy | 810 EDL files |
| **Geo-Block** | `build_geo_block_objects.py` | Country-based IP block lists | 14 EDL files (13 countries + ALL) |

All four families are assembled by `build_object_pipeline.py` and browsable via `edl_catalog.html` (served by `object-viewer-web-service.sh`).

---

## 2. Filesystem Layout

```
~/Documents/IP_Lookup/
│
├── Net_Group/
│   └── NG-{DATE}_v{N}/               # e.g. NG-20260623_v4
│       ├── EDL/                       # One .txt per network group object
│       │   ├── AO-{NAME}.txt          # Address Object: /32 host lists
│       │   └── NG-{NAME}.txt          # Network Group: subnet summaries
│       └── ccd_network_groups.set     # Panorama CLI import bundle
│
├── Net_Object/
│   ├── SO-{DATE}_v{N}/               # e.g. SO-20260623_v4
│   │   ├── EDL/                       # One .txt per service object
│   │   │   ├── APP_{ACRONYM}_{BU}.txt
│   │   │   ├── SVC_{NAME}_{BU}.txt
│   │   │   ├── DELIVERY_{NAME}.txt
│   │   │   ├── INFRA_{TYPE}_{SITE}.txt
│   │   │   └── NG-SVC-*.txt           # Aggregate super-groups
│   │   └── service_objects_v{DATE}.set  # Panorama CLI import bundle
│   │
│   └── IPDATASET-v{DATE}/            # Run-date versioned (not data-date)
│       ├── edl/                       # lowercase — Cloud Services EDLs
│       │   ├── {PROVIDER}-{SCOPE}.txt  # e.g. AZURE-US-ALL.txt
│       │   └── GEO-BLOCK-{CC}.txt      # e.g. GEO-BLOCK-CN.txt
│       ├── ipdataset_manifest_v{DATE}.csv
│       ├── ipdataset_objects_v{DATE}.set
│       ├── geo_block_manifest_v{DATE}.csv
│       └── geo_block_objects_v{DATE}.set
│
└── FW-Egress_Out/                     # Output dir for egress topology scripts
```

**Critical path note:** NG and SO use uppercase `EDL/`; IPDATASET uses lowercase `edl/`. The catalog JavaScript and `collect-edl_bundle.sh` both depend on this distinction.

---

## 3. Network Groups (NG)

### 3.1 Purpose

Network Groups represent the **source side** of firewall policy. They answer: *"Which enterprise location is this traffic coming from?"* Each object is a location-scoped collection of IPAM subnets associated with a specific site or business unit.

### 3.2 Three-Tier Hierarchy

The NG model is strictly hierarchical. CIDRs live only at Tier 3; Tiers 1 and 2 are aggregating groups.

```
Tier 1 — Business Unit / Site Type
  e.g. NG-BU-DATACENTER, NG-BU-CORPORATE, NG-BU-RETAIL

Tier 2 — Location
  e.g. NG-CORAM-COLUMBIA-SC-CORAM  (subnets for Coram Columbia SC)

Tier 3 — Address Object (leaf CIDR list)
  AO-CORAM-COLUMBIA-SC-CORAM  (the actual /24s and /25s)
```

The `.set` file reflects this: Tier-3 address objects are defined first (`set address addr-…`), then assembled into Tier-2 address-groups, which are assembled into Tier-1 groups.

### 3.3 Object Naming Conventions

| Prefix | Meaning | Example |
|--------|---------|---------|
| `AO-{BU}-{CITY}-{ST}-{TYPE}` | Address Object — leaf CIDR list for one location | `AO-CORAM-COLUMBIA-SC-CORAM` |
| `NG-{BU}-{CITY}-{ST}-{TYPE}` | Network Group — references one or more AOs | `NG-CORAM-COLUMBIA-SC-CORAM` |
| `AO-AWS`, `AO-AZURE`, `AO-GCP` | Cloud routing domain aggregates | `AO-AWS` |
| `NG-DR-{SITE}` | DR site groups | `NG-DR-SPARKS-NV-SWITCH-TRE` |

The CITY and STATE fields derive from `CANONICAL_LOCATION` in `location_master`. The TYPE field is `LOCATION_TYPE` (e.g. CORAM, CAREPLUS, CALL-CENTER, OMNICARE).

### 3.4 EDL File Format

```
# AO-CORAM-COLUMBIA-SC-CORAM
# Export Date: 2026-06-23
# Source: CCD Platform build_network_groups.py v1.8.4
# Subnets: 5
# Tier: 3
#
10.49.232.128/25
10.49.152.0/24
...
```

One CIDR per line. Comments only in the header block.

### 3.5 Panorama Import

`ccd_network_groups.set` contains the full Panorama CLI command sequence:

1. `set address addr-{cidr}` — defines leaf address objects (Tier 3)
2. `set address-group {AO-name} static [...]` — assembles Tier-3 groups
3. `set address-group {NG-name} static [...]` — assembles Tier-2 aggregates
4. `set address-group {BU-name} static [...]` — assembles Tier-1 super-groups

Import with: `load config partial from ccd_network_groups.set`

### 3.6 Generating

```bash
# Full run (from IP_Lookup base dir)
python3 build_network_groups.py --dry-run
python3 build_network_groups.py

# Pipeline stage 1
python3 build_object_pipeline.py  # runs stages 0–8 in sequence
```

---

## 4. Service Objects (SO)

### 4.1 Purpose

Service Objects represent the **destination side** of firewall policy. They answer: *"What application server or infrastructure component is being reached?"* Each object is a named collection of /32 host IPs belonging to a specific application or service, scoped to a business unit.

### 4.2 Object Classes

| Prefix | Class | Source | Example |
|--------|-------|--------|---------|
| `APP_{ACRONYM}_{BU}` | Application | `ent_host_master` + `app_subnet_index` | `APP_SPLUNKENTNONPCI_AZ` |
| `SVC_{NAME}_{BU}` | Infrastructure Service | CPC core services dataset | `SVC_AD_CORP_CVS_CVS` |
| `DELIVERY_{NAME}` | Platform Delivery | Delivery infrastructure dataset | `DELIVERY_SHARED_APP_PBM_SHEA` |
| `INFRA_{TYPE}_{SITE}` | Physical Infrastructure | ESXi/IBM HW inventory | `INFRA_ESXI_SHEA_PROD` |
| `NG-SVC-*` | Aggregate super-groups | Assembled from above | `NG-SVC-APP`, `NG-SVC-CPC` |

BU suffix values: `PBM` (Internal-PBM / CVS Caremark), `HCB` (Internal-HCB / Aetna), `AZ` (Azure), `GCP`, `AWS`, `COLO`, `INTERNET`, `RETAIL`, `UNKNOWN`.

### 4.3 EDL File Format

```
# APP_SPLUNKENTNONPCI_AZ
# Tier: 3
# Class: APP
# Generated by build_service_objects.py v1.0.5
# CIDRs: 11
10.74.9.37/32
10.74.9.38/32
...
```

All entries are /32 host addresses. One per line. Header metadata only.

### 4.4 Panorama Import — `.set` File

`service_objects_v{DATE}.set` is the DESTINATION-side counterpart to `ccd_network_groups.set`:

```
# DESTINATION SIDE of PA policy rules.
# Use alongside network_groups_v*.set (source side).

# ===== NG-SVC-APP — APP objects =====
set address host-10_242_82_68 ip-netmask 10.242.82.68/32
set address-group APP_1EPLAT_AZ static [ host-10_242_82_68 ... ]
...
```

Individual host address objects are named `host-{ip_with_underscores}`.

### 4.5 Counts (v20260623)

| Class | Object count |
|-------|-------------|
| APP | 2,725 |
| SVC | 269 |
| DELIVERY | 135 |
| INFRA | 78 |
| NG-SVC super-groups | 6 |
| **Total** | **3,213** |

### 4.6 Generating

```bash
python3 build_service_objects.py --dry-run
python3 build_service_objects.py
# Pipeline stage 3
```

---

## 5. Cloud Services (IPDATASET)

### 5.1 Purpose

Cloud Services EDLs contain the publicly routable IP blocks published by cloud providers and SaaS vendors. They are used to allow or monitor enterprise traffic to these external destinations. Unlike NG/SO, these are entirely external (non-RFC1918) addresses.

### 5.2 Source Registry — `ip_dataset.json`

`build_ipdataset_objects.py` reads filenames from `ip_dataset.json` (in `ipdatasets/`). **No hardcoded filenames.** The registry maps dataset serial numbers to filenames, categories, and metadata. The script processes all 35 registered datasets across three categories: IAAS, SAAS, and PARTNER.

### 5.3 Output Directory Versioning

The output directory is `Net_Object/IPDATASET-v{TODAY}` where TODAY is the **run date** (not the data date). This ensures the catalog's latest-directory sort always finds the current run.

### 5.4 EDL File Naming

```
{PROVIDER}-{SCOPE}.txt

Examples:
  AZURE-CLOUD-GLOBAL.txt     # All Azure global CIDRs
  AZURE-US-ALL.txt           # Azure US regions only
  AZURE-BACKUP-ALL.txt       # Azure Backup service tag
  CROWDSTRIKE-ALL.txt        # CrowdStrike Falcon sensor IPs
  ZSCALER-ALL.txt            # Zscaler proxy egress IPs
```

### 5.5 EDL File Format

```
# AZURE-CLOUD-GLOBAL — generated by build_ipdataset_objects.py v1.1.1
# 33362 CIDRs — 20260623
102.133.0.0/19
102.133.0.192/32
...
```

Mixed prefix lengths (unlike SO which is all /32). Header line includes CIDR count and data date.

### 5.6 Manifest File

`ipdataset_manifest_v{DATE}.csv` catalogs every object produced:

```
OBJECT_NAME,OBJECT_TYPE,CIDR_COUNT,SOURCE
CROWDSTRIKE-ALL,STATIC-GROUP,155,crowdstrike/ALL
AZURE-CLOUD-GLOBAL,EDL,33362,azure/Cloud-Global
...
```

### 5.7 Panorama Import — `.set` File

`ipdataset_objects_v{DATE}.set` contains static address group definitions for any objects small enough to embed directly, and EDL references for the larger ones. Import to the appropriate device group before referencing in policy.

### 5.8 Current Scale (v20260624)

810 EDL files written, 229,630 total CIDRs across all providers.

### 5.9 Generating

```bash
python3 build_ipdataset_objects.py --dry-run
python3 build_ipdataset_objects.py

# Pipeline stage 2.5
```

---

## 6. Geo-Block EDLs

### 6.1 Purpose

Geo-Block EDLs contain all CIDR ranges for a given country per the IP2Location LITE DB1 database. They are used for blanket country-based deny policy at the perimeter.

### 6.2 Source Database

IP2Location LITE DB1 CIDR (`IP2LOCATION-LITE-DB1.CIDR.CSV`) — 381,545 rows. Lives at `IP_Lookup/ipdatasets/`. `build_geo_block_objects.py` discovers it via a candidate path list; the current working path is `base_dir / 'ipdatasets' / 'IP2LOCATION-LITE-DB1.CIDR.CSV'`.

### 6.3 Country Set (v20260623)

13 countries blocked: NG (Nigeria), GH (Ghana), KZ (Kazakhstan), SN (Senegal), PK (Pakistan), UZ (Uzbekistan), KG (Kyrgyzstan), AF (Afghanistan), TJ (Tajikistan), TM (Turkmenistan), RU (Russia), IR (Iran), CN (China).

Special handling: Azure China CIDRs (`GEO-BLOCK-CN` carve-out) — 2 CIDRs removed from the CN block list to avoid breaking Azure China connectivity.

### 6.4 EDL File Naming

```
GEO-BLOCK-{ISO2}.txt     # Per-country
GEO-BLOCK-ALL.txt        # Union of all 13 countries (22,137 CIDRs)
```

### 6.5 EDL File Format

```
# GEO-BLOCK-CN — China
# Generated by build_geo_block_objects.py v1.0.2
# Generated at: 2026-06-24T01:29:41Z
# CIDRs: 6064
# Source: IP2Location LITE DB1 CIDR
1.0.1.0/24
1.0.2.0/23
...
```

### 6.6 Manifest File

`geo_block_manifest_v{DATE}.csv` catalogs the 14 objects:

```
OBJECT_NAME,OBJECT_TYPE,CIDR_COUNT,SOURCE
GEO-BLOCK-NG,EDL,592,geo_block/NG/Nigeria
GEO-BLOCK-CN,EDL,6064,geo_block/CN/China
GEO-BLOCK-ALL,EDL,22137,geo_block/ALL/combined
...
```

### 6.7 Generating

```bash
python3 build_geo_block_objects.py --dry-run
python3 build_geo_block_objects.py

# Pipeline stage 2.6
```

---

## 7. The Object Pipeline

### 7.1 Pipeline Script

`build_object_pipeline.py` is the master orchestrator. It runs all four dataset families in sequence, then optionally bundles outputs and serves the catalog.

```bash
# Full pipeline run
python3 build_object_pipeline.py

# With EDL bundle collection
python3 build_object_pipeline.py --collect

# With catalog web server
python3 build_object_pipeline.py --serve
```

### 7.2 Stage Sequence

| Stage | Script | Output |
|-------|--------|--------|
| 0 | `build_canonical_app_objects.py` | CPC canonical objects → ipam-db import |
| 1 | `build_network_groups.py` | `Net_Group/NG-{DATE}_v{N}/` |
| 2 | Topology report | NG breakdown HTML/CSV |
| 2.5 | `build_ipdataset_objects.py` | `Net_Object/IPDATASET-v{DATE}/` |
| 2.6 | `build_geo_block_objects.py` | `Net_Object/IPDATASET-v{DATE}/` (merged) |
| 3 | `build_service_objects.py` | `Net_Object/SO-{DATE}_v{N}/` |
| 4 | Service objects report | SO breakdown HTML/CSV |
| 5 | `build_edl_catalog.py` | `edl_catalog.html` |
| 6 | `generate_csna_hostgroups.py` | CSNA Stealthwatch export |
| 7 | `collect-edl_bundle.sh` | Only with `--collect` flag |
| 8 | `object-viewer-web-service.sh` | Only with `--serve` flag |

**Silent stage skip:** Stages 2.5 and 2.6 check `os.path.exists(scripts[key])` before running. If either script is missing from disk, the stage silently skips. Verify both scripts are installed if Cloud Services or Geo-Block tabs are empty in the catalog.

### 7.3 The EDL Catalog

`edl_catalog.html` is a self-contained interactive browser for all four families. It is rebuilt by Stage 5 using the existing HTML file as its template — `build_edl_catalog.py` strips the embedded catalog data and injects fresh data, so any fixes to the HTML template propagate automatically to future catalog builds.

**Catalog tabs:**

| Tab | Dataset family | EDL base dir |
|-----|---------------|-------------|
| Network Groups | NG | `Net_Group/NG-{DATE}_v{N}/EDL/` (uppercase) |
| Service Objects | SO | `Net_Object/SO-{DATE}_v{N}/EDL/` (uppercase) |
| Cloud Services | IPDATASET | `Net_Object/IPDATASET-v{DATE}/edl/` (lowercase) |
| Geo-Block | IPDATASET (GEO-BLOCK-*) | `Net_Object/IPDATASET-v{DATE}/edl/` (lowercase) |

The catalog identifies the active dataset by taking the latest-modified directory matching each stem pattern.

**Serving the catalog:**

```bash
./object-viewer-web-service.sh
# or
python3 build_object_pipeline.py --serve
```

Starts a Python HTTP server on port 8080. Browser opens automatically to `http://localhost:8080/edl_catalog.html`.

### 7.4 EDL Bundle Collection

`collect-edl_bundle.sh` copies the current NG, SO, Cloud Services, and Geo-Block EDL files into a single timestamped bundle for delivery or archival.

It reads NG/SO version strings from the HTML comment in `edl_catalog.html` and uses `edl/` (lowercase) for IPDATASET directories and `EDL/` (uppercase) for NG/SO directories. This aligns with the actual directory structure.

---

## 8. Pipeline Run Checklist

Use this sequence for a clean daily pipeline run:

```bash
cd ~/Documents/IP_Lookup

# 1. Dry run to verify inputs
python3 build_object_pipeline.py --dry-run

# 2. Full pipeline
python3 build_object_pipeline.py

# 3. Verify catalog counts
#    NG: ~727 EDL files
#    SO: ~3,213 EDL files
#    Cloud Services: ~810 EDL files
#    Geo-Block: 14 EDL files (13 countries + ALL)

# 4. Serve and inspect
./object-viewer-web-service.sh

# 5. Collect bundle (when ready for delivery)
python3 build_object_pipeline.py --collect
```

**If Cloud Services or Geo-Block tabs are empty:** verify `build_ipdataset_objects.py` and `build_geo_block_objects.py` are present in the base IP_Lookup directory. The pipeline silently skips stages when the scripts aren't found on disk.

---

## 9. Script Version Reference

| Script | Current version | Role |
|--------|----------------|------|
| `build_network_groups.py` | v1.8.4 | NG generation |
| `build_service_objects.py` | v1.0.5 | SO generation |
| `build_ipdataset_objects.py` | v1.1.1 | Cloud Services EDLs |
| `build_geo_block_objects.py` | v1.0.2 | Geo-Block EDLs |
| `build_edl_catalog.py` | — | Catalog HTML assembly |
| `build_object_pipeline.py` | v1.6.1 | Master orchestrator |
| `object-viewer-web-service.sh` | v1.0.0 | HTTP catalog server |
| `collect-edl_bundle.sh` | — | Bundle collector |

---

## 10. Key Architectural Rules

**IPAM-first:** No subnet enters any NG or SO object without a verified `CANONICAL_LOCATION` in `location_master`. The pipeline inherits the IPAM hard gate.

**No hardcoded filenames in IPDATASET:** `build_ipdataset_objects.py` reads all filenames from `ip_dataset.json`. Adding a new provider dataset to the registry is sufficient — no script changes needed.

**Run date vs. data date:** IPDATASET output directories use the run date (`IPDATASET-v{TODAY}`), not the dataset's data date. This ensures the catalog's latest-directory sort always resolves to the current run.

**Case sensitivity matters:** NG/SO EDL directories are `EDL/` (uppercase). IPDATASET EDL directories are `edl/` (lowercase). The catalog JavaScript, `collect-edl_bundle.sh`, and all path construction in the scripts must respect this distinction.

**Template propagation:** Because `build_edl_catalog.py` uses the existing `edl_catalog.html` as its template, fixing a bug in the HTML (JavaScript logic, CSS, etc.) automatically propagates to all subsequent catalog rebuilds. There is no separate template file to keep in sync.

**Geo-Block DB path:** The IP2Location LITE database must be present at `IP_Lookup/ipdatasets/IP2LOCATION-LITE-DB1.CIDR.CSV`. The script searches a candidate path list and fails cleanly if no candidate is found.
