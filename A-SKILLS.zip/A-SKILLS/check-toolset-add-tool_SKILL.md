---
name: check-toolset-add-tool
description: >
  Process for adding a new script's health check to check_toolset.py, or for
  auditing/fixing an existing entry. Use this skill whenever a CCD Platform
  script needs to be wired into check_toolset.py's TESTS list, whenever a
  check_toolset.py test is failing and the cause isn't obvious, or whenever
  someone asks "is this script covered by check_toolset" / "add this to
  check_toolset" / "why is this test failing". This skill is NON-NEGOTIABLE
  before adding any TESTS row — every step in this file was learned from a
  real bug this exact shortcut-taking caused (a false PASS, a crash, a
  timeout, or a misleading next-step). Do not assume a script's flags from
  its docstring or from what a similar script supports; verify.
---

# check_toolset.py — Adding and Auditing Tool Coverage

## The Problem This Skill Solves

check_toolset.py's whole value is that a green run means the platform's tools
actually work — not "probably work" or "worked when someone last looked."
Every shortcut below has actually happened and actually produced a false
signal in this exact codebase:

- **Assumed `--dry-run` was a complete, safe invocation.** `generate_fw_rule_report.py --dry-run`
  alone failed with a usage error — `--log` is required unless `--check` or
  `--splunk` is passed. `--dry-run` was never a no-op flag for this script.
- **Assumed `--dry-run` was fast.** `generate_csna_hostgroups.py --dry-run`
  timed out at the default 120s — confirmed at 136.9s on a direct timed run.
  It skips only the final file write, not the actual computation, so it's
  inherently a "full run minus the write," not a smoke test.
- **Assumed the safe flag would run cleanly because the script "looked" fine.**
  Switching to `--check` for `generate_fw_rule_report.py` surfaced a real
  `NameError` in `check_files()` — an `INFO` marker referenced but never
  defined, crashing every time an optional file was legitimately absent.
- **Assumed a missing script would fail loudly.** It didn't — `subprocess.run()`
  launches `python3` (always found), and `python3` failing to open a missing
  target script produces stderr text, not a `FileNotFoundError` in the parent.
  `--help` tests that treated "any output" as success reported a **false PASS**
  for scripts that didn't even exist on disk.
- **Assumed a version string comparison was safe as an exact/prefix match.**
  Both `check_toolset.py` and `collect_ccd_platform.py` had this bug
  independently: a stored floor like `v3.15` stopped matching the moment the
  real script advanced to `v3.16.x`, because `3.16.5` doesn't start with
  `3.15` even though it's clearly newer.

None of these were hypothetical. Follow every step below, in order, for every
new entry.

## Step-by-Step: Adding a New Script

### 1. Find the real version mechanism — don't guess from the docstring

```bash
grep -n "SCRIPT_VERSION\|^__version__\|VERSION = \|action='version'\|add_argument.*'--version'" script.py
```

Confirm there's an actual `--version` (or `-V`) flag wired to `action='version'`
or an explicit `if args.version: print(...); sys.exit(0)` — and that it exits
**before** any real work, not after. A script that prints its version banner
as the first line of a normal run is not the same as a script with a safe,
standalone `--version` flag.

### 2. Find every candidate safe flag — don't assume `--dry-run` is one of them

```bash
grep -n "add_argument" script.py
```

List every flag. Common safe candidates: `--version`, `--help`, `--dry-run`,
`--check`. **Do not assume all of these exist just because similar scripts in
this platform have them.** Some scripts have `--dry-run` with no `--version`
(`generate_ipam_hierarchy_report.py`). Some have neither
(`generate_ipam_map.py`, `generate_partner_map.py` — `--help` is the only safe
option). Some have a `--check` mode that's actually the correct no-op, with
`--dry-run` requiring other real arguments (`generate_fw_rule_report.py`).

### 3. For any flag that isn't `--version`/`--help`, confirm it actually skips writes

```bash
grep -n "dry_run\|args.check" script.py
```

Read the surrounding code. Confirm the write step is gated behind a clean
`if args.dry_run: print(...); return` (or equivalent) **before** any
`os.makedirs`/`open(..., 'w')`/`shutil.copy`. Don't infer this from a flag's
name or help text — read the actual branch.

### 4. Actually run it — against the real file, not a description of it

```bash
python3 script.py --version
python3 script.py <safe-flag-combo>
echo "exit code: $?"
```

This is the step every bug above was caught at. If the script needs real
input data you don't have, that's fine and expected (note it, don't force
it) — but you still need to see the *actual* failure mode to know whether
it's "missing test fixture" (harmless, will work on real data) or "a real
bug in the script" (needs fixing, or the test needs a different flag).

### 5. Time it

```bash
python3 -c "
import subprocess, time
t0 = time.time()
r = subprocess.run(['python3', 'script.py', '--your-flag'], capture_output=True, text=True, timeout=180)
print('elapsed:', time.time() - t0, 'returncode:', r.returncode)
"
```

Default timeout in `run_test()` is 120s. If real elapsed time is anywhere
close to that (say, over ~60-90s), add an entry to `TIMEOUT_OVERRIDE` (keyed
by the test's `description` string, same lookup pattern as `FAST_SKIP`) with
real headroom — production-scale data will likely be slower than whatever
you tested against, not faster. If it's slow at all, also add it to
`FAST_SKIP` so `--fast` runs stay fast.

### 6. Determine the floor version from what you actually saw in step 4

Use the real reported version, not a guess. For a fully-specified floor
(`'1.3'`, `'v3.16'`), the floor-comparison logic in `run_test()` does a
numeric `actual >= floor` check automatically — you don't need to keep
bumping it by hand as the script's version legitimately advances. Only use
an open trailing-dot wildcard (`'1.'`, `'v2.'`) if you deliberately want a
major-version jump to require re-review rather than pass silently forever.

### 7. Add the TESTS row(s) in the right group, with a comment explaining what you verified

```python
('generate', 'your_script.py',
 ['--version'],
 '1.3', 'your_script version'),
```

If you added anything to `FAST_SKIP` or `TIMEOUT_OVERRIDE`, do it in the same
edit. Write a comment on the new row(s) stating what you actually confirmed
(clean exit, genuinely skips writes, real timing) — not just "added test."

### 8. Version-bump check_toolset.py itself and add a changelog entry

Per the CCD versioning discipline: PATCH for a pure addition with no other
behavior change, MINOR if you also changed comparison logic or added a new
mechanism. Changelog entry states what was verified, not just what was added
— match the style already in the file's own history (e.g. the v1.7.0 entry).

### 9. Re-run against the real file to confirm the new row actually passes

Don't consider this done until you've seen the specific new test row print
`✓` in a real run, not just confirmed the file compiles.

### 10. Confirm `collect_ccd_platform.py` picks it up

As of `collect_ccd_platform.py` v1.1.0, its `SCRIPTS` list is derived
directly from `check_toolset.py`'s `TESTS` (see
`_derive_scripts_from_check_toolset()`). Adding a script to `TESTS` makes it
appear in `collect_ccd_platform.py`'s collection automatically — no second
edit needed. If you ever find yourself editing `collect_ccd_platform.py`'s
`SCRIPTS` list by hand for a script that's also tested in `check_toolset.py`,
stop — that's the exact two-lists-drifting-apart problem this derivation
exists to prevent.

## Auditing an Existing Entry (when a test is failing and the cause isn't obvious)

Work through Steps 1-5 above as if the script were new. A failing test is
either:

- **A real regression in the target script** (fix the script, keep the test
  — see the `generate_fw_rule_report.py` `INFO` NameError example above), or
- **A wrong assumption baked into the test itself** (fix the test — see the
  `--dry-run` vs `--check` example above), or
- **A genuinely slow operation hitting the default timeout** (add a
  `TIMEOUT_OVERRIDE` entry, don't just delete the test), or
- **A missing test fixture specific to the current environment** (note it
  explicitly, don't treat it as broken)

Never "fix" a failing test by loosening its expected-value check or removing
it outright without figuring out which of the four categories above it is.

## Retiring a Script's Test

If a script is confirmed EOL/legacy (ask the person directly — don't infer
this from a script simply looking old), remove its `TESTS` row entirely
rather than leaving it as a permanent expected failure. Add a changelog entry
naming the script and stating it was confirmed retired. Check whether it's
also referenced elsewhere (`FAST_SKIP`, `TIMEOUT_OVERRIDE`, `_EXPECTED`) and
remove those too. See the v1.6.2 (`build_all_ip_networks.py`,
`build_retail_site_codes.py`) and v1.6.6 (`update_asi.py`) changelog entries
for the precedent.
