---
name: nms-ndm-rebuild
description: CCD Platform NMS/host ingest pipeline — complete ingest cycle, script versions, run sequence, classification layers, and confirmed bugs fixed. Use whenever asked about build_nms_db.py, commit_nms.py, preprocess_p1/p2, ent_network_device_master, ent_iot_device_master, nms_db.sqlite, or the full ingest run order. Read before modifying any of these scripts or proposing a run order.
sources: [chat]
aliases: [build_nms_db, NDM, ent_network_device_master, diff_nms_export, preprocess_p1, preprocess_p2, commit_nms, ingest_cycle]
---

# CCD Platform — Full Ingest Cycle

**Last confirmed:** 2026-08-23 (Yggdrasil, full cycle completed)

---

## Current Script Versions

| Script | Version | Notes |
|--------|---------|-------|
| `build_nms_db.py` | v2.5.31 | 4-tier device classification |
| `commit_nms.py` | v1.0.6 | diff + review + import + state-aware next step |
| `preprocess_p1.py` | v2.12.4 | IPAM candidate pre-filter |
| `preprocess_p2.py` | v1.6.4 | SUGGESTED_MASTER priority, PROXY marker tightened |
| `update_app.py` | v1.19 | ADL date-based sort fix |
| `update_infrastructure.py` | v1.2.6 | old_ver fix, correct next step |
| `update_platform.py` | v1.2.6 | old_ver fix, Ingest cycle complete |
| `update_network.py` | v1.7 | Before→After output |
| `update_ipam.py` | v1.17 | Before→After output |
| `ipam-db.py` | v3.36.0 | CSNA + FW rule report removed from downstream chain |
| `ccd_host_enrichment.py` | v1.1.0 | ADL date-based sort fix (shared library) |

---

## Complete Ingest Cycle

### Daily (scheduled)
```bash
python3 build_IP_Network_Egress_FW_topology.py
```
Produces `unknown_ip_subnets_v{date}.csv` consumed by `preprocess_p1.py`.

### On-demand (when NMS source data changes)

#### Step 1 — mgmt_ip_index (only when Netbrain sources change)
```bash
python3 build_mgmt_ip_index.py --base . --netbrain ./IP_Datasets_Raw/NMS-Source --out-dir ./ipam-db
python3 ipam-db.py --import ./ipam-db/mgmt_ip_index_v{date}_built.csv --type mgmt_ip_index
```

#### Step 2 — NMS build + commit
```bash
python3 build_nms_db.py
python3 commit_nms.py
```
`commit_nms.py` reads `ipam-db.json` and prints the correct next step based on pipeline state.

#### Step 3 — Preprocess Pass 1
```bash
python3 preprocess_p1.py
```
Outputs two sections:

**RUN NOW** (automated, no review needed):
```bash
python3 update_ipam.py       # if ipam_candidates > 0
python3 build_nms_db.py      # if IPAM was updated
python3 commit_nms.py
```

**REVIEW REQUIRED** (human review before running):
```bash
python3 update_app.py        # review p1_ehm_enhancement_{date}.csv first
python3 update_infrastructure.py  # review p1_infra_enhancement_{date}.csv first
python3 update_platform.py   # review p1_platform_enhancement_{date}.csv first
```

#### Step 4 — Preprocess Pass 2
```bash
python3 preprocess_p2.py
```
Outputs RUN NOW section showing only non-zero candidates:
```bash
python3 update_app.py        # app_candidates
python3 update_infrastructure.py  # infra_candidates
python3 update_platform.py   # platform_candidates (last — prints "Ingest cycle complete")
```

---

## Terminal Output Pattern (all scripts)

Every script follows the same pattern — enforced by ccd-versioning-discipline Rule 7:
```
──────────────────────────────────────────────────
  Before  :  <prior state>
  After   :  <new state>
──────────────────────────────────────────────────

  Next step: python3 <next_script>
```
Explanations belong in `--help` and `--verbose`. Operational output is Before → After → Next step only.

---

## NMS Pipeline Architecture

### Source Priority (highest to lowest)
`FW_INTERFACE > FTC > F5_CONFIG > NETBRAIN > NAUTOBOT > FORESCOUT > CMDB > LEGACY_NMS > HOST_MASTER`

### Device Classification — 4 Tiers
Applied in order during `reconcile()` in `build_nms_db.py`:

1. **Source-reported** — device_type from FTC/Netbrain/Nautobot/ForeScout
2. **Vendor map** — `vendor_device_class_map_v{date}.csv` in `ipam-db/` (72 entries, substring match)
3. **OUI lookup** — `maclookup.app/api/v2/macs/{oui}` for blank/Unknown Vendor only (~285 devices), cached per OUI prefix
4. **Hostname pattern** — `HOSTNAME_DEVICE_TYPE_MAP` in script (substring match: `-tora`, `-es-`, `aci-bleaf`, etc.)

**Result (2026-08-23):** UNCLASSIFIED dropped from 5,496 → 21 rows in `nms_unclassified_v{date}.csv`

### ForeScout Filter (v2.5.28)
`fs-mac-{mac}` synthetic hostnames are no longer created. ForeScout rows with no DNS name are skipped — they have no real device identity and caused BLOCKED diffs when their MACs hit SHARED_MAC_EXCLUDED.

---

## commit_nms.py Diff Gate

**Exit states:**
- `[BLOCKED]` — ACTIVE devices absent from new export with no OOS entry. Prints full list of blocked hostnames. Do NOT import.
- `[REVIEW REQUIRED]` — location/type changes found. Auto-classifies:
  - **ACCEPTABLE** (auto-approve): Store→Corporate, same-city reclassification, canonical name fixes
  - **REVIEW**: different city or state — shown with count and details
- `[PASS]` — clean, imports automatically

**`--skip-diff`** — bypasses diff gate. Use when blocked devices are confirmed NOT IN DB (old pipeline residue, not real data loss).

**State-aware next step:** reads `ipam-db.json` after import. If stage2_required has uncommitted stems → prints `update_*.py --enrich-only` commands first.

---

## preprocess_p2.py Classifier

`classify_device()` priority order (v1.6.4):
1. **SUGGESTED_MASTER field** — checked first, always wins:
   - `delivery_infrastructure` → infrastructure
   - `delivery_platform` → platform
   - `ent_network_device_master` → network
   - `ent_host_master` → application
2. **Marker matching** — only fires when SUGGESTED_MASTER is blank

**NETWORK_MARKERS** (tightened v1.6.3): `BLUECOAT`, `NETWORK CONSOLE`, `F5-VIP`, `FIREWALL`, `PROXY APPLIANCE`, `WEB PROXY`, `FORWARD PROXY`
- Bare `PROXY` removed — matched "AAD Application proxy" (Windows app, not a proxy device)
- `FIREWALL` in APP_NAMES on a Windows server routes to application if `SUGGESTED_MASTER=ent_host_master`

**Confirmed real bugs fixed (2026-08-23):**
- 40 Windows servers (`mvmt*`/`wvmt*`) misrouted to network_candidates because `APP_NAMES: AAD Application proxy` matched `PROXY` marker
- 4 Palo Alto Panorama servers misrouted because `APP_NAMES: Palo Alto Networks Cloud Firewall` matched `FIREWALL` marker with `SUGGESTED_MASTER=ent_host_master`

---

## ADL Auto-Discovery Fix

`find_latest_adl()` in `ccd_host_enrichment.py` v1.1.0 and `update_app.py` v1.19:
- Sort by date in filename (`M-D-YYYY` or `MM-DD-YYYY`), not mtime
- Handles single-digit month/day (`APP_DATA-8-7`, not `APP_DATA-08-07`)
- mtime is unreliable — confirmed real: July 15 ADL selected over August 7 because July 15 had later mtime

---

## ipam-db.py Downstream Chain — Removed Items

Removed from all automatic next-step prompts (v3.35.0, v3.36.0):
- `generate_csna_hostgroups.py` — downstream consumer, runs on its own cadence
- `generate_fw_rule_report.py` — requires `--log` with FW log files, not a rebuild step
- Self-referential `app_subnet_index` re-import from `ent_host_master` chain

---

## IPAM Candidate Pre-Filter (preprocess_p1.py v2.12.4)

`check_ipam_coverage()` now pre-filters before generating candidates:
1. Link-local (`169.254.x.x`) — skip
2. Loopback (`127.x.x.x`) — skip
3. `/24 already in all_IP_networks` — LPM check on network address

**Result:** Candidates dropped from 138 → 24 on first run after fix (114 were DUPLICATE, already in IPAM from a different host IP on the same multi-homed server).

---

## Known Remaining Gaps (2026-08-23)

- CMDB source on July 11 data
- Netbrain collection gap: 139 ROUTER + 78 FIREWALL missing
- `nms_lm_crosscheck_v20260823.csv`: 992 MEDIUM gaps not yet imported
- UNCLASSIFIED: 21 rows in `nms_unclassified_v20260823.csv` for review
- `build_app_subnet_index.py` RISK_TIER: EDR, AppEx, T1, T2 not in RISK_PRIORITY map — resolved to 'No Risk'
- `update_network.py` still writes directly to registered NDM CSV bypassing nms_db.sqlite — architectural gap, deferred pending preprocess_p2 classifier fix (now correct, network_candidates = 0)

---

## RMAC Stable State (Yggdrasil v20260823, post-cycle)

| Metric | Value |
|--------|-------|
| ACTIVE | 24,554 |
| ADDED | 51 |
| MOVED | 1 |
| CHANGED | 69 |
| OUT-of-Service retained | 12,967 |
| UNCLASSIFIED (active) | 21 |
| REINTRODUCED per run | 0 |

