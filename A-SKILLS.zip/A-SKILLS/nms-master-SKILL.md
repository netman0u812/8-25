---
name: nms-master
description: >
  CCD Platform NMS (Network Management System) device database — CVS Health
  Information Security. Use for any task involving build_nms_db.py, the
  ent_network_device_master, mgmt_ip_index, ent_iot_device_master, or
  nms_db.sqlite. Covers the database-first architecture that replaces
  build_network_device_master.py + build_mgmt_ip_index.py, data source
  priority, device taxonomy, IoT separation, and LM cross-check. Trigger on:
  "NMS master", "build_nms_db", "network device master", "mgmt_ip_index",
  "ent_iot_device_master", "device taxonomy", "IoT devices", "AP location",
  "Nautobot", "FTC Solarwinds", "CMDB inventory", "NMS-Source",
  "Flow_Data", "nms_db.sqlite", "device type", "SWITCH_NEXUS",
  "FIREWALL_FTD", or any question about network device inventory sources.
---

# CCD NMS Device Database — build_nms_db.py

## Architecture (v1.0.6+)

Database-first design. Each source loads into its own raw table; a
reconciliation layer produces the authoritative master. Replaces
build_network_device_master.py (v3.36.0) and build_mgmt_ip_index.py (v1.2.2).

```
nms_db.sqlite
├── raw_fw_interface   -- FW Interface Inventory (IPAM-enriched, highest confidence)
├── raw_netbrain       -- Netbrain split-file format (*_ip_report.csv)
├── raw_nautobot       -- Nautobot/IP_Flow (devices-*.csv)
├── raw_ftc            -- FTC/Solarwinds Network Device Report
├── raw_cmdb           -- CMDB CI network appliances (lowest confidence)
├── nms_master         -- reconciled network infra, one row per device
└── iot_master         -- IoT/facility devices (APs, phones, PDUs, sensors)
```

## Source Priority

**Management IP:** FW_INTERFACE > FTC > NETBRAIN > NAUTOBOT > CMDB

**Location:** IPAM LPM > FW_INTERFACE > FTC > NAUTOBOT > NETBRAIN > CMDB

**Critical design constraint:** F5 and FW devices are specialty sources —
present in FW_INTERFACE and F5 datasets but NOT in Nautobot, FTC, or CMDB.
A device missing from a source ≠ decommissioned. Retail devices are absent
from Nautobot/FTC by design.

## Source File Locations (confirmed real paths on Yggdrasil)

| Source | Directory | Pattern |
|---|---|---|
| Netbrain | `IP_Datasets_Raw/NMS-Source/` | `*_ip_report.csv` (or zip) |
| Nautobot | `IP_Datasets_Raw/Flow_Data-*/` | `devices-*.csv` (or zip) — latest dated dir |
| FTC | `IP_Datasets_Raw/FTC_Network_Audit_Reports/` | `*Network*Device*.xlsx` |
| CMDB | `IP_Datasets_Raw/CMDB-Master/` | `CMDB_Master_Inventory*.csv` |
| FW Interface | `ipam-db/` | `ent-ipdataset-FW-INTERFACE-INVENTORY-v*.csv` |
| LM | `ipam-db/` | `location_master_v*.csv` |

Zips are auto-extracted by the script on first run. Subsequent runs skip
extraction since CSVs already exist.

## Netbrain New Split-File Format (v3.36.0+)

Netbrain changed from a single `site_ip_report_*.csv` to 6 per-device-class
files. Device class is derived from filename:

| File | DEVICE_CLASS |
|---|---|
| `router_ip_report.csv` | ROUTER |
| `switch_ip_report.csv` | SWITCH |
| `fw_ip_report.csv` | FIREWALL |
| `f5_ip_report.csv` | F5 |
| `wlc_ip_report.csv` | WLC |
| `ise_wan_opt_ip_report.csv` | ISE/WAN-OPT |

New schema: `_device, intf, description, ip_addr, shutdown, snmp_location`
Old schema (`Hostname, Site, Device Type, IPv4 Address, Live Status...`) still
supported for compatibility. `Site` field was dropped — was bogus/unreliable.

## Standardized Device Type Taxonomy

Two-axis model: DEVICE_CLASS (what it is) + FW_USE_CASE (firewall role only).

**Network Infrastructure (in nms_master):**
SWITCH, SWITCH_L3, SWITCH_NEXUS, SWITCH_ACI, ROUTER, ROUTER_SDWAN,
ROUTER_VOICE, FIREWALL_FTD, FIREWALL_ASA, FIREWALL_PA, FIREWALL_CP,
FIREWALL_SOURCEFIRE, FIREWALL, LOAD_BALANCER, WLC, AP, CELLULAR_AP,
ISE, DDI, ACI_MGMT, FMC, OOB_MGMT, PACKET_BROKER, PROXY, NTP, WAAS

**FW Use Cases (FIREWALL_* classes only):**
Internal, Perimeter, DMZ, B2B, VPN, PCI, Cloud, SDWAN

**IoT/Facility (in iot_master, NOT in nms_master):**
IP_PHONE, PDU, UPS, SENSOR, SURVEILLANCE, PATCH_PANEL, MODULE,
POWER_SUPPLY, VOIP_GATEWAY, VOIP_SERVER, CELLULAR_AP

`normalize_device_type(raw, source)` maps every source's raw strings to
these standard classes. Source-specific maps: NAUTOBOT, FTC, NDM/NETBRAIN,
FW_INTERFACE. Keyword fallback for anything not in the exact maps.

## IoT Dataset

Nautobot has 100% location + site_code coverage for ALL IoT devices.
The `iot_master` table is the authoritative source for:
- **AP presence by site** — 13,180 APs across 350 retail/facility sites
  (the ONLY source with this data — retail is absent from all other NMS sources)
- **Environmental sensors** — 2,899 across 39 sites
- **Phone/PDU/UPS** inventory per facility

Key value: 350 AP sites ↔ 322 IoT site_codes not in LM = candidate LM
additions for retail/facility locations the LM doesn't yet cover.

## Outputs (per run)

| File | Content |
|---|---|
| `ent_network_device_master_v{date}.csv` | Network infra, standardized classes |
| `mgmt_ip_index_v{date}_built.csv` | Management IPs, IPAM-enriched |
| `ent_iot_device_master_v{date}.csv` | IoT/facility by site and class |
| `nms_lm_crosscheck_v{date}.csv` | Advisory: LM gaps from NMS data |
| `nms_db.sqlite` | Full raw + reconciled database |

## LM Cross-Check (crosscheck_lm())

Three advisory checks — not blocking:
1. **MEDIUM**: NMS device with `canonical_loc` not in Location Master
2. **LOW**: Nautobot IoT `site_code` not in LM (→ candidate new LM entries)
3. **LOW**: LM network-class site (DataCenter/COLO/Office) with no NMS devices

## Run Command

No flags required — auto-discovers all sources:

```
python3 build_nms_db.py
```

Explicit override for any path:
```
python3 build_nms_db.py \
  --base-dir ~/Documents/IP_Lookup \
  --ipam-dir ipam-db/ \
  --db nms-db/nms_db.sqlite \
  --out-dir processed_outputs/
```

## Known Gaps (as of v1.0.6, 2026-08-22)

1. **Legacy NMS files not yet loaded** — `nms_device_index*.csv` and
   `nms_subnets*.csv` from `IP_Datasets_Raw/NMS-Source/` (May 1 data)
   are not yet consumed. These contained ~12,000 additional device rows
   in the old NDM. A `load_legacy_nms()` function is pending.

2. **IoT from non-Nautobot sources** — FTC has IoT devices (phones, APs)
   but they're currently filtered out. Only Nautobot IoT is loaded.

3. **build_network_device_master.py not yet retired** — v3.36.0 is the
   current deployed version. build_nms_db.py output should be validated
   against it before full retirement.

4. **`ent_iot_device_master` stem not yet in ipam-db.py MANAGED_STEMS** —
   need to add to ipam-db.py v3.33.0+ before it can be --imported.

## Real Production Numbers (2026-08-22 test run)

- 13,901 network infra devices in nms_master (77% HIGH confidence location)
- 28,821 IoT devices in iot_master (100% location coverage from Nautobot)
- 5,399 devices confirmed by 2+ sources (38% cross-validated)
- 9,634 HIGH confidence locations via IPAM LPM
- 322 LOW advisory items in LM cross-check
